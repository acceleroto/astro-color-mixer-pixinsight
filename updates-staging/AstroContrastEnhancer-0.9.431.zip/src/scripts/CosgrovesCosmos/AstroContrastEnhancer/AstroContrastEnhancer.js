#engine v8

#feature-id    Cosgrove's Cosmos > Astro Contrast Enhancer
#feature-info  Astro Contrast Enhancer v0.9.431. Hide responsive global detail crop overlays.
#feature-icon  @script_icons_dir/AstroContrastEnhancer/ace_control_sliders_24.png

/*
 * Astro Contrast Enhancer for PixInsight
 * Developed by Patrick A. Cosgrove for Cosgrove's Cosmos.
 * Copyright 2026 Patrick A. Cosgrove. All rights reserved.
 *
 * This script provides protected Texture, Clarity, Dehaze, and lasso-based
 * local contrast control for stretched astrophotography images in PixInsight.
 */

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/KeyCodes.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/StdCursor.jsh>

var ACE_VERSION = "v0.9.431";
var ACE_COPYRIGHT_NOTICE = "Developed by Patrick A. Cosgrove for Cosgrove's Cosmos - Copyright \u00A9 2026 Patrick A. Cosgrove. All rights reserved.";
var ACE_FOOTER_NOTICE = "Developed by Patrick A. Cosgrove for Cosgrove's Cosmos - \u00A9 2026";
var ACE_MAX_PREVIEW_ZOOM = 16.0;
var ACE_DEBUG_CONTROLS_ENABLED = false;
var ACE_TEXTURE_COMPARISON_CONTROLS_ENABLED = false;
var ACE_PERF_BUDGET_DRAFT_MS = 1000;
var ACE_PERF_BUDGET_DETAIL_MS = 2000;
var ACE_PERF_BUDGET_RESET_MS = 500;
var ACE_PERF_AUDIT_MAX_ROIS = 3;
var ACE_DEVELOPMENT_CONSOLE_LOGS_ENABLED = false;
var ACE_TOOL_NAME = "Astro Contrast Enhancer";
var ACE_SUBTITLE = "Multi-scale local contrast control for astrophotography";
var ACE_HOST_IS_WINDOWS = aceHostIsWindows();

var ACE_DISPLAY_MIN_WIDTH = 1360;
var ACE_DISPLAY_MIN_HEIGHT = 780;
var ACE_ACM_COMPACT_WINDOWS_MAX_WIDTH = 1880;
var ACE_ACM_COMPACT_WINDOWS_MAX_HEIGHT = 920;
var ACE_ACM_COMPACT_WINDOWS_MARGIN_WIDTH = 48;
var ACE_ACM_COMPACT_WINDOWS_MARGIN_HEIGHT = 72;
var ACE_DISPLAY_MARGIN_WIDTH = 80;
var ACE_DISPLAY_MARGIN_HEIGHT = 60;
var ACE_MIN_DIALOG_WIDTH = ACE_DISPLAY_MIN_WIDTH;
var ACE_MIN_DIALOG_HEIGHT = ACE_DISPLAY_MIN_HEIGHT;
var ACE_SETTINGS_PREFIX = "CosgrovesCosmos/AstroContrastEnhancer";
var ACE_SETTING_WINDOW_WIDTH = ACE_SETTINGS_PREFIX + "/windowWidth";
var ACE_SETTING_WINDOW_HEIGHT = ACE_SETTINGS_PREFIX + "/windowHeight";
var ACE_SETTING_WINDOW_X = ACE_SETTINGS_PREFIX + "/windowX";
var ACE_SETTING_WINDOW_Y = ACE_SETTINGS_PREFIX + "/windowY";
var ACE_SETTING_MARGINAL_WARNING_DISMISSED = ACE_SETTINGS_PREFIX + "/marginalWorkspaceWarningDismissed";
var ACE_LEFT_PANEL_WIDTH = 296;
var ACE_RIGHT_PANEL_WIDTH = 246;
var ACE_LABEL_WIDTH = 96;
var ACE_VALUE_WIDTH = 40;
var ACE_PANEL_MARGIN = 6;
var ACE_SECTION_SPACING = 4;
var ACE_ADVANCED_PANEL_MARGIN = 6;
var ACE_ADVANCED_SECTION_SPACING = 4;
var ACE_HEADER_MARGIN = 8;
var ACE_BUTTON_MIN_HEIGHT = 26;
var ACE_SMALL_BUTTON_WIDTH = 68;
var ACE_HEADER_HEIGHT = ACE_HOST_IS_WINDOWS ? 104 : 92;
var ACE_TOOLBAR_HEIGHT = ACE_HOST_IS_WINDOWS ? 30 : 28;
var ACE_PREVIEW_STATUS_HEIGHT = 0;
var ACE_FOOTER_HEIGHT = ACE_HOST_IS_WINDOWS ? 34 : 26;
var ACE_FONT_BODY = ACE_HOST_IS_WINDOWS ? 18 : 13;
var ACE_FONT_BOLD = ACE_HOST_IS_WINDOWS ? 19 : 14;
var ACE_FONT_SECTION = ACE_HOST_IS_WINDOWS ? 21 : 15;
var ACE_FONT_BUTTON = ACE_HOST_IS_WINDOWS ? 16 : 12;
var ACE_FONT_SMALL = ACE_HOST_IS_WINDOWS ? 16 : 12;
var ACE_FONT_TITLE = 25;
var ACE_FONT_HINT = ACE_HOST_IS_WINDOWS ? 15 : 11;
var ACE_FONT_HEADER_SUBTITLE = 12;
var ACE_FONT_OVERLAY_TITLE = 13;
var ACE_FONT_OVERLAY_BODY = 11;
var ACE_SLIDER_MIN = -100;
var ACE_SLIDER_MAX = 100;
var ACE_TEXTURE_CLARITY_SLIDER_MIN = -150;
var ACE_TEXTURE_CLARITY_SLIDER_MAX = 150;
var ACE_TEXTURE_SLIDER_MIN = -100;
var ACE_TEXTURE_SLIDER_MAX = 100;
var ACE_CLARITY_SLIDER_MAX = 150;
var ACE_DEHAZE_SLIDER_MIN = -100;
var ACE_DEHAZE_SLIDER_MAX = 100;
var ACE_ADVANCED_MIN = 50;
var ACE_ADVANCED_MAX = 150;
var DEFAULT_TEXTURE_SCALE = 100;
var DEFAULT_CLARITY_SCALE = 100;
var ACE_CLARITY_RESPONSE_LIGHT = "light";
var ACE_CLARITY_RESPONSE_BALANCED = "balanced";
var ACE_CLARITY_RESPONSE_STRONG = "strong";
var DEFAULT_CLARITY_RESPONSE = ACE_CLARITY_RESPONSE_BALANCED;
var DEFAULT_DEHAZE_VEIL_SIZE = 100;
var DEFAULT_DEHAZE_VEIL_STRENGTH = 100;
var DEFAULT_DEHAZE_HIGHLIGHT_PROTECT = 100;
var DEFAULT_DEHAZE_COMPACT_PROTECT = 100;
var DEFAULT_DEHAZE_VEIL_CONFIDENCE = 100;
var DEFAULT_DEHAZE_COLOR_RESTORE = 100;
var DEFAULT_DEHAZE_HAZE_ADD_BACK = 100;
var DEFAULT_SKY_PROTECTION_STRENGTH = 100;
var DEFAULT_DARK_PATCH_GUARD_STRENGTH = 100;
var DEFAULT_STAR_PROTECTION_STRENGTH = 100;
var DEFAULT_HALO_PROTECTION_STRENGTH = 100;
var DEFAULT_PROTECTION_SOFTNESS = 100;
var DEFAULT_OVERALL_PROTECTION_STRENGTH = 100;
var ACE_FEATHER_MIN = 0;
var ACE_FEATHER_MAX = 150;
var ACE_FEATHER_DEFAULT = 75;
var ACE_LASSO_MIN_POINT_SPACING = 24;
var ACE_LASSO_MAX_POINTS = 80;
var ACE_LASSO_MIN_AREA = 144;
var ACE_LASSO_MIN_SPAN = 10;
var ACE_LASSO_FULLRES_MAX_POINTS = 48;
var ACE_LASSO_FULLRES_MIN_SPACING = 18;
var ACE_LASSO_MOVE_HIT_TOLERANCE = 4;
var ACE_LASSO_AUTO_FOCUS_MAX_ZOOM = 3.0;
var ACE_LASSO_AUTO_FOCUS_MARGIN = 0.20;
var ACE_MAX_UNDO_STEPS = 5;
var ACE_PROTECTED_OVERLAY_STRENGTH = 0.30;
var ACE_PROTECTED_HATCH_STRENGTH = 0.20;
var ACE_PROTECTED_HATCH_SPACING = 14;
var ACE_PROTECTED_HATCH_WIDTH = 1;
var ACE_FEATHER_OVERLAY_STRENGTH = 0.24;
var ACE_DRAFT_MAX_EDGE = 1500;
var ACE_LOCAL_DRAFT_DISPLAY_GAIN_MIN = 1.0;
var ACE_LOCAL_DRAFT_DISPLAY_GAIN_MAX = 3.4;
var ACE_LOCAL_DRAFT_DISPLAY_GAIN_SCALE = 0.72;
var ACE_LOCAL_DRAFT_SOURCE_PROXY_MAX_EDGE = 760;
var ACE_INTERACTIVE_ADVANCED_MAP_MAX_EDGE = 240;
var ACE_INTERACTIVE_PREVIEW_INTERVAL_MS = 140;
var ACE_DETAIL_ZOOM_THRESHOLD = 2.0;
var ACE_DETAIL_MAX_PIXELS = 9000000;
var ACE_DETAIL_CONTEXT_RADIUS_SCALE = 3.0;
var ACE_DETAIL_MIN_CONTEXT_MARGIN = 16;
var ACE_DETAIL_MAX_CONTEXT_MARGIN = 72;
var ACE_DETAIL_SOFT_MAX_PIXELS = 1800000;
var ACE_DETAIL_RESPONSIVE_LOCAL_MAX_PIXELS = 450000;
var ACE_DETAIL_RESPONSIVE_GLOBAL_MAX_PIXELS = 150000;
var ACE_DETAIL_TIMING_LOG_THRESHOLD_MS = 1000;
var ACE_DETAIL_CROP_PREVIEW_ENABLED = true;
var ACE_LOW_ZOOM_GLOBAL_LOUPE_ENABLED = true;
var ACE_LOW_ZOOM_GLOBAL_LOUPE_MAX_ZOOM = 1.05;
var ACE_LOW_ZOOM_GLOBAL_LOUPE_WIDTH = 190;
var ACE_LOW_ZOOM_GLOBAL_LOUPE_HEIGHT = 150;
var ACE_LOW_ZOOM_GLOBAL_LOUPE_TIMER_SECONDS = 0.22;
var ACE_DETAIL_TEXTURE_HYBRID_DOWNSAMPLE = 2;
var ACE_DETAIL_TEXTURE_HYBRID_AB_AUDIT_LIMIT = 0;
var ACE_DETAIL_TEXTURE_HYBRID_AB_AUDIT_COUNT = 0;
var ACE_DETAIL_TEXTURE_HYBRID_BASELINE_ACTIVE = false;
var ACE_DETAIL_CLARITY_DZ_FAST_MIN_EDGE = 512;
var ACE_DETAIL_CLARITY_DZ_DOWNSAMPLE = 3;
var ACE_DETAIL_CLARITY_DZ_AB_AUDIT_LIMIT = 0;
var ACE_DETAIL_CLARITY_DZ_AB_AUDIT_COUNT = 0;
var ACE_DETAIL_CLARITY_DZ_BASELINE_ACTIVE = false;
var ACE_DETAIL_CLARITY_DZ_CANDIDATE_ACTIVE = false;
var ACE_DETAIL_AB_COMPARE_EXPORT_LIMIT = 0;
var ACE_DETAIL_AB_COMPARE_EXPORT_COUNT = 0;
var ACE_FULLRES_TEXTURE_HYBRID_CONFIDENCE_DOWNSAMPLE = 8;
var ACE_FULLRES_CLARITY_DZ_ZONE_DOWNSAMPLE = 8;
var ACE_FULLRES_GLOBAL_PROTECTION_MAP_DOWNSAMPLE = 8;
var ACE_FULLRES_LASSO_WEIGHT_DOWNSAMPLE = 2;
var ACE_STATE_VALIDATION_ROI_MAX_EDGE = 512;
var ACE_STATE_VALIDATION_MAX_ROIS = 4;
var ACE_STATE_VALIDATION_CLICK_COUNT = 5;
var ACE_STATE_VALIDATION_CLICK_WINDOW_MS = 1800;
var ACE_USE_FAST_STAR_PREVIEW = true;
var ACE_EPSILON = 1.0e-6;
var ACE_TEXTURE_AMOUNT = 2.15;
var ACE_TEXTURE_MODE_CURRENT = "texture_current";
var ACE_TEXTURE_MODE_STRENGTH_1P25 = "texture_current_strength_1p25";
var ACE_TEXTURE_MODE_STRENGTH_1P50 = "texture_current_strength_1p50";
var ACE_TEXTURE_MODE_STRENGTH_1P75 = "texture_current_strength_1p75";
var ACE_TEXTURE_MODE_STRENGTH_2P00 = "texture_current_strength_2p00";
var ACE_TEXTURE_MODE_ISOCORE_1P00 = "texture_artifactsafe_map_core_1p00";
var ACE_TEXTURE_MODE_ISOCORE_1P25 = "texture_artifactsafe_map_core_1p25";
var ACE_TEXTURE_MODE_ISOCORE_1P50 = "texture_artifactsafe_map_core_1p50";
var ACE_TEXTURE_MODE_ISOCORE_1P75 = "texture_artifactsafe_map_core_1p75";
var ACE_TEXTURE_MODE_COMPACT_BRIGHT_ONLY_1P50 = "texture_compact_bright_precondition_current_core_1p50";
var ACE_TEXTURE_MODE_ISOTROPIC_ONLY_1P50 = "texture_isotropic_core_no_compact_precondition_1p50";
var ACE_TEXTURE_MODE_GRIDGUARD_1P25 = "texture_current_gridguard_1p25";
var ACE_TEXTURE_MODE_GRIDGUARD_1P50 = "texture_current_gridguard_1p50";
var ACE_TEXTURE_MODE_GRIDGUARD_1P75 = "texture_current_gridguard_1p75";
var ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P25 = "texture_current_compactbright_gridguard_1p25";
var ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P50 = "texture_current_compactbright_gridguard_1p50";
var ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P75 = "texture_current_compactbright_gridguard_1p75";
var ACE_TEXTURE_MODE_GRIDGUARD_LIGHT_1P50 = "texture_current_gridguard_light_1p50";
var ACE_TEXTURE_MODE_GRIDGUARD_STRONG_1P50 = "texture_current_gridguard_strong_1p50";
var ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_LIGHT_1P50 = "texture_current_compactbright_gridguard_light_1p50";
var ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_STRONG_1P50 = "texture_current_compactbright_gridguard_strong_1p50";
var ACE_TEXTURE_MODE_SIGNALFIX_AA_1P25 = "texture_signalfix_aa_reconstruction_1p25";
var ACE_TEXTURE_MODE_SIGNALFIX_AA_1P50 = "texture_signalfix_aa_reconstruction_1p50";
var ACE_TEXTURE_MODE_SIGNALFIX_SOURCE_1P50 = "texture_signalfix_source_agree_1p50";
var ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P25 = "texture_signalfix_blend_1p25";
var ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P50 = "texture_signalfix_blend_1p50";
var ACE_TEXTURE_MODE_WIDE60 = "texture_scale_wider_gain_0p60";
var ACE_TEXTURE_MODE_DOG_MIDBLEND_REF = "texture_redesign_dog_fine_midblend_reference";
var ACE_TEXTURE_MODE_TENSOR_LIMITED_REF = "texture_redesign_structure_tensor_limited_reference";
var ACE_TEXTURE_MODE_HYBRID_CONSERVATIVE = "texture_hybrid_conservative";
var ACE_TEXTURE_MODE_HYBRID_MEDIUM = "texture_hybrid_dog_tensor_gate_medium";
var ACE_TEXTURE_MODE_HYBRID_LIGHT = "texture_hybrid_dog_tensor_gate_light";
var ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST = "texture_hybrid_dog_tensor_gate_light_fast_test";
var ACE_TEXTURE_MODE_HYBRID_HIGH = "texture_hybrid_high_strength";
var ACE_TEXTURE_MODE_PRODUCT_MAP = "texture_hybrid_light_product_slider_map";
var ACE_TEXTURE_MODE_PRODUCT_MAP_STAR_HYGIENE = "texture_hybrid_light_product_slider_map_star_hygiene";
var ACE_TEXTURE_MODE_SAFE_PRODUCT_STAR_HYGIENE = "texture_hybrid_medium_product_slider_map_star_hygiene";
var ACE_TEXTURE_MODE_HIGH_PRODUCT_MAP = "texture_hybrid_high_product_slider_map";
var ACE_TEXTURE_MODE_DEFAULT = ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST;
var ACE_TEXTURE_WIDE60_RADIUS = 5;
var ACE_TEXTURE_WIDE60_FINE_RADIUS_FACTOR = 0.45;
var ACE_TEXTURE_WIDE60_GAIN = 0.60;
var ACE_CONTRAST_STAR_PROTECTION_START = 0.34;
var ACE_CONTRAST_STAR_PROTECTION_END = 0.92;
var ACE_TEXTURE_STAR_CORE_SUPPRESSION = 0.86;
var ACE_CLARITY_STAR_CORE_SUPPRESSION = 0.72;
var ACE_CLARITY_AMOUNT = 1.20;
var ACE_CLARITY_DUALZONE_PRODUCT_GAIN = 1.32;
var ACE_CLARITY_MODE_LEGACY = "legacy";
var ACE_CLARITY_MODE_V2 = "v2";
var ACE_CLARITY_MODE_V2_DEPTH = "v2_depth";
var ACE_CLARITY_MODE_V3 = "v3";
var ACE_CLARITY_MODE_V3_RAW = "v3_raw";
var ACE_CLARITY_MODE_V3_WEIGHTED = "v3_weighted";
var ACE_CLARITY_MODE_V3_BACKGROUND = "v3_background";
var ACE_CLARITY_MODE_V3_STARS = "v3_stars";
var ACE_CLARITY_MODE_V3_FULL = "v3_full";
var ACE_CLARITY_MODE_V4 = "v4";
var ACE_CLARITY_MODE_FEATUREFIT_SHARED_LUMA_SAT_GATE = "featurefit_shared_luma_sat_gate";
var ACE_CLARITY_MODE_FEATUREFIT_TWO_TERM_LUMA_SAT_GATE = "featurefit_two_term_luma_sat_gate";
var ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT = "dualzone_opt_safer_bright";
var ACE_CLARITY_MODE_DUALZONE_BROADBAND_BOOST_GUARDED = "dualzone_broadband_boost_guarded";
var ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P30 = "dualzone_highend_1p30";
var ACE_CLARITY_MODE_DUALZONE_SAFEZONE_EXTRA_DARKDUST = "dualzone_safezone_extra_darkdust";
var ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P50 = "dualzone_highend_1p50";
var ACE_CLARITY_MODE_FAILED_V5B_0945_CURRENT_DISABLED = "failed_v5b_0945_current_disabled";
var ACE_CLARITY_MODE_DEFAULT = ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P50;
var ACE_DEHAZE_AMOUNT = 0.60;
var ACE_TEXTURE_RADIUS = 3;
var ACE_CLARITY_RADIUS = 12;
var ACE_DEHAZE_RADIUS = 88;
var ACE_TEXTURE_BANDPASS_GAIN = 1.34;
var ACE_CLARITY_BANDPASS_GAIN = 1.22;
var ACE_TEXTURE_EDGE_GAIN = 2.40;
var ACE_TEXTURE_SCALE_MIX = 0.26;
var ACE_TEXTURE_EDGE_SUPPORT_OPEN = 0.80;
var ACE_TEXTURE_EDGE_ALLOWED_OPEN = 0.78;
var ACE_TEXTURE_BANDPASS_SOFT_LIMIT = 0.145;
var ACE_CLARITY_BANDPASS_SOFT_LIMIT = 0.094;
var ACE_STRUCTURE_RADIUS = 5;
var ACE_FLOOR_RADIUS = 32;
var ACE_STRUCTURE_CONFIDENCE_SMOOTH_RADIUS = 8;
var ACE_LOCAL_FLOOR_SUPPORT_SMOOTH_RADIUS = 4;
var ACE_DEHAZE_EXCESS_SMOOTH_RADIUS = 5;
var ACE_ALLOWED_MIN = 0.18;
var ACE_ALLOWED_SMOOTH_RADIUS = 5;
var ACE_DARK_PATCH_SUPPRESSION = 0.93;
var ACE_CLARITY_NEGATIVE_GUARD = 0.52;
var ACE_CLARITY_HIGHLIGHT_GUARD = 0.70;
var ACE_CLARITY_MIN_POSITIVE_KEEP = 0.24;
var ACE_CLARITY_NEGATIVE_MIN_KEEP = 0.55;
var ACE_CLARITY_NEGATIVE_CONFIDENCE_KEEP = 0.35;
var ACE_CLARITY_LOCAL_SMALL_STAR_GUARD = 0.88;
var ACE_CLARITY_LOCAL_STAR_POWER = 1.45;
var CLARITY_V2_SHADOW_START = 0.045;
var CLARITY_V2_MID_LOW = 0.180;
var CLARITY_V2_HIGH_START = 0.700;
var CLARITY_V2_HIGHLIGHT_END = 0.955;
var CLARITY_V2_ACTIVITY_LOW_START = 0.004;
var CLARITY_V2_ACTIVITY_LOW_END = 0.020;
var CLARITY_V2_ACTIVITY_HIGH_START = 0.060;
var CLARITY_V2_ACTIVITY_HIGH_END = 0.150;
var CLARITY_V2_SOFT_LIMIT = 0.082;
var CLARITY_V2_SOFT_KNEE = 1.35;
var CLARITY_V2_MAX_DELTA = 0.105;
var CLARITY_V2_COLOR_GAIN = 0.00;
var CLARITY_V2_STAR_SUPPRESSION = 0.88;
var CLARITY_V2_HIGHLIGHT_SUPPRESSION = 0.92;
var CLARITY_V2_COMPACT_SUPPRESSION = 0.86;
var CLARITY_V2_BACKGROUND_KEEP_MIN = 0.52;
var CLARITY_V2_DEPTH_ENABLE = true;
var CLARITY_V2_DEPTH_SHADOW_GAIN = 0.52;
var CLARITY_V2_DEPTH_HIGHLIGHT_GAIN = 0.00;
var CLARITY_V2_DEPTH_MIX = 1.00;
var CLARITY_V2_BASE_MIX = 0.82;
var CLARITY_V2_DEPTH_MAX_DELTA = 0.075;
var CLARITY_V2_DEPTH_SOFT_KNEE = 1.20;
var CLARITY_V2_DEPTH_MIDTONE_POWER = 1.12;
var CLARITY_V2_DEPTH_ACTIVITY_POWER = 0.85;
var CLARITY_V2_DEPTH_BRIGHT_START = 0.46;
var CLARITY_V2_DEPTH_BRIGHT_END = 0.82;
var CLARITY_V2_DEPTH_POSITIVE_STRUCTURE_POWER = 1.55;
var CLARITY_V2_DEPTH_FLOOR_MARGIN = 0.012;
var CLARITY_V2_DEPTH_FLOOR_SOFTNESS = 0.030;
var CLARITY_V2_POSITIVE_GLOW_RADIUS = 18;
var CLARITY_V2_POSITIVE_GLOW_SUPPRESSION = 0.55;
var CLARITY_V2_POSITIVE_GAIN = 0.45;
var CLARITY_V2_NEGATIVE_GAIN = 1.00;
var CLARITY_V2_POSITIVE_RATIO_LIMIT = 0.45;
var CLARITY_V2_POSITIVE_RATIO_LIMIT_ENABLE = false;
var CLARITY_V2_POSITIVE_STRUCTURE_POWER = 2.00;
var CLARITY_V2_NEGATIVE_FLOOR_MARGIN = 0.012;
var CLARITY_V2_MIN_POSITIVE_RETENTION = 0.25;
var CLARITY_V2_TUNING_A = "A";
var CLARITY_V2_TUNING_B = "B";
var CLARITY_V2_TUNING_C = "C";
var CLARITY_V2_TUNING_DEFAULT = CLARITY_V2_TUNING_A;
var CLARITY_V2_DIAGNOSTIC_LOG_ENABLED = false;
var CLARITY_V2_DIAGNOSTIC_LOG_INTERVAL_MS = 850;
var gClarityV2DiagnosticLastLogMs = 0;
var CLARITY_V3_CURVE_K = 1.55;
var CLARITY_V3_GLOBAL_GAIN = 1.49;
var CLARITY_V3_SCALE_MIN = 0.010;
var CLARITY_V3_SCALE_GAIN = 1.18;
var CLARITY_V3_MIDTONE_LOW = 0.055;
var CLARITY_V3_MIDTONE_PEAK_LOW = 0.180;
var CLARITY_V3_MIDTONE_PEAK_HIGH = 0.620;
var CLARITY_V3_MIDTONE_HIGH = 0.900;
var CLARITY_V3_STRUCTURE_LOW_START = 0.004;
var CLARITY_V3_STRUCTURE_LOW_END = 0.026;
var CLARITY_V3_STRUCTURE_HIGH_START = 0.115;
var CLARITY_V3_STRUCTURE_HIGH_END = 0.260;
var CLARITY_V3_TRANSITION_LOW = 0.006;
var CLARITY_V3_TRANSITION_HIGH = 0.030;
var CLARITY_V3_TRANSITION_MIN_KEEP = 0.46;
var CLARITY_V3_SMOOTH_FIELD_LOW = 0.010;
var CLARITY_V3_SMOOTH_FIELD_HIGH = 0.055;
var CLARITY_V3_SMOOTH_FIELD_MIN_KEEP = 0.66;
var CLARITY_V3_HIGHLIGHT_START = 0.700;
var CLARITY_V3_HIGHLIGHT_END = 0.965;
var CLARITY_V3_HIGHLIGHT_SUPPRESSION = 0.80;
var CLARITY_V3_COMPACT_SUPPRESSION = 0.82;
var CLARITY_V3_POSITIVE_LIMIT = 0.070;
var CLARITY_V3_NEGATIVE_LIMIT = 0.082;
var CLARITY_V3_SOFT_KNEE = 1.18;
var CLARITY_V3_BACKGROUND_KEEP_MIN = 0.46;
var CLARITY_V3_MIDTONE_POWER = 0.75;
var CLARITY_V3_STRUCTURE_POWER = 0.75;
var CLARITY_V3_POSITIVE_BACKGROUND_POWER = 0.35;
var CLARITY_V3_NEGATIVE_BACKGROUND_POWER = 0.65;
var CLARITY_V3_NEGATIVE_DARK_PATCH_POWER = 0.75;
var CLARITY_V3_STAR_POWER = 1.00;
var CLARITY_V3_HALO_POWER = 0.85;
var CLARITY_V3_HIGHLIGHT_POWER = 1.00;
var CLARITY_V3_POSITIVE_MIN_ALLOWED = 0.25;
var CLARITY_V3_NEGATIVE_MIN_ALLOWED = 0.20;
var CLARITY_V3_MIN_ALLOWED_STAR_CORE_CUTOFF = 0.72;
var CLARITY_V3_MIN_ALLOWED_HIGHLIGHT_CUTOFF = 0.58;
var CLARITY_V3_MIN_ALLOWED_COMPACT_CUTOFF = 0.55;
var CLARITY_V3_MIN_ALLOWED_DARKPATCH_CUTOFF = 0.78;
var CLARITY_V3_DIAGNOSTIC_LOG_ENABLED = false;
var CLARITY_V3_DIAGNOSTIC_LOG_INTERVAL_MS = 850;
var gClarityV3DiagnosticLastLogMs = 0;
var CLARITY_V4_SMALL_RADIUS_MIN = 4;
var CLARITY_V4_SMALL_RADIUS_TEXTURE_FACTOR = 1.5;
var CLARITY_V4_BROAD_RADIUS_FACTOR = 3.2;
var CLARITY_V4_ACTIVITY_RADIUS_FACTOR = 0.65;
var CLARITY_V4_FINE_MID_WEIGHT = 0.45;
var CLARITY_V4_MID_BROAD_WEIGHT = 0.75;
var CLARITY_V4_GLOBAL_GAIN = 2.15;
var CLARITY_V4_ACTIVITY_LOW = 0.0035;
var CLARITY_V4_ACTIVITY_HIGH = 0.022;
var CLARITY_V4_ACTIVITY_POWER = 0.70;
var CLARITY_V4_MIDTONE_LOW = 0.050;
var CLARITY_V4_MIDTONE_PEAK_LOW = 0.165;
var CLARITY_V4_MIDTONE_PEAK_HIGH = 0.650;
var CLARITY_V4_MIDTONE_HIGH = 0.925;
var CLARITY_V4_HIGHLIGHT_START = 0.700;
var CLARITY_V4_HIGHLIGHT_END = 0.965;
var CLARITY_V4_HIGHLIGHT_SUPPRESSION = 0.86;
var CLARITY_V4_COMPACT_SUPPRESSION = 0.86;
var CLARITY_V4_POSITIVE_BACKGROUND_POWER = 0.25;
var CLARITY_V4_NEGATIVE_BACKGROUND_POWER = 0.60;
var CLARITY_V4_DARKPATCH_POWER = 0.75;
var CLARITY_V4_POSITIVE_LIMIT = 0.090;
var CLARITY_V4_NEGATIVE_LIMIT = 0.095;
var CLARITY_V4_SOFT_KNEE = 1.18;
var CLARITY_V4_POSITIVE_MIN_ALLOWED = 0.24;
var CLARITY_V4_NEGATIVE_MIN_ALLOWED = 0.18;
var CLARITY_V4_STRONG_DELTA_THRESHOLD = 0.010;
var CLARITY_V4_DIAGNOSTIC_LOG_ENABLED = false;
var CLARITY_V4_DIAGNOSTIC_LOG_INTERVAL_MS = 850;
var gClarityV4DiagnosticLastLogMs = 0;
var USE_CLARITY_V5B_POSITIVE = false;
var FORCE_CLARITY_V4 = false;
var CLARITY_V5B_TONE_MODE = "forced_v4"; // allowed: "forced_v4", "v5b_0945_current", "v5b_highlight_guard_test"
var ACE_CLARITY_ALGORITHM_ID_V4 = "clarity_v4_ace_1_43";
var ACE_CLARITY_ALGORITHM_ID_FEATUREFIT_SHARED_LUMA_SAT_GATE = "clarity_featurefit_shared_luma_sat_gate";
var ACE_CLARITY_ALGORITHM_ID_FEATUREFIT_TWO_TERM_LUMA_SAT_GATE = "clarity_featurefit_two_term_luma_sat_gate";
var ACE_CLARITY_ALGORITHM_ID_DUALZONE_OPT_SAFER_BRIGHT = "clarity_dualzone_opt_safer_bright";
var ACE_CLARITY_ALGORITHM_ID_DUALZONE_BROADBAND_BOOST_GUARDED = "clarity_dualzone_broadband_boost_guarded";
var ACE_CLARITY_ALGORITHM_ID_DUALZONE_HIGHEND_1P30 = "clarity_dualzone_highend_1p30";
var ACE_CLARITY_ALGORITHM_ID_DUALZONE_SAFEZONE_EXTRA_DARKDUST = "clarity_dualzone_safezone_extra_darkdust";
var ACE_CLARITY_ALGORITHM_ID_DUALZONE_HIGHEND_1P50 = "clarity_dualzone_highend_1p50";
var ACE_CLARITY_ALGORITHM_ID_V5B_REJECTED = "clarity_v5b_broad_scurve_rejected";
var ACE_CLARITY_ALGORITHM_ID_V5B_POSITIVE = "clarity_v5b_positive_broad_scurve_gamma_1_3_highlight_guard_test";
var ACE_CLARITY_ALGORITHM_ID_V5B_POSITIVE_CURRENT_0945 = "clarity_v5b_positive_broad_scurve_gamma_1_3_v0_9_145_current";
var ACE_CLARITY_V5B_FINAL_COMPOSITION_FORMULA_ID = "clarity_v5b_benchmark_matched_luminance_composition";
var CLARITY_V5B_POSITIVE_BROAD_SCURVE_BASE_GAIN = 0.032;
var CLARITY_V5B_POSITIVE_BROAD_SCURVE_GAMMA = 1.3;
var CLARITY_V5B_HIGHLIGHT_GUARD_START = 0.52;
var CLARITY_V5B_HIGHLIGHT_GUARD_END = 0.92;
var CLARITY_V5B_HIGHLIGHT_GUARD_MIN_KEEP = 0.18;
var CLARITY_V5B_SATURATION_GUARD_START = 0.08;
var CLARITY_V5B_SATURATION_GUARD_END = 0.24;
var CLARITY_V5B_SATURATION_GUARD_MIN_KEEP = 0.45;
var CLARITY_V5B_MIDTONE_GATE_LOW = 0.060;
var CLARITY_V5B_MIDTONE_GATE_HIGH = 0.940;
var CLARITY_V5B_BROAD_BASE_RADIUS = 56;
var CLARITY_V5B_BROAD_SCALE_RADIUS = 28;
var CLARITY_V5B_LOCAL_SCALE_FLOOR = 0.045;
var CLARITY_V5B_LOCAL_SCALE_GAIN = 3.0;
var CLARITY_V5B_SCURVE_GAIN = 1.6;
var CLARITY_V5B_LINEAR_KEEP = 0.15;
var CLARITY_V5B_STAR_KEEP_POWER = 1.2;
var CLARITY_V5B_DIAGNOSTIC_LOG_ENABLED = false;
var CLARITY_V5B_DIAGNOSTIC_LOG_INTERVAL_MS = 850;
var gClarityV5bDiagnosticLastLogMs = 0;
var USE_CLARITY_FEATUREFIT_GATED_POSITIVE = false;
var CLARITY_FEATUREFIT_INTERNAL_MODE = "forced_v4"; // allowed: "forced_v4", "featurefit_shared_luma_sat_gate", "featurefit_two_term_luma_sat_gate", "failed_v5b_0945_current_disabled"
var CLARITY_FEATUREFIT_LOCAL_BASE_RADIUS = 56;
var CLARITY_FEATUREFIT_LOCAL_DETAIL_RADIUS = 3;
var CLARITY_FEATUREFIT_LOCAL_RMS_RADIUS = 8;
var CLARITY_FEATUREFIT_MIDTONE_LOW = 0.050;
var CLARITY_FEATUREFIT_MIDTONE_PEAK_LOW = 0.240;
var CLARITY_FEATUREFIT_MIDTONE_PEAK_HIGH = 0.580;
var CLARITY_FEATUREFIT_MIDTONE_HIGH = 0.920;
var CLARITY_FEATUREFIT_SHARED_C1_DARK_SIDE = -0.00704853187300082;
var CLARITY_FEATUREFIT_SHARED_C2_DARK_MIDTONE = -0.013447111503026653;
var CLARITY_FEATUREFIT_SHARED_C3_LOCAL_RMS = -0.0008657916283153728;
var CLARITY_FEATUREFIT_TWO_TERM_C1_DARK_SIDE = -0.007010979989729212;
var CLARITY_FEATUREFIT_TWO_TERM_C2_DARK_MIDTONE = -0.01352308382642898;
var CLARITY_FEATUREFIT_LUMA_GATE_START = 0.42;
var CLARITY_FEATUREFIT_LUMA_GATE_END = 0.74;
var CLARITY_FEATUREFIT_SAT_GATE_START = 0.16;
var CLARITY_FEATUREFIT_SAT_GATE_END = 0.44;
var CLARITY_FEATUREFIT_LUMA_SAT_SUPPRESSION = 0.90;
var CLARITY_FEATUREFIT_GATE_FLOOR = 0.07;
var CLARITY_FEATUREFIT_STAR_KEEP = 0.20;
var CLARITY_FEATUREFIT_POSITIVE_CLIP = 0.008;
var CLARITY_FEATUREFIT_NEGATIVE_CLIP = -0.026;
var CLARITY_FEATUREFIT_RATIO_HI = 1.85;
var CLARITY_FEATUREFIT_DIAGNOSTIC_LOG_ENABLED = false;
var CLARITY_FEATUREFIT_DIAGNOSTIC_LOG_INTERVAL_MS = 850;
var gClarityFeatureFitDiagnosticLastLogMs = 0;
var USE_CLARITY_DUALZONE_OPT_POSITIVE = false;
var CLARITY_DUALZONE_OPT_INTERNAL_MODE = "forced_v4"; // allowed: "forced_v4", "dualzone_opt_safer_bright"
var CLARITY_DUALZONE_OPT_MIDTONE_GAIN = 3.54;
var CLARITY_DUALZONE_OPT_DARK_DUST_GAIN = 4.00;
var CLARITY_DUALZONE_OPT_BRIGHT_ZONE_GAIN = 1.91;
var CLARITY_DUALZONE_OPT_HIGH_LUMA_SUPPRESSION = 0.53;
var CLARITY_DUALZONE_OPT_HIGH_SAT_SUPPRESSION = 0.23;
var CLARITY_DUALZONE_OPT_PLATEAU_LIMITER = 0.00;
var USE_CLARITY_DUALZONE_BOOST_POSITIVE = false;
var CLARITY_DUALZONE_BOOST_INTERNAL_MODE = "forced_v4"; // allowed: "forced_v4", "dualzone_broadband_boost_guarded", "dualzone_highend_1p30", "dualzone_safezone_extra_darkdust", "dualzone_highend_1p50"
var CLARITY_DUALZONE_BOOST_MIDTONE_GAIN = 4.1064;
var CLARITY_DUALZONE_BOOST_DARK_DUST_GAIN = 4.96;
var CLARITY_DUALZONE_BOOST_BRIGHT_ZONE_GAIN = 1.91;
var CLARITY_DUALZONE_BOOST_HIGH_LUMA_SUPPRESSION = 0.60;
var CLARITY_DUALZONE_BOOST_HIGH_SAT_SUPPRESSION = 0.31;
var CLARITY_DUALZONE_BOOST_PLATEAU_LIMITER = 0.00;
var CLARITY_DUALZONE_HIGHEND_RESPONSE_START = 75.0;
var CLARITY_DUALZONE_HIGHEND_RESPONSE_END = 150.0;
var CLARITY_DUALZONE_BOOST_DIAGNOSTIC_LOG_ENABLED = false;
var CLARITY_DUALZONE_BOOST_DIAGNOSTIC_LOG_INTERVAL_MS = 850;
var gClarityDualZoneBoostDiagnosticLastLogMs = 0;
var CLARITY_DUALZONE_OPT_DIAGNOSTIC_LOG_ENABLED = false;
var CLARITY_DUALZONE_OPT_DIAGNOSTIC_LOG_INTERVAL_MS = 850;
var gClarityDualZoneOptDiagnosticLastLogMs = 0;
var ACE_CLARITY_DUALZONE_FAST_BLURS_ENABLED = true;
var ACE_CLARITY_DUALZONE_FULLRES_MEAN_DOWNSAMPLE = 6;
var ACE_CLARITY_DUALZONE_FULLRES_ZONE_DOWNSAMPLE = 2;
var ACE_OUTPUT_DETAIL_REFRESH_COOLDOWN_MS = 1800;
var ACE_DEHAZE_NO_LIFT_START = 0.48;
var ACE_DEHAZE_NO_LIFT_END = 0.78;
var ACE_DEHAZE_NEGATIVE_GUARD = 0.28;
var ACE_DEHAZE_HIGHLIGHT_GUARD = 0.88;
var ACE_DEHAZE_COMPACT_GUARD = 0.98;
var ACE_DEHAZE_MIN_POSITIVE_KEEP = 0.04;
var ACE_DEHAZE_MODE = "veil";
var ACE_DEHAZE_APP_MODE_CURRENT = "dehaze_current_ace";
var ACE_DEHAZE_APP_MODE_GAIN_MATCH = "dehaze_current_gain_match";
var ACE_DEHAZE_APP_MODE_TONE_COLOR = "dehaze_tone_color_combo";
var ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR = "dehaze_protected_tone_color";
var ACE_DEHAZE_APP_MODE_COLOR_SEPARATION = "dehaze_color_separation";
var ACE_DEHAZE_APP_MODE_TONE_REDISTRIBUTION = "dehaze_tone_redistribution";
var ACE_DEHAZE_APP_MODE_DEFAULT = ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR;
var ACE_DEHAZE_SLIDER_GAMMA = 1.28;
var ACE_DEHAZE_VEIL_RADIUS = 120;
var ACE_DEHAZE_VEIL_PASSES = 2;
var ACE_DEHAZE_PREVIEW_DOWNSAMPLE = 3;
var ACE_DEHAZE_FULLRES_DOWNSAMPLE = 10;
var ACE_FULLRES_DEHAZE_CONFIDENCE_DOWNSAMPLE = 6;
var ACE_DEHAZE_MAX_REDUCTION = 0.11;
var ACE_DEHAZE_CONTRAST_RESTORE = 0.42;
var ACE_DEHAZE_BROAD_CONTRAST_RESTORE = 0.18;
var ACE_DEHAZE_COLOR_RESTORE = 0.20;
var ACE_DEHAZE_NEGATIVE_HAZE_MIX = 0.54;
var ACE_DEHAZE_NEGATIVE_HAZE_LIFT = 0.30;
var ACE_DEHAZE_NEGATIVE_CHROMA_VEIL = 0.18;
var ACE_DEHAZE_HIGHLIGHT_START = 0.84;
var ACE_DEHAZE_HIGHLIGHT_END = 0.99;
var ACE_DEHAZE_LOCAL_BACKGROUND_POWER = 5.0;
var ACE_DEHAZE_LOCAL_CONFIDENCE_KEEP = 0.05;
var ACE_DEHAZE_LOCAL_FLOOR_BUFFER = 0.012;
var ACE_DEHAZE_LOCAL_BLACK_SCALE = 0.18;
var ACE_DEHAZE_LOCAL_MID_SCALE = 1.75;
var ACE_DEHAZE_LOCAL_RESTORE_SCALE = 1.85;
var ACE_DEHAZE_LOCAL_HIGHLIGHT_SCALE = 0.70;
var ACE_DEHAZE_LOCAL_SMALL_STAR_GUARD = 0.94;
var ACE_DEHAZE_LOCAL_STAR_POWER = 1.7;
var ACE_POSITIVE_BACKGROUND_SUPPRESSION = 0.38;
var ACE_LOCAL_FLOOR_TOLERANCE = 0.008;
var ACE_TEXTURE_BACKGROUND_MIN = 0.42;
var ACE_TEXTURE_BACKGROUND_ARTIFACT_KEEP_MIN = 0.30;
var ACE_CLARITY_BACKGROUND_ARTIFACT_KEEP_MIN = 0.35;
var ACE_TEXTURE_STRUCTURE_SELF_SUPPORT = 0.012;
var ACE_TEXTURE_STRUCTURE_SUPPORT_SCALE = 1.10;
var ACE_TEXTURE_STRUCTURE_BROAD_SUPPORT_SCALE = 2.20;
var ACE_MASK_PREVIEW_MAX_EDGE = 520;
var ACE_STAR_SIGNAL_RADIUS = 5;
var ACE_STAR_COMPACT_RADIUS = 1;
var ACE_STAR_CORE_BLUR_RADIUS = 1;
var ACE_STAR_CORE_GROW_RADIUS = 2;
var ACE_STAR_HALO_GROW_RADIUS = 5;
var ACE_STAR_HALO_BLUR_RADIUS = 6;
var ACE_STAR_NEAR_SATURATION = 0.92;
var ACE_STAR_PROTECTION_FLOOR = 0.04;
var ACE_STAR_MIN_SIGNAL = 0.018;
var ACE_STAR_SIGMA_FACTOR = 2.25;
var ACE_STAR_CORE_STRENGTH = 0.96;
var ACE_STAR_HALO_STRENGTH = 0.60;
var ACE_STAR_FULLRES_DOWNSAMPLE = 3;

var ACE_COLORS = {
   window: 0xff353535,
   header: 0xff303030,
   headerDark: 0xff292929,
   panel: 0xff404040,
   panelAlt: 0xff383838,
   panelDark: 0xff303030,
   inset: 0xff2b2b2b,
   controlBay: 0xff071018,
   controlBayAlt: 0xff101923,
   controlBayBlueDeep: 0xff06111d,
   controlBayBlueMid: 0xff1b3b59,
   controlBayGoldBorder: 0xffffc24a,
   controlBayBorder: 0xff2b3a46,
   controlBayBorderDim: 0xff26323d,
   controlBayRow: 0xff0b1620,
   controlBayRowActive: 0xff0d1a25,
   controlBayGlow: 0xff121f2b,
   controlBayRail: 0xff050b11,
   controlBayRailEdge: 0xff344756,
   controlBaySeparator: 0xff1c2a35,
   controlBayValue: 0xff121a22,
   controlBayTick: 0xff60707c,
   controlBayTickMajor: 0xff788692,
   controlBayLabel: 0xff7c8792,
   passViewer: 0xffd8d8d8,
   line: 0xff747474,
   lineDim: 0xff5f5f5f,
   text: 0xfff2f2f2,
   darkText: 0xff161616,
   muted: 0xffd2d2d2,
   accent: 0xffd8dcff,
   accentSoft: 0xff9fa7d8,
   sectionTitle: 0xffffc24a,
   texture: 0xff8fc7ff,
   clarity: 0xffd8dcff,
   dehaze: 0xffffd277,
   active: 0xffcbd58a,
   warning: 0xffffd277
};

function aceMessage(text, title, icon) {
   (new MessageBox(text, title || ACE_TOOL_NAME + " " + ACE_VERSION, icon || StdIcon_Information, StdButton_Ok)).execute();
}

function aceHostIsWindows() {
   try {
      var paths = [
         String(File.systemTempDirectory || ""),
         String(File.homeDirectory || ""),
         String(File.currentWorkingDirectory || "")
      ];
      for (var i = 0; i < paths.length; ++i) {
         if (/^[A-Za-z]:[\\\/]/.test(paths[i]) || paths[i].indexOf("\\") >= 0)
            return true;
      }
      if (typeof CoreApplication !== "undefined" && CoreApplication.platform) {
         var platform = String(CoreApplication.platform).toLowerCase();
         if (platform.indexOf("win") >= 0)
            return true;
      }
      return false;
   } catch (error) {
      return false;
   }
}

function aceDefaultDialogSize() {
   return {
      width: ACE_DISPLAY_MIN_WIDTH,
      height: ACE_DISPLAY_MIN_HEIGHT
   };
}

function aceAcmCompactDialogSizeForWorkspace(workspace) {
   if (!ACE_HOST_IS_WINDOWS || !workspace)
      return aceDefaultDialogSize();
   return {
      width: Math.max(ACE_DISPLAY_MIN_WIDTH, Math.min(ACE_ACM_COMPACT_WINDOWS_MAX_WIDTH, Math.floor(workspace.width - ACE_ACM_COMPACT_WINDOWS_MARGIN_WIDTH))),
      height: Math.max(ACE_DISPLAY_MIN_HEIGHT, Math.min(ACE_ACM_COMPACT_WINDOWS_MAX_HEIGHT, Math.floor(workspace.height - ACE_ACM_COMPACT_WINDOWS_MARGIN_HEIGHT)))
   };
}

function aceMinimumSavedWindowWidthForPlatform() {
   return ACE_DISPLAY_MIN_WIDTH;
}

function aceSavedWindowSizeIsUsableForPlatform(saved) {
   if (!saved)
      return false;
   if (saved.width < aceMinimumSavedWindowWidthForPlatform())
      return false;
   if (saved.height < ACE_DISPLAY_MIN_HEIGHT)
      return false;
   if (ACE_HOST_IS_WINDOWS && saved.width <= ACE_DISPLAY_MIN_WIDTH + 8 && saved.height > ACE_ACM_COMPACT_WINDOWS_MAX_HEIGHT)
      return false;
   return true;
}

function aceFormatScreenSizeForWarning(size) {
   if (!size)
      return "unavailable";
   return Math.round(size.width || 0) + " x " + Math.round(size.height || 0);
}

function aceGetOptionalDialogRect(dialog, propertyName) {
   if (!dialog)
      return null;
   try {
      return (propertyName in dialog) ? dialog[propertyName] : null;
   } catch (error) {
      return null;
   }
}

function aceGetOptionalDialogNumber(dialog, propertyName) {
   if (!dialog)
      return null;
   try {
      var value = (propertyName in dialog) ? dialog[propertyName] : null;
      return typeof value === "number" && isFinite(value) ? value : null;
   } catch (error) {
      return null;
   }
}

function aceGetDialogPosition(dialog) {
   if (!dialog)
      return null;
   try {
      if ("position" in dialog && dialog.position && typeof dialog.position.x === "number" && typeof dialog.position.y === "number")
         return { x: Math.round(dialog.position.x), y: Math.round(dialog.position.y) };
   } catch (error1) {
   }
   var x = aceGetOptionalDialogNumber(dialog, "x");
   var y = aceGetOptionalDialogNumber(dialog, "y");
   if (x !== null && y !== null)
      return { x: Math.round(x), y: Math.round(y) };
   return null;
}

function aceGetDialogAvailableScreenSize(dialog) {
   var candidates = [
      aceGetOptionalDialogRect(dialog, "availableScreenRect"),
      aceGetOptionalDialogRect(dialog, "availableScreenBounds"),
      aceGetOptionalDialogRect(dialog, "availableRect"),
      aceGetOptionalDialogRect(dialog, "screenRect"),
      aceGetOptionalDialogRect(dialog, "screenBounds")
   ];
   for (var i = 0; i < candidates.length; ++i) {
      var rect = candidates[i];
      if (rect && typeof rect.width === "number" && typeof rect.height === "number" && rect.width > 0 && rect.height > 0)
         return { width: rect.width, height: rect.height };
   }
   return null;
}

function aceDisplayPlatformName() {
   return ACE_HOST_IS_WINDOWS ? "Windows" : "macOS / Unix";
}

function aceReadSettingInt(key) {
   if (typeof Settings === "undefined")
      return null;
   try {
      var value = Settings.read(key, DataType_Int32);
      return typeof value === "number" && isFinite(value) ? Math.round(value) : null;
   } catch (error) {
      return null;
   }
}

function aceReadSettingBool(key) {
   if (typeof Settings === "undefined")
      return false;
   try {
      return Settings.read(key, DataType_Int32) !== 0;
   } catch (error) {
      return false;
   }
}

function aceWriteSettingBool(key, value) {
   if (typeof Settings === "undefined")
      return;
   try {
      Settings.write(key, DataType_Int32, value ? 1 : 0);
   } catch (error) {
   }
}

function aceClassifyWorkspace(size) {
   if (!size)
      return "UNKNOWN";
   if (size.width < ACE_DISPLAY_MIN_WIDTH || size.height < ACE_DISPLAY_MIN_HEIGHT)
      return "BELOW_MINIMUM";
   if (size.width < ACE_DISPLAY_MIN_WIDTH + ACE_DISPLAY_MARGIN_WIDTH || size.height < ACE_DISPLAY_MIN_HEIGHT + ACE_DISPLAY_MARGIN_HEIGHT)
      return "MARGINAL";
   return "OK";
}

function aceWindowSizeFitsWorkspace(size, workspace) {
   if (!size || !workspace)
      return true;
   return size.width <= workspace.width && size.height <= workspace.height;
}

function aceWindowPositionFitsWorkspace(pos, size, workspace) {
   if (!pos || !size || !workspace)
      return false;
   return pos.x >= 0 && pos.y >= 0 && pos.x + size.width <= workspace.width && pos.y + size.height <= workspace.height;
}

function aceLargestUsableDialogSize(workspace) {
   if (!workspace)
      return aceDefaultDialogSize();
   return {
      width: Math.max(640, Math.floor(workspace.width)),
      height: Math.max(480, Math.floor(workspace.height))
   };
}

function aceEstimateScalingText(dialog) {
   var ratios = [];
   var pixelRatio = aceGetOptionalDialogNumber(dialog, "devicePixelRatio");
   if (pixelRatio && pixelRatio > 0)
      ratios.push("devicePixelRatio " + Math.round(pixelRatio * 100) + "%");
   var scale = aceGetOptionalDialogNumber(dialog, "devicePixelRatioF");
   if (scale && scale > 0 && scale !== pixelRatio)
      ratios.push("devicePixelRatioF " + Math.round(scale * 100) + "%");
   return ratios.length ? ratios.join(", ") : "unavailable";
}

function aceBuildDisplayDiagnosticsLines(dialog, warningShown) {
   var workspace = aceGetDialogAvailableScreenSize(dialog);
   var preferredSize = aceAcmCompactDialogSizeForWorkspace(workspace);
   var classification = aceClassifyWorkspace(workspace);
   var currentW = dialog && dialog.width ? dialog.width : null;
   var currentH = dialog && dialog.height ? dialog.height : null;
   var saved = dialog && typeof dialog.readWindowSizePreference === "function" ? dialog.readWindowSizePreference() : null;
   return [
      "ACE Display Diagnostics",
      "",
      "ACE version: " + ACE_VERSION,
      "Platform: " + aceDisplayPlatformName(),
      "Available workspace: " + aceFormatScreenSizeForWarning(workspace) + " logical pixels",
      "ACE required minimum: " + ACE_DISPLAY_MIN_WIDTH + " x " + ACE_DISPLAY_MIN_HEIGHT + " logical pixels",
      "Preferred launch size: " + preferredSize.width + " x " + preferredSize.height + " logical pixels",
      "Minimum saved width on this platform: " + aceMinimumSavedWindowWidthForPlatform() + " logical pixels",
      "Current window: " + (currentW && currentH ? Math.round(currentW) + " x " + Math.round(currentH) : "unavailable") + " logical pixels",
      "Saved window: " + (saved ? saved.width + " x " + saved.height + (saved.x !== null && saved.y !== null ? " at " + saved.x + ", " + saved.y : "") : "none"),
      "Estimated display scaling: " + aceEstimateScalingText(dialog),
      "Display classification: " + classification,
      "Warning shown this launch: " + (warningShown ? "yes" : "no"),
      "",
      "ACE uses one supported interface layout. It can be enlarged and a preferred window arrangement can be saved, but ACE does not switch to Standard, Compact, or Small-Screen layouts."
   ];
}

function aceBuildWorkspaceWarning(dialog, classification) {
   var workspace = aceGetDialogAvailableScreenSize(dialog);
   if (classification === "MARGINAL") {
      return "ACE is running close to its minimum recommended window size.\n\n" +
         "The interface should work, but some controls may feel crowded. For best results, maximize the ACE window, use a larger monitor, or reduce Windows display scaling if that remains comfortable for normal use.";
   }
   return "ACE requires more usable screen space than is currently available.\n\n" +
      "Your display may be physically large or high-resolution, but Windows display scaling or the current display environment may be reducing the logical workspace available to the application.\n\n" +
      "ACE uses one supported interface layout and does not provide separate Standard, Compact, or Small-Screen interface variants.\n\n" +
      "PixInsight reports available workspace as " + aceFormatScreenSizeForWarning(workspace) + " logical pixels. ACE requires at least " + ACE_DISPLAY_MIN_WIDTH + " x " + ACE_DISPLAY_MIN_HEIGHT + " logical pixels.\n\n" +
      "For best results, maximize the ACE window, reduce Windows display scaling if practical, or use a larger external monitor. You may continue, but some controls may appear crowded.";
}

function aceLogDisplayDiagnostics(dialog, warningShown) {
   if (!warningShown && !ACE_DEVELOPMENT_CONSOLE_LOGS_ENABLED && !ACE_DEBUG_CONTROLS_ENABLED)
      return;
   var lines = aceBuildDisplayDiagnosticsLines(dialog, warningShown);
   console.writeln("");
   for (var i = 0; i < lines.length; ++i)
      console.writeln(lines[i]);
}

function aceShowDocument(title, lines) {
   var dialog = new Dialog;
   dialog.windowTitle = title || ACE_TOOL_NAME;
   dialog.userResizable = true;

   var textBox = new TextBox(dialog);
   textBox.readOnly = true;
   textBox.wordWrapping = true;
   textBox.text = lines.join("\n");
   textBox.minWidth = 720;
   textBox.minHeight = 480;
   textBox.backgroundColor = ACE_COLORS.inset;
   textBox.textColor = ACE_COLORS.text;
   textBox.foregroundColor = ACE_COLORS.text;
   var docFont = new Font;
   docFont.family = "DejaVu Sans Mono";
   docFont.pixelSize = ACE_FONT_BODY;
   textBox.font = docFont;

   var resetDocumentToTop = function() {
      if (typeof textBox.setSelection === "function")
         textBox.setSelection(0, 0);
      if (typeof textBox.setCaretPosition === "function")
         textBox.setCaretPosition(0);
      if (typeof textBox.home === "function")
         textBox.home();
      textBox.cursorPosition = 0;
      textBox.caretPosition = 0;
      textBox.selectionStart = 0;
      textBox.selectionEnd = 0;
   };

   var closeButton = new PushButton(dialog);
   closeButton.text = "Close";
   closeButton.onClick = function() { dialog.ok(); };

   var buttons = new HorizontalSizer;
   buttons.addStretch();
   buttons.add(closeButton);

   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 8;
   dialog.sizer.spacing = 8;
   dialog.sizer.add(textBox, 100);
   dialog.sizer.add(buttons);
   dialog.adjustToContents();
   resetDocumentToTop();
   dialog.onShow = function() {
      resetDocumentToTop();
   };
   dialog.execute();
}

function aceFaqDocument() {
   return [
      "ASTRO CONTRAST ENHANCER FAQ",
      "Version " + ACE_VERSION,
      "",
      "What does Astro Contrast Enhancer do?",
      "Astro Contrast Enhancer provides protected local contrast control for astrophotography images. It separates contrast work into Texture, Clarity, and Dehaze so fine detail, mid-scale structure, and broad veil or wash can be adjusted independently.",
      "",
      "What is the basic workflow?",
      "Start with the image loaded in Preview mode. Make small global adjustments with Texture and Clarity first. Add Dehaze only when the image has broad veil, wash, haze, or low-frequency flatness that needs correction. Use Local Selection when only part of the image needs adjustment.",
      "",
      "What should I adjust first?",
      "Start small. Texture and Clarity are usually the safest first adjustments. Dehaze is powerful and should be added after the basic contrast balance feels right.",
      "",
      "Should I use Starless or Stars Present?",
      "Use Stars Present when the source image still contains stars. This enables star and halo protection. Use Starless only when stars have already been removed or when you are processing a starless image.",
      "",
      "What does Texture do?",
      "Texture adjusts fine-scale local contrast. It is useful for small wisps, fine dust detail, delicate filaments, and small structural features. Too much Texture can make noise or small artifacts more visible.",
      "",
      "What does Clarity do?",
      "Clarity adjusts mid-scale local contrast. It is useful for nebula folds, dust lanes, galaxy structure, reflection nebulosity, and broad but still structured detail. Too much Clarity can make backgrounds look heavy or unnatural, so the protection system helps restrain risky changes. Advanced > Clarity Response can be set to Light, Balanced, or Strong when a target needs more or less visible response.",
      "",
      "What does Dehaze do?",
      "Positive Dehaze reduces broad veil, wash, or haze-like low-frequency flatness. Negative Dehaze adds back a softer haze character. Astro Contrast Enhancer's Dehaze is designed as an astro-safe veil reduction, not just a large-scale contrast boost.",
      "",
      "How is Dehaze different from Clarity?",
      "Clarity enhances mid-scale structure. Dehaze works on broader veil and wash. Dehaze also uses highlight and compact-source protection so stars and bright points are not pushed as aggressively as broad nebulosity or haze-like regions.",
      "",
      "What is Local Selection?",
      "Local Selection lets you draw a lasso and apply adjustments locally. In normal mode, the adjustment applies inside the lasso. Invert applies the adjustment outside the lasso. Local Selection is useful when one region needs a different contrast treatment than the rest of the image.",
      "",
      "What does Feather / Roll-off do?",
      "Feather / Roll-off controls how softly the lasso transition blends into the surrounding image. Larger values create a smoother transition. This release defaults to 75 px and allows up to 150 px.",
      "",
      "What does Protected Overlay show?",
      "Protected Overlay lightly shades the protected side of a lasso selection. In normal lasso mode, the outside is protected. In inverted mode, the inside is protected. This helps show where the local edit will and will not apply.",
      "",
      "What are the protection options?",
      "Protect Sky Background limits contrast changes in smooth background regions. Prevent Local Dark Patches reduces the risk of dirty dark holes. Protect Stars and Protect Star Halos reduce contrast changes on stars and surrounding halos when working with Stars Present images.",
      "",
      "What are the Advanced controls for?",
      "Advanced controls tune the behavior behind the main sliders for the current session. Scale controls adjust the size of structures targeted by Texture, Clarity, and Dehaze. Clarity Response controls how early Product Clarity opens up useful midtone and dust-lane structure. Dehaze controls tune veil strength and bright protection. Protection Strength makes enabled protections more open or more conservative.",
      "",
      "Does opening Advanced change the image?",
      "No. Opening Advanced does not change output. Only moving an Advanced control changes behavior. Defaults returns the active Advanced tab to the standard settings. Advanced values are active for the current run and are stored with committed local edits, but they are not silently saved as future application defaults.",
      "",
      "Why does ACE warn about display size or scaling?",
      "ACE uses one supported interface layout with a 1360 x 780 logical-pixel minimum based on the compact layout target developed for Astro Color Mixer. On Windows, ACE follows the Astro Color Mixer Compact sizing rule: use the compact minimum on constrained displays, or use extra available workspace up to the compact cap while preserving margins. ACE can be enlarged, and a preferred window arrangement can be saved, but ACE does not include separate Standard, Compact, or Small-Screen interface variants.",
      "",
      "On Windows systems using high display scaling, the physical display resolution may not reflect the actual workspace available to ACE. For example, a high-resolution laptop running at 200-250% scaling may provide much less usable application space than expected.",
      "",
      "If ACE detects that the available logical workspace is below its supported minimum, it will show a display warning. For best results, maximize the ACE window, use a larger external display, or reduce Windows display scaling if that remains comfortable for normal use.",
      "",
      "What view should I use while adjusting?",
      "Preview shows the protected contrast result. Texture and Clarity show scale maps. Dehaze shows a broad smooth veil estimate; it is expected to look low-frequency rather than detailed. Delta shows the luminance change. Lasso, Star, and Edit Area show specific masks or edit regions when available.",
      "",
      "Why does ACE show detail pending at 200%?",
      "At 200% and higher, ACE may request a native detail crop so local contrast decisions are based on source-detail data instead of only the draft preview. While that detail crop is processing, ACE may show a responsive protected draft/proxy preview. The final Commit and full-resolution output still use the faithful protected processing path.",
      "",
      "Why are some view buttons disabled?",
      "Some views are only meaningful in certain modes. Star view is unavailable in Starless mode. Lasso view is unavailable until a lasso exists. Delta is unavailable when there is no adjustment to compare.",
      "",
      "What does Save Current Mask do?",
      "Save Current Mask saves the current diagnostic view as a new image. In Texture, Clarity, Dehaze, or Delta view it saves the current diagnostic map. In Lasso, Star, or Edit Area view it saves the corresponding mask.",
      "",
      "How do I save the processed result?",
      "Save New Image creates a new full-resolution processed image. Apply to Target writes the full-resolution result back to the selected target image. Save Current Mask saves a diagnostic image, not the processed image.",
      "",
      "Does the final output use preview data?",
      "No. The preview is for interaction. Save New Image and Apply to Target rebuild the result from the original full-resolution source data using the current global settings and committed local edits.",
      "",
      "What should I watch for?",
      "Watch stars, halos, backgrounds, and faint nebulosity. If stars look harsh, use Stars Present mode and stronger protection. If backgrounds look dirty, reduce Clarity or Dehaze, increase Protection Strength, or use Local Selection.",
      "",
      "What is the best way to use this tool?",
      "Use it visually and gradually. Make small global adjustments, inspect the diagnostic views when needed, then use Local Selection for regions that need special treatment. Save a new image when you are satisfied."
   ];
}

function aceTechnicalDocument() {
   return [
      "ASTRO CONTRAST ENHANCER TECHNICAL APPENDIX",
      "Version " + ACE_VERSION,
      "",
      "1. Overview",
      "Astro Contrast Enhancer performs protected local contrast adjustments on RGB astrophotography images. The tool separates contrast work into three user-facing adjustment families:",
      "  - Texture: fine-scale local contrast",
      "  - Clarity: mid-scale local contrast",
      "  - Dehaze: broad veil reduction or haze add-back",
      "",
      "The tool is designed for visual control. It is not a general sharpening tool and it is not intended to replace deconvolution, denoising, or star-processing tools. Its purpose is to help shape contrast at meaningful spatial scales while reducing the risk of damage to stars, halos, smooth backgrounds, and low-confidence regions.",
      "",
      "2. How ACE Fits into PixInsight",
      "Astro Contrast Enhancer is an interactive protected contrast-editing environment for PixInsight, designed for late-stage contrast shaping of stretched astrophotography images.",
      "",
      "PixInsight already includes excellent technical contrast tools, including LocalHistogramEqualization, HDRMultiscaleTransform, CurvesTransformation, HistogramTransformation, MultiscaleLinearTransform, MultiscaleMedianTransform, masks, PixelMath, and many custom workflows. ACE does not replace those tools.",
      "",
      "ACE is different in workflow and intent. It is designed as a late-stage visual finishing environment: a place to shape fine detail, midtone depth, and broad veil with real-time preview, protection, and local editing. Expert users can reproduce many contrast effects with masks and multiscale workflows, but ACE makes a common class of finishing adjustments faster, more direct, and more protected.",
      "",
      "Texture sharpens the surface. Clarity opens the structure. Dehaze lifts the veil.",
      "",
      "Three contrast scales:",
      "  - Texture works on fine detail. It enhances crisp structure such as wisps, ridges, filaments, small dust edges, and delicate texture. It is protected fine-scale contrast, not traditional sharpening.",
      "  - Clarity works on midtone structure. It opens depth in nebulae, galaxies, and dust lanes while protecting bright saturated regions from flattening or overexpansion.",
      "  - Dehaze works on broad veil and tonal/color separation. It reduces broad wash and restores depth using protected tone and color correction without simply crushing the background.",
      "",
      "Comparison to PixInsight processes:",
      "  - LocalHistogramEqualization is powerful for local contrast, but it can be parameter-sensitive and often benefits from careful masking. ACE provides a more direct photographer-style approach for fine detail, midtone depth, and broad veil reduction with built-in protections.",
      "  - HDRMultiscaleTransform is excellent for high-dynamic-range compression and structural recovery. ACE is not an HDR replacement; it is a finishing-stage contrast environment for shaping texture, clarity, and veil interactively.",
      "  - MultiscaleLinearTransform and MultiscaleMedianTransform provide deep technical control over scale-based processing. ACE packages common late-stage contrast goals into intuitive controls with real-time preview and protection.",
      "  - CurvesTransformation is essential for global tone and color shaping. ACE complements Curves by adding protected local and multiscale contrast behavior, plus lasso-based local editing.",
      "  - Expert mask workflows can target nearly any adjustment. ACE makes many local contrast edits faster by combining selection, feathering, protection, preview, and commit into one interactive workflow.",
      "",
      "Built-in protection:",
      "Astrophotography contrast work is risky because the structures we want to enhance are mixed with stars, background sky, high-saturation nebulosity, and low-signal regions. ACE is designed around protection. Its goal is not simply to increase contrast, but to do so while protecting stars, background sky, bright structures, and local edit boundaries.",
      "",
      "ACE protection includes star protection, background protection, highlight and bright-structure protection, selection background-uniformity safeguards, local sky-floor behavior, and the project artifact-safe operation standard.",
      "",
      "Local lasso editing:",
      "One of ACE's most distinctive features is its lasso-based local edit workflow. Instead of building a separate mask, applying a process, undoing, retuning the mask, and trying again, ACE allows the user to select a region, feather the edge, apply Texture, Clarity, or Dehaze locally, preview the result, and commit the edit when satisfied. Star and background protection remain active during local edits.",
      "",
      "ACE brings protected local contrast editing to PixInsight without requiring a separate mask-building workflow for every adjustment.",
      "",
      "When to use ACE:",
      "ACE is best used late in the workflow, after the image is stretched and substantially developed. Typical uses include adding final crispness to nebular structure, opening midtones in a galaxy or nebula, reducing broad veil in a flat image, adding depth to a selected region, refining local areas without leaving PixInsight, and performing local contrast edits without building a custom mask stack.",
      "",
      "What ACE is not:",
      "ACE is not a one-click magic enhancer. It is not a replacement for all PixInsight contrast tools, expert mask-driven workflows, calibration, or linear preprocessing. It is mainly a finishing-stage contrast shaping tool.",
      "",
      "Reusable positioning summary:",
      "ACE is not just another local contrast process. It is an interactive protected contrast-editing environment for PixInsight. It separates contrast into Texture, Clarity, and Dehaze; protects stars and background sky; and adds lasso-based local editing for late-stage astrophotography refinement.",
      "",
      "3. Preview and Full-Resolution Output",
      "The preview pipeline is optimized for interaction. The source RGB image is converted into a preview working representation, and reusable caches are built from luminance, scale layers, protection masks, lasso weights, and Dehaze support maps.",
      "",
      "Interactive slider changes update the draft preview first. This keeps the tool responsive while the user is exploring settings.",
      "",
      "For lasso edits at inspection zooms, ACE can also request a native source-detail crop. The crop is bounded to the visible lasso/edit area and composited into the preview. This allows 200% and higher zoom levels to show detail from the source data without replacing the whole viewport.",
      "",
      "When native detail is pending, ACE may display a protected source-informed proxy so the user sees a responsive indication of the adjustment. This proxy is display-only. Commit, Before/After, Save New Image, and Apply to Target use the faithful protected processing path.",
      "",
      "Full-resolution output does not upscale the preview. Save New Image and Apply to Target rebuild the result from the original full-resolution source data using the current global settings and committed local edit recipe.",
      "",
      "Conceptually:",
      "  source image",
      "  + global Texture / Clarity / Dehaze settings",
      "  + committed Local Selection edits",
      "  + protection settings",
      "  + Advanced settings",
      "  = full-resolution output",
      "",
      "4. Texture Computation",
      "Texture is a fine-scale local contrast adjustment. At a high level, Texture is based on a fine luminance residual:",
      "  Texture layer ~= luminance - blur(luminance, texture radius)",
      "",
      "The Texture slider controls the strength of this fine-scale residual. Texture Scale controls the radius used to define the fine-detail scale.",
      "",
      "Texture is useful for small wisps, filaments, dust texture, and delicate fine structure. Star and highlight protections reduce Texture influence in regions where fine-scale contrast could damage stars or make noise more visible.",
      "",
      "5. Clarity Computation",
      "Clarity is a mid-scale local contrast adjustment. At a high level, Clarity is based on a broader luminance residual:",
      "  Clarity layer ~= luminance - blur(luminance, clarity radius)",
      "",
      "The Clarity slider controls the strength of this mid-scale residual. Clarity Scale controls the size of the structures affected.",
      "",
      "Clarity is useful for nebula folds, dust lanes, galaxy detail, and broad but structured features. Dark-patch prevention and sky/background protection reduce negative deltas in regions where aggressive local contrast could create dirty backgrounds or unnatural dark holes.",
      "",
      "6. Dehaze Computation",
      "Dehaze uses an astro-safe veil-reduction model rather than a simple large-scale contrast residual.",
      "",
      "The goal is to reduce broad veil, wash, or haze-like flatness while protecting stars, highlights, and compact bright structures.",
      "",
      "At a high level, the positive Dehaze path uses:",
      "  - luminance estimation",
      "  - compact/highlight suppression before veil estimation",
      "  - broad veil-field estimation",
      "  - haze/veil confidence",
      "  - highlight and compact-source protection",
      "  - controlled luminance correction",
      "  - optional conservative color restoration, if enabled internally",
      "",
      "Conceptually:",
      "  cleaned luminance = luminance with compact/highlight structures softened",
      "  veil field = broad smooth estimate of low-frequency wash",
      "  allowed Dehaze = veil confidence * protection weights",
      "  Dehaze delta = protected veil reduction and broad-detail restoration",
      "",
      "Dehaze Scale changes the broad veil field scale. Veil Strength changes how strongly the estimated veil participates in positive Dehaze. Highlight Guard changes how strongly bright nebulosity, highlights, and star cores are protected from positive Dehaze and Clarity lift.",
      "",
      "Dehaze map semantics:",
      "  Bright = stronger estimated broad veil / haze field",
      "  Dark = weaker estimated broad veil / haze field",
      "  The map is intentionally smooth and low-frequency. It is not a star mask, lasso mask, or allowed/protected mask.",
      "",
      "7. Negative Dehaze",
      "Negative Dehaze adds a broad haze or veil character instead of reducing it. This can be useful when the image has been pushed too hard or when a softer presentation is desired.",
      "",
      "The negative path is kept smooth to avoid imprinting mask artifacts or harsh local structure into the image.",
      "",
      "8. Protection System",
      "The protection system controls where a raw contrast delta is allowed to affect the image.",
      "",
      "Protection combines several weights, including:",
      "  - sky/background confidence",
      "  - dark-patch prevention",
      "  - star protection",
      "  - halo protection",
      "  - highlight protection",
      "  - compact-source Dehaze protection",
      "  - lasso weight, when Local Selection is active",
      "",
      "Conceptually:",
      "  protected delta = raw delta * allowed weight",
      "  output luminance = luminance + protected delta",
      "",
      "White or bright mask values generally indicate areas where adjustment is allowed. Dark values indicate protected areas. Gray values indicate partial allowance.",
      "",
      "Protection Strength is a high-level Advanced control for enabled protections. It does not replace the right-panel protection checkboxes. The checkboxes decide which protection families are active. Protection Strength controls how conservative the active protections are.",
      "",
      "9. Local Selection",
      "Local Selection creates a feathered lasso weight map.",
      "",
      "In normal lasso mode:",
      "  inside lasso = active",
      "  outside lasso = protected",
      "  feather zone = smooth transition",
      "",
      "In inverted lasso mode:",
      "  outside lasso = active",
      "  inside lasso = protected",
      "  feather zone = smooth transition",
      "",
      "Feather / Roll-off controls the width of the transition.",
      "",
      "Committed local edits store the lasso geometry, feather value, invert state, slider values, protection settings, Advanced settings, and algorithm version. This allows full-resolution output to replay the edit consistently.",
      "",
      "10. Advanced Controls",
      "Advanced controls are intentionally curated. They expose the most useful expert adjustments without turning the tool into an engineering control panel.",
      "",
      "Scale tab:",
      "  - Texture Scale controls fine-detail radius.",
      "  - Clarity Scale controls mid-scale radius.",
      "  - Dehaze Scale controls the broad Dehaze veil field.",
      "",
      "Clarity tab:",
      "  - Clarity Response offers Light, Balanced, and Strong Product Clarity response. Balanced is the release default. Strong opens galaxy and dust-lane response earlier while retaining star and highlight protection.",
      "",
      "Dehaze tab:",
      "  - Veil Strength controls the strength of estimated veil reduction.",
      "  - Highlight Guard controls how strongly bright nebulosity, highlights, and star cores are protected from Dehaze and positive Clarity lift.",
      "",
      "Protection tab:",
      "  - Protection Strength controls how conservative enabled protections are.",
      "",
      "Opening Advanced does not change the image. Moving an Advanced control changes behavior. Defaults restores the active tab to the standard settings. Advanced values remain active while you work and are stored with committed local edits. They are not saved as future application defaults unless a dedicated preset/default feature is added later.",
      "",
      "11. Diagnostic Views",
      "The preview toolbar provides several diagnostic views.",
      "",
      "Preview:",
      "Shows the protected contrast result.",
      "",
      "Texture:",
      "Shows the fine-scale Texture map when available.",
      "",
      "Clarity:",
      "Shows the mid-scale Clarity map when available.",
      "",
      "Dehaze:",
      "Shows the broad Dehaze veil estimate. Bright areas indicate more estimated veil or haze. Dark areas indicate less estimated veil. This diagnostic is expected to be smooth.",
      "",
      "Delta:",
      "Shows the luminance change caused by the current adjustment.",
      "",
      "Lasso:",
      "Shows the lasso selection mask when a lasso exists.",
      "",
      "Star:",
      "Shows star or halo protection when available.",
      "",
      "Edit Area:",
      "Shows the active local edit area or related allowed region when available.",
      "",
      "Some views are disabled when they are not meaningful in the current mode.",
      "",
      "12. Full-Resolution Output",
      "Save New Image and Apply to Target generate full-resolution output from the original source image and the current edit recipe.",
      "",
      "The output engine uses optimized full-resolution rendering. Global adjustment state is applied once. Committed local edits are replayed in order. Lasso edits are processed using image-coordinate geometry and appropriate bounding regions where possible.",
      "",
      "The output recipe includes:",
      "  - source identity",
      "  - global adjustment values",
      "  - curated Advanced settings",
      "  - protection options",
      "  - committed local edits",
      "  - lasso geometry and feather values",
      "  - algorithm version",
      "",
      "Preview data is not used as final output.",
      "",
      "13. Console Output",
      "Normal PixInsight console output is intentionally concise. It reports user-facing progress, final output timing, warnings, validation results, and explicit audit reports. Development timing diagnostics for source loading, draft proxies, native detail crops, lasso commit stages, and cache reuse are hidden unless development logging or debug controls are enabled.",
      "",
      "14. Release Notes for " + ACE_VERSION,
      "Current build focus:",
      "  - Responsive global native-detail crops are no longer painted as rectangular patches over the main preview; global capped detail remains internal responsive work.",
      "  - This release package includes a 24x24 PNG script icon resource and #feature-icon metadata so PixInsight can test loading the ACE menu icon.",
      "  - Product Texture, Clarity, and Dehaze are protected contrast controls with Stars Present / Starless input modes.",
      "  - Local Selection supports lasso drawing, move, invert, feather, refine, expand, contract, cancel, undo, redo, and commit.",
      "  - At 200% and above, lasso work can use native detail crops so common inspection zooms show source-detail contrast instead of only low-resolution draft pixels.",
      "  - While native detail is still pending, ACE can show a responsive protected source-informed preview proxy; Commit and Before/After continue to use the faithful protected result.",
      "  - Native detail, lasso geometry, slider changes, Before/After, and commit now use guarded state transitions to avoid stale crops and half-settled selections.",
      "  - Local Commit fast-paths current pending protected previews and falls back to a final protected rebuild only when state changed.",
      "  - Advanced > Clarity Response adds Light, Balanced, and Strong Product Clarity behavior for targets that need more or less midtone/dust-lane response.",
      "  - Full-resolution Save New Image and Apply to Target rebuild from the original source data and committed edit recipe; preview caps do not limit final output.",
      "  - Normal console output is limited to user-facing progress, output timing, warnings, validation, and explicit audit reports. Development timing diagnostics are hidden unless development logging is enabled.",
      "  - ACE uses one supported 1360 x 780 logical-pixel minimum layout with saved window size/position support and Display Diagnostics for support."
   ];
}

function aceAboutDocument() {
   return [
      ACE_TOOL_NAME + " " + ACE_VERSION,
      "",
      "Developed by Patrick A. Cosgrove for Cosgrove's Cosmos.",
      "Copyright \u00A9 2026 Patrick A. Cosgrove. All rights reserved.",
      "",
      "Website:",
      "https://cosgrovescosmos.com/",
      "",
      "Astro Contrast Enhancer is part of the Cosgrove's Cosmos utility family for astrophotography processing in PixInsight.",
      "",
      "It provides a compact, visual workflow for protected local contrast enhancement using Texture, Clarity, and Dehaze controls.",
      "",
      "Release highlights:",
      "  - Preview-first protected Texture, Clarity, and Dehaze workflow.",
      "  - Texture uses the Hybrid Light path with a -100 to +100 product slider range.",
      "  - Clarity uses the lead DualZone +DZBoost path with stronger positive response and stronger local-selection response.",
      "  - Dehaze uses the protected tone/color path and a smooth broad-veil diagnostic map.",
      "  - Diagnostic views for scale maps, delta, lasso masks, star protection, and edit areas.",
      "  - Stars Present and Starless input modes.",
      "  - Sky, star, halo, and dark-patch protection.",
      "  - Native detail-crop previews at 200% and higher when source data is available.",
      "  - Responsive protected source-proxy display while native local detail is pending.",
      "  - Minimum Local Selection geometry checks to prevent tiny or collapsed lasso shapes.",
      "  - Local Selection with lasso-centered zoom, invert, and feathered roll-off.",
      "  - Fast-path local Commit when the pending protected preview is already current.",
      "  - Feather / Roll-off default 75 px and maximum 150 px.",
      "  - Roomier Advanced controls with visible helper graphs for scale, Dehaze response, and Protection Strength.",
      "  - Startup warning when operating-system display scaling leaves less than the supported 1360 x 780 workspace.",
      "  - Center-screen startup cache-building message while the first preview response is prepared.",
      "  - Debug-only internal algorithm selectors hidden in normal use.",
      "  - Full-resolution Save New Image, Apply to Target, and Save Current Mask output.",
      "  - Deferred active-image startup load so the shell appears before preview work begins.",
      "  - Center-screen target loading message while preview caches are built.",
      "  - Scrollable in-app FAQ, Technical Appendix, and About documentation.",
      "",
      "This build reflects the intended product direction: a compact, practical, visual contrast tool rather than an engineering control panel."
   ];
}

function aceSetLabel(label, text, bold, color) {
   label.text = String(text || "");
   label.textColor = color || ACE_COLORS.text;
   label.foregroundColor = color || ACE_COLORS.text;
   var font = new Font;
   font.pixelSize = bold ? ACE_FONT_BOLD : ACE_FONT_BODY;
   font.bold = !!bold;
   label.font = font;
}

function acePaintPanel(control, fill, border) {
   control.aceFill = fill || ACE_COLORS.panel;
   control.aceBorder = border || ACE_COLORS.lineDim;
   control.onPaint = function() {
      var g = new Graphics(this);
      g.brush = new Brush(this.aceFill);
      g.pen = new Pen(this.aceBorder);
      g.drawRect(this.boundsRect);
      g.end();
   };
}

function acePaintGroupBox(control, fill, border) {
   control.aceFill = fill || ACE_COLORS.headerDark;
   control.aceBorder = border || ACE_COLORS.sectionTitle;
   control.onPaint = function() {
      var g = new Graphics(this);
      g.brush = new Brush(this.aceFill);
      g.pen = new Pen(this.aceBorder, 1);
      g.drawRect(new Rect(1, 1, Math.max(1, this.width - 2), Math.max(1, this.height - 2)));
      g.end();
   };
}

function acePaintEnhancementControlBay(control, dialog) {
   control.aceDialog = dialog || null;
   control.onPaint = function() {
      var active = false;
      var d = this.aceDialog;
      if (d && d.appState && d.appState.params)
         active = d.appState.params.texture !== 0 || d.appState.params.clarity !== 0 || d.appState.params.dehaze !== 0;
      var g = new Graphics(this);
      var w = Math.max(1, this.width);
      var h = Math.max(1, this.height);
      g.brush = new Brush(ACE_COLORS.controlBayBlueDeep);
      g.pen = new Pen(0x00303846);
      g.drawRect(this.boundsRect);
      g.brush = new Brush(0x661b3b59);
      g.drawRect(new Rect(1, 1, w - 1, Math.max(2, Math.round(h * 0.52))));
      g.brush = new Brush(0x3a1b3b59);
      g.drawRect(new Rect(Math.round(w * 0.26), 2, w - 2, Math.max(3, Math.round(h * 0.78))));
      g.brush = new Brush(0x2a284b6d);
      g.drawRect(new Rect(Math.round(w * 0.48), Math.round(h * 0.10), w - 3, Math.max(4, Math.round(h * 0.68))));
      var diagonalStep = 18;
      for (var dg = -h; dg < w; dg += diagonalStep) {
         var alpha = active ? 0x36 : 0x2a;
         var color = (alpha << 24) | (ACE_COLORS.controlBayBlueMid & 0x00ffffff);
         g.pen = new Pen(color, 3);
         g.drawLine(dg, h - 2, dg + h, 2);
      }
      for (var gl = -Math.round(h * 0.5); gl < w; gl += diagonalStep * 2) {
         g.pen = new Pen(active ? 0x36ffc24a : 0x224a6375, 1);
         g.drawLine(gl, h - 4, gl + h, 4);
      }
      g.brush = new Brush(0x26000000 | (ACE_COLORS.controlBayGlow & 0x00ffffff));
      g.drawRect(new Rect(4, Math.round(h * 0.13), Math.max(5, w - 4), Math.round(h * 0.60)));
      g.brush = new Brush(0x52050b11);
      g.drawRect(new Rect(2, Math.max(2, h - Math.round(h * 0.18)), Math.max(3, w - 2), Math.max(3, h - 2)));
      g.pen = new Pen((active ? 0xd8000000 : 0xb0000000) | (ACE_COLORS.controlBayGoldBorder & 0x00ffffff), 1);
      g.drawRect(new Rect(1, 1, Math.max(2, w - 1), Math.max(2, h - 1)));
      g.pen = new Pen(active ? 0x78ffe3a0 : 0x52ffc24a, 1);
      g.drawRect(new Rect(2, 2, Math.max(3, w - 2), Math.max(3, h - 2)));
      g.pen = new Pen(active ? 0xb0ffe3a0 : 0x78ffc24a, 1);
      g.drawLine(3, 2, Math.max(3, w - 4), 2);
      g.pen = new Pen(0x344a6375, 1);
      g.drawLine(3, 3, Math.max(3, w - 4), 3);
      g.pen = new Pen(active ? 0x3ab99734 : 0x26344553, 1);
      g.drawLine(3, Math.max(3, h - 3), Math.max(3, w - 4), Math.max(3, h - 3));
      g.pen = new Pen(0x6a1c2a35, 1);
      g.drawLine(8, Math.round(h * 0.34), Math.max(8, w - 8), Math.round(h * 0.34));
      g.pen = new Pen(0x581c2a35, 1);
      g.drawLine(8, Math.round(h * 0.66), Math.max(8, w - 8), Math.round(h * 0.66));
      g.end();
   };
}

function aceFixHeight(control, height) {
   control.scaledMinHeight = height;
   control.maxHeight = height;
   if (typeof control.setFixedHeight === "function")
      control.setFixedHeight(height);
}

function aceSetCollapsed(control, collapsed) {
   if (!control)
      return;
   if (control.aceExpandedScaledMinHeight !== undefined)
      control._aceExpandedScaledMinHeight = control.aceExpandedScaledMinHeight;
   if (control.aceExpandedMaxHeight !== undefined)
      control._aceExpandedMaxHeight = control.aceExpandedMaxHeight;
   if (control._aceExpandedScaledMinHeight === undefined)
      control._aceExpandedScaledMinHeight = control.scaledMinHeight || 1;
   if (control._aceExpandedMaxHeight === undefined)
      control._aceExpandedMaxHeight = control.maxHeight || 100000;
   control.visible = !collapsed;
   control.scaledMinHeight = collapsed ? 0 : control._aceExpandedScaledMinHeight;
   control.maxHeight = collapsed ? 0 : control._aceExpandedMaxHeight;
}

function aceTryLoadBitmap(path) {
   try {
      return new Bitmap(path);
   } catch (error) {
      return null;
   }
}

function aceTryLoadFirstBitmap(paths) {
   for (var i = 0; i < paths.length; ++i) {
      var bitmap = aceTryLoadBitmap(paths[i]);
      if (bitmap)
         return bitmap;
   }
   return null;
}

function aceClamp(value, minValue, maxValue) {
   return Math.min(maxValue, Math.max(minValue, value));
}

function aceClamp01(value) {
   return aceClamp(value, 0, 1);
}

function aceRefreshNow(control) {
   if (!control)
      return;
   control.update();
   if (typeof control.repaint === "function")
      control.repaint();
   if (typeof CoreApplication !== "undefined" && typeof CoreApplication.processEvents === "function")
      CoreApplication.processEvents();
}

function aceGetFitScale(panelWidth, panelHeight, bitmapWidth, bitmapHeight) {
   var usableWidth = Math.max(1, panelWidth - 8);
   var usableHeight = Math.max(1, panelHeight - 8);
   return Math.min(usableWidth / Math.max(1, bitmapWidth), usableHeight / Math.max(1, bitmapHeight));
}

function aceGetViewportRectForScale(panelWidth, panelHeight, bitmapWidth, bitmapHeight, scale, panX, panY) {
   var targetWidth = Math.max(1, Math.round(bitmapWidth * scale));
   var targetHeight = Math.max(1, Math.round(bitmapHeight * scale));
   var x = Math.round((panelWidth - targetWidth) * 0.5 + panX);
   var y = Math.round((panelHeight - targetHeight) * 0.5 + panY);
   return new Rect(x, y, x + targetWidth, y + targetHeight);
}

function aceGetVisibleBitmapRectForScale(panelWidth, panelHeight, bitmapWidth, bitmapHeight, scale, panX, panY) {
   var viewportRect = aceGetViewportRectForScale(panelWidth, panelHeight, bitmapWidth, bitmapHeight, scale, panX, panY);
   var left = aceClamp((0 - viewportRect.x0) / Math.max(ACE_EPSILON, scale), 0, bitmapWidth);
   var top = aceClamp((0 - viewportRect.y0) / Math.max(ACE_EPSILON, scale), 0, bitmapHeight);
   var right = aceClamp((panelWidth - viewportRect.x0) / Math.max(ACE_EPSILON, scale), 0, bitmapWidth);
   var bottom = aceClamp((panelHeight - viewportRect.y0) / Math.max(ACE_EPSILON, scale), 0, bitmapHeight);
   return {
      x0: left,
      y0: top,
      x1: right,
      y1: bottom,
      width: Math.max(0, right - left),
      height: Math.max(0, bottom - top)
   };
}

function aceFindWindowForViewId(viewId) {
   if (!viewId || !ImageWindow.windows)
      return null;
   for (var i = 0; i < ImageWindow.windows.length; ++i) {
      var win = ImageWindow.windows[i];
      if (!win || win.isNull)
         continue;
      if (win.currentView && !win.currentView.isNull && (win.currentView.fullId === viewId || win.currentView.id === viewId))
         return win;
      if (win.mainView && !win.mainView.isNull && (win.mainView.fullId === viewId || win.mainView.id === viewId))
         return win;
   }
   return null;
}

function aceFindViewForViewId(viewId) {
   var win = aceFindWindowForViewId(viewId);
   if (!win || win.isNull)
      return null;
   if (win.currentView && !win.currentView.isNull && (win.currentView.fullId === viewId || win.currentView.id === viewId))
      return { window: win, view: win.currentView };
   if (win.mainView && !win.mainView.isNull)
      return { window: win, view: win.mainView };
   return null;
}

function aceBaseSourceIdForGeneratedAceOutput(viewId) {
   viewId = String(viewId || "");
   var marker = viewId.indexOf("_ACE");
   if (marker <= 0)
      return "";
   var suffix = viewId.substr(marker);
   if (suffix !== "_ACE" && suffix.indexOf("_ACE_") !== 0)
      return "";
   return viewId.substr(0, marker);
}

function aceResolveStartupSourceView(view) {
   if (!view || view.isNull)
      return null;
   var viewId = view.fullId || view.id;
   var baseId = aceBaseSourceIdForGeneratedAceOutput(viewId);
   if (baseId) {
      var base = aceFindViewForViewId(baseId);
      if (base && base.view)
         return base.view;
   }
   return view;
}

function aceResolveSelectedSourceView(view) {
   return aceResolveStartupSourceView(view);
}

function aceListOpenRgbViews() {
   var views = [];
   var seen = {};
   if (!ImageWindow.windows)
      return views;
   for (var i = 0; i < ImageWindow.windows.length; ++i) {
      var win = ImageWindow.windows[i];
      if (!win || win.isNull || !win.mainView || win.mainView.isNull)
         continue;
      var view = win.mainView;
      var image = view.image;
      if (!image || image.numberOfChannels < 3 || !image.isColor)
         continue;
      var id = view.fullId || view.id;
      if (!id || seen[id])
         continue;
      seen[id] = true;
      views.push({ id: id, width: image.width, height: image.height });
   }
   return views;
}

function aceStartupImageAvailabilityMessage() {
   var totalWindows = ImageWindow.windows ? ImageWindow.windows.length : 0;
   if (totalWindows <= 0)
      return "Astro Contrast Enhancer needs an open RGB/color image. Open a stretched RGB image in PixInsight, select its view, then run ACE again.";
   return "Astro Contrast Enhancer found open PixInsight image windows, but none are RGB/color images. Open or select an RGB/color image, then run ACE again.";
}

function aceStartupHasRgbImage() {
   return aceListOpenRgbViews().length > 0;
}

function aceReportStartupImageUnavailable() {
   var message = aceStartupImageAvailabilityMessage();
   if (typeof console !== "undefined" && console && typeof console.writeln === "function")
      console.writeln("[ACE] Startup cancelled | " + message);
   aceMessage(message, ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
}

function aceReadRgbImageFromView(view) {
   if (!view || view.isNull)
      throw new Error("No active image. Open an image and select its view.");
   var image = view.image;
   if (!image || image.numberOfChannels < 3 || !image.isColor)
      throw new Error("The active image is not an RGB/color image.");

   var width = image.width;
   var height = image.height;
   var count = width * height;
   var rect = new Rect(0, 0, width, height);
   var r = new Float32Array(count);
   var g = new Float32Array(count);
   var b = new Float32Array(count);
   image.getSamples(r, rect, 0);
   image.getSamples(g, rect, 1);
   image.getSamples(b, rect, 2);

   var rgb = new Float32Array(count * 3);
   for (var i = 0; i < count; ++i) {
      var base = i * 3;
      rgb[base] = r[i];
      rgb[base + 1] = g[i];
      rgb[base + 2] = b[i];
   }

   return { viewId: view.fullId || view.id, width: width, height: height, rgb: rgb };
}

function aceReadActiveRgbImage() {
   var activeWindow = ImageWindow.activeWindow;
   if (!activeWindow || activeWindow.isNull)
      throw new Error("No active image. Open an image and select its view.");
   return aceReadRgbImageFromView(aceResolveStartupSourceView(activeWindow.currentView));
}

function aceReadRgbCropFromView(view, cropRect) {
   if (!view || view.isNull)
      throw new Error("Source image is no longer available.");
   var image = view.image;
   if (!image || image.numberOfChannels < 3 || !image.isColor)
      throw new Error("The source image is not an RGB/color image.");

   var x0 = aceClamp(Math.floor(cropRect.x0), 0, image.width - 1);
   var y0 = aceClamp(Math.floor(cropRect.y0), 0, image.height - 1);
   var x1 = aceClamp(Math.ceil(cropRect.x1), x0 + 1, image.width);
   var y1 = aceClamp(Math.ceil(cropRect.y1), y0 + 1, image.height);
   var width = Math.max(1, x1 - x0);
   var height = Math.max(1, y1 - y0);
   var count = width * height;
   var rect = new Rect(x0, y0, x1, y1);
   var r = new Float32Array(count);
   var g = new Float32Array(count);
   var b = new Float32Array(count);
   image.getSamples(r, rect, 0);
   image.getSamples(g, rect, 1);
   image.getSamples(b, rect, 2);

   var rgb = new Float32Array(count * 3);
   for (var i = 0; i < count; ++i) {
      var base = i * 3;
      rgb[base] = r[i];
      rgb[base + 1] = g[i];
      rgb[base + 2] = b[i];
   }

   return { x0: x0, y0: y0, x1: x1, y1: y1, width: width, height: height, rgb: rgb };
}

function aceCropRgbBuffer(rgb, width, height, x0, y0, cropWidth, cropHeight) {
   x0 = aceClamp(Math.floor(x0), 0, Math.max(0, width - 1));
   y0 = aceClamp(Math.floor(y0), 0, Math.max(0, height - 1));
   cropWidth = Math.max(1, Math.min(Math.floor(cropWidth), width - x0));
   cropHeight = Math.max(1, Math.min(Math.floor(cropHeight), height - y0));
   var out = new Float32Array(cropWidth * cropHeight * 3);
   for (var y = 0; y < cropHeight; ++y) {
      var srcRow = (y0 + y) * width;
      var dstRow = y * cropWidth;
      for (var x = 0; x < cropWidth; ++x) {
         var src = (srcRow + x0 + x) * 3;
         var dst = (dstRow + x) * 3;
         out[dst] = rgb[src];
         out[dst + 1] = rgb[src + 1];
         out[dst + 2] = rgb[src + 2];
      }
   }
   return out;
}

function aceCropGrayBuffer(gray, width, height, x0, y0, cropWidth, cropHeight) {
   if (!gray)
      return null;
   x0 = aceClamp(Math.floor(x0), 0, Math.max(0, width - 1));
   y0 = aceClamp(Math.floor(y0), 0, Math.max(0, height - 1));
   cropWidth = Math.max(1, Math.min(Math.floor(cropWidth), width - x0));
   cropHeight = Math.max(1, Math.min(Math.floor(cropHeight), height - y0));
   var out = new Float32Array(cropWidth * cropHeight);
   for (var y = 0; y < cropHeight; ++y) {
      var srcRow = (y0 + y) * width;
      var dstRow = y * cropWidth;
      for (var x = 0; x < cropWidth; ++x)
         out[dstRow + x] = gray[srcRow + x0 + x];
   }
   return out;
}

function aceWriteGrayRect(width, height, gray, rect, regionGray) {
   if (!gray || !regionGray || !rect)
      return;
   var rw = rect.x1 - rect.x0;
   var rh = rect.y1 - rect.y0;
   for (var y = 0; y < rh; ++y) {
      var dstBase = (rect.y0 + y) * width + rect.x0;
      var srcBase = y * rw;
      for (var x = 0; x < rw; ++x)
         gray[dstBase + x] = regionGray[srcBase + x];
   }
}

function aceFilledGray(width, height, value) {
   var out = new Float32Array(width * height);
   for (var i = 0; i < out.length; ++i)
      out[i] = value;
   return out;
}

function aceDownsampleRgbAntialias(rgb, width, height, maxEdge) {
   var longest = Math.max(width, height);
   if (longest <= maxEdge)
      return { width: width, height: height, rgb: new Float32Array(rgb), scale: 1 };
   var scale = maxEdge / longest;
   var targetWidth = Math.max(1, Math.round(width * scale));
   var targetHeight = Math.max(1, Math.round(height * scale));
   var invScale = 1 / scale;
   var samplesPerAxis = 4;
   var sampleCount = samplesPerAxis * samplesPerAxis;
   var output = new Float32Array(targetWidth * targetHeight * 3);
   for (var y = 0; y < targetHeight; ++y) {
      var srcY0 = y * invScale;
      var srcY1 = Math.min(height, (y + 1) * invScale);
      for (var x = 0; x < targetWidth; ++x) {
         var srcX0 = x * invScale;
         var srcX1 = Math.min(width, (x + 1) * invScale);
         var sumR = 0;
         var sumG = 0;
         var sumB = 0;
         for (var sy = 0; sy < samplesPerAxis; ++sy) {
            var fy = (sy + 0.5) / samplesPerAxis;
            var srcY = Math.min(height - 1, Math.max(0, Math.floor(srcY0 + (srcY1 - srcY0) * fy)));
            for (var sx = 0; sx < samplesPerAxis; ++sx) {
               var fx = (sx + 0.5) / samplesPerAxis;
               var srcX = Math.min(width - 1, Math.max(0, Math.floor(srcX0 + (srcX1 - srcX0) * fx)));
               var srcBase = (srcY * width + srcX) * 3;
               sumR += rgb[srcBase];
               sumG += rgb[srcBase + 1];
               sumB += rgb[srcBase + 2];
            }
         }
         var dstBase = (y * targetWidth + x) * 3;
         output[dstBase] = sumR / sampleCount;
         output[dstBase + 1] = sumG / sampleCount;
         output[dstBase + 2] = sumB / sampleCount;
      }
   }
   return { width: targetWidth, height: targetHeight, rgb: output, scale: scale };
}

function aceRenderBitmapFromRgb(width, height, rgb) {
   var count = width * height;
   var r = new Float32Array(count);
   var g = new Float32Array(count);
   var b = new Float32Array(count);
   for (var i = 0; i < count; ++i) {
      var base = i * 3;
      r[i] = aceClamp01(rgb[base]);
      g[i] = aceClamp01(rgb[base + 1]);
      b[i] = aceClamp01(rgb[base + 2]);
   }
   var tempImage = new Image(width, height, 3, ColorSpace_RGB, 32, SampleType_Real);
   var rect = new Rect(0, 0, width, height);
   tempImage.setSamples(r, rect, 0);
   tempImage.setSamples(g, rect, 1);
   tempImage.setSamples(b, rect, 2);
   return tempImage.render();
}

function aceRenderBitmapFromGray(width, height, gray) {
   var count = width * height;
   var channel = new Float32Array(count);
   for (var i = 0; i < count; ++i)
      channel[i] = aceClamp01(gray[i]);
   var tempImage = new Image(width, height, 3, ColorSpace_RGB, 32, SampleType_Real);
   var rect = new Rect(0, 0, width, height);
   tempImage.setSamples(channel, rect, 0);
   tempImage.setSamples(channel, rect, 1);
   tempImage.setSamples(channel, rect, 2);
   return tempImage.render();
}

function aceRenderSignedMapBitmap(width, height, signedMap, displayGain) {
   return aceRenderBitmapFromGray(width, height, aceSignedMapToDisplayGray(width, height, signedMap, displayGain));
}

function aceSignedMapToDisplayGray(width, height, signedMap, displayGain) {
   var count = width * height;
   var maxAbs = 0;
   var meanAbs = 0;
   for (var i = 0; i < count; ++i) {
      var a = Math.abs(signedMap[i]);
      maxAbs = Math.max(maxAbs, a);
      meanAbs += a;
   }
   meanAbs /= Math.max(1, count);
   var gain = Math.max(0.25, displayGain || 1);
   var norm = Math.max(1.0e-5, Math.min(maxAbs, Math.max(meanAbs * 8, maxAbs * 0.28)) / gain);
   var gray = new Float32Array(count);
   for (var j = 0; j < count; ++j)
      gray[j] = aceClamp01(0.5 + 0.5 * signedMap[j] / norm);
   return gray;
}

function aceSignedMapStats(width, height, signedMap) {
   var count = width * height;
   var maxAbs = 0;
   var meanAbs = 0;
   var signedMean = 0;
   for (var i = 0; i < count; ++i) {
      var value = signedMap[i];
      var absValue = Math.abs(value);
      if (absValue > maxAbs)
         maxAbs = absValue;
      meanAbs += absValue;
      signedMean += value;
   }
   return {
      maxAbs: maxAbs,
      meanAbs: meanAbs / Math.max(1, count),
      signedMean: signedMean / Math.max(1, count)
   };
}

function aceRenderSignedMapBitmapWithSize(width, height, signedMap) {
   return aceRenderSignedMapBitmap(width, height, signedMap);
}

function acePercentileAbsFloat(data, percentile) {
   if (!data || data.length < 1)
      return 0;
   var count = data.length;
   var sampleLimit = 1000000;
   var stride = Math.max(1, Math.ceil(count / sampleLimit));
   var values = [];
   values.length = Math.ceil(count / stride);
   var n = 0;
   for (var i = 0; i < count; i += stride) {
      var value = Math.abs(data[i]);
      if (isFinite(value))
         values[n++] = value;
   }
   if (n < 1)
      return 0;
   values.length = n;
   values.sort(function(a, b) { return a - b; });
   var index = Math.max(0, Math.min(n - 1, Math.floor((percentile / 100) * (n - 1))));
   return values[index];
}

function acePercentileFloat(data, percentile) {
   if (!data || data.length < 1)
      return 0;
   var count = data.length;
   var sampleLimit = 1000000;
   var stride = Math.max(1, Math.ceil(count / sampleLimit));
   var values = [];
   values.length = Math.ceil(count / stride);
   var n = 0;
   for (var i = 0; i < count; i += stride) {
      var value = data[i];
      if (isFinite(value))
         values[n++] = value;
   }
   if (n < 1)
      return 0;
   values.length = n;
   values.sort(function(a, b) { return a - b; });
   var index = Math.max(0, Math.min(n - 1, Math.floor((percentile / 100) * (n - 1))));
   return values[index];
}

function aceNormalizeFeatureFitField(data) {
   var count = data ? data.length : 0;
   var out = new Float32Array(count);
   if (!data || count < 1)
      return { data: out, center: 0, scale: 0 };
   var center = acePercentileFloat(data, 50.0);
   var deviations = new Float32Array(count);
   for (var i = 0; i < count; ++i)
      deviations[i] = Math.abs(data[i] - center);
   var scale = acePercentileFloat(deviations, 95.0);
   if (scale <= 1.0e-8)
      return { data: out, center: center, scale: scale };
   for (var j = 0; j < count; ++j)
      out[j] = aceClamp((data[j] - center) / scale, -3.0, 3.0);
   return { data: out, center: center, scale: scale };
}

function aceSanitizeImageId(id) {
   id = String(id || "Image").replace(/[^A-Za-z0-9_]/g, "_");
   if (!id.length || !/[A-Za-z]/.test(id.charAt(0)))
      id = "ACE_" + id;
   while (id.indexOf("__") >= 0)
      id = id.replace(/__/g, "_");
   return id;
}

function aceUniqueImageId(baseId) {
   var base = aceSanitizeImageId(baseId);
   var candidate = base;
   var index = 1;
   while (aceFindWindowForViewId(candidate)) {
      candidate = base + "_" + index;
      ++index;
   }
   return candidate;
}

function aceSetRgbImageSamples(image, width, height, rgb) {
   var count = width * height;
   var r = new Float32Array(count);
   var g = new Float32Array(count);
   var b = new Float32Array(count);
   for (var i = 0; i < count; ++i) {
      var base = i * 3;
      r[i] = aceClamp01(rgb[base]);
      g[i] = aceClamp01(rgb[base + 1]);
      b[i] = aceClamp01(rgb[base + 2]);
   }
   var rect = new Rect(0, 0, width, height);
   image.setSamples(r, rect, 0);
   image.setSamples(g, rect, 1);
   image.setSamples(b, rect, 2);
}

function aceSetGrayImageSamples(image, width, height, gray) {
   var count = width * height;
   var channel = new Float32Array(count);
   for (var i = 0; i < count; ++i)
      channel[i] = aceClamp01(gray[i]);
   image.setSamples(channel, new Rect(0, 0, width, height), 0);
}

function aceExtractRgbRect(width, height, rgb, rect) {
   var rw = rect.x1 - rect.x0;
   var rh = rect.y1 - rect.y0;
   var out = new Float32Array(rw * rh * 3);
   for (var y = 0; y < rh; ++y) {
      if ((y & 31) === 0)
         aceYieldToPixInsight();
      var srcBase = ((rect.y0 + y) * width + rect.x0) * 3;
      var dstBase = y * rw * 3;
      for (var x = 0; x < rw * 3; ++x)
         out[dstBase + x] = rgb[srcBase + x];
   }
   return { width: rw, height: rh, rgb: out };
}

function aceWriteRgbRect(width, height, rgb, rect, regionRgb) {
   var rw = rect.x1 - rect.x0;
   var rh = rect.y1 - rect.y0;
   for (var y = 0; y < rh; ++y) {
      if ((y & 31) === 0)
         aceYieldToPixInsight();
      var dstBase = ((rect.y0 + y) * width + rect.x0) * 3;
      var srcBase = y * rw * 3;
      for (var x = 0; x < rw * 3; ++x)
         rgb[dstBase + x] = regionRgb[srcBase + x];
   }
}

function aceLassoBounds(points, width, height, margin) {
   if (!points || points.length < 3)
      return { x0: 0, y0: 0, x1: width, y1: height };
   var minX = width;
   var minY = height;
   var maxX = 0;
   var maxY = 0;
   for (var i = 0; i < points.length; ++i) {
      minX = Math.min(minX, points[i].x);
      minY = Math.min(minY, points[i].y);
      maxX = Math.max(maxX, points[i].x);
      maxY = Math.max(maxY, points[i].y);
   }
   margin = Math.max(0, margin || 0);
   return {
      x0: aceClamp(Math.floor(minX - margin), 0, width - 1),
      y0: aceClamp(Math.floor(minY - margin), 0, height - 1),
      x1: aceClamp(Math.ceil(maxX + margin), 1, width),
      y1: aceClamp(Math.ceil(maxY + margin), 1, height)
   };
}

function aceCreateRgbImageWindow(width, height, rgb, id, showWindow) {
   showWindow = showWindow !== false;
   var windowId = aceUniqueImageId(id);
   var win = new ImageWindow(width, height, 3, 32, true, true, windowId);
   win.mainView.beginProcess();
   try {
      aceSetRgbImageSamples(win.mainView.image, width, height, rgb);
   } finally {
      win.mainView.endProcess();
   }
   if (showWindow)
      win.show();
   return win;
}

function aceCreateGrayImageWindow(width, height, gray, id, showWindow) {
   showWindow = showWindow !== false;
   var windowId = aceUniqueImageId(id);
   var win = new ImageWindow(width, height, 1, 32, true, false, windowId);
   win.mainView.beginProcess();
   try {
      aceSetGrayImageSamples(win.mainView.image, width, height, gray);
   } finally {
      win.mainView.endProcess();
   }
   if (showWindow)
      win.show();
   return win;
}

function aceMessageChoice(text, title) {
   return (new MessageBox(text, title || ACE_TOOL_NAME, StdIcon_Question, StdButton_Yes, StdButton_No, StdButton_Cancel)).execute();
}

function aceLuminanceFromRgb(width, height, rgb) {
   var count = width * height;
   var luminance = new Float32Array(count);
   for (var i = 0; i < count; ++i) {
      if ((i & 131071) === 0)
         aceYieldToPixInsight();
      var base = i * 3;
      luminance[i] = 0.2126 * rgb[base] + 0.7152 * rgb[base + 1] + 0.0722 * rgb[base + 2];
   }
   return luminance;
}

function aceDownsampleFloatAverage(width, height, data, factor) {
   factor = Math.max(1, Math.round(factor || 1));
   if (factor <= 1)
      return { width: width, height: height, data: new Float32Array(data), factor: 1 };
   var outWidth = Math.max(1, Math.ceil(width / factor));
   var outHeight = Math.max(1, Math.ceil(height / factor));
   var output = new Float32Array(outWidth * outHeight);
   for (var y = 0; y < outHeight; ++y) {
      if ((y & 15) === 0)
         aceYieldToPixInsight();
      var y0 = y * factor;
      var y1 = Math.min(height, y0 + factor);
      for (var x = 0; x < outWidth; ++x) {
         var x0 = x * factor;
         var x1 = Math.min(width, x0 + factor);
         var sum = 0;
         var samples = 0;
         for (var yy = y0; yy < y1; ++yy) {
            var row = yy * width;
            for (var xx = x0; xx < x1; ++xx) {
               sum += data[row + xx];
               ++samples;
            }
         }
         output[y * outWidth + x] = sum / Math.max(1, samples);
      }
   }
   return { width: outWidth, height: outHeight, data: output, factor: factor };
}

function aceDownsampleFloatMax(width, height, data, factor) {
   factor = Math.max(1, Math.round(factor || 1));
   if (factor <= 1)
      return { width: width, height: height, data: new Float32Array(data), factor: 1 };
   var outWidth = Math.max(1, Math.ceil(width / factor));
   var outHeight = Math.max(1, Math.ceil(height / factor));
   var output = new Float32Array(outWidth * outHeight);
   for (var y = 0; y < outHeight; ++y) {
      if ((y & 15) === 0)
         aceYieldToPixInsight();
      var y0 = y * factor;
      var y1 = Math.min(height, y0 + factor);
      for (var x = 0; x < outWidth; ++x) {
         var x0 = x * factor;
         var x1 = Math.min(width, x0 + factor);
         var maxValue = 0;
         for (var yy = y0; yy < y1; ++yy) {
            var row = yy * width;
            for (var xx = x0; xx < x1; ++xx)
               if (data[row + xx] > maxValue)
                  maxValue = data[row + xx];
         }
         output[y * outWidth + x] = maxValue;
      }
   }
   return { width: outWidth, height: outHeight, data: output, factor: factor };
}

function aceUpsampleFloatBilinear(srcWidth, srcHeight, data, dstWidth, dstHeight) {
   if (srcWidth === dstWidth && srcHeight === dstHeight)
      return new Float32Array(data);
   var output = new Float32Array(dstWidth * dstHeight);
   var scaleX = srcWidth > 1 ? (srcWidth - 1) / Math.max(1, dstWidth - 1) : 0;
   var scaleY = srcHeight > 1 ? (srcHeight - 1) / Math.max(1, dstHeight - 1) : 0;
   for (var y = 0; y < dstHeight; ++y) {
      if ((y & 31) === 0)
         aceYieldToPixInsight();
      var sy = y * scaleY;
      var y0 = Math.floor(sy);
      var y1 = Math.min(srcHeight - 1, y0 + 1);
      var fy = sy - y0;
      for (var x = 0; x < dstWidth; ++x) {
         var sx = x * scaleX;
         var x0 = Math.floor(sx);
         var x1 = Math.min(srcWidth - 1, x0 + 1);
         var fx = sx - x0;
         var top = data[y0 * srcWidth + x0] * (1 - fx) + data[y0 * srcWidth + x1] * fx;
         var bottom = data[y1 * srcWidth + x0] * (1 - fx) + data[y1 * srcWidth + x1] * fx;
         output[y * dstWidth + x] = top * (1 - fy) + bottom * fy;
      }
   }
   return output;
}

function aceSmoothStep(edge0, edge1, value) {
   var x = aceClamp01((value - edge0) / Math.max(ACE_EPSILON, edge1 - edge0));
   return x * x * (3 - 2 * x);
}

function aceShortText(text, maxLength) {
   text = String(text || "");
   maxLength = Math.max(8, maxLength || 80);
   if (text.length <= maxLength)
      return text;
   return text.substr(0, maxLength - 3) + "...";
}

function aceFitTextToWidth(font, text, width) {
   text = String(text || "");
   if (!font || font.width(text) <= width)
      return text;
   var ellipsis = "...";
   var maxWidth = Math.max(0, width - font.width(ellipsis));
   while (text.length > 1 && font.width(text) > maxWidth)
      text = text.substr(0, text.length - 1);
   return text + ellipsis;
}

function aceIsBeforeAfterShortcut(key, modifiers) {
   var isC = key === Key_C || key === 0x43 || key === 0x63;
   var hasCommand = (modifiers & KeyModifier_Control) !== 0 || (modifiers & KeyModifier_Meta) !== 0;
   return isC && hasCommand && (modifiers & KeyModifier_Alt) === 0;
}

var ACE_LAST_EVENT_YIELD_MS = 0;
var ACE_EVENT_YIELD_SUPPRESSION_DEPTH = 0;

function aceYieldToPixInsight() {
   if (ACE_EVENT_YIELD_SUPPRESSION_DEPTH > 0)
      return;
   var now = Date.now();
   if (now - ACE_LAST_EVENT_YIELD_MS < 140)
      return;
   ACE_LAST_EVENT_YIELD_MS = now;
   if (typeof CoreApplication !== "undefined" && typeof CoreApplication.processEvents === "function")
      CoreApplication.processEvents();
}

function aceWithSuppressedEventYields(callback) {
   ++ACE_EVENT_YIELD_SUPPRESSION_DEPTH;
   try {
      return callback();
   } finally {
      --ACE_EVENT_YIELD_SUPPRESSION_DEPTH;
   }
}

function aceBoxBlurFloat(width, height, data, radius) {
   radius = Math.max(1, Math.round(radius));
   var count = width * height;
   var span = radius * 2 + 1;
   var horizontal = new Float32Array(count);
   var output = new Float32Array(count);
   for (var y = 0; y < height; ++y) {
      if ((y & 31) === 0)
         aceYieldToPixInsight();
      var row = y * width;
      var sum = 0;
      for (var ix = -radius; ix <= radius; ++ix)
         sum += data[row + aceClamp(ix, 0, width - 1)];
      for (var x = 0; x < width; ++x) {
         horizontal[row + x] = sum / span;
         var removeX = aceClamp(x - radius, 0, width - 1);
         var addX = aceClamp(x + radius + 1, 0, width - 1);
         sum += data[row + addX] - data[row + removeX];
      }
   }
   var verticalSums = new Float64Array(width);
   for (var iy = -radius; iy <= radius; ++iy) {
      var initRow = aceClamp(iy, 0, height - 1) * width;
      for (var sx = 0; sx < width; ++sx)
         verticalSums[sx] += horizontal[initRow + sx];
   }
   for (var y2 = 0; y2 < height; ++y2) {
      if ((y2 & 31) === 0)
         aceYieldToPixInsight();
      var outRow = y2 * width;
      for (var x2 = 0; x2 < width; ++x2)
         output[outRow + x2] = verticalSums[x2] / span;
      var removeY = aceClamp(y2 - radius, 0, height - 1) * width;
      var addY = aceClamp(y2 + radius + 1, 0, height - 1) * width;
      for (var ux = 0; ux < width; ++ux)
         verticalSums[ux] += horizontal[addY + ux] - horizontal[removeY + ux];
   }
   return output;
}

function aceRecursiveSmoothFloat(width, height, data, radius, sigmaScale, passOverride) {
   radius = Math.max(1, Math.round(radius || 1));
   var count = width * height;
   sigmaScale = sigmaScale || 0.58;
   var sigma = Math.max(0.45, radius * sigmaScale);
   var alpha = aceClamp(1 - Math.exp(-1.695 / sigma), 0.04, 0.92);
   var current = new Float32Array(data);
   var temp = new Float32Array(count);
   var passes = passOverride || (radius <= 2 ? 2 : 3);
   for (var pass = 0; pass < passes; ++pass) {
      for (var y = 0; y < height; ++y) {
         if ((y & 31) === 0)
            aceYieldToPixInsight();
         var row = y * width;
         var prev = current[row];
         temp[row] = prev;
         for (var x = 1; x < width; ++x) {
            var idx = row + x;
            prev += alpha * (current[idx] - prev);
            temp[idx] = prev;
         }
         prev = temp[row + width - 1];
         temp[row + width - 1] = prev;
         for (var xr = width - 2; xr >= 0; --xr) {
            var ridx = row + xr;
            prev += alpha * (temp[ridx] - prev);
            temp[ridx] = prev;
         }
      }
      for (var x2 = 0; x2 < width; ++x2) {
         if ((x2 & 31) === 0)
            aceYieldToPixInsight();
         var prevY = temp[x2];
         current[x2] = prevY;
         for (var y2 = 1; y2 < height; ++y2) {
            var idx2 = y2 * width + x2;
            prevY += alpha * (temp[idx2] - prevY);
            current[idx2] = prevY;
         }
         prevY = current[(height - 1) * width + x2];
         current[(height - 1) * width + x2] = prevY;
         for (var yr = height - 2; yr >= 0; --yr) {
            var ridx2 = yr * width + x2;
            prevY += alpha * (current[ridx2] - prevY);
            current[ridx2] = prevY;
         }
      }
   }
   return current;
}

function aceSoftScaleBlurFloat(width, height, data, radius) {
   radius = Math.max(1, Math.round(radius || 1));
   return aceRecursiveSmoothFloat(width, height, data, radius);
}

function aceClarityDualZoneBlurFloat(width, height, data, radius) {
   radius = Math.max(1, Math.round(radius || 1));
   if (!ACE_CLARITY_DUALZONE_FAST_BLURS_ENABLED)
      return aceSoftScaleBlurFloat(width, height, data, radius);
   return aceRecursiveSmoothFloat(width, height, data, radius, 0.58, 2);
}

function aceTextureScaleBlurFloat(width, height, data, radius) {
   radius = Math.max(1, Math.round(radius || 1));
   return aceRecursiveSmoothFloat(width, height, data, radius, 0.38, radius <= 2 ? 1 : 2);
}

function aceGaussianKernelFloat(sigma) {
   sigma = Math.max(0.35, sigma || 0.75);
   var radius = Math.max(1, Math.ceil(sigma * 3));
   var kernel = new Float32Array(radius * 2 + 1);
   var sum = 0;
   for (var i = -radius; i <= radius; ++i) {
      var value = Math.exp(-(i * i) / (2 * sigma * sigma));
      kernel[i + radius] = value;
      sum += value;
   }
   if (sum > 0)
      for (var k = 0; k < kernel.length; ++k)
         kernel[k] /= sum;
   return { radius: radius, kernel: kernel };
}

function aceIsotropicGaussianBlurFloat(width, height, data, sigma) {
   var spec = aceGaussianKernelFloat(sigma);
   var radius = spec.radius;
   var kernel = spec.kernel;
   var count = width * height;
   var temp = new Float32Array(count);
   var out = new Float32Array(count);
   for (var y = 0; y < height; ++y) {
      if ((y & 31) === 0)
         aceYieldToPixInsight();
      var row = y * width;
      for (var x = 0; x < width; ++x) {
         var sum = 0;
         for (var dx = -radius; dx <= radius; ++dx) {
            var sx = Math.max(0, Math.min(width - 1, x + dx));
            sum += data[row + sx] * kernel[dx + radius];
         }
         temp[row + x] = sum;
      }
   }
   for (var x2 = 0; x2 < width; ++x2) {
      if ((x2 & 31) === 0)
         aceYieldToPixInsight();
      for (var y2 = 0; y2 < height; ++y2) {
         var sum2 = 0;
         for (var dy = -radius; dy <= radius; ++dy) {
            var sy = Math.max(0, Math.min(height - 1, y2 + dy));
            sum2 += temp[sy * width + x2] * kernel[dy + radius];
         }
         out[y2 * width + x2] = sum2;
      }
   }
   return out;
}

function aceTextureIsoCoreBlurFloat(width, height, data, radius) {
   radius = Math.max(1, Math.round(radius || 1));
   return aceIsotropicGaussianBlurFloat(width, height, data, Math.max(0.45, radius * 0.62));
}

function aceTextureHybridFastBlurFloat(width, height, data, sigma) {
   sigma = Math.max(0.35, sigma || 0.75);
   var radius = Math.max(1, Math.round(sigma / 0.62));
   return aceRecursiveSmoothFloat(width, height, data, radius, 0.42, radius <= 2 ? 1 : 2);
}

function aceTextureCompactBrightPreconditionFloat(width, height, luminance, sourceSaturation) {
   var count = width * height;
   var localSmooth = aceIsotropicGaussianBlurFloat(width, height, luminance, 0.85);
   var compactSeed = new Float32Array(count);
   for (var i = 0; i < count; ++i) {
      var bright = aceSmoothStep(0.72, 0.98, luminance[i]);
      var saturated = sourceSaturation ? aceSmoothStep(0.22, 0.72, sourceSaturation[i]) : 0;
      var compactResidual = aceSmoothStep(0.006, 0.050, Math.max(0, luminance[i] - localSmooth[i]));
      compactSeed[i] = aceClamp01(Math.max(bright * compactResidual, bright * saturated * 0.55));
   }
   var compactMask = aceIsotropicGaussianBlurFloat(width, height, compactSeed, 1.45);
   var out = new Float32Array(count);
   for (var j = 0; j < count; ++j) {
      var mix = 0.72 * aceClamp01(compactMask[j]);
      out[j] = luminance[j] * (1 - mix) + localSmooth[j] * mix;
   }
   return { luminance: out, mask: compactMask };
}

function aceTextureHybridStarMaskFloat(width, height, luminance, sourceSaturation, sampleScale, useFastHybrid) {
   var radiusScale = aceClamp((typeof sampleScale === "number" && isFinite(sampleScale)) ? sampleScale : 1, 0.25, 1);
   var count = width * height;
   var blur = useFastHybrid ? aceTextureHybridFastBlurFloat : aceIsotropicGaussianBlurFloat;
   var smooth = blur(width, height, luminance, 1.1 * radiusScale);
   var seed = new Float32Array(count);
   for (var i = 0; i < count; ++i) {
      var compact = aceSmoothStep(0.006, 0.045, Math.max(0, luminance[i] - smooth[i]));
      var bright = aceSmoothStep(0.60, 0.97, luminance[i]);
      var sat = sourceSaturation ? aceSmoothStep(0.18, 0.65, sourceSaturation[i]) : 0;
      seed[i] = Math.max(compact * bright, bright * sat * 0.45);
   }
   return blur(width, height, seed, 1.8 * radiusScale);
}

function aceTextureHybridSourceSupportFloat(width, height, luminance, sampleScale, useFastHybrid) {
   var radiusScale = aceClamp((typeof sampleScale === "number" && isFinite(sampleScale)) ? sampleScale : 1, 0.25, 1);
   var count = width * height;
   var blur = useFastHybrid ? aceTextureHybridFastBlurFloat : aceIsotropicGaussianBlurFloat;
   var smooth = blur(width, height, luminance, 1.2 * radiusScale);
   var support = new Float32Array(count);
   for (var y = 0; y < height; ++y) {
      if ((y & 31) === 0)
         aceYieldToPixInsight();
      var ym = Math.max(0, y - 1);
      var yp = Math.min(height - 1, y + 1);
      for (var x = 0; x < width; ++x) {
         var xm = Math.max(0, x - 1);
         var xp = Math.min(width - 1, x + 1);
         var idx = y * width + x;
         var gx = 0.5 * (smooth[y * width + xp] - smooth[y * width + xm]);
         var gy = 0.5 * (smooth[yp * width + x] - smooth[ym * width + x]);
         support[idx] = aceSmoothStep(0.0015, 0.018, Math.sqrt(gx * gx + gy * gy));
      }
   }
   return support;
}

function aceTextureHybridStructureConfidenceFloat(width, height, luminance, sampleScale, useFastHybrid) {
   var radiusScale = aceClamp((typeof sampleScale === "number" && isFinite(sampleScale)) ? sampleScale : 1, 0.25, 1);
   var count = width * height;
   var blur = useFastHybrid ? aceTextureHybridFastBlurFloat : aceIsotropicGaussianBlurFloat;
   var smooth = blur(width, height, luminance, 1.0 * radiusScale);
   var gx = new Float32Array(count);
   var gy = new Float32Array(count);
   for (var y = 0; y < height; ++y) {
      if ((y & 31) === 0)
         aceYieldToPixInsight();
      var ym = Math.max(0, y - 1);
      var yp = Math.min(height - 1, y + 1);
      for (var x = 0; x < width; ++x) {
         var xm = Math.max(0, x - 1);
         var xp = Math.min(width - 1, x + 1);
         var idx = y * width + x;
         var a00 = smooth[ym * width + xm], a01 = smooth[ym * width + x], a02 = smooth[ym * width + xp];
         var a10 = smooth[y * width + xm],                                  a12 = smooth[y * width + xp];
         var a20 = smooth[yp * width + xm], a21 = smooth[yp * width + x], a22 = smooth[yp * width + xp];
         gx[idx] = a02 + 2 * a12 + a22 - a00 - 2 * a10 - a20;
         gy[idx] = a20 + 2 * a21 + a22 - a00 - 2 * a01 - a02;
      }
   }
   var jxx = new Float32Array(count);
   var jyy = new Float32Array(count);
   var jxy = new Float32Array(count);
   for (var i = 0; i < count; ++i) {
      jxx[i] = gx[i] * gx[i];
      jyy[i] = gy[i] * gy[i];
      jxy[i] = gx[i] * gy[i];
   }
   jxx = blur(width, height, jxx, 1.6 * radiusScale);
   jyy = blur(width, height, jyy, 1.6 * radiusScale);
   jxy = blur(width, height, jxy, 1.6 * radiusScale);
   var conf = new Float32Array(count);
   for (var c = 0; c < count; ++c) {
      var trace = jxx[c] + jyy[c];
      var det = Math.max(0, jxx[c] * jyy[c] - jxy[c] * jxy[c]);
      var coherence = Math.sqrt(Math.max(0, trace * trace - 4 * det)) / Math.max(trace, ACE_EPSILON);
      var energy = aceSmoothStep(0.00002, 0.0015, trace);
      conf[c] = aceClamp01(coherence * energy);
   }
   return conf;
}

function aceBuildTextureHybridLayersCore(width, height, luminance, sourceSaturation, sampleScale, timing, timingPrefix, useFastHybrid, buildHybridStarMask, textureMode) {
   var radiusScale = aceClamp((typeof sampleScale === "number" && isFinite(sampleScale)) ? sampleScale : 1, 0.25, 1);
   var prefix = timingPrefix || "Operation";
   var flavorLabel = useFastHybrid ? "fast" : "exact";
   buildHybridStarMask = buildHybridStarMask !== false;
   textureMode = aceNormalizeTextureMode(textureMode || ACE_TEXTURE_MODE_DEFAULT);
   var buildTensorLayer = aceTextureHybridNeedsTensorLayer(textureMode);
   var buildActiveLightOnly = aceIsFullResolutionOperationPrefix(prefix) &&
      !buildTensorLayer &&
      !buildHybridStarMask &&
      (textureMode === ACE_TEXTURE_MODE_HYBRID_LIGHT ||
       textureMode === ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST);
   var blur = useFastHybrid ? aceTextureHybridFastBlurFloat : aceIsotropicGaussianBlurFloat;
   var timingActive = !!(timing && timing.items);
   var stage = timingActive ? Date.now() : 0;
   var count = width * height;
   var dogFineA = blur(width, height, luminance, 0.65 * radiusScale);
   var dogFineB = blur(width, height, luminance, 1.60 * radiusScale);
   var dogMidA = blur(width, height, luminance, 1.20 * radiusScale);
   var dogMidB = blur(width, height, luminance, 3.20 * radiusScale);
   acePerfMark(timing, prefix + " detail - Texture hybrid " + flavorLabel + " Dog blurs scale=" + aceValidationNumber(radiusScale, 3), stage);
   stage = timingActive ? Date.now() : 0;
   var tensorA = buildTensorLayer ? blur(width, height, luminance, 0.75 * radiusScale) : null;
   var tensorB = buildTensorLayer ? blur(width, height, luminance, 1.90 * radiusScale) : null;
   acePerfMark(timing, prefix + " detail - Texture hybrid " + flavorLabel + " tensor blurs" + (buildTensorLayer ? "" : " skipped") + " scale=" + aceValidationNumber(radiusScale, 3), stage);
   stage = timingActive ? Date.now() : 0;
   var support = aceTextureHybridSourceSupportFloat(width, height, luminance, sampleScale, useFastHybrid);
   acePerfMark(timing, prefix + " detail - Texture hybrid " + flavorLabel + " source support", stage);
   stage = timingActive ? Date.now() : 0;
   var confidence = aceTextureHybridStructureConfidenceFloat(width, height, luminance, sampleScale, useFastHybrid);
   acePerfMark(timing, prefix + " detail - Texture hybrid " + flavorLabel + " structure confidence", stage);
   stage = timingActive ? Date.now() : 0;
   var dogRaw = buildActiveLightOnly ? null : new Float32Array(count);
   var tensorRaw = buildTensorLayer ? new Float32Array(count) : null;
   var tensorAcceptance = buildActiveLightOnly ? null : new Float32Array(count);
   var hybridConservative = buildActiveLightOnly ? null : new Float32Array(count);
   var hybridMedium = buildActiveLightOnly ? null : new Float32Array(count);
   var hybridLight = new Float32Array(count);
   var hybridHigh = buildActiveLightOnly ? null : new Float32Array(count);
   for (var i = 0; i < count; ++i) {
      var dogValue = aceSoftLimitSigned((0.72 * (dogFineA[i] - dogFineB[i]) + 0.28 * (dogMidA[i] - dogMidB[i])) * 3.2, ACE_TEXTURE_BANDPASS_SOFT_LIMIT);
      if (dogRaw)
         dogRaw[i] = dogValue;
      var tensorGate = aceClamp01((0.18 + 0.82 * confidence[i]) * (0.35 + 0.65 * support[i]));
      if (tensorAcceptance)
         tensorAcceptance[i] = tensorGate;
      if (buildTensorLayer) {
         var tensorBase = (tensorA[i] - tensorB[i]) * tensorGate;
         tensorRaw[i] = aceSoftLimitSigned(tensorBase * 3.2, ACE_TEXTURE_BANDPASS_SOFT_LIMIT) * tensorGate;
      }
      var lightGate = aceClamp(0.60 + 0.40 * tensorGate, 0, 1);
      hybridLight[i] = dogValue * lightGate;
      if (!buildActiveLightOnly) {
         var mediumGate = aceClamp(0.35 + 0.65 * tensorGate, 0, 1);
         var conservativeGate = aceClamp((0.28 + 0.72 * tensorGate) * (0.70 + 0.30 * support[i]), 0, 1);
         var highGate = aceClamp(0.45 + 0.55 * tensorGate, 0, 1);
         hybridMedium[i] = dogValue * mediumGate;
         hybridConservative[i] = buildTensorLayer ?
            aceSoftLimitSigned(dogValue * 0.88 + tensorRaw[i] * 0.12, ACE_TEXTURE_BANDPASS_SOFT_LIMIT) * conservativeGate :
            dogValue * conservativeGate;
         hybridHigh[i] = aceSoftLimitSigned(dogValue * 1.20, ACE_TEXTURE_BANDPASS_SOFT_LIMIT) * highGate;
      }
   }
   acePerfMark(timing, prefix + " detail - Texture hybrid " + flavorLabel + " mix loop" + (buildActiveLightOnly ? " active-light-only" : ""), stage);
   stage = timingActive ? Date.now() : 0;
   var hybridStarMask = buildHybridStarMask ? aceTextureHybridStarMaskFloat(width, height, luminance, sourceSaturation, sampleScale, useFastHybrid) : null;
   acePerfMark(timing, prefix + " detail - Texture hybrid " + flavorLabel + " star mask" + (buildHybridStarMask ? "" : " skipped"), stage);
   return {
      dogMidblendLayer: dogRaw || hybridLight,
      tensorLimitedLayer: tensorRaw || hybridLight,
      tensorConfidence: confidence,
      tensorAcceptance: tensorAcceptance || confidence,
      hybridConservativeLayer: hybridConservative || hybridLight,
      hybridMediumLayer: hybridMedium || hybridLight,
      hybridLightLayer: hybridLight,
      hybridHighLayer: hybridHigh || hybridLight,
      hybridStarMask: hybridStarMask
   };
}

function aceCompareFloatBuffers(label, a, b) {
   if (!a || !b || a.length !== b.length)
      return label + "=unavailable";
   var count = a.length;
   var sumAbs = 0;
   var sumSq = 0;
   var maxAbs = 0;
   var over002 = 0;
   var over005 = 0;
   for (var i = 0; i < count; ++i) {
      var d = Math.abs(a[i] - b[i]);
      sumAbs += d;
      sumSq += d * d;
      if (d > maxAbs)
         maxAbs = d;
      if (d > 0.002)
         ++over002;
      if (d > 0.005)
         ++over005;
   }
   var inv = count > 0 ? 1 / count : 0;
   return label +
      "_meanAbs=" + aceValidationNumber(sumAbs * inv, 6) +
      " " + label + "_rms=" + aceValidationNumber(Math.sqrt(sumSq * inv), 6) +
      " " + label + "_maxAbs=" + aceValidationNumber(maxAbs, 6) +
      " " + label + "_pct_gt_0p002=" + aceValidationNumber(100 * over002 * inv, 3) + "%" +
      " " + label + "_pct_gt_0p005=" + aceValidationNumber(100 * over005 * inv, 3) + "%";
}

function aceTextureHybridDifferenceWarning(lightDiffText, acceptanceDiffText) {
   return "watch=fine_star_halos,small_dark_ridges,thin_nebula_texture,pan_edge_consistency";
}

function aceBuildTextureHybridLayersDetailCandidate(width, height, luminance, sourceSaturation, sampleScale, timing, timingPrefix, useFastHybrid, buildHybridStarMask, factor, textureMode) {
   var radiusScale = aceClamp((typeof sampleScale === "number" && isFinite(sampleScale)) ? sampleScale : 1, 0.25, 1);
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   var stage = timingActive ? Date.now() : 0;
   var blur = useFastHybrid ? aceTextureHybridFastBlurFloat : aceIsotropicGaussianBlurFloat;
   textureMode = aceNormalizeTextureMode(textureMode || ACE_TEXTURE_MODE_DEFAULT);
   var buildTensorLayer = aceTextureHybridNeedsTensorLayer(textureMode);
   var buildActiveLightOnly = aceIsFullResolutionOperationPrefix(prefix) &&
      !buildTensorLayer &&
      !buildHybridStarMask &&
      (textureMode === ACE_TEXTURE_MODE_HYBRID_LIGHT ||
       textureMode === ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST);
   var count = width * height;
   var dogFineA = blur(width, height, luminance, 0.65 * radiusScale);
   var dogFineB = blur(width, height, luminance, 1.60 * radiusScale);
   var dogMidA = blur(width, height, luminance, 1.20 * radiusScale);
   var dogMidB = blur(width, height, luminance, 3.20 * radiusScale);
   acePerfMark(timing, prefix + " detail - Texture hybrid gate candidate native Dog blurs scale=" + aceValidationNumber(radiusScale, 3), stage);
   stage = timingActive ? Date.now() : 0;
   var tensorA = buildTensorLayer ? blur(width, height, luminance, 0.75 * radiusScale) : null;
   var tensorB = buildTensorLayer ? blur(width, height, luminance, 1.90 * radiusScale) : null;
   acePerfMark(timing, prefix + " detail - Texture hybrid gate candidate native tensor blurs" + (buildTensorLayer ? "" : " skipped") + " scale=" + aceValidationNumber(radiusScale, 3), stage);
   stage = timingActive ? Date.now() : 0;
   var smallLum = aceDownsampleFloatAverage(width, height, luminance, factor);
   var smallScale = Math.max(0.25, (sampleScale || 1) / Math.max(1, smallLum.factor));
   var smallConfidence = aceTextureHybridStructureConfidenceFloat(smallLum.width, smallLum.height, smallLum.data, smallScale, useFastHybrid);
   var supportCandidate = buildActiveLightOnly && smallLum.factor > 1;
   var smallSupport = supportCandidate ?
      aceTextureHybridSourceSupportFloat(smallLum.width, smallLum.height, smallLum.data, smallScale, useFastHybrid) :
      null;
   var support = supportCandidate ?
      aceUpsampleFloatBilinear(smallLum.width, smallLum.height, smallSupport, width, height) :
      aceTextureHybridSourceSupportFloat(width, height, luminance, sampleScale, useFastHybrid);
   var confidence = aceUpsampleFloatBilinear(smallLum.width, smallLum.height, smallConfidence, width, height);
   acePerfMark(timing, prefix + " detail - Texture hybrid confidence candidate support/confidence x" + smallLum.factor + (supportCandidate ? " support-x" + smallLum.factor : " native-support"), stage);
   stage = timingActive ? Date.now() : 0;
   var dogRaw = buildActiveLightOnly ? null : new Float32Array(count);
   var tensorRaw = buildTensorLayer ? new Float32Array(count) : null;
   var tensorAcceptance = buildActiveLightOnly ? null : new Float32Array(count);
   var hybridConservative = buildActiveLightOnly ? null : new Float32Array(count);
   var hybridMedium = buildActiveLightOnly ? null : new Float32Array(count);
   var hybridLight = new Float32Array(count);
   var hybridHigh = buildActiveLightOnly ? null : new Float32Array(count);
   for (var i = 0; i < count; ++i) {
      var dogValue = aceSoftLimitSigned((0.72 * (dogFineA[i] - dogFineB[i]) + 0.28 * (dogMidA[i] - dogMidB[i])) * 3.2, ACE_TEXTURE_BANDPASS_SOFT_LIMIT);
      if (dogRaw)
         dogRaw[i] = dogValue;
      var tensorGate = aceClamp01((0.18 + 0.82 * confidence[i]) * (0.35 + 0.65 * support[i]));
      if (tensorAcceptance)
         tensorAcceptance[i] = tensorGate;
      if (buildTensorLayer) {
         var tensorBase = (tensorA[i] - tensorB[i]) * tensorGate;
         tensorRaw[i] = aceSoftLimitSigned(tensorBase * 3.2, ACE_TEXTURE_BANDPASS_SOFT_LIMIT) * tensorGate;
      }
      var lightGate = aceClamp(0.60 + 0.40 * tensorGate, 0, 1);
      hybridLight[i] = dogValue * lightGate;
      if (!buildActiveLightOnly) {
         var mediumGate = aceClamp(0.35 + 0.65 * tensorGate, 0, 1);
         var conservativeGate = aceClamp((0.28 + 0.72 * tensorGate) * (0.70 + 0.30 * support[i]), 0, 1);
         var highGate = aceClamp(0.45 + 0.55 * tensorGate, 0, 1);
         hybridMedium[i] = dogValue * mediumGate;
         hybridConservative[i] = buildTensorLayer ?
            aceSoftLimitSigned(dogValue * 0.88 + tensorRaw[i] * 0.12, ACE_TEXTURE_BANDPASS_SOFT_LIMIT) * conservativeGate :
            dogValue * conservativeGate;
         hybridHigh[i] = aceSoftLimitSigned(dogValue * 1.20, ACE_TEXTURE_BANDPASS_SOFT_LIMIT) * highGate;
      }
   }
   acePerfMark(timing, prefix + " detail - Texture hybrid confidence candidate mix loop" + (buildActiveLightOnly ? " active-light-only" : ""), stage);
   stage = timingActive ? Date.now() : 0;
   var hybridStarMask = buildHybridStarMask ? aceTextureHybridStarMaskFloat(width, height, luminance, sourceSaturation, sampleScale, useFastHybrid) : null;
   acePerfMark(timing, prefix + " detail - Texture hybrid confidence candidate star mask" + (buildHybridStarMask ? "" : " skipped"), stage);
   var result = {
      dogMidblendLayer: dogRaw || hybridLight,
      tensorLimitedLayer: tensorRaw || hybridLight,
      tensorConfidence: confidence,
      tensorAcceptance: tensorAcceptance || confidence,
      hybridConservativeLayer: hybridConservative || hybridLight,
      hybridMediumLayer: hybridMedium || hybridLight,
      hybridLightLayer: hybridLight,
      hybridHighLayer: hybridHigh || hybridLight,
      hybridStarMask: hybridStarMask
   };
   return result;
}

function aceBuildTextureHybridLayers(width, height, luminance, sourceSaturation, sampleScale, timing, timingPrefix, useFastHybrid, buildHybridStarMask, textureMode) {
   var prefix = timingPrefix || "Operation";
   var detailCandidate = useFastHybrid &&
      aceIsNativeDetailPreviewPrefix(prefix) &&
      ACE_DETAIL_TEXTURE_HYBRID_DOWNSAMPLE > 1 &&
      Math.max(width, height) > 700;
   var fullResCandidate = useFastHybrid &&
      aceIsFullResolutionOperationPrefix(prefix) &&
      ACE_FULLRES_TEXTURE_HYBRID_CONFIDENCE_DOWNSAMPLE > 1 &&
      Math.max(width, height) > 2200;
   if (!(detailCandidate || fullResCandidate) || ACE_DETAIL_TEXTURE_HYBRID_BASELINE_ACTIVE)
      return aceBuildTextureHybridLayersCore(width, height, luminance, sourceSaturation, sampleScale, timing, prefix, useFastHybrid, buildHybridStarMask, textureMode);
   var factor = fullResCandidate ? ACE_FULLRES_TEXTURE_HYBRID_CONFIDENCE_DOWNSAMPLE : ACE_DETAIL_TEXTURE_HYBRID_DOWNSAMPLE;
   var candidate = aceBuildTextureHybridLayersDetailCandidate(width, height, luminance, sourceSaturation, sampleScale, timing, prefix, useFastHybrid, buildHybridStarMask, factor, textureMode);
   if (ACE_DETAIL_TEXTURE_HYBRID_AB_AUDIT_COUNT < ACE_DETAIL_TEXTURE_HYBRID_AB_AUDIT_LIMIT) {
      ++ACE_DETAIL_TEXTURE_HYBRID_AB_AUDIT_COUNT;
      var auditTiming = { items: [] };
      var auditStart = Date.now();
      var baseline = aceBuildTextureHybridLayersCore(width, height, luminance, sourceSaturation, sampleScale, auditTiming, prefix + " baseline", useFastHybrid, buildHybridStarMask, textureMode);
      var auditMs = Date.now() - auditStart;
      var lightDiff = aceCompareFloatBuffers("hybridLight", baseline.hybridLightLayer, candidate.hybridLightLayer);
      var confDiff = aceCompareFloatBuffers("tensorConfidence", baseline.tensorConfidence, candidate.tensorConfidence);
      var acceptDiff = aceCompareFloatBuffers("tensorAcceptance", baseline.tensorAcceptance, candidate.tensorAcceptance);
      aceDevelopmentConsoleWriteLine("[ACE] Detail texture hybrid A/B audit | candidate=confidence_x" + factor +
         " size=" + width + "x" + height +
         " baseline_ms=" + auditMs +
         " candidate_note=displaying_candidate" +
         " | " + lightDiff +
         " | " + confDiff +
         " | " + acceptDiff +
         " | " + aceTextureHybridDifferenceWarning(lightDiff, acceptDiff) +
         " | baseline_timing=" + aceTimingSummary(auditTiming, 8));
   }
   return candidate;
}

function aceSoftLimitSigned(value, limit) {
   limit = Math.max(ACE_EPSILON, limit || 1);
   return limit * Math.tanh(value / limit);
}

function aceSoftKneeLimitSigned(value, limit, kneePower) {
   limit = Math.max(ACE_EPSILON, limit || 1);
   kneePower = Math.max(0.35, kneePower || 1);
   var sign = value < 0 ? -1 : 1;
   var magnitude = Math.abs(value);
   var normalized = magnitude / limit;
   var compressed = limit * (1 - Math.exp(-Math.pow(normalized, kneePower)));
   return sign * compressed;
}

function aceSoftDeadbandSigned(value, threshold) {
   threshold = Math.max(0, threshold || 0);
   var magnitude = Math.abs(value);
   if (magnitude <= threshold)
      return 0;
   var sign = value < 0 ? -1 : 1;
   var softened = magnitude - threshold;
   var ramp = aceSmoothStep(0, threshold * 3 + ACE_EPSILON, softened);
   return sign * softened * ramp;
}

function aceSoftLocalFloor(width, height, luminance, radius) {
   var broad = aceBoxBlurFloat(width, height, luminance, radius);
   var modest = aceBoxBlurFloat(width, height, luminance, Math.max(2, Math.round(radius * 0.35)));
   var count = width * height;
   var floor = new Float32Array(count);
   for (var i = 0; i < count; ++i) {
      var lowEnvelope = Math.min(broad[i], modest[i], luminance[i]);
      floor[i] = aceClamp01(lowEnvelope - ACE_LOCAL_FLOOR_TOLERANCE);
   }
   return floor;
}

function aceSmoothMaskSupport(width, height, data, radius) {
   radius = Math.max(1, Math.round(radius || 1));
   var smoothed = aceRecursiveSmoothFloat(width, height, data, radius);
   var count = width * height;
   for (var i = 0; i < count; ++i)
      smoothed[i] = aceClamp01(smoothed[i]);
   return smoothed;
}

function aceSmoothFloorSupport(width, height, floor, luminance, radius) {
   radius = Math.max(1, Math.round(radius || 1));
   var smoothed = aceRecursiveSmoothFloat(width, height, floor, radius);
   var count = width * height;
   for (var i = 0; i < count; ++i)
      smoothed[i] = aceClamp(smoothed[i], 0, luminance ? luminance[i] : 1);
   return smoothed;
}

function aceDilateFloat(width, height, data, radius) {
   radius = Math.max(1, Math.round(radius));
   var count = width * height;
   var horizontal = new Float32Array(count);
   var output = new Float32Array(count);
   for (var y = 0; y < height; ++y) {
      if ((y & 31) === 0)
         aceYieldToPixInsight();
      var row = y * width;
      for (var x = 0; x < width; ++x) {
         var x0 = Math.max(0, x - radius);
         var x1 = Math.min(width - 1, x + radius);
         var maxValue = 0;
         for (var xx = x0; xx <= x1; ++xx)
            if (data[row + xx] > maxValue)
               maxValue = data[row + xx];
         horizontal[row + x] = maxValue;
      }
   }
   for (var x2 = 0; x2 < width; ++x2) {
      if ((x2 & 31) === 0)
         aceYieldToPixInsight();
      for (var y2 = 0; y2 < height; ++y2) {
         var y0 = Math.max(0, y2 - radius);
         var y1 = Math.min(height - 1, y2 + radius);
         var maxValue2 = 0;
         for (var yy = y0; yy <= y1; ++yy)
            if (horizontal[yy * width + x2] > maxValue2)
               maxValue2 = horizontal[yy * width + x2];
         output[y2 * width + x2] = maxValue2;
      }
   }
   return output;
}

function aceDilateFloatDisk(width, height, data, radius) {
   radius = Math.max(1, Math.round(radius));
   var count = width * height;
   var output = new Float32Array(count);
   var r2 = radius * radius;
   for (var y = 0; y < height; ++y) {
      if ((y & 15) === 0)
         aceYieldToPixInsight();
      for (var x = 0; x < width; ++x) {
         var maxValue = 0;
         for (var dy = -radius; dy <= radius; ++dy) {
            var yy = aceClamp(y + dy, 0, height - 1);
            var dy2 = dy * dy;
            for (var dx = -radius; dx <= radius; ++dx) {
               if (dx * dx + dy2 > r2)
                  continue;
               var value = data[yy * width + aceClamp(x + dx, 0, width - 1)];
               if (value > maxValue)
                  maxValue = value;
            }
         }
         output[y * width + x] = maxValue;
      }
   }
   return output;
}

function aceDiskBlurFloat(width, height, data, radius) {
   radius = Math.max(1, Math.round(radius));
   var count = width * height;
   var output = new Float32Array(count);
   var r2 = radius * radius;
   for (var y = 0; y < height; ++y) {
      if ((y & 15) === 0)
         aceYieldToPixInsight();
      for (var x = 0; x < width; ++x) {
         var sum = 0;
         var samples = 0;
         for (var dy = -radius; dy <= radius; ++dy) {
            var yy = aceClamp(y + dy, 0, height - 1);
            var dy2 = dy * dy;
            for (var dx = -radius; dx <= radius; ++dx) {
               if (dx * dx + dy2 > r2)
                  continue;
               sum += data[yy * width + aceClamp(x + dx, 0, width - 1)];
               ++samples;
            }
         }
         output[y * width + x] = sum / Math.max(1, samples);
      }
   }
   return output;
}

function acePointInPolygon(x, y, points) {
   var inside = false;
   for (var i = 0, j = points.length - 1; i < points.length; j = i++) {
      var xi = points[i].x;
      var yi = points[i].y;
      var xj = points[j].x;
      var yj = points[j].y;
      var dy = yj - yi;
      var intersects = Math.abs(dy) > ACE_EPSILON &&
         ((yi > y) !== (yj > y)) &&
         (x < (xj - xi) * (y - yi) / dy + xi);
      if (intersects)
         inside = !inside;
   }
   return inside;
}

function aceDistanceToSegmentSquared(px, py, ax, ay, bx, by) {
   var vx = bx - ax;
   var vy = by - ay;
   var wx = px - ax;
   var wy = py - ay;
   var len2 = vx * vx + vy * vy;
   var t = len2 > ACE_EPSILON ? aceClamp01((wx * vx + wy * vy) / len2) : 0;
   var dx = px - (ax + t * vx);
   var dy = py - (ay + t * vy);
   return dx * dx + dy * dy;
}

function aceBuildLassoWeightMap(width, height, sourceX0, sourceY0, sourceStepX, sourceStepY, points, featherPx, inverted) {
   var count = width * height;
   var mask = new Float32Array(count);
   if (!points || points.length < 3)
      return mask;
   var localPoints = [];
   for (var p = 0; p < points.length; ++p)
      localPoints.push({
         x: (points[p].x - sourceX0) / Math.max(ACE_EPSILON, sourceStepX),
         y: (points[p].y - sourceY0) / Math.max(ACE_EPSILON, sourceStepY)
      });
   var minX = width;
   var minY = height;
   var maxX = -1;
   var maxY = -1;
   for (var q = 0; q < localPoints.length; ++q) {
      minX = Math.min(minX, localPoints[q].x);
      minY = Math.min(minY, localPoints[q].y);
      maxX = Math.max(maxX, localPoints[q].x);
      maxY = Math.max(maxY, localPoints[q].y);
   }
   var avgStep = Math.max(ACE_EPSILON, (Math.abs(sourceStepX) + Math.abs(sourceStepY)) * 0.5);
   var radius = Math.round(Math.max(0, featherPx || 0) / avgStep);
   var testX0 = aceClamp(Math.floor(minX - radius - 2), 0, width - 1);
   var testY0 = aceClamp(Math.floor(minY - radius - 2), 0, height - 1);
   var testX1 = aceClamp(Math.ceil(maxX + radius + 2), 0, width - 1);
   var testY1 = aceClamp(Math.ceil(maxY + radius + 2), 0, height - 1);
   var featherRadius = Math.max(0, radius);
   for (var y = testY0; y <= testY1; ++y) {
      if ((y & 31) === 0)
         aceYieldToPixInsight();
      var row = y * width;
      var py = y + 0.5;
      for (var x = testX0; x <= testX1; ++x) {
         var px = x + 0.5;
         var inside = acePointInPolygon(px, py, localPoints);
         if (featherRadius <= 0) {
            mask[row + x] = inside ? 1 : 0;
            continue;
         }
         var minDistance2 = 1.0e30;
         for (var e = 0, j = localPoints.length - 1; e < localPoints.length; j = e++) {
            var p0 = localPoints[j];
            var p1 = localPoints[e];
            minDistance2 = Math.min(minDistance2, aceDistanceToSegmentSquared(px, py, p0.x, p0.y, p1.x, p1.y));
         }
         var d = Math.sqrt(minDistance2);
         var falloff = aceSmoothStep(0, featherRadius, d);
         if (inside)
            mask[row + x] = d >= featherRadius ? 1 : 0.5 + 0.5 * falloff;
         else
            mask[row + x] = d >= featherRadius ? 0 : 0.5 - 0.5 * falloff;
      }
   }
   if (inverted) {
      for (var i = 0; i < count; ++i) {
         if ((i & 131071) === 0)
            aceYieldToPixInsight();
         mask[i] = 1 - mask[i];
      }
   }
   for (var k = 0; k < count; ++k) {
      if ((k & 131071) === 0)
         aceYieldToPixInsight();
      mask[k] = aceClamp01(mask[k]);
   }
   return mask;
}

function aceBuildFullResolutionLassoWeightMap(width, height, sourceX0, sourceY0, points, featherPx, inverted, timing, timingPrefix) {
   var factor = ACE_FULLRES_LASSO_WEIGHT_DOWNSAMPLE;
   var feather = Math.max(0, featherPx || 0);
   var useFast = factor > 1 &&
      feather >= factor * 8 &&
      width * height > 750000 &&
      Math.max(width, height) > 900;
   if (!useFast)
      return aceBuildLassoWeightMap(width, height, sourceX0, sourceY0, 1, 1, points, featherPx, inverted);

   var smallWidth = Math.max(1, Math.ceil(width / factor));
   var smallHeight = Math.max(1, Math.ceil(height / factor));
   var stage = Date.now();
   var small = aceBuildLassoWeightMap(
      smallWidth,
      smallHeight,
      sourceX0,
      sourceY0,
      factor,
      factor,
      points,
      feather,
      inverted
   );
   acePerfMark(timing, (timingPrefix || "Local edit") + " detail - lasso weight small x" + factor + " " + smallWidth + "x" + smallHeight, stage);
   stage = Date.now();
   var upsampled = aceUpsampleFloatBilinear(smallWidth, smallHeight, small, width, height);
   acePerfMark(timing, (timingPrefix || "Local edit") + " detail - lasso weight upsample x" + factor, stage);
   return upsampled;
}

function aceDecimateLassoPoints(points, minSpacing, maxPoints) {
   if (!points || points.length < 3)
      return points ? points.slice(0) : [];
   var output = [points[0]];
   var spacing2 = Math.max(1, minSpacing || ACE_LASSO_MIN_POINT_SPACING);
   spacing2 *= spacing2;
   for (var i = 1; i < points.length; ++i) {
      var prev = output[output.length - 1];
      var dx = points[i].x - prev.x;
      var dy = points[i].y - prev.y;
      if (dx * dx + dy * dy >= spacing2)
         output.push(points[i]);
   }
   if (output.length < 3)
      output = points.slice(0, Math.min(points.length, 3));
   while (output.length > maxPoints) {
      var thinned = [];
      for (var j = 0; j < output.length; j += 2)
         thinned.push(output[j]);
      output = thinned;
   }
   return output;
}

function aceLassoPolygonArea(points) {
   if (!points || points.length < 3)
      return 0;
   var area = 0;
   for (var i = 0, j = points.length - 1; i < points.length; j = i++)
      area += points[j].x * points[i].y - points[i].x * points[j].y;
   return Math.abs(area) * 0.5;
}

function aceLassoPerimeter(points) {
   if (!points || points.length < 2)
      return 0;
   var length = 0;
   for (var i = 0; i < points.length; ++i) {
      var next = points[(i + 1) % points.length];
      var dx = next.x - points[i].x;
      var dy = next.y - points[i].y;
      length += Math.sqrt(dx * dx + dy * dy);
   }
   return length;
}

function aceLassoGeometryInfo(points) {
   if (!points || points.length < 3)
      return { valid: false, area: 0, width: 0, height: 0 };
   var x0 = points[0].x;
   var y0 = points[0].y;
   var x1 = points[0].x;
   var y1 = points[0].y;
   for (var i = 1; i < points.length; ++i) {
      x0 = Math.min(x0, points[i].x);
      y0 = Math.min(y0, points[i].y);
      x1 = Math.max(x1, points[i].x);
      y1 = Math.max(y1, points[i].y);
   }
   var width = x1 - x0;
   var height = y1 - y0;
   var area = aceLassoPolygonArea(points);
   return {
      valid: area >= ACE_LASSO_MIN_AREA && width >= ACE_LASSO_MIN_SPAN && height >= ACE_LASSO_MIN_SPAN,
      area: area,
      width: width,
      height: height
   };
}

function aceSmoothLassoPoints(points) {
   if (!points || points.length < 4)
      return points ? points.slice(0) : [];
   var output = [];
   for (var i = 0; i < points.length; ++i) {
      var prev = points[(i + points.length - 1) % points.length];
      var cur = points[i];
      var next = points[(i + 1) % points.length];
      output.push({
         x: (prev.x + cur.x * 2 + next.x) * 0.25,
         y: (prev.y + cur.y * 2 + next.y) * 0.25
      });
   }
   return output;
}

function aceLassoHullCross(o, a, b) {
   return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
}

function aceConvexHullLassoPoints(points) {
   if (!points || points.length < 3)
      return points ? points.slice(0) : [];
   var sorted = [];
   for (var i = 0; i < points.length; ++i)
      sorted.push({ x: points[i].x, y: points[i].y });
   sorted.sort(function(a, b) {
      if (Math.abs(a.x - b.x) > ACE_EPSILON)
         return a.x < b.x ? -1 : 1;
      if (Math.abs(a.y - b.y) > ACE_EPSILON)
         return a.y < b.y ? -1 : 1;
      return 0;
   });
   var unique = [];
   for (var u = 0; u < sorted.length; ++u) {
      var last = unique.length ? unique[unique.length - 1] : null;
      if (!last || Math.abs(sorted[u].x - last.x) > ACE_EPSILON || Math.abs(sorted[u].y - last.y) > ACE_EPSILON)
         unique.push(sorted[u]);
   }
   if (unique.length < 3)
      return unique;
   var lower = [];
   for (var l = 0; l < unique.length; ++l) {
      while (lower.length >= 2 && aceLassoHullCross(lower[lower.length - 2], lower[lower.length - 1], unique[l]) <= 0)
         lower.pop();
      lower.push(unique[l]);
   }
   var upper = [];
   for (var r = unique.length - 1; r >= 0; --r) {
      while (upper.length >= 2 && aceLassoHullCross(upper[upper.length - 2], upper[upper.length - 1], unique[r]) <= 0)
         upper.pop();
      upper.push(unique[r]);
   }
   lower.pop();
   upper.pop();
   var hull = lower.concat(upper);
   return hull.length >= 3 ? hull : unique;
}

function aceDensifyLassoEdges(points, maxSegmentLength) {
   if (!points || points.length < 3)
      return points ? points.slice(0) : [];
   var output = [];
   var maxLen = Math.max(8, maxSegmentLength || 32);
   for (var i = 0; i < points.length; ++i) {
      var p0 = points[i];
      var p1 = points[(i + 1) % points.length];
      output.push({ x: p0.x, y: p0.y });
      var dx = p1.x - p0.x;
      var dy = p1.y - p0.y;
      var steps = Math.min(24, Math.floor(Math.sqrt(dx * dx + dy * dy) / maxLen));
      for (var s = 1; s <= steps; ++s) {
         var t = s / (steps + 1);
         output.push({ x: p0.x + dx * t, y: p0.y + dy * t });
      }
   }
   return output;
}

function aceFinalizeLassoPoints(points) {
   var perimeter = aceLassoPerimeter(points);
   var adaptiveSpacing = Math.max(3, Math.min(ACE_LASSO_MIN_POINT_SPACING, perimeter / 16));
   var clean = aceDecimateLassoPoints(points, adaptiveSpacing, ACE_LASSO_MAX_POINTS);
   clean = aceConvexHullLassoPoints(clean);
   clean = aceDensifyLassoEdges(clean, Math.max(18, adaptiveSpacing * 3));
   clean = aceSmoothLassoPoints(clean);
   clean = aceSmoothLassoPoints(clean);
   return aceDecimateLassoPoints(clean, Math.max(3, Math.min(10, adaptiveSpacing * 0.75)), ACE_LASSO_MAX_POINTS);
}

function aceFullResolutionLassoPoints(points) {
   if (!points || points.length <= ACE_LASSO_FULLRES_MAX_POINTS)
      return points ? points.slice(0) : [];
   var simplified = aceDecimateLassoPoints(points, ACE_LASSO_FULLRES_MIN_SPACING, ACE_LASSO_FULLRES_MAX_POINTS);
   if (aceLassoGeometryInfo(simplified).valid)
      return simplified;
   return points.slice(0);
}

function aceEmptyStarProtectionMaps(width, height) {
   var count = width * height;
   var emptyMask = new Float32Array(count);
   var allAllowed = new Float32Array(count);
   for (var z = 0; z < count; ++z)
      allAllowed[z] = 1;
   return { protectionMask: emptyMask, allowedWeight: allAllowed };
}

function aceBuildStarProtectionBase(width, height, luminance) {
   var count = width * height;
   var compactBlur = aceDiskBlurFloat(width, height, luminance, ACE_STAR_COMPACT_RADIUS);
   var starBlur = aceDiskBlurFloat(width, height, luminance, ACE_STAR_SIGNAL_RADIUS);
   var coreSeed = new Float32Array(count);
   var meanSignal = 0;
   var meanSignal2 = 0;
   var maxSignal = 0;
   for (var i = 0; i < count; ++i) {
      var signal = Math.max(0, compactBlur[i] - starBlur[i]);
      meanSignal += signal;
      meanSignal2 += signal * signal;
      maxSignal = Math.max(maxSignal, signal);
   }
   meanSignal /= Math.max(1, count);
   meanSignal2 /= Math.max(1, count);
   var variance = Math.max(0, meanSignal2 - meanSignal * meanSignal);
   var sigma = Math.sqrt(variance);
   var threshold = Math.max(ACE_STAR_MIN_SIGNAL, Math.min(0.16, meanSignal + sigma * ACE_STAR_SIGMA_FACTOR + maxSignal * 0.025));
   for (var j = 0; j < count; ++j) {
      var localSignal = Math.max(0, compactBlur[j] - starBlur[j]);
      var peakSignal = Math.max(0, luminance[j] - starBlur[j]);
      var compactnessScore = aceSmoothStep(threshold * 0.55, threshold * 1.70, localSignal);
      var peakScore = aceSmoothStep(threshold * 0.45, threshold * 1.85, peakSignal);
      var brightnessScore = aceSmoothStep(starBlur[j] + threshold * 0.22, starBlur[j] + threshold * 1.55, luminance[j]);
      var contrastScore = Math.sqrt(aceClamp01(compactnessScore * Math.max(peakScore, brightnessScore)));
      var saturationScore = aceSmoothStep(ACE_STAR_NEAR_SATURATION - 0.08, ACE_STAR_NEAR_SATURATION, luminance[j]);
      coreSeed[j] = Math.max(contrastScore, saturationScore);
   }
   coreSeed = aceDiskBlurFloat(width, height, coreSeed, 1);
   var coreGrown = aceDilateFloatDisk(width, height, coreSeed, ACE_STAR_CORE_GROW_RADIUS);
   var coreMask = aceDiskBlurFloat(width, height, coreGrown, Math.max(ACE_STAR_CORE_BLUR_RADIUS, 2));
   var haloSource = aceDilateFloatDisk(width, height, coreMask, ACE_STAR_HALO_GROW_RADIUS);
   var haloMask = aceDiskBlurFloat(width, height, haloSource, Math.max(ACE_STAR_HALO_BLUR_RADIUS, 8));
   haloMask = aceDiskBlurFloat(width, height, haloMask, 2);
   return {
      width: width,
      height: height,
      coreMask: coreMask,
      haloMask: haloMask
   };
}

function aceBuildStarProtectionBaseFast(width, height, luminance, radiusScale) {
   radiusScale = radiusScale !== undefined ? Math.max(0.2, radiusScale) : 1;
   var compactRadius = Math.max(1, Math.round(ACE_STAR_COMPACT_RADIUS * radiusScale));
   var signalRadius = Math.max(compactRadius + 1, Math.round(ACE_STAR_SIGNAL_RADIUS * radiusScale));
   var coreBlurRadius = Math.max(1, Math.round(Math.max(ACE_STAR_CORE_BLUR_RADIUS, 2) * radiusScale));
   var coreGrowRadius = Math.max(1, Math.round(ACE_STAR_CORE_GROW_RADIUS * radiusScale));
   var haloGrowRadius = Math.max(coreGrowRadius + 1, Math.round(ACE_STAR_HALO_GROW_RADIUS * radiusScale));
   var haloBlurRadius = Math.max(2, Math.round(Math.max(ACE_STAR_HALO_BLUR_RADIUS, 8) * radiusScale));
   var haloFinalBlurRadius = Math.max(1, Math.round(2 * radiusScale));
   var count = width * height;
   var compactBlur = aceBoxBlurFloat(width, height, luminance, compactRadius);
   var starBlur = aceBoxBlurFloat(width, height, luminance, signalRadius);
   var coreSeed = new Float32Array(count);
   var meanSignal = 0;
   var meanSignal2 = 0;
   var maxSignal = 0;
   for (var i = 0; i < count; ++i) {
      var signal = Math.max(0, compactBlur[i] - starBlur[i]);
      meanSignal += signal;
      meanSignal2 += signal * signal;
      maxSignal = Math.max(maxSignal, signal);
   }
   meanSignal /= Math.max(1, count);
   meanSignal2 /= Math.max(1, count);
   var variance = Math.max(0, meanSignal2 - meanSignal * meanSignal);
   var sigma = Math.sqrt(variance);
   var threshold = Math.max(ACE_STAR_MIN_SIGNAL, Math.min(0.16, meanSignal + sigma * ACE_STAR_SIGMA_FACTOR + maxSignal * 0.025));
   for (var j = 0; j < count; ++j) {
      var localSignal = Math.max(0, compactBlur[j] - starBlur[j]);
      var peakSignal = Math.max(0, luminance[j] - starBlur[j]);
      var compactnessScore = aceSmoothStep(threshold * 0.55, threshold * 1.70, localSignal);
      var peakScore = aceSmoothStep(threshold * 0.45, threshold * 1.85, peakSignal);
      var brightnessScore = aceSmoothStep(starBlur[j] + threshold * 0.22, starBlur[j] + threshold * 1.55, luminance[j]);
      var contrastScore = Math.sqrt(aceClamp01(compactnessScore * Math.max(peakScore, brightnessScore)));
      var saturationScore = aceSmoothStep(ACE_STAR_NEAR_SATURATION - 0.08, ACE_STAR_NEAR_SATURATION, luminance[j]);
      coreSeed[j] = Math.max(contrastScore, saturationScore);
   }
   coreSeed = aceBoxBlurFloat(width, height, coreSeed, Math.max(1, Math.round(radiusScale)));
   var coreGrown = aceDilateFloat(width, height, coreSeed, coreGrowRadius);
   var coreMask = aceBoxBlurFloat(width, height, coreGrown, coreBlurRadius);
   var haloSource = aceDilateFloat(width, height, coreMask, haloGrowRadius);
   var haloMask = aceBoxBlurFloat(width, height, haloSource, haloBlurRadius);
   haloMask = aceBoxBlurFloat(width, height, haloMask, haloFinalBlurRadius);
   return {
      width: width,
      height: height,
      coreMask: coreMask,
      haloMask: haloMask,
      downsampleFactor: 1
   };
}

function aceBuildStarProtectionBaseFullResolutionFast(width, height, luminance, forceDownsampleFactor) {
   var maxEdge = Math.max(width, height);
   var factor = forceDownsampleFactor && forceDownsampleFactor > 1 ?
      Math.max(1, Math.round(forceDownsampleFactor)) :
      (maxEdge > 2200 ? ACE_STAR_FULLRES_DOWNSAMPLE : 1);
   if (factor <= 1)
      return aceBuildStarProtectionBaseFast(width, height, luminance);
   var small = aceDownsampleFloatMax(width, height, luminance, factor);
   var base = aceBuildStarProtectionBaseFast(small.width, small.height, small.data, 1 / Math.max(1, small.factor));
   base.fullWidth = width;
   base.fullHeight = height;
   base.downsampleFactor = small.factor;
   return base;
}

function aceComposeStarProtectionMaps(width, height, base, protectStars, protectHalos, advanced) {
   if (!protectStars || !base)
      return aceEmptyStarProtectionMaps(width, height);
   var count = width * height;
   var protectionMask = new Float32Array(count);
   var allowedWeight = new Float32Array(count);
   var starStrength = ACE_STAR_CORE_STRENGTH * aceAdvancedFactor(advanced, "starProtectionStrength");
   var haloStrength = ACE_STAR_HALO_STRENGTH * aceAdvancedFactor(advanced, "haloProtectionStrength");
   var overallStrength = aceAdvancedFactor(advanced, "overallProtectionStrength");
   for (var k = 0; k < count; ++k) {
      var core = base.coreMask[k];
      var halo = protectHalos ? base.haloMask[k] : core;
      var coreProtection = core * starStrength;
      var haloProtection = protectHalos ? Math.max(0, halo - core * 0.45) * haloStrength : 0;
      protectionMask[k] = aceClamp01(Math.max(coreProtection, haloProtection));
   }
   protectionMask = aceDiskBlurFloat(width, height, protectionMask, Math.max(1, Math.round(aceAdvancedFactor(advanced, "protectionSoftness"))));
   for (var j = 0; j < count; ++j) {
      protectionMask[j] = aceClamp01(protectionMask[j]);
      var allowed = 1 - protectionMask[j];
      if (overallStrength !== 1)
         allowed = aceClamp01(1 - aceClamp01(1 - allowed) * overallStrength);
      allowedWeight[j] = aceClamp(allowed, ACE_STAR_PROTECTION_FLOOR, 1);
   }
   return { protectionMask: protectionMask, allowedWeight: allowedWeight };
}

function aceComposeStarProtectionMapsFast(width, height, base, protectStars, protectHalos, advanced) {
   if (!protectStars || !base)
      return aceEmptyStarProtectionMaps(width, height);
   var count = width * height;
   var protectionMask = new Float32Array(count);
   var allowedWeight = new Float32Array(count);
   var starStrength = ACE_STAR_CORE_STRENGTH * aceAdvancedFactor(advanced, "starProtectionStrength");
   var haloStrength = ACE_STAR_HALO_STRENGTH * aceAdvancedFactor(advanced, "haloProtectionStrength");
   var overallStrength = aceAdvancedFactor(advanced, "overallProtectionStrength");
   for (var k = 0; k < count; ++k) {
      var core = base.coreMask[k];
      var halo = protectHalos ? base.haloMask[k] : core;
      var coreProtection = core * starStrength;
      var haloProtection = protectHalos ? Math.max(0, halo - core * 0.45) * haloStrength : 0;
      protectionMask[k] = aceClamp01(Math.max(coreProtection, haloProtection));
   }
   protectionMask = aceBoxBlurFloat(width, height, protectionMask, Math.max(1, Math.round(aceAdvancedFactor(advanced, "protectionSoftness"))));
   for (var j = 0; j < count; ++j) {
      protectionMask[j] = aceClamp01(protectionMask[j]);
      var allowed = 1 - protectionMask[j];
      if (overallStrength !== 1)
         allowed = aceClamp01(1 - aceClamp01(1 - allowed) * overallStrength);
      allowedWeight[j] = aceClamp(allowed, ACE_STAR_PROTECTION_FLOOR, 1);
   }
   return { protectionMask: protectionMask, allowedWeight: allowedWeight };
}

function aceComposeStarProtectionMapsFullResolutionFast(width, height, base, protectStars, protectHalos, advanced) {
   if (!protectStars || !base)
      return aceEmptyStarProtectionMaps(width, height);
   if (base.width === width && base.height === height)
      return aceComposeStarProtectionMapsFast(width, height, base, protectStars, protectHalos, advanced);
   var smallMaps = aceComposeStarProtectionMapsFast(base.width, base.height, base, protectStars, protectHalos, advanced);
   return {
      protectionMask: aceUpsampleFloatBilinear(base.width, base.height, smallMaps.protectionMask, width, height),
      allowedWeight: aceUpsampleFloatBilinear(base.width, base.height, smallMaps.allowedWeight, width, height)
   };
}

function aceBuildTextureGridGuard(width, height, luminance, textureLayer, strength) {
   var count = width * height;
   var risk = new Float32Array(count);
   var weight = new Float32Array(count);
   var smoothStrength = aceClamp(strength, 0, 1);
   for (var i = 0; i < count; ++i) {
      risk[i] = 0;
      weight[i] = 1;
   }
   if (width < 3 || height < 3)
      return { risk: risk, weight: weight };
   for (var y = 1; y < height - 1; ++y) {
      var row = y * width;
      for (var x = 1; x < width - 1; ++x) {
         var k = row + x;
         var c = textureLayer[k];
         var n = textureLayer[k - width];
         var s = textureLayer[k + width];
         var w = textureLayer[k - 1];
         var e = textureLayer[k + 1];
         var nw = textureLayer[k - width - 1];
         var ne = textureLayer[k - width + 1];
         var sw = textureLayer[k + width - 1];
         var se = textureLayer[k + width + 1];
         var axisSecond = Math.abs(w - 2 * c + e) + Math.abs(n - 2 * c + s);
         var diagSecond = Math.abs(nw - 2 * c + se) + Math.abs(ne - 2 * c + sw);
         var neighborMean = (n + s + w + e) * 0.25;
         var signFlip =
            ((c > 0 && n < 0) || (c < 0 && n > 0) ? 1 : 0) +
            ((c > 0 && s < 0) || (c < 0 && s > 0) ? 1 : 0) +
            ((c > 0 && w < 0) || (c < 0 && w > 0) ? 1 : 0) +
            ((c > 0 && e < 0) || (c < 0 && e > 0) ? 1 : 0);
         var lc = luminance[k];
         var ln = luminance[k - width];
         var ls = luminance[k + width];
         var lw = luminance[k - 1];
         var le = luminance[k + 1];
         var lnw = luminance[k - width - 1];
         var lne = luminance[k - width + 1];
         var lsw = luminance[k + width - 1];
         var lse = luminance[k + width + 1];
         var sourceAxis = Math.abs(lw - 2 * lc + le) + Math.abs(ln - 2 * lc + ls);
         var sourceDiag = Math.abs(lnw - 2 * lc + lse) + Math.abs(lne - 2 * lc + lsw);
         var mapEnergy = axisSecond + diagSecond + Math.abs(c - neighborMean);
         var sourceSupport = sourceAxis + sourceDiag + ACE_EPSILON;
         var unsupportedGrid = aceSmoothStep(0.012, 0.070, mapEnergy - sourceSupport * 0.85);
         var axisBias = aceSmoothStep(0.006, 0.050, axisSecond - diagSecond * 0.80 - sourceAxis * 0.25);
         var checkerRisk = aceSmoothStep(0.006, 0.040, Math.abs(c - neighborMean)) * (signFlip / 4.0);
         var activeTexture = aceSmoothStep(0.0025, 0.020, Math.abs(c));
         risk[k] = aceClamp01(activeTexture * Math.max(unsupportedGrid * 0.75, axisBias * 0.65, checkerRisk));
      }
   }
   var smoothRisk = aceIsotropicGaussianBlurFloat(width, height, risk, 0.80);
   for (var j = 0; j < count; ++j)
      weight[j] = aceClamp(1 - smoothStrength * smoothRisk[j], 0.22, 1);
   return { risk: smoothRisk, weight: weight };
}

function acePerfMark(timing, label, startMs) {
   if (timing && timing.items)
      timing.items.push({ label: label, ms: Date.now() - startMs });
}

function aceTimingSummary(timing, maxItems) {
   if (!timing || !timing.items || timing.items.length === 0)
      return "stages=none";
   var items = timing.items.slice(0);
   items.sort(function(a, b) { return b.ms - a.ms; });
   var limit = Math.min(maxItems || 8, items.length);
   var parts = [];
   for (var i = 0; i < limit; ++i) {
      var label = String(items[i].label || "stage").replace(/^Detail preview detail - /, "").replace(/^Detail preview /, "");
      parts.push(label + "=" + items[i].ms + "ms");
   }
   return parts.join(" | ");
}

function aceConsoleWriteLine(text) {
   if (typeof console !== "undefined" && console && typeof console.writeln === "function")
      console.writeln(text);
   else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
      Console.writeln(text);
}

function aceDevelopmentConsoleWriteLine(text) {
   if (ACE_DEVELOPMENT_CONSOLE_LOGS_ENABLED || ACE_DEBUG_CONTROLS_ENABLED)
      aceConsoleWriteLine(text);
}

function MultiScaleContrastEngine() {
}

function aceTextureModeUsesFastHybrid(mode) {
   mode = aceNormalizeTextureMode(mode);
   return mode === ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST;
}

function aceTextureHybridFlavorForMode(mode) {
   return aceTextureModeUsesFastHybrid(mode) ? "fast" : "exact";
}

function aceTextureHybridNeedsTensorLayer(mode) {
   mode = aceNormalizeTextureMode(mode);
   return mode === ACE_TEXTURE_MODE_TENSOR_LIMITED_REF ||
      mode === ACE_TEXTURE_MODE_HYBRID_CONSERVATIVE;
}

function aceLayerCacheNeedsTextureHybrid(cache, flavor) {
   flavor = flavor || "exact";
   return !cache || !cache.textureHybridReady || cache.textureHybridFlavor !== flavor;
}

function acePreviewNeedsTextureHybrid(params) {
   if (!params || params.texture === 0)
      return false;
   return aceTextureModeUsesDogTensorHybrid(params.textureMode);
}

function acePreviewTextureHybridFlavor(params) {
   return aceTextureHybridFlavorForMode(params ? params.textureMode : ACE_TEXTURE_MODE_DEFAULT);
}

function aceTextureModeNeedsHybridStarMask(mode) {
   mode = aceNormalizeTextureMode(mode);
   return mode === ACE_TEXTURE_MODE_PRODUCT_MAP_STAR_HYGIENE ||
      mode === ACE_TEXTURE_MODE_SAFE_PRODUCT_STAR_HYGIENE;
}

function aceParamsAreTextureOnly(params) {
   return !!params && params.texture !== 0 && params.clarity === 0 && params.dehaze === 0;
}

function aceParamsUseProductDualZoneClarity(params) {
   if (!params || params.clarity <= 0)
      return false;
   var mode = aceNormalizeClarityMode(params.clarityMode);
   return mode === ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT || aceIsClarityDualZoneBoostMode(mode);
}

function aceLayerCacheRequirementsForParams(params) {
   return {
      textureHybrid: acePreviewNeedsTextureHybrid(params),
      textureHybridFlavor: acePreviewTextureHybridFlavor(params),
      textureHybridMode: aceNormalizeTextureMode(params ? params.textureMode : ACE_TEXTURE_MODE_DEFAULT),
      textureHybridStarMask: aceTextureModeNeedsHybridStarMask(params ? params.textureMode : ACE_TEXTURE_MODE_DEFAULT),
      textureOnlyLean: aceParamsAreTextureOnly(params),
      clarityDualZoneLean: aceParamsUseProductDualZoneClarity(params)
   };
}

MultiScaleContrastEngine.prototype.buildLayerCache = function(width, height, rgb, advanced, timing, timingPrefix, sampleScale, requirements) {
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   var totalStart = timingActive ? Date.now() : 0;
   var stage = timingActive ? Date.now() : 0;
   requirements = requirements || {};
   var buildTextureHybridMaps = requirements.textureHybrid !== false;
   var textureHybridFlavor = requirements.textureHybridFlavor === "fast" ? "fast" : "exact";
   var textureHybridMode = aceNormalizeTextureMode(requirements.textureHybridMode || ACE_TEXTURE_MODE_DEFAULT);
   var useFastTextureHybrid = buildTextureHybridMaps && textureHybridFlavor === "fast";
   var buildTextureHybridStarMask = requirements.textureHybridStarMask !== false;
   var textureOnlyLean = !!requirements.textureOnlyLean;
   var clarityDualZoneLean = !!requirements.clarityDualZoneLean && !textureOnlyLean;
   var luminance = aceLuminanceFromRgb(width, height, rgb);
   acePerfMark(timing, prefix + " detail - layer luminance", stage);
   advanced = aceCopyAdvancedParams(advanced);
   var radiusScale = aceClamp((typeof sampleScale === "number" && isFinite(sampleScale)) ? sampleScale : 1, 0.25, 1);
   var radiusGap = Math.max(1, Math.round(2 * radiusScale));
   var textureRadius = Math.max(1, Math.round(ACE_TEXTURE_RADIUS * aceAdvancedFactor(advanced, "textureScale") * radiusScale));
   var clarityRadius = Math.max(textureRadius + radiusGap, Math.round(ACE_CLARITY_RADIUS * aceAdvancedFactor(advanced, "clarityScale") * radiusScale));
   var dehazeRadius = Math.max(clarityRadius + radiusGap, Math.round(ACE_DEHAZE_RADIUS * aceAdvancedFactor(advanced, "dehazeVeilSize") * radiusScale));
   var textureFineRadius = Math.max(1, Math.round(textureRadius * 0.40));
   var textureBandRadius = Math.max(textureFineRadius + radiusGap, textureRadius);
   var textureWide60Radius = Math.max(textureRadius, Math.round(ACE_TEXTURE_WIDE60_RADIUS * radiusScale));
   var textureWide60FineRadius = Math.max(1, Math.round(textureWide60Radius * ACE_TEXTURE_WIDE60_FINE_RADIUS_FACTOR));
   var textureWide60BandRadius = Math.max(textureWide60FineRadius + radiusGap, textureWide60Radius);
   var clarityV4SmallRadius = Math.max(CLARITY_V4_SMALL_RADIUS_MIN, Math.round(textureRadius * CLARITY_V4_SMALL_RADIUS_TEXTURE_FACTOR));
   var clarityV4BroadRadius = Math.max(clarityRadius + Math.max(2, Math.round(4 * radiusScale)), Math.round(clarityRadius * CLARITY_V4_BROAD_RADIUS_FACTOR));
   var clarityV4ActivityRadius = Math.max(2, Math.round(clarityRadius * CLARITY_V4_ACTIVITY_RADIUS_FACTOR));
   var count = width * height;
   var buildArchivedTextureMaps = !!ACE_DEBUG_CONTROLS_ENABLED;
   var sourceSaturation = new Float32Array(count);
   if (buildArchivedTextureMaps) {
      for (var si = 0; si < count; ++si) {
         var sbase = si * 3;
         var sr = rgb[sbase];
         var sg = rgb[sbase + 1];
         var sb = rgb[sbase + 2];
         var smax = Math.max(sr, sg, sb);
         var smin = Math.min(sr, sg, sb);
         sourceSaturation[si] = smax > ACE_EPSILON ? (smax - smin) / smax : 0;
      }
   }
   var texturePrecondition = buildArchivedTextureMaps ?
      aceTextureCompactBrightPreconditionFloat(width, height, luminance, sourceSaturation) :
      { luminance: luminance, mask: null };
   stage = timingActive ? Date.now() : 0;
   var textureFineBlur = aceTextureScaleBlurFloat(width, height, luminance, textureFineRadius);
   acePerfMark(timing, prefix + " detail - texture fine blur r" + textureFineRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var textureBlur = aceTextureScaleBlurFloat(width, height, luminance, textureBandRadius);
   acePerfMark(timing, prefix + " detail - texture scale blur r" + textureBandRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var textureIsoFineBlur = buildArchivedTextureMaps ? aceTextureIsoCoreBlurFloat(width, height, texturePrecondition.luminance, textureFineRadius) : textureFineBlur;
   acePerfMark(timing, prefix + " detail - Texture IsoCore fine blur r" + textureFineRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var textureIsoBlur = buildArchivedTextureMaps ? aceTextureIsoCoreBlurFloat(width, height, texturePrecondition.luminance, textureBandRadius) : textureBlur;
   acePerfMark(timing, prefix + " detail - Texture IsoCore scale blur r" + textureBandRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var textureIsotropicOnlyFineBlur = buildArchivedTextureMaps ? aceTextureIsoCoreBlurFloat(width, height, luminance, textureFineRadius) : textureFineBlur;
   acePerfMark(timing, prefix + " detail - Texture IsotropicOnly fine blur r" + textureFineRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var textureIsotropicOnlyBlur = buildArchivedTextureMaps ? aceTextureIsoCoreBlurFloat(width, height, luminance, textureBandRadius) : textureBlur;
   acePerfMark(timing, prefix + " detail - Texture IsotropicOnly scale blur r" + textureBandRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var textureCompactOnlyFineBlur = buildArchivedTextureMaps ? aceTextureScaleBlurFloat(width, height, texturePrecondition.luminance, textureFineRadius) : textureFineBlur;
   acePerfMark(timing, prefix + " detail - Texture CompactBrightOnly fine blur r" + textureFineRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var textureCompactOnlyBlur = buildArchivedTextureMaps ? aceTextureScaleBlurFloat(width, height, texturePrecondition.luminance, textureBandRadius) : textureBlur;
   acePerfMark(timing, prefix + " detail - Texture CompactBrightOnly scale blur r" + textureBandRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var textureWide60FineBlur = buildArchivedTextureMaps ? (textureWide60FineRadius === textureFineRadius ? textureFineBlur : aceTextureScaleBlurFloat(width, height, luminance, textureWide60FineRadius)) : textureFineBlur;
   acePerfMark(timing, prefix + " detail - Texture Wide60 fine blur r" + textureWide60FineRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var textureWide60Blur = buildArchivedTextureMaps ? (textureWide60BandRadius === textureBandRadius ? textureBlur : aceTextureScaleBlurFloat(width, height, luminance, textureWide60BandRadius)) : textureBlur;
   acePerfMark(timing, prefix + " detail - Texture Wide60 scale blur r" + textureWide60BandRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var clarityBlur = textureOnlyLean ? textureBlur : aceSoftScaleBlurFloat(width, height, luminance, clarityRadius);
   acePerfMark(timing, prefix + " detail - clarity scale blur r" + clarityRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var clarityV4SmallBlur = textureOnlyLean ? textureBlur : (clarityV4SmallRadius === textureBandRadius ? textureBlur : aceSoftScaleBlurFloat(width, height, luminance, clarityV4SmallRadius));
   acePerfMark(timing, prefix + " detail - clarity V4 small blur r" + clarityV4SmallRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var clarityV4BroadBlur = textureOnlyLean ? textureBlur : aceSoftScaleBlurFloat(width, height, luminance, clarityV4BroadRadius);
   acePerfMark(timing, prefix + " detail - clarity V4 broad blur r" + clarityV4BroadRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var dehazeBlur = textureOnlyLean ? textureBlur : aceBoxBlurFloat(width, height, luminance, dehazeRadius);
   acePerfMark(timing, prefix + " detail - legacy dehaze blur r" + dehazeRadius, stage);
   var textureLayer = new Float32Array(count);
   var textureArtifactSafeLayer = buildArchivedTextureMaps ? new Float32Array(count) : textureLayer;
   var textureIsotropicOnlyLayer = buildArchivedTextureMaps ? new Float32Array(count) : textureLayer;
   var textureCompactBrightOnlyLayer = buildArchivedTextureMaps ? new Float32Array(count) : textureLayer;
   var textureWide60Layer = buildArchivedTextureMaps ? new Float32Array(count) : textureLayer;
   var clarityLayer = new Float32Array(count);
   var skipLegacyClarityScaffolding = textureOnlyLean || clarityDualZoneLean;
   var clarityV2Layer = skipLegacyClarityScaffolding ? clarityLayer : new Float32Array(count);
   var clarityV2Allowed = skipLegacyClarityScaffolding ? clarityLayer : new Float32Array(count);
   var clarityV2Response = skipLegacyClarityScaffolding ? clarityLayer : new Float32Array(count);
   var clarityV2LocalDeviation = skipLegacyClarityScaffolding ? clarityLayer : new Float32Array(count);
   var clarityV2MidtoneWeight = skipLegacyClarityScaffolding ? clarityLayer : new Float32Array(count);
   var clarityV2ActivityWeight = skipLegacyClarityScaffolding ? clarityLayer : new Float32Array(count);
   var clarityV3AbsDeviation = skipLegacyClarityScaffolding ? clarityLayer : new Float32Array(count);
   var clarityV4ReliefSignal = textureOnlyLean ? clarityLayer : new Float32Array(count);
   var clarityV4ReliefAbs = textureOnlyLean ? clarityLayer : new Float32Array(count);
   var dehazeLayer = new Float32Array(count);
   var structureSeed = new Float32Array(count);
   stage = timingActive ? Date.now() : 0;
   for (var i = 0; i < count; ++i) {
      var base = i * 3;
      var r = rgb[base];
      var g = rgb[base + 1];
      var b = rgb[base + 2];
      if (!buildArchivedTextureMaps) {
         var smaxLoop = Math.max(r, g, b);
         var sminLoop = Math.min(r, g, b);
         sourceSaturation[i] = smaxLoop > ACE_EPSILON ? (smaxLoop - sminLoop) / smaxLoop : 0;
      }
      var l = luminance[i];
      var fineEdgeLayer = (l - textureFineBlur[i]) * ACE_TEXTURE_EDGE_GAIN;
      var scaleTextureLayer = (textureFineBlur[i] - textureBlur[i]) * ACE_TEXTURE_BANDPASS_GAIN;
      var rawTextureLayer = fineEdgeLayer + scaleTextureLayer * ACE_TEXTURE_SCALE_MIX;
      var rawClarityLayer = (textureBlur[i] - clarityBlur[i]) * ACE_CLARITY_BANDPASS_GAIN;
      textureLayer[i] = ACE_TEXTURE_BANDPASS_SOFT_LIMIT * Math.tanh(rawTextureLayer / ACE_TEXTURE_BANDPASS_SOFT_LIMIT);
      if (buildArchivedTextureMaps) {
         var isoL = texturePrecondition.luminance[i];
         var isoFineEdgeLayer = (isoL - textureIsoFineBlur[i]) * ACE_TEXTURE_EDGE_GAIN;
         var isoScaleTextureLayer = (textureIsoFineBlur[i] - textureIsoBlur[i]) * ACE_TEXTURE_BANDPASS_GAIN;
         var rawIsoTextureLayer = isoFineEdgeLayer + isoScaleTextureLayer * ACE_TEXTURE_SCALE_MIX;
         var isotropicOnlyFineEdgeLayer = (l - textureIsotropicOnlyFineBlur[i]) * ACE_TEXTURE_EDGE_GAIN;
         var isotropicOnlyScaleTextureLayer = (textureIsotropicOnlyFineBlur[i] - textureIsotropicOnlyBlur[i]) * ACE_TEXTURE_BANDPASS_GAIN;
         var rawIsotropicOnlyTextureLayer = isotropicOnlyFineEdgeLayer + isotropicOnlyScaleTextureLayer * ACE_TEXTURE_SCALE_MIX;
         var compactOnlyFineEdgeLayer = (isoL - textureCompactOnlyFineBlur[i]) * ACE_TEXTURE_EDGE_GAIN;
         var compactOnlyScaleTextureLayer = (textureCompactOnlyFineBlur[i] - textureCompactOnlyBlur[i]) * ACE_TEXTURE_BANDPASS_GAIN;
         var rawCompactOnlyTextureLayer = compactOnlyFineEdgeLayer + compactOnlyScaleTextureLayer * ACE_TEXTURE_SCALE_MIX;
         var wide60FineEdgeLayer = (l - textureWide60FineBlur[i]) * ACE_TEXTURE_EDGE_GAIN;
         var wide60ScaleTextureLayer = (textureWide60FineBlur[i] - textureWide60Blur[i]) * ACE_TEXTURE_BANDPASS_GAIN;
         var rawWide60TextureLayer = wide60FineEdgeLayer + wide60ScaleTextureLayer * ACE_TEXTURE_SCALE_MIX;
         textureArtifactSafeLayer[i] = aceSoftLimitSigned(rawIsoTextureLayer, ACE_TEXTURE_BANDPASS_SOFT_LIMIT);
         textureIsotropicOnlyLayer[i] = aceSoftLimitSigned(rawIsotropicOnlyTextureLayer, ACE_TEXTURE_BANDPASS_SOFT_LIMIT);
         textureCompactBrightOnlyLayer[i] = aceSoftLimitSigned(rawCompactOnlyTextureLayer, ACE_TEXTURE_BANDPASS_SOFT_LIMIT);
         textureWide60Layer[i] = aceSoftLimitSigned(rawWide60TextureLayer, ACE_TEXTURE_BANDPASS_SOFT_LIMIT);
      }
      if (textureOnlyLean) {
         clarityLayer[i] = 0;
         dehazeLayer[i] = 0;
         structureSeed[i] = Math.abs(textureLayer[i]) * ACE_TEXTURE_STRUCTURE_SUPPORT_SCALE + ACE_TEXTURE_STRUCTURE_SELF_SUPPORT;
      } else if (clarityDualZoneLean) {
         clarityLayer[i] = ACE_CLARITY_BANDPASS_SOFT_LIMIT * Math.tanh(rawClarityLayer / ACE_CLARITY_BANDPASS_SOFT_LIMIT);
         var bandFineMidLean = clarityV4SmallBlur[i] - clarityBlur[i];
         var bandMidBroadLean = clarityBlur[i] - clarityV4BroadBlur[i];
         var reliefLean = CLARITY_V4_FINE_MID_WEIGHT * bandFineMidLean + CLARITY_V4_MID_BROAD_WEIGHT * bandMidBroadLean;
         clarityV4ReliefSignal[i] = reliefLean;
         clarityV4ReliefAbs[i] = Math.abs(reliefLean);
         var bgGateTLean = (l - 0.04) / 0.20;
         bgGateTLean = bgGateTLean < 0 ? 0 : (bgGateTLean > 1 ? 1 : bgGateTLean);
         var backgroundGateLean = bgGateTLean * bgGateTLean * (3 - 2 * bgGateTLean);
         dehazeLayer[i] = (l - dehazeBlur[i]) * backgroundGateLean;
         var broadStructureSupportLean = Math.max(
            Math.abs(clarityLayer[i]) * ACE_TEXTURE_STRUCTURE_BROAD_SUPPORT_SCALE,
            Math.abs(dehazeLayer[i])
         ) + ACE_TEXTURE_STRUCTURE_SELF_SUPPORT;
         var textureStructureSupportLean = Math.min(
            Math.abs(textureLayer[i]) * ACE_TEXTURE_STRUCTURE_SUPPORT_SCALE,
            broadStructureSupportLean
         );
         structureSeed[i] = Math.max(
            textureStructureSupportLean,
            Math.abs(clarityLayer[i]) * 1.5,
            Math.abs(dehazeLayer[i]) * 0.8
         );
      } else {
         clarityLayer[i] = ACE_CLARITY_BANDPASS_SOFT_LIMIT * Math.tanh(rawClarityLayer / ACE_CLARITY_BANDPASS_SOFT_LIMIT);
         var clarityBand = textureBlur[i] - clarityBlur[i];
         var clarityActivity = Math.abs(clarityBand);
         var midtoneWeight =
            aceSmoothStep(CLARITY_V2_SHADOW_START, CLARITY_V2_MID_LOW, l) *
            (1 - aceSmoothStep(CLARITY_V2_HIGH_START, CLARITY_V2_HIGHLIGHT_END, l));
         var activityWeight =
            aceSmoothStep(CLARITY_V2_ACTIVITY_LOW_START, CLARITY_V2_ACTIVITY_LOW_END, clarityActivity) *
            (1 - aceSmoothStep(CLARITY_V2_ACTIVITY_HIGH_START, CLARITY_V2_ACTIVITY_HIGH_END, clarityActivity));
         var highlightWeight = 1 - CLARITY_V2_HIGHLIGHT_SUPPRESSION *
            aceSmoothStep(CLARITY_V2_HIGH_START, CLARITY_V2_HIGHLIGHT_END, l);
         var compactSignal = aceSmoothStep(0.010, 0.060, Math.max(0, textureLayer[i])) *
            aceSmoothStep(0.45, 0.92, l);
         var compactWeight = 1 - CLARITY_V2_COMPACT_SUPPRESSION * compactSignal;
         clarityV2Layer[i] = aceSoftLimitSigned(clarityBand, CLARITY_V2_SOFT_LIMIT);
         clarityV2Allowed[i] = aceClamp01(midtoneWeight * activityWeight * highlightWeight * compactWeight);
         clarityV2Response[i] = Math.abs(clarityV2Layer[i]) * clarityV2Allowed[i];
         clarityV2LocalDeviation[i] = l - clarityBlur[i];
         clarityV3AbsDeviation[i] = Math.abs(clarityV2LocalDeviation[i]);
         var bandFineMid = clarityV4SmallBlur[i] - clarityBlur[i];
         var bandMidBroad = clarityBlur[i] - clarityV4BroadBlur[i];
         var relief = CLARITY_V4_FINE_MID_WEIGHT * bandFineMid + CLARITY_V4_MID_BROAD_WEIGHT * bandMidBroad;
         clarityV4ReliefSignal[i] = relief;
         clarityV4ReliefAbs[i] = Math.abs(relief);
         clarityV2MidtoneWeight[i] = aceClamp01(midtoneWeight);
         clarityV2ActivityWeight[i] = aceClamp01(activityWeight);
         var bgGateT = (l - 0.04) / 0.20;
         bgGateT = bgGateT < 0 ? 0 : (bgGateT > 1 ? 1 : bgGateT);
         var backgroundGate = bgGateT * bgGateT * (3 - 2 * bgGateT);
         dehazeLayer[i] = (l - dehazeBlur[i]) * backgroundGate;
         var broadStructureSupport = Math.max(
            Math.abs(clarityLayer[i]) * ACE_TEXTURE_STRUCTURE_BROAD_SUPPORT_SCALE,
            Math.abs(dehazeLayer[i])
         ) + ACE_TEXTURE_STRUCTURE_SELF_SUPPORT;
         var textureStructureSupport = Math.min(
            Math.abs(textureLayer[i]) * ACE_TEXTURE_STRUCTURE_SUPPORT_SCALE,
            broadStructureSupport
         );
         structureSeed[i] = Math.max(
            textureStructureSupport,
            Math.abs(clarityLayer[i]) * 1.5,
            Math.abs(dehazeLayer[i]) * 0.8
         );
      }
   }
   acePerfMark(timing, prefix + " detail - layer residuals", stage);
   stage = timingActive ? Date.now() : 0;
   var textureGridGuard = buildArchivedTextureMaps ? aceBuildTextureGridGuard(width, height, luminance, textureLayer, 0.64) : null;
   var textureGridGuardLight = buildArchivedTextureMaps ? aceBuildTextureGridGuard(width, height, luminance, textureLayer, 0.42) : null;
   var textureGridGuardStrong = buildArchivedTextureMaps ? aceBuildTextureGridGuard(width, height, luminance, textureLayer, 0.82) : null;
   var textureCompactGridGuard = buildArchivedTextureMaps ? aceBuildTextureGridGuard(width, height, luminance, textureCompactBrightOnlyLayer, 0.64) : null;
   var textureCompactGridGuardLight = buildArchivedTextureMaps ? aceBuildTextureGridGuard(width, height, luminance, textureCompactBrightOnlyLayer, 0.42) : null;
   var textureCompactGridGuardStrong = buildArchivedTextureMaps ? aceBuildTextureGridGuard(width, height, luminance, textureCompactBrightOnlyLayer, 0.82) : null;
   var textureGridGuardLayer = new Float32Array(count);
   var textureGridGuardLightLayer = new Float32Array(count);
   var textureGridGuardStrongLayer = new Float32Array(count);
   var textureCompactGridGuardLayer = new Float32Array(count);
   var textureCompactGridGuardLightLayer = new Float32Array(count);
   var textureCompactGridGuardStrongLayer = new Float32Array(count);
   var textureSignalFixAALayer = new Float32Array(count);
   var textureSignalFixSourceLayer = new Float32Array(count);
   var textureSignalFixBlendLayer = new Float32Array(count);
   var textureSignalFixAgreement = new Float32Array(count);
   if (buildArchivedTextureMaps) {
      var textureSignalFixBroadSmall = aceIsotropicGaussianBlurFloat(width, height, luminance, 2.3);
      var textureSignalFixBroadLarge = aceIsotropicGaussianBlurFloat(width, height, luminance, 5.2);
      for (var gi = 0; gi < count; ++gi) {
         textureGridGuardLayer[gi] = textureLayer[gi] * textureGridGuard.weight[gi];
         textureGridGuardLightLayer[gi] = textureLayer[gi] * textureGridGuardLight.weight[gi];
         textureGridGuardStrongLayer[gi] = textureLayer[gi] * textureGridGuardStrong.weight[gi];
         textureCompactGridGuardLayer[gi] = textureCompactBrightOnlyLayer[gi] * textureCompactGridGuard.weight[gi];
         textureCompactGridGuardLightLayer[gi] = textureCompactBrightOnlyLayer[gi] * textureCompactGridGuardLight.weight[gi];
         textureCompactGridGuardStrongLayer[gi] = textureCompactBrightOnlyLayer[gi] * textureCompactGridGuardStrong.weight[gi];
         var sourceAgree = aceSmoothStep(0.002, 0.018, Math.abs(textureSignalFixBroadSmall[gi] - textureSignalFixBroadLarge[gi]));
         var signalFineHighpass = (luminance[gi] - textureFineBlur[gi]) * ACE_TEXTURE_EDGE_GAIN * (0.35 + 0.65 * sourceAgree);
         var signalBandpass = (textureFineBlur[gi] - textureBlur[gi]) * ACE_TEXTURE_BANDPASS_GAIN;
         textureSignalFixSourceLayer[gi] = aceSoftLimitSigned(signalFineHighpass + signalBandpass * ACE_TEXTURE_SCALE_MIX, ACE_TEXTURE_BANDPASS_SOFT_LIMIT);
         textureSignalFixAgreement[gi] = sourceAgree;
      }
      textureSignalFixAALayer = aceIsotropicGaussianBlurFloat(width, height, textureLayer, 0.48);
      for (var si2 = 0; si2 < count; ++si2)
         textureSignalFixBlendLayer[si2] = 0.55 * textureSignalFixAALayer[si2] + 0.45 * textureSignalFixSourceLayer[si2];
   } else {
      textureGridGuardLayer = textureLayer;
      textureGridGuardLightLayer = textureLayer;
      textureGridGuardStrongLayer = textureLayer;
      textureCompactGridGuardLayer = textureLayer;
      textureCompactGridGuardLightLayer = textureLayer;
      textureCompactGridGuardStrongLayer = textureLayer;
      textureSignalFixAALayer = textureLayer;
      textureSignalFixSourceLayer = textureLayer;
      textureSignalFixBlendLayer = textureLayer;
   }
   acePerfMark(timing, prefix + " detail - Texture GridGuard maps", stage);
   stage = timingActive ? Date.now() : 0;
   var textureHybrid = buildTextureHybridMaps ?
      aceBuildTextureHybridLayers(width, height, luminance, sourceSaturation, radiusScale, timing, prefix, useFastTextureHybrid, buildTextureHybridStarMask, textureHybridMode) : null;
   acePerfMark(timing, prefix + " detail - Texture DoG/tensor hybrid maps" + (buildTextureHybridMaps ? " " + textureHybridFlavor : " skipped"), stage);
   stage = timingActive ? Date.now() : 0;
   var clarityV3LocalScale = skipLegacyClarityScaffolding ? clarityLayer : aceSoftScaleBlurFloat(width, height, clarityV3AbsDeviation, Math.max(1, Math.round(clarityRadius * 0.5)));
   acePerfMark(timing, prefix + " detail - clarity V3 local scale", stage);
   stage = timingActive ? Date.now() : 0;
   var clarityV4Activity = aceSoftScaleBlurFloat(width, height, clarityV4ReliefAbs, clarityV4ActivityRadius);
   acePerfMark(timing, prefix + " detail - clarity V4 activity r" + clarityV4ActivityRadius, stage);
   stage = timingActive ? Date.now() : 0;
   var localStructure = aceSoftScaleBlurFloat(width, height, structureSeed, ACE_STRUCTURE_RADIUS);
   acePerfMark(timing, prefix + " detail - structure blur", stage);
   var confidence = new Float32Array(count);
   var allowedWeight = new Float32Array(count);
   var skyStrength = aceAdvancedFactor(advanced, "skyProtectionStrength");
   var overallStrength = aceAdvancedFactor(advanced, "overallProtectionStrength");
   var localFloor = null;
   var useFullResGlobalProtectionMapCandidate =
      prefix.indexOf("Global adjustment") === 0 &&
      ACE_FULLRES_GLOBAL_PROTECTION_MAP_DOWNSAMPLE > 1 &&
      Math.max(width, height) > 2200;
   if (useFullResGlobalProtectionMapCandidate) {
      stage = timingActive ? Date.now() : 0;
      var protectionSmallLum = aceDownsampleFloatAverage(width, height, luminance, ACE_FULLRES_GLOBAL_PROTECTION_MAP_DOWNSAMPLE);
      var protectionSmallStructure = aceDownsampleFloatAverage(width, height, localStructure, ACE_FULLRES_GLOBAL_PROTECTION_MAP_DOWNSAMPLE);
      var protectionFactor = Math.max(1, protectionSmallLum.factor);
      var protectionWidth = protectionSmallLum.width;
      var protectionHeight = protectionSmallLum.height;
      var protectionCount = protectionWidth * protectionHeight;
      var protectionFloorRadius = Math.max(1, Math.round(ACE_FLOOR_RADIUS / protectionFactor));
      var protectionFloorSupportRadius = Math.max(1, Math.round(ACE_LOCAL_FLOOR_SUPPORT_SMOOTH_RADIUS / protectionFactor));
      var protectionAllowedRadius = Math.max(1, Math.round(ACE_ALLOWED_SMOOTH_RADIUS * aceAdvancedFactor(advanced, "protectionSoftness") / protectionFactor));
      var smallLocalFloor = aceSoftLocalFloor(protectionWidth, protectionHeight, protectionSmallLum.data, protectionFloorRadius);
      smallLocalFloor = aceSmoothFloorSupport(protectionWidth, protectionHeight, smallLocalFloor, protectionSmallLum.data, protectionFloorSupportRadius);
      var smallConfidence = new Float32Array(protectionCount);
      var smallAllowed = new Float32Array(protectionCount);
      for (var sj = 0; sj < protectionCount; ++sj) {
         var smallFloorLift = aceClamp01((protectionSmallLum.data[sj] - smallLocalFloor[sj]) * 4.0);
         var smallConfidenceValue = Math.max(
            aceSmoothStep(0.006, 0.055, protectionSmallStructure.data[sj]),
            aceSmoothStep(0.015, 0.18, smallFloorLift)
         );
         smallConfidence[sj] = smallConfidenceValue;
         var smallPoweredConfidence = skyStrength === 1 ? smallConfidenceValue : Math.pow(smallConfidenceValue, skyStrength);
         var smallAllowedValue = ACE_ALLOWED_MIN + (1 - ACE_ALLOWED_MIN) * smallPoweredConfidence;
         if (overallStrength !== 1)
            smallAllowedValue = aceClamp01(1 - aceClamp01(1 - smallAllowedValue) * overallStrength);
         smallAllowed[sj] = aceClamp01(smallAllowedValue);
      }
      smallConfidence = aceSmoothMaskSupport(protectionWidth, protectionHeight, smallConfidence, Math.max(1, Math.round(ACE_STRUCTURE_CONFIDENCE_SMOOTH_RADIUS / protectionFactor)));
      for (var sk = 0; sk < protectionCount; ++sk) {
         var smallSmoothedConfidence = smallConfidence[sk];
         var smallSmoothedPowered = skyStrength === 1 ? smallSmoothedConfidence : Math.pow(smallSmoothedConfidence, skyStrength);
         var smallSmoothedAllowed = ACE_ALLOWED_MIN + (1 - ACE_ALLOWED_MIN) * smallSmoothedPowered;
         if (overallStrength !== 1)
            smallSmoothedAllowed = aceClamp01(1 - aceClamp01(1 - smallSmoothedAllowed) * overallStrength);
         smallAllowed[sk] = aceClamp01(smallSmoothedAllowed);
      }
      smallAllowed = aceSoftScaleBlurFloat(protectionWidth, protectionHeight, smallAllowed, protectionAllowedRadius);
      confidence = aceUpsampleFloatBilinear(protectionWidth, protectionHeight, smallConfidence, width, height);
      allowedWeight = aceUpsampleFloatBilinear(protectionWidth, protectionHeight, smallAllowed, width, height);
      localFloor = aceUpsampleFloatBilinear(protectionWidth, protectionHeight, smallLocalFloor, width, height);
      acePerfMark(timing, prefix + " detail - fullres global protection maps x" + protectionFactor, stage);
   } else {
      stage = timingActive ? Date.now() : 0;
      localFloor = aceSoftLocalFloor(width, height, luminance, ACE_FLOOR_RADIUS);
      acePerfMark(timing, prefix + " detail - local floor", stage);
      stage = timingActive ? Date.now() : 0;
      localFloor = aceSmoothFloorSupport(width, height, localFloor, luminance, ACE_LOCAL_FLOOR_SUPPORT_SMOOTH_RADIUS);
      acePerfMark(timing, prefix + " detail - local floor support smoothing", stage);
      stage = timingActive ? Date.now() : 0;
      for (var j = 0; j < count; ++j) {
         var floorLift = aceClamp01((luminance[j] - localFloor[j]) * 4.0);
         var confidenceValue = Math.max(
            aceSmoothStep(0.006, 0.055, localStructure[j]),
            aceSmoothStep(0.015, 0.18, floorLift)
         );
         confidence[j] = confidenceValue;
         var poweredConfidence = skyStrength === 1 ? confidenceValue : Math.pow(confidenceValue, skyStrength);
         var allowed = ACE_ALLOWED_MIN + (1 - ACE_ALLOWED_MIN) * poweredConfidence;
         if (overallStrength !== 1)
            allowed = aceClamp01(1 - aceClamp01(1 - allowed) * overallStrength);
         allowedWeight[j] = aceClamp01(allowed);
      }
      acePerfMark(timing, prefix + " detail - confidence/allowed", stage);
      stage = timingActive ? Date.now() : 0;
      confidence = aceSmoothMaskSupport(width, height, confidence, ACE_STRUCTURE_CONFIDENCE_SMOOTH_RADIUS);
      acePerfMark(timing, prefix + " detail - confidence support smoothing", stage);
      stage = timingActive ? Date.now() : 0;
      for (var k = 0; k < count; ++k) {
         var smoothedConfidence = confidence[k];
         var smoothedPowered = skyStrength === 1 ? smoothedConfidence : Math.pow(smoothedConfidence, skyStrength);
         var smoothedAllowed = ACE_ALLOWED_MIN + (1 - ACE_ALLOWED_MIN) * smoothedPowered;
         if (overallStrength !== 1)
            smoothedAllowed = aceClamp01(1 - aceClamp01(1 - smoothedAllowed) * overallStrength);
         allowedWeight[k] = aceClamp01(smoothedAllowed);
      }
      acePerfMark(timing, prefix + " detail - allowed from smoothed confidence", stage);
      stage = timingActive ? Date.now() : 0;
      allowedWeight = aceSoftScaleBlurFloat(width, height, allowedWeight, Math.max(1, Math.round(ACE_ALLOWED_SMOOTH_RADIUS * aceAdvancedFactor(advanced, "protectionSoftness"))));
      acePerfMark(timing, prefix + " detail - allowed smoothing", stage);
   }
   acePerfMark(timing, prefix + " detail - layer cache total", totalStart);
   return {
      width: width,
      height: height,
      sampleScale: radiusScale,
      advancedKey: aceAdvancedKey(advanced),
      textureHybridReady: !!textureHybrid,
      textureHybridFlavor: textureHybrid ? textureHybridFlavor : "",
      luminance: luminance,
      legacyDehazeBlur: dehazeBlur,
      sourceSaturation: sourceSaturation,
      textureLayer: textureLayer,
      textureArtifactSafeLayer: textureArtifactSafeLayer,
      textureIsotropicOnlyLayer: textureIsotropicOnlyLayer,
      textureCompactBrightOnlyLayer: textureCompactBrightOnlyLayer,
      textureGridGuardLayer: textureGridGuardLayer,
      textureGridGuardLightLayer: textureGridGuardLightLayer,
      textureGridGuardStrongLayer: textureGridGuardStrongLayer,
      textureCompactGridGuardLayer: textureCompactGridGuardLayer,
      textureCompactGridGuardLightLayer: textureCompactGridGuardLightLayer,
      textureCompactGridGuardStrongLayer: textureCompactGridGuardStrongLayer,
      textureSignalFixAALayer: textureSignalFixAALayer,
      textureSignalFixSourceLayer: textureSignalFixSourceLayer,
      textureSignalFixBlendLayer: textureSignalFixBlendLayer,
      textureSignalFixAgreement: textureSignalFixAgreement,
      textureDogMidblendLayer: textureHybrid ? textureHybrid.dogMidblendLayer : null,
      textureTensorLimitedLayer: textureHybrid ? textureHybrid.tensorLimitedLayer : null,
      textureHybridConservativeLayer: textureHybrid ? textureHybrid.hybridConservativeLayer : null,
      textureHybridMediumLayer: textureHybrid ? textureHybrid.hybridMediumLayer : null,
      textureHybridLightLayer: textureHybrid ? textureHybrid.hybridLightLayer : null,
      textureHybridHighLayer: textureHybrid ? textureHybrid.hybridHighLayer : null,
      textureHybridTensorConfidence: textureHybrid ? textureHybrid.tensorConfidence : null,
      textureHybridTensorAcceptance: textureHybrid ? textureHybrid.tensorAcceptance : null,
      textureHybridStarMask: textureHybrid ? textureHybrid.hybridStarMask : null,
      textureGridGuardRisk: textureGridGuard ? textureGridGuard.risk : null,
      textureGridGuardWeight: textureGridGuard ? textureGridGuard.weight : null,
      textureGridGuardLightWeight: textureGridGuardLight ? textureGridGuardLight.weight : null,
      textureGridGuardStrongWeight: textureGridGuardStrong ? textureGridGuardStrong.weight : null,
      textureCompactGridGuardRisk: textureCompactGridGuard ? textureCompactGridGuard.risk : null,
      textureCompactGridGuardWeight: textureCompactGridGuard ? textureCompactGridGuard.weight : null,
      textureCompactGridGuardLightWeight: textureCompactGridGuardLight ? textureCompactGridGuardLight.weight : null,
      textureCompactGridGuardStrongWeight: textureCompactGridGuardStrong ? textureCompactGridGuardStrong.weight : null,
      texturePreconditionedLuminance: texturePrecondition.luminance,
      textureCompactBrightMask: texturePrecondition.mask,
      textureIsoFineBlur: textureIsoFineBlur,
      textureIsoBlur: textureIsoBlur,
      textureWide60Layer: textureWide60Layer,
      clarityLayer: clarityLayer,
      clarityV2Layer: clarityV2Layer,
      clarityV2Allowed: clarityV2Allowed,
      clarityV2Response: clarityV2Response,
      clarityV2LocalDeviation: clarityV2LocalDeviation,
      clarityV2MidtoneWeight: clarityV2MidtoneWeight,
      clarityV2ActivityWeight: clarityV2ActivityWeight,
      clarityV3LocalBase: clarityBlur,
      clarityV3LocalScale: clarityV3LocalScale,
      clarityV4ReliefSignal: clarityV4ReliefSignal,
      clarityV4Activity: clarityV4Activity,
      dehazeLayer: dehazeLayer,
      localFloor: localFloor,
      structureConfidence: confidence,
      allowedWeight: allowedWeight,
      lastAllowedWeight: allowedWeight
   };
};

MultiScaleContrastEngine.prototype.dehazeStrength = function(sliderValue) {
   var x = aceClamp(sliderValue / 100, -1.25, 1.25);
   var sign = x < 0 ? -1 : 1;
   return sign * Math.pow(Math.abs(x), ACE_DEHAZE_SLIDER_GAMMA);
};

MultiScaleContrastEngine.prototype.ensureDehazeVeilCache = function(width, height, rgb, cache, starAllowedWeight, advanced, timing, timingPrefix) {
   if (!cache)
      return null;
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   var advancedKey = aceAdvancedKey(advanced);
   if (cache.dehazeVeil && cache.dehazeVeilStarAllowedWeight === starAllowedWeight && cache.dehazeVeilAdvancedKey === advancedKey) {
      acePerfMark(timing, prefix + " detail - dehaze veil cache hit", timingActive ? Date.now() : 0);
      return cache.dehazeVeil;
   }
   var totalStart = timingActive ? Date.now() : 0;
   var count = width * height;
   var luminance = cache.luminance;
   var cleaned = new Float32Array(count);
   var compactAllowed = new Float32Array(count);
   var highlightAllowed = new Float32Array(count);
   var highlightProtectFactor = aceAdvancedFactor(advanced, "dehazeHighlightProtect");
   var compactProtectFactor = aceAdvancedFactor(advanced, "dehazeCompactProtect");
   var stage = timingActive ? Date.now() : 0;
   for (var i = 0; i < count; ++i) {
      if ((i & 131071) === 0)
         aceYieldToPixInsight();
      var l = luminance[i];
      var starAllowed = starAllowedWeight ? starAllowedWeight[i] : 1;
      var highT = (l - ACE_DEHAZE_HIGHLIGHT_START) / (ACE_DEHAZE_HIGHLIGHT_END - ACE_DEHAZE_HIGHLIGHT_START);
      highT = highT < 0 ? 0 : (highT > 1 ? 1 : highT);
      var highlightProtect = highT * highT * (3 - 2 * highT) * highlightProtectFactor;
      highlightProtect = highlightProtect < 0 ? 0 : (highlightProtect > 1 ? 1 : highlightProtect);
      var compactProtect = Math.max((1 - starAllowed) * compactProtectFactor, highlightProtect);
      var compactKeep = 1 - compactProtect;
      compactAllowed[i] = compactKeep < 0 ? 0 : (compactKeep > 1 ? 1 : compactKeep);
      var highlightKeep = 1 - highlightProtect;
      highlightAllowed[i] = highlightKeep < 0 ? 0 : (highlightKeep > 1 ? 1 : highlightKeep);
      var localFloor = cache.localFloor ? cache.localFloor[i] : Math.min(l, cache.legacyDehazeBlur ? cache.legacyDehazeBlur[i] : l);
      var floorT = (localFloor - 0.05) / 0.30;
      floorT = floorT < 0 ? 0 : (floorT > 1 ? 1 : floorT);
      var replacement = Math.min(l, localFloor + 0.10 + 0.15 * floorT * floorT * (3 - 2 * floorT));
      cleaned[i] = l * (1 - compactProtect) + replacement * compactProtect;
   }
   acePerfMark(timing, prefix + " detail - dehaze clean/protect", stage);
   var maxEdge = Math.max(width, height);
   var factor = maxEdge > 2200 ? ACE_DEHAZE_FULLRES_DOWNSAMPLE : ACE_DEHAZE_PREVIEW_DOWNSAMPLE;
   stage = timingActive ? Date.now() : 0;
   var small = aceDownsampleFloatAverage(width, height, cleaned, factor);
   acePerfMark(timing, prefix + " detail - dehaze downsample x" + small.factor, stage);
   var smallBlur = small.data;
   var radius = Math.max(2, Math.round(ACE_DEHAZE_VEIL_RADIUS * aceAdvancedFactor(advanced, "dehazeVeilSize") / Math.max(1, small.factor)));
   stage = timingActive ? Date.now() : 0;
   for (var pass = 0; pass < ACE_DEHAZE_VEIL_PASSES; ++pass)
      smallBlur = aceBoxBlurFloat(small.width, small.height, smallBlur, radius);
   acePerfMark(timing, prefix + " detail - dehaze veil blur r" + radius + " x" + ACE_DEHAZE_VEIL_PASSES, stage);
   stage = timingActive ? Date.now() : 0;
   var veil = aceUpsampleFloatBilinear(small.width, small.height, smallBlur, width, height);
   acePerfMark(timing, prefix + " detail - dehaze upsample", stage);
   var confidence = new Float32Array(count);
   var veilExcess = new Float32Array(count);
   var veilConfidence = aceAdvancedFactor(advanced, "dehazeVeilConfidence");
   var veilConfidenceLow = 0.010 * veilConfidence;
   var veilConfidenceHigh = 0.180 * veilConfidence;
   var useFullResDehazeConfidenceCandidate =
      prefix.indexOf("Global adjustment") === 0 &&
      ACE_FULLRES_DEHAZE_CONFIDENCE_DOWNSAMPLE > 1 &&
      maxEdge > 2200;
   if (useFullResDehazeConfidenceCandidate) {
      stage = timingActive ? Date.now() : 0;
      var dehazeConfidenceFactor = ACE_FULLRES_DEHAZE_CONFIDENCE_DOWNSAMPLE;
      var smallVeil = aceDownsampleFloatAverage(width, height, veil, dehazeConfidenceFactor);
      var smallFloor = cache.localFloor ?
         aceDownsampleFloatAverage(width, height, cache.localFloor, dehazeConfidenceFactor) :
         null;
      var confFactor = Math.max(1, smallVeil.factor);
      var confCount = smallVeil.width * smallVeil.height;
      var smallExcess = new Float32Array(confCount);
      for (var se = 0; se < confCount; ++se) {
         var seFloor = smallFloor ? smallFloor.data[se] : 0;
         smallExcess[se] = Math.max(0, smallVeil.data[se] - seFloor);
      }
      smallExcess = aceSmoothMaskSupport(smallVeil.width, smallVeil.height, smallExcess, Math.max(1, Math.round(ACE_DEHAZE_EXCESS_SMOOTH_RADIUS / confFactor)));
      var smallConfidence = new Float32Array(confCount);
      for (var sc = 0; sc < confCount; ++sc) {
         var smallVeilPresence = aceSmoothStep(veilConfidenceLow, veilConfidenceHigh, smallExcess[sc]);
         smallConfidence[sc] = aceClamp01(0.35 + 0.65 * smallVeilPresence);
      }
      smallConfidence = aceBoxBlurFloat(smallVeil.width, smallVeil.height, smallConfidence, Math.max(1, Math.round(ACE_ALLOWED_SMOOTH_RADIUS * 0.8 / confFactor)));
      veilExcess = aceUpsampleFloatBilinear(smallVeil.width, smallVeil.height, smallExcess, width, height);
      confidence = aceUpsampleFloatBilinear(smallVeil.width, smallVeil.height, smallConfidence, width, height);
      acePerfMark(timing, prefix + " detail - dehaze confidence/excess x" + confFactor, stage);
   } else {
      stage = timingActive ? Date.now() : 0;
      for (var j = 0; j < count; ++j) {
         if ((j & 131071) === 0)
            aceYieldToPixInsight();
         var floor = cache.localFloor ? cache.localFloor[j] : 0;
         var excess = Math.max(0, veil[j] - floor);
         veilExcess[j] = excess;
      }
      acePerfMark(timing, prefix + " detail - dehaze excess", stage);
      stage = timingActive ? Date.now() : 0;
      veilExcess = aceSmoothMaskSupport(width, height, veilExcess, ACE_DEHAZE_EXCESS_SMOOTH_RADIUS);
      acePerfMark(timing, prefix + " detail - dehaze excess smoothing", stage);
      stage = timingActive ? Date.now() : 0;
      for (var c = 0; c < count; ++c) {
         if ((c & 131071) === 0)
            aceYieldToPixInsight();
         var veilPresence = aceSmoothStep(veilConfidenceLow, veilConfidenceHigh, veilExcess[c]);
         confidence[c] = aceClamp01(0.35 + 0.65 * veilPresence);
      }
      acePerfMark(timing, prefix + " detail - dehaze confidence", stage);
      stage = timingActive ? Date.now() : 0;
      confidence = aceBoxBlurFloat(width, height, confidence, Math.max(2, Math.round(ACE_ALLOWED_SMOOTH_RADIUS * 0.8)));
      acePerfMark(timing, prefix + " detail - dehaze confidence smoothing", stage);
   }
   acePerfMark(timing, prefix + " detail - dehaze veil total", totalStart);
   cache.dehazeVeil = {
      veil: veil,
      confidence: confidence,
      veilExcess: veilExcess,
      compactAllowed: compactAllowed,
      highlightAllowed: highlightAllowed
   };
   cache.dehazeVeilStarAllowedWeight = starAllowedWeight;
   cache.dehazeVeilAdvancedKey = advancedKey;
   return cache.dehazeVeil;
};

MultiScaleContrastEngine.prototype.computeClarityV2AntiGlowDelta = function(width, height, params, cache, starAllowedWeight, protectSky, timing, timingPrefix) {
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   var totalStart = timingActive ? Date.now() : 0;
   var stage = timingActive ? Date.now() : 0;
   var count = width * height;
   var clarityAmount = aceClamp(params.clarity / 100, -1.5, 1.5) * ACE_CLARITY_AMOUNT;
   var tuning = aceClarityV2TuningProfile(params);
   var provisional = new Float32Array(count);
   var positive = new Float32Array(count);
   var broadPositive;
   for (var i = 0; i < count; ++i) {
      if ((i & 131071) === 0)
         aceYieldToPixInsight();
      var l = cache.luminance[i];
      var starAllowed = starAllowedWeight ? starAllowedWeight[i] : 1;
      var starProtection = starAllowedWeight ? aceClamp01(1 - starAllowed) : 0;
      var localStarProtection = aceSmoothStep(ACE_CONTRAST_STAR_PROTECTION_START, ACE_CONTRAST_STAR_PROTECTION_END, starProtection);
      var clarityV2StarAllowed = starAllowedWeight ?
         aceClamp01(1 - CLARITY_V2_STAR_SUPPRESSION * localStarProtection) :
         1;
      var clarityV2AllowedWeight = cache.clarityV2Allowed ? cache.clarityV2Allowed[i] : 1;
      var clarityV2RawDelta = clarityAmount *
         (cache.clarityV2Layer ? cache.clarityV2Layer[i] : cache.clarityLayer[i]) *
         clarityV2StarAllowed *
         clarityV2AllowedWeight;
      var localFloorForClarity = cache.localFloor ? cache.localFloor[i] : 0;
      var upwardRoom = Math.max(0.002, (1 - l) * 0.55);
      var downwardRoom = Math.max(0.002, (l - localFloorForClarity + 0.025) * 0.72);
      var clarityV2Limit = Math.min(CLARITY_V2_MAX_DELTA, clarityV2RawDelta >= 0 ? upwardRoom : downwardRoom);
      var baseClarityDelta = aceSoftKneeLimitSigned(clarityV2RawDelta, clarityV2Limit, CLARITY_V2_SOFT_KNEE);
      var localDeviation = cache.clarityV2LocalDeviation ? cache.clarityV2LocalDeviation[i] : (cache.clarityV2Layer ? cache.clarityV2Layer[i] : cache.clarityLayer[i]);
      var brightSide = Math.max(0, localDeviation);
      var darkSide = Math.max(0, -localDeviation);
      var depthMidtone = cache.clarityV2MidtoneWeight ? cache.clarityV2MidtoneWeight[i] : aceSmoothStep(CLARITY_V2_SHADOW_START, CLARITY_V2_MID_LOW, l) * (1 - aceSmoothStep(CLARITY_V2_HIGH_START, CLARITY_V2_HIGHLIGHT_END, l));
      var depthActivity = cache.clarityV2ActivityWeight ? cache.clarityV2ActivityWeight[i] : aceSmoothStep(CLARITY_V2_ACTIVITY_LOW_START, CLARITY_V2_ACTIVITY_LOW_END, Math.abs(cache.clarityV2Layer ? cache.clarityV2Layer[i] : cache.clarityLayer[i]));
      var highlightDepthKeep = 1 - CLARITY_V2_HIGHLIGHT_SUPPRESSION * aceSmoothStep(CLARITY_V2_HIGH_START, CLARITY_V2_HIGHLIGHT_END, l);
      var backgroundAllowed = protectSky && cache.allowedWeight ? cache.allowedWeight[i] : 1;
      var confidence = cache.structureConfidence ? cache.structureConfidence[i] : 1;
      var depthWeight =
         Math.pow(aceClamp01(depthMidtone), CLARITY_V2_DEPTH_MIDTONE_POWER) *
         Math.pow(aceClamp01(depthActivity), CLARITY_V2_DEPTH_ACTIVITY_POWER) *
         aceClamp01(backgroundAllowed) *
         aceClamp01(confidence) *
         aceClamp01(clarityV2StarAllowed) *
         aceClamp01(highlightDepthKeep);
      var brightSideAllowed =
         depthWeight *
         Math.pow(aceClamp01(depthActivity), CLARITY_V2_DEPTH_POSITIVE_STRUCTURE_POWER) *
         (1 - aceSmoothStep(CLARITY_V2_DEPTH_BRIGHT_START, CLARITY_V2_DEPTH_BRIGHT_END, l)) *
         aceClamp01(highlightDepthKeep);
      var negativeDepthDelta = -CLARITY_V2_DEPTH_SHADOW_GAIN * darkSide * depthWeight;
      var positiveDepthDelta = CLARITY_V2_DEPTH_HIGHLIGHT_GAIN * brightSide * brightSideAllowed;
      var depthRawDelta = clarityAmount * (negativeDepthDelta + positiveDepthDelta);
      var depthUpRoom = Math.max(0.002, (1 - l) * 0.38);
      var depthDownRoom = Math.max(0.002, (l - localFloorForClarity + 0.020) * 0.58);
      var depthLimit = Math.min(CLARITY_V2_DEPTH_MAX_DELTA, depthRawDelta >= 0 ? depthUpRoom : depthDownRoom);
      var depthClarityDelta = aceSoftKneeLimitSigned(depthRawDelta, depthLimit, CLARITY_V2_DEPTH_SOFT_KNEE);
      var combined = baseClarityDelta * tuning.baseMix + depthClarityDelta * tuning.depthMix;
      provisional[i] = combined;
      positive[i] = Math.max(0, combined);
   }
   acePerfMark(timing, prefix + " detail - Clarity V2 anti-glow positive split", stage);
   stage = timingActive ? Date.now() : 0;
   var maxEdge = Math.max(width, height);
   var factor = maxEdge > 2200 ? 4 : 2;
   var small = aceDownsampleFloatAverage(width, height, positive, factor);
   var glowRadius = Math.max(1, Math.round(CLARITY_V2_POSITIVE_GLOW_RADIUS / Math.max(1, small.factor)));
   var smallBroad = aceSoftScaleBlurFloat(small.width, small.height, small.data, glowRadius);
   broadPositive = aceUpsampleFloatBilinear(small.width, small.height, smallBroad, width, height);
   acePerfMark(timing, prefix + " detail - Clarity V2 anti-glow broad positive estimate", stage);
   stage = timingActive ? Date.now() : 0;
   var corrected = new Float32Array(count);
   var posEnergy = 0;
   var negEnergy = 0;
   var positiveDeltaSum = 0;
   var positiveDeltaMax = 0;
   var negativeDeltaAbsSum = 0;
   var negativeDeltaAbsMax = 0;
   var broadPositiveSum = 0;
   var localPositiveSum = 0;
   var positiveSafeSum = 0;
   var negativeSafeAbsSum = 0;
   for (var j = 0; j < count; ++j) {
      if ((j & 131071) === 0)
         aceYieldToPixInsight();
      var l2 = cache.luminance[j];
      var provisionalDelta = provisional[j];
      var positiveDelta = positive[j];
      var negativeDeltaAbs = Math.max(0, -provisionalDelta);
      var starAllowed2 = starAllowedWeight ? starAllowedWeight[j] : 1;
      var starProtection2 = starAllowedWeight ? aceClamp01(1 - starAllowed2) : 0;
      var localStarProtection2 = aceSmoothStep(ACE_CONTRAST_STAR_PROTECTION_START, ACE_CONTRAST_STAR_PROTECTION_END, starProtection2);
      var clarityV2StarAllowed2 = starAllowedWeight ?
         aceClamp01(1 - CLARITY_V2_STAR_SUPPRESSION * localStarProtection2) :
         1;
      var depthMidtone2 = cache.clarityV2MidtoneWeight ? cache.clarityV2MidtoneWeight[j] : aceSmoothStep(CLARITY_V2_SHADOW_START, CLARITY_V2_MID_LOW, l2) * (1 - aceSmoothStep(CLARITY_V2_HIGH_START, CLARITY_V2_HIGHLIGHT_END, l2));
      var depthActivity2 = cache.clarityV2ActivityWeight ? cache.clarityV2ActivityWeight[j] : aceSmoothStep(CLARITY_V2_ACTIVITY_LOW_START, CLARITY_V2_ACTIVITY_LOW_END, Math.abs(cache.clarityV2Layer ? cache.clarityV2Layer[j] : cache.clarityLayer[j]));
      var highlightAllowed2 = 1 - CLARITY_V2_HIGHLIGHT_SUPPRESSION * aceSmoothStep(CLARITY_V2_HIGH_START, CLARITY_V2_HIGHLIGHT_END, l2);
      var backgroundAllowed2 = protectSky && cache.allowedWeight ? cache.allowedWeight[j] : 1;
      var confidence2 = cache.structureConfidence ? cache.structureConfidence[j] : 1;
      var structurePreserveWeight = Math.pow(aceClamp01(depthActivity2), 0.85);
      var effectiveGlowSuppression = tuning.glowSuppression * (1 - structurePreserveWeight);
      var positiveLocal = Math.max(0, positiveDelta - effectiveGlowSuppression * broadPositive[j]);
      var positiveLocalRetained = Math.max(positiveLocal, positiveDelta * tuning.minPositiveRetention);
      var positiveAllowed =
         Math.pow(aceClamp01(depthMidtone2), CLARITY_V2_DEPTH_MIDTONE_POWER) *
         Math.pow(aceClamp01(depthActivity2), CLARITY_V2_POSITIVE_STRUCTURE_POWER) *
         aceClamp01(highlightAllowed2) *
         aceClamp01(clarityV2StarAllowed2) *
         aceClamp01(backgroundAllowed2) *
         aceClamp01(confidence2) *
         (1 - aceSmoothStep(CLARITY_V2_DEPTH_BRIGHT_START, CLARITY_V2_DEPTH_BRIGHT_END, l2));
      var negativeAllowed =
         Math.pow(aceClamp01(depthMidtone2), CLARITY_V2_DEPTH_MIDTONE_POWER) *
         Math.pow(aceClamp01(depthActivity2), CLARITY_V2_DEPTH_ACTIVITY_POWER) *
         aceClamp01(backgroundAllowed2) *
         aceClamp01(confidence2) *
         aceClamp01(clarityV2StarAllowed2);
      var positiveSafe = positiveLocalRetained * positiveAllowed * tuning.positiveGain;
      var negativeSafe = Math.min(0, provisionalDelta) * negativeAllowed * CLARITY_V2_NEGATIVE_GAIN;
      corrected[j] = positiveSafe + negativeSafe;
      posEnergy += positiveSafe;
      negEnergy += Math.abs(negativeSafe);
      positiveDeltaSum += positiveDelta;
      if (positiveDelta > positiveDeltaMax)
         positiveDeltaMax = positiveDelta;
      negativeDeltaAbsSum += negativeDeltaAbs;
      if (negativeDeltaAbs > negativeDeltaAbsMax)
         negativeDeltaAbsMax = negativeDeltaAbs;
      broadPositiveSum += broadPositive[j];
      localPositiveSum += positiveLocalRetained;
      positiveSafeSum += positiveSafe;
      negativeSafeAbsSum += Math.abs(negativeSafe);
   }
   acePerfMark(timing, prefix + " detail - Clarity V2 anti-glow positive suppression/recombine", stage);
   stage = timingActive ? Date.now() : 0;
   var positiveScale = 1;
   if (tuning.ratioLimitEnable && posEnergy > tuning.ratioLimit * Math.max(ACE_EPSILON, negEnergy))
      positiveScale = (tuning.ratioLimit * Math.max(ACE_EPSILON, negEnergy)) / Math.max(ACE_EPSILON, posEnergy);
   for (var k = 0; k < count; ++k) {
      if ((k & 131071) === 0)
         aceYieldToPixInsight();
      if (positiveScale < 1 && corrected[k] > 0)
         corrected[k] *= positiveScale;
      if (corrected[k] < 0 && cache.localFloor) {
         var protectedFloor = cache.localFloor[k] + CLARITY_V2_NEGATIVE_FLOOR_MARGIN;
         var floorRisk = aceSmoothStep(0.002, CLARITY_V2_DEPTH_FLOOR_SOFTNESS, protectedFloor - (cache.luminance[k] + corrected[k]));
         if (floorRisk > 0)
            corrected[k] += (protectedFloor - (cache.luminance[k] + corrected[k])) * floorRisk * 0.70;
      }
   }
   acePerfMark(timing, prefix + " detail - Clarity V2 anti-glow ratio/floor guard", stage);
   var nowMs = Date.now();
   var shouldLog = CLARITY_V2_DIAGNOSTIC_LOG_ENABLED && params.clarity !== 0 &&
      (maxEdge <= ACE_DRAFT_MAX_EDGE + 512 || prefix.indexOf("Preview") >= 0 || prefix.indexOf("Clarity map") >= 0) &&
      nowMs - gClarityV2DiagnosticLastLogMs >= CLARITY_V2_DIAGNOSTIC_LOG_INTERVAL_MS;
   if (shouldLog) {
      gClarityV2DiagnosticLastLogMs = nowMs;
      var invCount = count > 0 ? 1 / count : 0;
      var ratio = posEnergy / Math.max(ACE_EPSILON, negEnergy);
      var report = "[ACE] Clarity V2" + tuning.id +
         " stats | amount=" + params.clarity +
         " posMean=" + aceValidationNumber(positiveDeltaSum * invCount, 5) +
         " posMax=" + aceValidationNumber(positiveDeltaMax, 5) +
         " negMeanAbs=" + aceValidationNumber(negativeDeltaAbsSum * invCount, 5) +
         " negMaxAbs=" + aceValidationNumber(negativeDeltaAbsMax, 5) +
         " broadPosMean=" + aceValidationNumber(broadPositiveSum * invCount, 5) +
         " localPosMean=" + aceValidationNumber(localPositiveSum * invCount, 5) +
         " posSafeMean=" + aceValidationNumber(positiveSafeSum * invCount, 5) +
         " negSafeMeanAbs=" + aceValidationNumber(negativeSafeAbsSum * invCount, 5) +
         " posNegEnergyRatio=" + aceValidationNumber(ratio, 3) +
         " posScale=" + aceValidationNumber(positiveScale, 3) +
         " gain=" + aceValidationNumber(tuning.positiveGain, 2) +
         " glow=" + aceValidationNumber(tuning.glowSuppression, 2) +
         " retain=" + aceValidationNumber(tuning.minPositiveRetention, 2);
      if (typeof console !== "undefined" && console && typeof console.writeln === "function")
         console.writeln(report);
      else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
         Console.writeln(report);
   }
   acePerfMark(timing, prefix + " detail - Clarity V2 anti-glow total", totalStart);
   return corrected;
};

MultiScaleContrastEngine.prototype.computeClarityV3Delta = function(width, height, params, cache, starAllowedWeight, protectSky, timing, timingPrefix) {
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   var totalStart = timingActive ? Date.now() : 0;
   var stage = timingActive ? Date.now() : 0;
   var count = width * height;
   var mode = aceNormalizeClarityMode(params.clarityMode);
   if (!aceIsClarityV3Mode(mode))
      mode = ACE_CLARITY_MODE_V3_FULL;
   var clarityStrength = aceClamp(params.clarity / 100, -1.5, 1.5);
   var strength = clarityStrength * ACE_CLARITY_AMOUNT * CLARITY_V3_GLOBAL_GAIN;
   var out = new Float32Array(count);
   var curveNorm = Math.tanh(CLARITY_V3_CURVE_K);
   var positiveEnergy = 0;
   var negativeEnergy = 0;
   var rawAbsSum = 0;
   var weightedAbsSum = 0;
   var backgroundAllowedSum = 0;
   var starAllowedSum = 0;
   var haloAllowedSum = 0;
   var darkPatchAllowedSum = 0;
   var highlightAllowedSum = 0;
   var compactAllowedSum = 0;
   var finalAllowedSum = 0;
   var protectedAbsSum = 0;
   var protectedMax = 0;
   var posSum = 0;
   var negAbsSum = 0;
   var strongDeltaCount = 0;
   var suppressedBelow10Count = 0;
   var backgroundMin = 1, backgroundMax = 0;
   var starMin = 1, starMax = 0;
   var haloMin = 1, haloMax = 0;
   var darkPatchMin = 1, darkPatchMax = 0;
   var highlightMin = 1, highlightMax = 0;
   var compactMin = 1, compactMax = 0;
   var finalMin = 1, finalMax = 0;
   for (var i = 0; i < count; ++i) {
      if ((i & 131071) === 0)
         aceYieldToPixInsight();
      var l = cache.luminance[i];
      var localBase = cache.clarityV3LocalBase ? cache.clarityV3LocalBase[i] : l - cache.clarityLayer[i];
      var localScale = cache.clarityV3LocalScale ? cache.clarityV3LocalScale[i] : Math.abs(l - localBase);
      localScale = Math.max(CLARITY_V3_SCALE_MIN, localScale * CLARITY_V3_SCALE_GAIN);
      var d = l - localBase;
      var localAbs = Math.abs(d);
      var dNorm = d / localScale;
      var curvedNorm = Math.tanh(CLARITY_V3_CURVE_K * dNorm) / Math.max(ACE_EPSILON, curveNorm);
      var curvedD = curvedNorm * localScale;
      var edgePreserve = 1 - aceSmoothStep(1.15, 3.25, Math.abs(dNorm));
      var rawDelta = (curvedD - d) * edgePreserve * strength;
      var midtoneWeight =
         aceSmoothStep(CLARITY_V3_MIDTONE_LOW, CLARITY_V3_MIDTONE_PEAK_LOW, l) *
         (1 - aceSmoothStep(CLARITY_V3_MIDTONE_PEAK_HIGH, CLARITY_V3_MIDTONE_HIGH, l));
      var structureWeight =
         aceSmoothStep(CLARITY_V3_STRUCTURE_LOW_START, CLARITY_V3_STRUCTURE_LOW_END, localScale) *
         (1 - aceSmoothStep(CLARITY_V3_STRUCTURE_HIGH_START, CLARITY_V3_STRUCTURE_HIGH_END, localScale));
      var transitionWeight = aceSmoothStep(CLARITY_V3_TRANSITION_LOW, CLARITY_V3_TRANSITION_HIGH, localAbs);
      var transitionKeep = CLARITY_V3_TRANSITION_MIN_KEEP + (1 - CLARITY_V3_TRANSITION_MIN_KEEP) * transitionWeight;
      var smoothFieldWeight = aceSmoothStep(CLARITY_V3_SMOOTH_FIELD_LOW, CLARITY_V3_SMOOTH_FIELD_HIGH, localScale);
      var smoothFieldKeep = CLARITY_V3_SMOOTH_FIELD_MIN_KEEP + (1 - CLARITY_V3_SMOOTH_FIELD_MIN_KEEP) * smoothFieldWeight;
      var structureWeightFinal = aceClamp01(structureWeight * transitionKeep * smoothFieldKeep);
      var highlightAllowed = 1 - CLARITY_V3_HIGHLIGHT_SUPPRESSION *
         aceSmoothStep(CLARITY_V3_HIGHLIGHT_START, CLARITY_V3_HIGHLIGHT_END, l);
      var starAllowed = starAllowedWeight ? starAllowedWeight[i] : 1;
      var starProtection = starAllowedWeight ? aceClamp01(1 - starAllowed) : 0;
      var localStarProtection = aceSmoothStep(ACE_CONTRAST_STAR_PROTECTION_START, ACE_CONTRAST_STAR_PROTECTION_END, starProtection);
      var clarityStarAllowed = starAllowedWeight ?
         aceClamp01(1 - CLARITY_V2_STAR_SUPPRESSION * localStarProtection) :
         1;
      var haloAllowed = clarityStarAllowed;
      var compactSignal = aceSmoothStep(0.006, 0.055, Math.max(0, cache.textureLayer[i])) *
         aceSmoothStep(0.46, 0.92, l);
      var compactAllowed = 1 - CLARITY_V3_COMPACT_SUPPRESSION * compactSignal;
      var backgroundAllowed = protectSky && cache.allowedWeight ? cache.allowedWeight[i] : 1;
      var confidence = cache.structureConfidence ? cache.structureConfidence[i] : 1;
      var toneStructureAllowed =
         Math.pow(aceClamp01(midtoneWeight), CLARITY_V3_MIDTONE_POWER) *
         Math.pow(aceClamp01(structureWeightFinal), CLARITY_V3_STRUCTURE_POWER);
      var starHaloAllowed =
         Math.pow(aceClamp01(clarityStarAllowed), CLARITY_V3_STAR_POWER) *
         Math.pow(aceClamp01(haloAllowed), CLARITY_V3_HALO_POWER);
      var positiveSafetyAllowed =
         Math.pow(aceClamp01(highlightAllowed), CLARITY_V3_HIGHLIGHT_POWER) *
         aceClamp01(compactAllowed);
      var limited = rawDelta >= 0 ?
         aceSoftKneeLimitSigned(rawDelta, CLARITY_V3_POSITIVE_LIMIT, CLARITY_V3_SOFT_KNEE) :
         aceSoftKneeLimitSigned(rawDelta, CLARITY_V3_NEGATIVE_LIMIT, CLARITY_V3_SOFT_KNEE);
      var weightedDelta = limited * toneStructureAllowed;
      var darkPatchAllowed = 1;
      var floorCorrection = 0;
      if (weightedDelta < 0 && cache.localFloor) {
         var protectedFloor = cache.localFloor[i] + CLARITY_V2_NEGATIVE_FLOOR_MARGIN;
         var floorRisk = aceSmoothStep(0.002, CLARITY_V2_DEPTH_FLOOR_SOFTNESS, protectedFloor - (l + weightedDelta));
         darkPatchAllowed = 1 - floorRisk * 0.70;
         if (floorRisk > 0)
            floorCorrection = (protectedFloor - (l + weightedDelta)) * floorRisk * 0.70;
      }
      var positiveAllowed =
         toneStructureAllowed *
         starHaloAllowed *
         positiveSafetyAllowed *
         Math.pow(aceClamp01(backgroundAllowed), CLARITY_V3_POSITIVE_BACKGROUND_POWER);
      var negativeAllowed =
         toneStructureAllowed *
         starHaloAllowed *
         Math.pow(aceClamp01(backgroundAllowed), CLARITY_V3_NEGATIVE_BACKGROUND_POWER) *
         Math.pow(aceClamp01(darkPatchAllowed), CLARITY_V3_NEGATIVE_DARK_PATCH_POWER);
      var positiveFloorAllowed =
         clarityStarAllowed >= CLARITY_V3_MIN_ALLOWED_STAR_CORE_CUTOFF &&
         haloAllowed >= CLARITY_V3_MIN_ALLOWED_STAR_CORE_CUTOFF &&
         highlightAllowed >= CLARITY_V3_MIN_ALLOWED_HIGHLIGHT_CUTOFF &&
         compactAllowed >= CLARITY_V3_MIN_ALLOWED_COMPACT_CUTOFF;
      var negativeFloorAllowed =
         positiveFloorAllowed &&
         darkPatchAllowed >= CLARITY_V3_MIN_ALLOWED_DARKPATCH_CUTOFF;
      if (positiveFloorAllowed)
         positiveAllowed = Math.max(positiveAllowed, CLARITY_V3_POSITIVE_MIN_ALLOWED);
      if (negativeFloorAllowed)
         negativeAllowed = Math.max(negativeAllowed, CLARITY_V3_NEGATIVE_MIN_ALLOWED);
      var finalAllowed = 1;
      if (mode === ACE_CLARITY_MODE_V3_WEIGHTED)
         finalAllowed = toneStructureAllowed;
      else if (mode === ACE_CLARITY_MODE_V3_BACKGROUND)
         finalAllowed = limited >= 0 ?
            toneStructureAllowed * Math.pow(aceClamp01(backgroundAllowed), CLARITY_V3_POSITIVE_BACKGROUND_POWER) :
            toneStructureAllowed * Math.pow(aceClamp01(backgroundAllowed), CLARITY_V3_NEGATIVE_BACKGROUND_POWER) * Math.pow(aceClamp01(darkPatchAllowed), CLARITY_V3_NEGATIVE_DARK_PATCH_POWER);
      else if (mode === ACE_CLARITY_MODE_V3_STARS)
         finalAllowed = limited >= 0 ?
            toneStructureAllowed * starHaloAllowed * positiveSafetyAllowed :
            toneStructureAllowed * starHaloAllowed;
      else if (mode === ACE_CLARITY_MODE_V3_FULL)
         finalAllowed = limited >= 0 ? positiveAllowed : negativeAllowed;
      else
         finalAllowed = 1;
      if ((mode === ACE_CLARITY_MODE_V3_BACKGROUND || mode === ACE_CLARITY_MODE_V3_STARS || mode === ACE_CLARITY_MODE_V3_FULL) && limited >= 0 && positiveFloorAllowed)
         finalAllowed = Math.max(finalAllowed, CLARITY_V3_POSITIVE_MIN_ALLOWED);
      if ((mode === ACE_CLARITY_MODE_V3_BACKGROUND || mode === ACE_CLARITY_MODE_V3_STARS || mode === ACE_CLARITY_MODE_V3_FULL) && limited < 0 && negativeFloorAllowed)
         finalAllowed = Math.max(finalAllowed, CLARITY_V3_NEGATIVE_MIN_ALLOWED);
      var protectedDelta = limited * finalAllowed;
      if ((mode === ACE_CLARITY_MODE_V3_BACKGROUND || mode === ACE_CLARITY_MODE_V3_FULL) && protectedDelta < 0 && floorCorrection !== 0)
         protectedDelta += floorCorrection;
      out[i] = protectedDelta;
      if (protectedDelta > 0)
         positiveEnergy += protectedDelta;
      else
         negativeEnergy += -protectedDelta;
      if (protectedDelta > 0)
         posSum += protectedDelta;
      else
         negAbsSum += -protectedDelta;
      rawAbsSum += Math.abs(rawDelta);
      weightedAbsSum += Math.abs(weightedDelta);
      var protectedAbs = Math.abs(protectedDelta);
      protectedAbsSum += protectedAbs;
      if (protectedAbs > protectedMax)
         protectedMax = protectedAbs;
      if (protectedAbs >= 0.010)
         ++strongDeltaCount;
      if (Math.abs(rawDelta) > ACE_EPSILON && protectedAbs / Math.abs(rawDelta) < 0.10)
         ++suppressedBelow10Count;
      backgroundAllowedSum += backgroundAllowed;
      starAllowedSum += clarityStarAllowed;
      haloAllowedSum += haloAllowed;
      darkPatchAllowedSum += darkPatchAllowed;
      highlightAllowedSum += highlightAllowed;
      compactAllowedSum += compactAllowed;
      finalAllowedSum += finalAllowed;
      if (backgroundAllowed < backgroundMin) backgroundMin = backgroundAllowed;
      if (backgroundAllowed > backgroundMax) backgroundMax = backgroundAllowed;
      if (clarityStarAllowed < starMin) starMin = clarityStarAllowed;
      if (clarityStarAllowed > starMax) starMax = clarityStarAllowed;
      if (haloAllowed < haloMin) haloMin = haloAllowed;
      if (haloAllowed > haloMax) haloMax = haloAllowed;
      if (darkPatchAllowed < darkPatchMin) darkPatchMin = darkPatchAllowed;
      if (darkPatchAllowed > darkPatchMax) darkPatchMax = darkPatchAllowed;
      if (highlightAllowed < highlightMin) highlightMin = highlightAllowed;
      if (highlightAllowed > highlightMax) highlightMax = highlightAllowed;
      if (compactAllowed < compactMin) compactMin = compactAllowed;
      if (compactAllowed > compactMax) compactMax = compactAllowed;
      if (finalAllowed < finalMin) finalMin = finalAllowed;
      if (finalAllowed > finalMax) finalMax = finalAllowed;
   }
   acePerfMark(timing, prefix + " detail - " + aceClarityV3ModeLabel(mode) + " local S-curve", stage);
   var nowMs = Date.now();
   var maxEdge = Math.max(width, height);
   var shouldLog = CLARITY_V3_DIAGNOSTIC_LOG_ENABLED && params.clarity !== 0 &&
      (maxEdge <= ACE_DRAFT_MAX_EDGE + 512 || prefix.indexOf("Preview") >= 0 || prefix.indexOf("Clarity map") >= 0) &&
      nowMs - gClarityV3DiagnosticLastLogMs >= CLARITY_V3_DIAGNOSTIC_LOG_INTERVAL_MS;
   if (shouldLog) {
      gClarityV3DiagnosticLastLogMs = nowMs;
      var invCount = count > 0 ? 1 / count : 0;
      var rawAbsMean = rawAbsSum * invCount;
      var weightedAbsMean = weightedAbsSum * invCount;
      var protectedAbsMean = protectedAbsSum * invCount;
      var deltaDisplayScale = Math.max(1.0e-5, Math.min(protectedMax, Math.max(protectedAbsMean * 8, protectedMax * 0.28)));
      var report = "[ACE] " + aceClarityV3ModeLabel(mode) + " diagnostics | clarityAmount=" + params.clarity +
         " rawAbsMean=" + aceValidationNumber(rawAbsSum * invCount, 5) +
         " weightedAbsMean=" + aceValidationNumber(weightedAbsMean, 5) +
         " backgroundAllowedMean=" + aceValidationNumber(backgroundAllowedSum * invCount, 4) +
         " starAllowedMean=" + aceValidationNumber(starAllowedSum * invCount, 4) +
         " haloAllowedMean=" + aceValidationNumber(haloAllowedSum * invCount, 4) + " (combined star/halo allowed; 1=effect allowed)" +
         " darkPatchAllowedMean=" + aceValidationNumber(darkPatchAllowedSum * invCount, 4) +
         " highlightAllowedMean=" + aceValidationNumber(highlightAllowedSum * invCount, 4) +
         " compactAllowedMean=" + aceValidationNumber(compactAllowedSum * invCount, 4) +
         " finalAllowedMean=" + aceValidationNumber(finalAllowedSum * invCount, 4) +
         " protectedAbsMean=" + aceValidationNumber(protectedAbsSum * invCount, 5) +
         " protectedMax=" + aceValidationNumber(protectedMax, 5) +
         " protected/raw=" + aceValidationNumber(protectedAbsMean / Math.max(ACE_EPSILON, rawAbsMean), 3) +
         " weighted/raw=" + aceValidationNumber(weightedAbsMean / Math.max(ACE_EPSILON, rawAbsMean), 3) +
         " deltaDisplayScale=+-" + aceValidationNumber(deltaDisplayScale, 5) + " (Delta view contrast scaled for visibility)" +
         " posMean=" + aceValidationNumber(posSum * invCount, 5) +
         " negMeanAbs=" + aceValidationNumber(negAbsSum * invCount, 5) +
         " posNegEnergyRatio=" + aceValidationNumber(positiveEnergy / Math.max(ACE_EPSILON, negativeEnergy), 3) +
         " percentPixelsStrongDelta=" + aceValidationNumber(100 * strongDeltaCount * invCount, 2) + "%" +
         " percentPixelsSuppressedBelow10Percent=" + aceValidationNumber(100 * suppressedBelow10Count * invCount, 2) + "%";
      var polarity = "[ACE] " + aceClarityV3ModeLabel(mode) + " mask polarity audit (allowed: 1=effect allowed, 0=protected) | " +
         "background min/mean/max=" + aceValidationNumber(backgroundMin, 3) + "/" + aceValidationNumber(backgroundAllowedSum * invCount, 3) + "/" + aceValidationNumber(backgroundMax, 3) +
         " star min/mean/max=" + aceValidationNumber(starMin, 3) + "/" + aceValidationNumber(starAllowedSum * invCount, 3) + "/" + aceValidationNumber(starMax, 3) +
         " halo min/mean/max=" + aceValidationNumber(haloMin, 3) + "/" + aceValidationNumber(haloAllowedSum * invCount, 3) + "/" + aceValidationNumber(haloMax, 3) +
         " darkPatch min/mean/max=" + aceValidationNumber(darkPatchMin, 3) + "/" + aceValidationNumber(darkPatchAllowedSum * invCount, 3) + "/" + aceValidationNumber(darkPatchMax, 3) +
         " highlight min/mean/max=" + aceValidationNumber(highlightMin, 3) + "/" + aceValidationNumber(highlightAllowedSum * invCount, 3) + "/" + aceValidationNumber(highlightMax, 3) +
         " compact min/mean/max=" + aceValidationNumber(compactMin, 3) + "/" + aceValidationNumber(compactAllowedSum * invCount, 3) + "/" + aceValidationNumber(compactMax, 3) +
         " final min/mean/max=" + aceValidationNumber(finalMin, 3) + "/" + aceValidationNumber(finalAllowedSum * invCount, 3) + "/" + aceValidationNumber(finalMax, 3);
      if (typeof console !== "undefined" && console && typeof console.writeln === "function")
      {
         console.writeln(report);
         console.writeln(polarity);
      }
      else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
      {
         Console.writeln(report);
         Console.writeln(polarity);
      }
   }
   acePerfMark(timing, prefix + " detail - " + aceClarityV3ModeLabel(mode) + " total", totalStart);
   return out;
};

MultiScaleContrastEngine.prototype.computeClarityV4Delta = function(width, height, params, cache, starAllowedWeight, protectSky, timing, timingPrefix) {
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   var totalStart = timingActive ? Date.now() : 0;
   var stage = timingActive ? Date.now() : 0;
   var count = width * height;
   var clarityStrength = aceClamp(params.clarity / 100, -1.5, 1.5);
   var strength = clarityStrength * ACE_CLARITY_AMOUNT * CLARITY_V4_GLOBAL_GAIN;
   var out = new Float32Array(count);
   var rawReliefAbsSum = 0;
   var activitySum = 0;
   var weightedAbsSum = 0;
   var protectedAbsSum = 0;
   var protectedMax = 0;
   var finalAllowedSum = 0;
   var posSum = 0;
   var negAbsSum = 0;
   var positiveEnergy = 0;
   var negativeEnergy = 0;
   var strongDeltaCount = 0;
   var suppressedBelow10Count = 0;
   for (var i = 0; i < count; ++i) {
      if ((i & 131071) === 0)
         aceYieldToPixInsight();
      var l = cache.luminance[i];
      var relief = cache.clarityV4ReliefSignal ? cache.clarityV4ReliefSignal[i] : cache.clarityLayer[i];
      var activity = cache.clarityV4Activity ? cache.clarityV4Activity[i] : Math.abs(relief);
      var rawDelta = relief * strength;
      var activityWeight = Math.pow(aceSmoothStep(CLARITY_V4_ACTIVITY_LOW, CLARITY_V4_ACTIVITY_HIGH, activity), CLARITY_V4_ACTIVITY_POWER);
      var midtoneWeight =
         aceSmoothStep(CLARITY_V4_MIDTONE_LOW, CLARITY_V4_MIDTONE_PEAK_LOW, l) *
         (1 - aceSmoothStep(CLARITY_V4_MIDTONE_PEAK_HIGH, CLARITY_V4_MIDTONE_HIGH, l));
      var starAllowed = starAllowedWeight ? starAllowedWeight[i] : 1;
      var starProtection = starAllowedWeight ? aceClamp01(1 - starAllowed) : 0;
      var localStarProtection = aceSmoothStep(ACE_CONTRAST_STAR_PROTECTION_START, ACE_CONTRAST_STAR_PROTECTION_END, starProtection);
      var clarityStarAllowed = starAllowedWeight ?
         aceClamp01(1 - CLARITY_V2_STAR_SUPPRESSION * localStarProtection) :
         1;
      var haloAllowed = clarityStarAllowed;
      var highlightAllowed = 1 - CLARITY_V4_HIGHLIGHT_SUPPRESSION *
         aceSmoothStep(CLARITY_V4_HIGHLIGHT_START, CLARITY_V4_HIGHLIGHT_END, l);
      var compactSignal = aceSmoothStep(0.006, 0.055, Math.max(0, cache.textureLayer[i])) *
         aceSmoothStep(0.46, 0.92, l);
      var compactAllowed = 1 - CLARITY_V4_COMPACT_SUPPRESSION * compactSignal;
      var backgroundAllowed = protectSky && cache.allowedWeight ? cache.allowedWeight[i] : 1;
      var toneStructureAllowed = aceClamp01(midtoneWeight) * aceClamp01(activityWeight);
      var limited = rawDelta >= 0 ?
         aceSoftKneeLimitSigned(rawDelta, CLARITY_V4_POSITIVE_LIMIT, CLARITY_V4_SOFT_KNEE) :
         aceSoftKneeLimitSigned(rawDelta, CLARITY_V4_NEGATIVE_LIMIT, CLARITY_V4_SOFT_KNEE);
      var darkPatchAllowed = 1;
      var floorCorrection = 0;
      var weightedDelta = limited * toneStructureAllowed;
      if (weightedDelta < 0 && cache.localFloor) {
         var protectedFloor = cache.localFloor[i] + CLARITY_V2_NEGATIVE_FLOOR_MARGIN;
         var floorRisk = aceSmoothStep(0.002, CLARITY_V2_DEPTH_FLOOR_SOFTNESS, protectedFloor - (l + weightedDelta));
         darkPatchAllowed = 1 - floorRisk * 0.70;
         if (floorRisk > 0)
            floorCorrection = (protectedFloor - (l + weightedDelta)) * floorRisk * 0.70;
      }
      var starHaloAllowed =
         Math.pow(aceClamp01(clarityStarAllowed), CLARITY_V3_STAR_POWER) *
         Math.pow(aceClamp01(haloAllowed), CLARITY_V3_HALO_POWER);
      var positiveAllowed =
         toneStructureAllowed *
         starHaloAllowed *
         aceClamp01(highlightAllowed) *
         aceClamp01(compactAllowed) *
         Math.pow(aceClamp01(backgroundAllowed), CLARITY_V4_POSITIVE_BACKGROUND_POWER);
      var negativeAllowed =
         toneStructureAllowed *
         starHaloAllowed *
         Math.pow(aceClamp01(backgroundAllowed), CLARITY_V4_NEGATIVE_BACKGROUND_POWER) *
         Math.pow(aceClamp01(darkPatchAllowed), CLARITY_V4_DARKPATCH_POWER);
      var positiveFloorAllowed =
         clarityStarAllowed >= CLARITY_V3_MIN_ALLOWED_STAR_CORE_CUTOFF &&
         haloAllowed >= CLARITY_V3_MIN_ALLOWED_STAR_CORE_CUTOFF &&
         highlightAllowed >= CLARITY_V3_MIN_ALLOWED_HIGHLIGHT_CUTOFF &&
         compactAllowed >= CLARITY_V3_MIN_ALLOWED_COMPACT_CUTOFF;
      var negativeFloorAllowed =
         positiveFloorAllowed &&
         darkPatchAllowed >= CLARITY_V3_MIN_ALLOWED_DARKPATCH_CUTOFF;
      if (positiveFloorAllowed)
         positiveAllowed = Math.max(positiveAllowed, CLARITY_V4_POSITIVE_MIN_ALLOWED);
      if (negativeFloorAllowed)
         negativeAllowed = Math.max(negativeAllowed, CLARITY_V4_NEGATIVE_MIN_ALLOWED);
      var finalAllowed = limited >= 0 ? positiveAllowed : negativeAllowed;
      var protectedDelta = limited * finalAllowed;
      if (protectedDelta < 0 && floorCorrection !== 0)
         protectedDelta += floorCorrection;
      out[i] = protectedDelta;
      rawReliefAbsSum += Math.abs(rawDelta);
      activitySum += activity;
      weightedAbsSum += Math.abs(weightedDelta);
      var protectedAbs = Math.abs(protectedDelta);
      protectedAbsSum += protectedAbs;
      if (protectedAbs > protectedMax)
         protectedMax = protectedAbs;
      finalAllowedSum += finalAllowed;
      if (protectedDelta > 0) {
         posSum += protectedDelta;
         positiveEnergy += protectedDelta;
      } else {
         negAbsSum += -protectedDelta;
         negativeEnergy += -protectedDelta;
      }
      if (protectedAbs >= CLARITY_V4_STRONG_DELTA_THRESHOLD)
         ++strongDeltaCount;
      if (Math.abs(rawDelta) > ACE_EPSILON && protectedAbs / Math.abs(rawDelta) < 0.10)
         ++suppressedBelow10Count;
   }
   acePerfMark(timing, prefix + " detail - Clarity V4 multi-scale relief", stage);
   var nowMs = Date.now();
   var maxEdge = Math.max(width, height);
   var shouldLog = CLARITY_V4_DIAGNOSTIC_LOG_ENABLED && params.clarity !== 0 &&
      (maxEdge <= ACE_DRAFT_MAX_EDGE + 512 || prefix.indexOf("Preview") >= 0 || prefix.indexOf("Clarity map") >= 0) &&
      nowMs - gClarityV4DiagnosticLastLogMs >= CLARITY_V4_DIAGNOSTIC_LOG_INTERVAL_MS;
   if (shouldLog) {
      gClarityV4DiagnosticLastLogMs = nowMs;
      var invCount = count > 0 ? 1 / count : 0;
      var rawReliefAbsMean = rawReliefAbsSum * invCount;
      var weightedAbsMean = weightedAbsSum * invCount;
      var protectedAbsMean = protectedAbsSum * invCount;
      var deltaDisplayScale = Math.max(1.0e-5, Math.min(protectedMax, Math.max(protectedAbsMean * 8, protectedMax * 0.28)));
      var report = "[ACE] Clarity V4 diagnostics | clarityAmount=" + params.clarity +
         " rawReliefAbsMean=" + aceValidationNumber(rawReliefAbsMean, 5) +
         " activityMean=" + aceValidationNumber(activitySum * invCount, 5) +
         " weightedAbsMean=" + aceValidationNumber(weightedAbsMean, 5) +
         " protectedAbsMean=" + aceValidationNumber(protectedAbsMean, 5) +
         " protected/raw=" + aceValidationNumber(protectedAbsMean / Math.max(ACE_EPSILON, rawReliefAbsMean), 3) +
         " finalAllowedMean=" + aceValidationNumber(finalAllowedSum * invCount, 4) +
         " posMean=" + aceValidationNumber(posSum * invCount, 5) +
         " negMeanAbs=" + aceValidationNumber(negAbsSum * invCount, 5) +
         " posNegEnergyRatio=" + aceValidationNumber(positiveEnergy / Math.max(ACE_EPSILON, negativeEnergy), 3) +
         " percentPixelsStrongDelta=" + aceValidationNumber(100 * strongDeltaCount * invCount, 2) + "%" +
         " percentPixelsSuppressedBelow10Percent=" + aceValidationNumber(100 * suppressedBelow10Count * invCount, 2) + "%" +
         " deltaDisplayScale=+-" + aceValidationNumber(deltaDisplayScale, 5) + " (Delta view contrast scaled for visibility)";
      if (typeof console !== "undefined" && console && typeof console.writeln === "function")
         console.writeln(report);
      else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
         Console.writeln(report);
   }
   acePerfMark(timing, prefix + " detail - Clarity V4 total", totalStart);
   return out;
};

MultiScaleContrastEngine.prototype.buildBroadLocalSCurveComponent = function(width, height, cache, starAllowedWeight, timing, timingPrefix) {
   if (!cache)
      return null;
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   if (cache.clarityV5bBroadLocalSCurve && cache.clarityV5bStarAllowedWeight === starAllowedWeight) {
      acePerfMark(timing, prefix + " detail - Clarity V5b broad S-curve cache hit", timingActive ? Date.now() : 0);
      return cache.clarityV5bBroadLocalSCurve;
   }
   var totalStart = timingActive ? Date.now() : 0;
   var stage = timingActive ? Date.now() : 0;
   var count = width * height;
   var luminance = cache.luminance;
   var base56 = aceSoftScaleBlurFloat(width, height, luminance, CLARITY_V5B_BROAD_BASE_RADIUS);
   acePerfMark(timing, prefix + " detail - Clarity V5b broad base r" + CLARITY_V5B_BROAD_BASE_RADIUS, stage);
   stage = timingActive ? Date.now() : 0;
   var absDeviation = new Float32Array(count);
   for (var i = 0; i < count; ++i) {
      if ((i & 131071) === 0)
         aceYieldToPixInsight();
      absDeviation[i] = Math.abs(luminance[i] - base56[i]);
   }
   var localScale = aceSoftScaleBlurFloat(width, height, absDeviation, CLARITY_V5B_BROAD_SCALE_RADIUS);
   acePerfMark(timing, prefix + " detail - Clarity V5b local scale r" + CLARITY_V5B_BROAD_SCALE_RADIUS, stage);
   stage = timingActive ? Date.now() : 0;
   var raw = new Float32Array(count);
   for (var j = 0; j < count; ++j) {
      if ((j & 131071) === 0)
         aceYieldToPixInsight();
      var l = luminance[j];
      var midtone =
         aceSmoothStep(0.045, 0.24, l) *
         (1 - aceSmoothStep(0.68, 0.96, l));
      var localNorm = (l - base56[j]) / Math.max(CLARITY_V5B_LOCAL_SCALE_FLOOR, localScale[j] * CLARITY_V5B_LOCAL_SCALE_GAIN);
      var starKeep = Math.pow(aceClamp01(starAllowedWeight ? starAllowedWeight[j] : 1), CLARITY_V5B_STAR_KEEP_POWER);
      raw[j] = (Math.tanh(localNorm * CLARITY_V5B_SCURVE_GAIN) - localNorm * CLARITY_V5B_LINEAR_KEEP) * midtone * starKeep;
   }
   var scale = acePercentileAbsFloat(raw, 99.0);
   var broad = new Float32Array(count);
   if (scale > ACE_EPSILON) {
      for (var k = 0; k < count; ++k) {
         if ((k & 131071) === 0)
            aceYieldToPixInsight();
         broad[k] = aceClamp(raw[k] / scale, -1, 1);
      }
   }
   cache.clarityV5bBroadLocalSCurve = broad;
   cache.clarityV5bBroadLocalSCurveScale = scale;
   cache.clarityV5bStarAllowedWeight = starAllowedWeight;
   acePerfMark(timing, prefix + " detail - Clarity V5b broad S-curve normalize p99=" + aceValidationNumber(scale, 5), stage);
   acePerfMark(timing, prefix + " detail - Clarity V5b broad S-curve total", totalStart);
   return broad;
};

MultiScaleContrastEngine.prototype.clarityV5bToneMode = function() {
   if (FORCE_CLARITY_V4 || CLARITY_V5B_TONE_MODE === "forced_v4")
      return "forced_v4";
   if (CLARITY_V5B_TONE_MODE === "v5b_0945_current")
      return "v5b_0945_current";
   if (CLARITY_V5B_TONE_MODE === "v5b_highlight_guard_test")
      return "v5b_highlight_guard_test";
   return "forced_v4";
};

MultiScaleContrastEngine.prototype.clarityV5bEffectivePositiveSlider = function(sliderValue) {
   var s = aceClamp(sliderValue, 0, 100);
   return s;
};

MultiScaleContrastEngine.prototype.clarityV5bPositiveScale = function(sliderValue) {
   var effectiveSlider = this.clarityV5bEffectivePositiveSlider(sliderValue);
   var x = aceClamp(effectiveSlider / 100, 0, 1);
   return CLARITY_V5B_POSITIVE_BROAD_SCURVE_BASE_GAIN * Math.pow(x, CLARITY_V5B_POSITIVE_BROAD_SCURVE_GAMMA);
};

MultiScaleContrastEngine.prototype.clarityV5bHighlightGuardKeep = function(luminance, saturation) {
   if (this.clarityV5bToneMode() !== "v5b_highlight_guard_test")
      return 1;
   var midtoneGate =
      aceSmoothStep(CLARITY_V5B_MIDTONE_GATE_LOW, CLARITY_V5B_HIGHLIGHT_GUARD_START, luminance) *
      (1 - aceSmoothStep(CLARITY_V5B_HIGHLIGHT_GUARD_START, CLARITY_V5B_MIDTONE_GATE_HIGH, luminance));
   var highlightKeep = 1 - (1 - CLARITY_V5B_HIGHLIGHT_GUARD_MIN_KEEP) *
      aceSmoothStep(CLARITY_V5B_HIGHLIGHT_GUARD_START, CLARITY_V5B_HIGHLIGHT_GUARD_END, luminance);
   var saturationKeep = 1 - (1 - CLARITY_V5B_SATURATION_GUARD_MIN_KEEP) *
      aceSmoothStep(CLARITY_V5B_SATURATION_GUARD_START, CLARITY_V5B_SATURATION_GUARD_END, saturation || 0);
   return aceClamp01(midtoneGate * highlightKeep * saturationKeep);
};

MultiScaleContrastEngine.prototype.logClarityPathProof = function(params, clarityMode, clarityV5bPositiveActive, broadScale, timingPrefix, advanced) {
   if (!ACE_DEVELOPMENT_CONSOLE_LOGS_ENABLED)
      return;
   var slider = params ? params.clarity : 0;
   var mode = aceNormalizeClarityMode(clarityMode);
   var toneMode = this.clarityV5bToneMode();
   var featureFitMode = this.clarityFeatureFitMode(mode);
   var featureFitActive = this.isClarityFeatureFitActive(params, mode);
   var dualZoneOptActive = this.isClarityDualZoneOptActive(params, mode);
   var dualZoneBoostActive = this.isClarityDualZoneBoostActive(params, mode);
   var dualZoneActive = dualZoneOptActive || dualZoneBoostActive;
   var dualZoneProfile = dualZoneActive ? aceClarityDualZoneProfile(dualZoneBoostActive ? mode : ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT, slider, advanced) : null;
   var effectiveSlider = this.clarityV5bEffectivePositiveSlider(slider);
   var uiLabel = dualZoneActive ? dualZoneProfile.uiLabel :
      (aceIsClarityFeatureFitMode(mode) ? aceClarityFeatureFitModeLabel(mode) :
      (mode === ACE_CLARITY_MODE_V4 ? "V4" :
      (aceIsClarityV3Mode(mode) ? aceClarityV3ButtonLabel(mode) :
      (mode === ACE_CLARITY_MODE_V2 || mode === ACE_CLARITY_MODE_V2_DEPTH ? "V2" : "V1"))));
   var featureFitAlgorithmId = featureFitMode === "featurefit_two_term_luma_sat_gate" ?
      ACE_CLARITY_ALGORITHM_ID_FEATUREFIT_TWO_TERM_LUMA_SAT_GATE :
      ACE_CLARITY_ALGORITHM_ID_FEATUREFIT_SHARED_LUMA_SAT_GATE;
   var algorithmId = dualZoneActive ? dualZoneProfile.algorithmId :
      (featureFitActive ? featureFitAlgorithmId : (clarityV5bPositiveActive ?
      (toneMode === "v5b_0945_current" ? ACE_CLARITY_ALGORITHM_ID_V5B_POSITIVE_CURRENT_0945 : ACE_CLARITY_ALGORITHM_ID_V5B_POSITIVE) :
      (mode === ACE_CLARITY_MODE_V4 ? ACE_CLARITY_ALGORITHM_ID_V4 : mode)));
   var actualPath = dualZoneActive ? "internal " + dualZoneProfile.mode + " DualZone positive correction; negative Clarity remains V4" :
      (featureFitActive ? "V4 plus internal feature-fit gated positive correction" :
      (clarityV5bPositiveActive ? "V4 plus internal V5b positive broad S-curve debug path" :
      (mode === ACE_CLARITY_MODE_V4 ? "V4 only" : "non-V4 legacy/debug clarity mode")));
   var prefix = timingPrefix || "Operation";
   var renderMode = prefix.indexOf("Full") >= 0 || prefix.indexOf("Global adjustment") >= 0 ? "full" :
      (prefix.indexOf("Local edit") >= 0 ? "lasso/local" :
      (prefix.indexOf("Preview") >= 0 || prefix.indexOf("Clarity map") >= 0 ? "preview" : prefix));
   var report = "[ACE] Clarity path proof | " +
      "ace_version=" + ACE_VERSION +
      "clarity_slider_value=" + slider +
      " clarity_ui_label_selected=" + uiLabel +
      " clarity_algorithm_id=" + algorithmId +
      " clarity_algorithm_positive=" + (dualZoneActive ? dualZoneProfile.algorithmId : (featureFitActive ? featureFitAlgorithmId : (clarityV5bPositiveActive ? algorithmId : ACE_CLARITY_ALGORITHM_ID_V4))) +
      " clarity_algorithm_negative=" + ACE_CLARITY_ALGORITHM_ID_V4 +
      " clarity_path_actual=" + actualPath +
      " clarity_positive_path=" + (dualZoneActive ? dualZoneProfile.mode : (featureFitActive ? "featurefit_gated" : (clarityV5bPositiveActive ? "v5b" : (slider > 0 && mode === ACE_CLARITY_MODE_V4 ? "v4" : "not-active")))) +
      " clarity_response=" + (dualZoneActive ? dualZoneProfile.response : "not-active") +
      " clarity_negative_path=v4" +
      " clarity_tone_mode=" + toneMode +
      " clarity_featurefit_mode=" + featureFitMode +
      " featurefit_candidate_id=" + (featureFitActive ? featureFitMode : "not-active") +
      " dualzone_candidate_id=" + (dualZoneActive ? dualZoneProfile.candidateId : "not-active") +
      " dualzone_optimized_parameters=" + (dualZoneActive ? "response:" + dualZoneProfile.response + ",activity_low:" + dualZoneProfile.activityLow + ",activity_high:" + dualZoneProfile.activityHigh + ",midtone_gain:" + dualZoneProfile.midtoneGain + ",dark_dust_gain:" + dualZoneProfile.darkDustGain + ",bright_zone_gain:" + dualZoneProfile.brightZoneGain + ",high_luma_suppression_strength:" + dualZoneProfile.highLumaSuppression + ",high_sat_suppression_strength:" + dualZoneProfile.highSatSuppression + ",plateau_limiter_strength:" + dualZoneProfile.plateauLimiter : "not-active") +
      " dualzone_high_headroom_t=" + (dualZoneActive ? aceValidationNumber(dualZoneProfile.highHeadroomT, 6) : "not-active") +
      " dualzone_safe_zone_scale=" + (dualZoneActive ? aceValidationNumber(dualZoneProfile.safeZoneScale, 6) : "not-active") +
      " dualzone_midtone_scale=" + (dualZoneActive ? aceValidationNumber(dualZoneProfile.midtoneScale, 6) : "not-active") +
      " dualzone_dark_dust_scale=" + (dualZoneActive ? aceValidationNumber(dualZoneProfile.darkDustScale, 6) : "not-active") +
      " product_range_philosophy=0-75_normal_practical,75-100_strong_usable,100-150_intentional_overshoot_high_headroom" +
      " featurefit_coefficients=" + (featureFitActive ? "shared:-0.00704853187300082,-0.013447111503026653,-0.0008657916283153728 two_term:-0.007010979989729212,-0.01352308382642898" : "not-active") +
      " luma_saturation_gate_active=" + (featureFitActive ? "yes" : "no") +
      " is_v5b_positive_active=" + (clarityV5bPositiveActive ? "true" : "false") +
      " broad_scurve_base_gain=" + CLARITY_V5B_POSITIVE_BROAD_SCURVE_BASE_GAIN +
      " broad_scurve_gamma=" + CLARITY_V5B_POSITIVE_BROAD_SCURVE_GAMMA +
      " v5b_highlight_guard_active=" + (clarityV5bPositiveActive && toneMode === "v5b_highlight_guard_test" ? "yes" : "no") +
      " effective_positive_slider=" + aceValidationNumber(effectiveSlider, 3) +
      " clamp_active=" + (slider > 100 ? "yes" : "no") +
      " broad_scurve_scale=" + aceValidationNumber(broadScale || 0, 6) +
      " effective_broad_scurve_scale=" + aceValidationNumber(broadScale || 0, 6) +
      " v4_component_active=" + (mode === ACE_CLARITY_MODE_V4 && slider !== 0 ? "yes" : "no") +
      " broad_scurve_component_active=" + (clarityV5bPositiveActive ? "yes" : "no") +
      " featurefit_component_active=" + (featureFitActive ? "yes" : "no") +
      " protection_masks_applied_to_v4_component=yes" +
      " protection_masks_applied_to_broad_scurve_component=" + (clarityV5bPositiveActive ? (toneMode === "v5b_highlight_guard_test" ? "highlight_upper_midtone_saturation_guard" : "v0_9_145_current_unprotected") : "not-active") +
      " protection_masks_applied_to_featurefit_component=" + (featureFitActive ? "luma_saturation_gate_plus_star_keep" : "not-active") +
      " protection_masks_applied_to_dualzone_component=" + (dualZoneActive ? "smooth_bright_high_sat_suppression_plus_star_weight saturation_prominence_guard:" + dualZoneProfile.saturationProminenceGuard : "not-active") +
      " final_composition_formula_id=" + (dualZoneActive ? dualZoneProfile.finalCompositionFormulaId : (featureFitActive ? "clarity_featurefit_gated_post_v4_luminance_composition" : (clarityV5bPositiveActive ? ACE_CLARITY_V5B_FINAL_COMPOSITION_FORMULA_ID : "standard_ace_luminance_composition"))) +
      " preview_path_name=PreviewProcessor.processPreview->MultiScaleContrastEngine.apply" +
      " full_render_path_name=renderFullResolutionOutput->applyFullResolutionOperation->MultiScaleContrastEngine.apply" +
      " lasso_local_render_path_name=applyFullResolutionLassoEdit->applyFullResolutionOperation->MultiScaleContrastEngine.apply" +
      " render_mode=" + renderMode +
      " USE_CLARITY_V5B_POSITIVE=" + (USE_CLARITY_V5B_POSITIVE ? "true" : "false") +
      " USE_CLARITY_DUALZONE_OPT_POSITIVE=" + (USE_CLARITY_DUALZONE_OPT_POSITIVE ? "true" : "false") +
      " USE_CLARITY_DUALZONE_BOOST_POSITIVE=" + (USE_CLARITY_DUALZONE_BOOST_POSITIVE ? "true" : "false") +
      " FORCE_CLARITY_V4=" + (FORCE_CLARITY_V4 ? "true" : "false") +
      " CLARITY_V5B_TONE_MODE=" + CLARITY_V5B_TONE_MODE +
      " CLARITY_DUALZONE_OPT_INTERNAL_MODE=" + CLARITY_DUALZONE_OPT_INTERNAL_MODE +
      " CLARITY_DUALZONE_BOOST_INTERNAL_MODE=" + CLARITY_DUALZONE_BOOST_INTERNAL_MODE;
   if (typeof console !== "undefined" && console && typeof console.writeln === "function")
      console.writeln(report);
   else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
      Console.writeln(report);
};

MultiScaleContrastEngine.prototype.computeClarityV5bPositiveDelta = function(width, height, params, cache, starAllowedWeight, timing, timingPrefix) {
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   var totalStart = timingActive ? Date.now() : 0;
   var count = width * height;
   var scale = this.clarityV5bPositiveScale(params.clarity);
   var effectiveSlider = this.clarityV5bEffectivePositiveSlider(params.clarity);
   var toneMode = this.clarityV5bToneMode();
   var broad = this.buildBroadLocalSCurveComponent(width, height, cache, starAllowedWeight, timing, prefix);
   var out = new Float32Array(count);
   var stage = timingActive ? Date.now() : 0;
   var absSum = 0;
   var maxAbs = 0;
   var keepSum = 0;
   for (var i = 0; i < count; ++i) {
      if ((i & 131071) === 0)
         aceYieldToPixInsight();
      var guardKeep = this.clarityV5bHighlightGuardKeep(cache.luminance[i], cache.sourceSaturation ? cache.sourceSaturation[i] : 0);
      var delta = scale * (broad ? broad[i] : 0) * guardKeep;
      out[i] = delta;
      keepSum += guardKeep;
      var absDelta = Math.abs(delta);
      absSum += absDelta;
      if (absDelta > maxAbs)
         maxAbs = absDelta;
   }
   acePerfMark(timing, prefix + " detail - Clarity V5b positive broad delta", stage);
   var nowMs = Date.now();
   var shouldLog = CLARITY_V5B_DIAGNOSTIC_LOG_ENABLED && params.clarity > 0 &&
      (Math.max(width, height) <= ACE_DRAFT_MAX_EDGE + 512 || prefix.indexOf("Preview") >= 0 || prefix.indexOf("Clarity map") >= 0) &&
      nowMs - gClarityV5bDiagnosticLastLogMs >= CLARITY_V5B_DIAGNOSTIC_LOG_INTERVAL_MS;
   if (shouldLog) {
      gClarityV5bDiagnosticLastLogMs = nowMs;
      var algorithmId = toneMode === "v5b_0945_current" ? ACE_CLARITY_ALGORITHM_ID_V5B_POSITIVE_CURRENT_0945 : ACE_CLARITY_ALGORITHM_ID_V5B_POSITIVE;
      var report = "[ACE] Clarity V5b positive diagnostics | clarity_algorithm_used=" + algorithmId +
         " ace_version=" + ACE_VERSION +
         " clarity_slider_value=" + params.clarity +
         " clarity_algorithm_positive=" + algorithmId +
         " clarity_algorithm_negative=" + ACE_CLARITY_ALGORITHM_ID_V4 +
         " clarity_tone_mode=" + toneMode +
         " clarity_positive_path=v5b" +
         " clarity_negative_path=v4" +
         " broad_scurve_base_gain=" + CLARITY_V5B_POSITIVE_BROAD_SCURVE_BASE_GAIN +
         " broad_scurve_gamma=" + CLARITY_V5B_POSITIVE_BROAD_SCURVE_GAMMA +
         " v5b_highlight_guard_active=" + (toneMode === "v5b_highlight_guard_test" ? "yes" : "no") +
         " v5b_highlight_guard_mean_keep=" + aceValidationNumber(keepSum / Math.max(1, count), 6) +
         " effective_positive_slider=" + aceValidationNumber(effectiveSlider, 3) +
         " clamp_active=" + (params.clarity > 100 ? "yes" : "no") +
         " broad_scurve_scale=" + aceValidationNumber(scale, 6) +
         " effective_broad_scurve_scale=" + aceValidationNumber(scale, 6) +
         " broadFieldP99=" + aceValidationNumber(cache.clarityV5bBroadLocalSCurveScale || 0, 5) +
         " broadDeltaMeanAbs=" + aceValidationNumber(absSum / Math.max(1, count), 6) +
         " broadDeltaMaxAbs=" + aceValidationNumber(maxAbs, 6) +
         " preview_full_render_mode=" + prefix +
         " lasso_local_mode=" + (prefix.indexOf("Local edit") >= 0 ? "yes" : "no") +
         " rollbackSwitches=USE_CLARITY_V5B_POSITIVE,FORCE_CLARITY_V4,CLARITY_V5B_TONE_MODE";
      if (typeof console !== "undefined" && console && typeof console.writeln === "function")
         console.writeln(report);
      else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
         Console.writeln(report);
   }
   acePerfMark(timing, prefix + " detail - Clarity V5b positive total", totalStart);
   return out;
};

MultiScaleContrastEngine.prototype.clarityFeatureFitMode = function(mode) {
   mode = aceNormalizeClarityMode(mode);
   if (mode === ACE_CLARITY_MODE_FEATUREFIT_SHARED_LUMA_SAT_GATE)
      return "featurefit_shared_luma_sat_gate";
   if (mode === ACE_CLARITY_MODE_FEATUREFIT_TWO_TERM_LUMA_SAT_GATE)
      return "featurefit_two_term_luma_sat_gate";
   if (USE_CLARITY_FEATUREFIT_GATED_POSITIVE && CLARITY_FEATUREFIT_INTERNAL_MODE === "featurefit_shared_luma_sat_gate")
      return "featurefit_shared_luma_sat_gate";
   if (USE_CLARITY_FEATUREFIT_GATED_POSITIVE && CLARITY_FEATUREFIT_INTERNAL_MODE === "featurefit_two_term_luma_sat_gate")
      return "featurefit_two_term_luma_sat_gate";
   return "forced_v4";
};

MultiScaleContrastEngine.prototype.isClarityFeatureFitActive = function(params, mode) {
   return !!params && params.clarity > 0 && this.clarityFeatureFitMode(mode) !== "forced_v4";
};

MultiScaleContrastEngine.prototype.computeClarityFeatureFitGatedDelta = function(width, height, params, cache, starAllowedWeight, timing, timingPrefix, mode) {
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   var totalStart = timingActive ? Date.now() : 0;
   var stage = timingActive ? Date.now() : 0;
   var count = width * height;
   var ffMode = this.clarityFeatureFitMode(mode);
   var luminance = cache.luminance;
   var localBase = cache.clarityFeatureFitLocalBase;
   if (!localBase) {
      localBase = aceSoftScaleBlurFloat(width, height, luminance, CLARITY_FEATUREFIT_LOCAL_BASE_RADIUS);
      cache.clarityFeatureFitLocalBase = localBase;
   }
   acePerfMark(timing, prefix + " detail - Clarity +FFit local base r" + CLARITY_FEATUREFIT_LOCAL_BASE_RADIUS, stage);
   stage = timingActive ? Date.now() : 0;
   var darkSide = new Float32Array(count);
   var darkMid = new Float32Array(count);
   var localDetail = new Float32Array(count);
   var detailBase = aceSoftScaleBlurFloat(width, height, luminance, CLARITY_FEATUREFIT_LOCAL_DETAIL_RADIUS);
   for (var i = 0; i < count; ++i) {
      if ((i & 131071) === 0)
         aceYieldToPixInsight();
      var l = luminance[i];
      var dark = Math.max(localBase[i] - l, 0);
      var mid =
         aceSmoothStep(CLARITY_FEATUREFIT_MIDTONE_LOW, CLARITY_FEATUREFIT_MIDTONE_PEAK_LOW, l) *
         (1 - aceSmoothStep(CLARITY_FEATUREFIT_MIDTONE_PEAK_HIGH, CLARITY_FEATUREFIT_MIDTONE_HIGH, l));
      darkSide[i] = dark;
      darkMid[i] = dark * mid;
      var d = l - detailBase[i];
      localDetail[i] = d * d;
   }
   var localMeanSquare = aceBoxBlurFloat(width, height, localDetail, CLARITY_FEATUREFIT_LOCAL_RMS_RADIUS);
   var localRms = new Float32Array(count);
   for (var r = 0; r < count; ++r)
      localRms[r] = Math.sqrt(Math.max(0, localMeanSquare[r]));
   acePerfMark(timing, prefix + " detail - Clarity +FFit features", stage);
   stage = timingActive ? Date.now() : 0;
   var darkNorm = aceNormalizeFeatureFitField(darkSide);
   var darkMidNorm = aceNormalizeFeatureFitField(darkMid);
   var localRmsNorm = aceNormalizeFeatureFitField(localRms);
   var out = new Float32Array(count);
   var rawMin = 1.0e9, rawMax = -1.0e9, rawSum = 0, rawAbsSum = 0;
   var gateSum = 0, gateMin = 1, gateMax = 0;
   var corrMin = 1.0e9, corrMax = -1.0e9, corrSum = 0, corrAbsSum = 0;
   var corrP95Samples = new Float32Array(count);
   var corrP99Samples = new Float32Array(count);
   var clipCount = 0;
   var c1 = ffMode === "featurefit_two_term_luma_sat_gate" ? CLARITY_FEATUREFIT_TWO_TERM_C1_DARK_SIDE : CLARITY_FEATUREFIT_SHARED_C1_DARK_SIDE;
   var c2 = ffMode === "featurefit_two_term_luma_sat_gate" ? CLARITY_FEATUREFIT_TWO_TERM_C2_DARK_MIDTONE : CLARITY_FEATUREFIT_SHARED_C2_DARK_MIDTONE;
   var c3 = ffMode === "featurefit_two_term_luma_sat_gate" ? 0 : CLARITY_FEATUREFIT_SHARED_C3_LOCAL_RMS;
   for (var j = 0; j < count; ++j) {
      if ((j & 131071) === 0)
         aceYieldToPixInsight();
      var raw = c1 * darkNorm.data[j] + c2 * darkMidNorm.data[j] + c3 * localRmsNorm.data[j];
      var sat = cache.sourceSaturation ? cache.sourceSaturation[j] : 0;
      var joint =
         aceSmoothStep(CLARITY_FEATUREFIT_LUMA_GATE_START, CLARITY_FEATUREFIT_LUMA_GATE_END, luminance[j]) *
         aceSmoothStep(CLARITY_FEATUREFIT_SAT_GATE_START, CLARITY_FEATUREFIT_SAT_GATE_END, sat);
      var gate = 1 - CLARITY_FEATUREFIT_LUMA_SAT_SUPPRESSION * joint;
      gate = Math.max(CLARITY_FEATUREFIT_GATE_FLOOR, gate);
      if (starAllowedWeight) {
         var starProtection = aceClamp01(1 - starAllowedWeight[j]);
         var compact = aceSmoothStep(ACE_CONTRAST_STAR_PROTECTION_START, ACE_CONTRAST_STAR_PROTECTION_END, starProtection);
         gate = Math.min(gate, 1 - (1 - CLARITY_FEATUREFIT_STAR_KEEP) * compact);
         gate = Math.max(CLARITY_FEATUREFIT_GATE_FLOOR, gate);
      }
      var delta = aceClamp(raw * gate, CLARITY_FEATUREFIT_NEGATIVE_CLIP, CLARITY_FEATUREFIT_POSITIVE_CLIP);
      out[j] = delta;
      rawMin = Math.min(rawMin, raw);
      rawMax = Math.max(rawMax, raw);
      rawSum += raw;
      rawAbsSum += Math.abs(raw);
      gateSum += gate;
      gateMin = Math.min(gateMin, gate);
      gateMax = Math.max(gateMax, gate);
      corrMin = Math.min(corrMin, delta);
      corrMax = Math.max(corrMax, delta);
      corrSum += delta;
      var absDelta = Math.abs(delta);
      corrAbsSum += absDelta;
      corrP95Samples[j] = absDelta;
      corrP99Samples[j] = absDelta;
      if (raw * gate !== delta)
         ++clipCount;
   }
   var corrP95 = acePercentileFloat(corrP95Samples, 95.0);
   var corrP99 = acePercentileFloat(corrP99Samples, 99.0);
   acePerfMark(timing, prefix + " detail - Clarity +FFit normalized gated correction", stage);
   var nowMs = Date.now();
   var shouldLog = CLARITY_FEATUREFIT_DIAGNOSTIC_LOG_ENABLED && params.clarity > 0 &&
      (Math.max(width, height) <= ACE_DRAFT_MAX_EDGE + 512 || prefix.indexOf("Preview") >= 0 || prefix.indexOf("Clarity map") >= 0) &&
      nowMs - gClarityFeatureFitDiagnosticLastLogMs >= CLARITY_FEATUREFIT_DIAGNOSTIC_LOG_INTERVAL_MS;
   if (shouldLog) {
      gClarityFeatureFitDiagnosticLastLogMs = nowMs;
      var invCount = count > 0 ? 1 / count : 0;
      var algorithmId = ffMode === "featurefit_two_term_luma_sat_gate" ? ACE_CLARITY_ALGORITHM_ID_FEATUREFIT_TWO_TERM_LUMA_SAT_GATE : ACE_CLARITY_ALGORITHM_ID_FEATUREFIT_SHARED_LUMA_SAT_GATE;
      var report = "[ACE] Clarity +FFitGated diagnostics | ace_version=" + ACE_VERSION +
         " clarity_algorithm_id=" + algorithmId +
         " clarity_algorithm_mode=" + ffMode +
         " featurefit_candidate_id=" + ffMode +
         " coefficients_used=c1_dark_side:" + c1 + ",c2_dark_mid:" + c2 + ",c3_local_rms:" + c3 +
         " luma_saturation_gate_active=yes" +
         " luma_gate_start=" + CLARITY_FEATUREFIT_LUMA_GATE_START +
         " luma_gate_end=" + CLARITY_FEATUREFIT_LUMA_GATE_END +
         " saturation_gate_start=" + CLARITY_FEATUREFIT_SAT_GATE_START +
         " saturation_gate_end=" + CLARITY_FEATUREFIT_SAT_GATE_END +
         " mean_gate_value=" + aceValidationNumber(gateSum * invCount, 6) +
         " gate_min=" + aceValidationNumber(gateMin, 6) +
         " gate_max=" + aceValidationNumber(gateMax, 6) +
         " raw_correction_min=" + aceValidationNumber(rawMin, 6) +
         " raw_correction_max=" + aceValidationNumber(rawMax, 6) +
         " raw_correction_mean=" + aceValidationNumber(rawSum * invCount, 6) +
         " correction_min=" + aceValidationNumber(corrMin, 6) +
         " correction_max=" + aceValidationNumber(corrMax, 6) +
         " correction_mean=" + aceValidationNumber(corrSum * invCount, 6) +
         " correction_abs_mean=" + aceValidationNumber(corrAbsSum * invCount, 6) +
         " correction_p95_abs=" + aceValidationNumber(corrP95, 6) +
         " correction_p99_abs=" + aceValidationNumber(corrP99, 6) +
         " clipping_fraction=" + aceValidationNumber(clipCount * invCount, 6) +
         " feature_norm_dark_side_center=" + aceValidationNumber(darkNorm.center, 6) +
         " feature_norm_dark_side_scale=" + aceValidationNumber(darkNorm.scale, 6) +
         " feature_norm_dark_mid_center=" + aceValidationNumber(darkMidNorm.center, 6) +
         " feature_norm_dark_mid_scale=" + aceValidationNumber(darkMidNorm.scale, 6) +
         " feature_norm_local_rms_center=" + aceValidationNumber(localRmsNorm.center, 6) +
         " feature_norm_local_rms_scale=" + aceValidationNumber(localRmsNorm.scale, 6) +
         " preview_vs_full_render_path=" + prefix +
         " rollback_switch_status=ACE_CLARITY_MODE_DEFAULT:" + ACE_CLARITY_MODE_DEFAULT + ",USE_CLARITY_FEATUREFIT_GATED_POSITIVE:" + USE_CLARITY_FEATUREFIT_GATED_POSITIVE + ",CLARITY_FEATUREFIT_INTERNAL_MODE:" + CLARITY_FEATUREFIT_INTERNAL_MODE;
      if (typeof console !== "undefined" && console && typeof console.writeln === "function")
         console.writeln(report);
      else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
         Console.writeln(report);
   }
   acePerfMark(timing, prefix + " detail - Clarity +FFit total", totalStart);
   return out;
};

MultiScaleContrastEngine.prototype.applyClarityFeatureFitBenchmarkComposition = function(width, height, output, featureFitDelta, timing, timingPrefix) {
   if (!featureFitDelta)
      return output;
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   var totalStart = timingActive ? Date.now() : 0;
   var count = width * height;
   var out = new Float32Array(output.length);
   var clipCount = 0;
   for (var i = 0; i < count; ++i) {
      if ((i & 131071) === 0)
         aceYieldToPixInsight();
      var base = i * 3;
      var r = output[base];
      var g = output[base + 1];
      var b = output[base + 2];
      var l = 0.2126 * r + 0.7152 * g + 0.0722 * b;
      var targetL = aceClamp(l + featureFitDelta[i], 0, 1);
      var ratio = aceClamp(targetL / Math.max(l, ACE_EPSILON), 0.45, CLARITY_FEATUREFIT_RATIO_HI);
      var preR = r * ratio;
      var preG = g * ratio;
      var preB = b * ratio;
      if (preR < 0 || preR > 1 || preG < 0 || preG > 1 || preB < 0 || preB > 1)
         ++clipCount;
      out[base] = aceClamp01(preR);
      out[base + 1] = aceClamp01(preG);
      out[base + 2] = aceClamp01(preB);
   }
   var report = "[ACE] Clarity +FFitGated final composition diagnostics | " +
      "final_composition_mode=post_v4_luminance_delta" +
      " final_composition_formula_id=clarity_featurefit_gated_post_v4_luminance_composition" +
      " rgb_reconstruction_used_source_chroma=yes_v4_output_chroma" +
      " protection_masks_applied_to_v4_component=yes" +
      " protection_masks_applied_to_featurefit_correction=luma_saturation_gate_plus_star_keep" +
      " protection_masks_applied_to_final_combined_output=standard_ace_luminance_delta_safety_before_post_v4_featurefit" +
      " clipping_fraction=" + aceValidationNumber(clipCount / Math.max(1, count), 6);
   if (typeof console !== "undefined" && console && typeof console.writeln === "function")
      console.writeln(report);
   else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
      Console.writeln(report);
   acePerfMark(timing, prefix + " detail - Clarity +FFit benchmark final composition", totalStart);
   return out;
};

MultiScaleContrastEngine.prototype.isClarityDualZoneOptActive = function(params, mode) {
   mode = aceNormalizeClarityMode(mode);
   return !!params && params.clarity > 0 &&
      (mode === ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT ||
       (USE_CLARITY_DUALZONE_OPT_POSITIVE && CLARITY_DUALZONE_OPT_INTERNAL_MODE === "dualzone_opt_safer_bright"));
};

MultiScaleContrastEngine.prototype.isClarityDualZoneBoostActive = function(params, mode) {
   mode = aceNormalizeClarityMode(mode);
   return !!params && params.clarity > 0 &&
      (aceIsClarityDualZoneBoostMode(mode) ||
       (USE_CLARITY_DUALZONE_BOOST_POSITIVE && CLARITY_DUALZONE_BOOST_INTERNAL_MODE !== "forced_v4"));
};

function aceClarityDualZoneHighendT(slider) {
   return aceSmoothStep(CLARITY_DUALZONE_HIGHEND_RESPONSE_START, CLARITY_DUALZONE_HIGHEND_RESPONSE_END, Math.max(0, slider || 0));
}

function aceNormalizeClarityResponse(response) {
   if (response === ACE_CLARITY_RESPONSE_LIGHT)
      return ACE_CLARITY_RESPONSE_LIGHT;
   if (response === ACE_CLARITY_RESPONSE_STRONG)
      return ACE_CLARITY_RESPONSE_STRONG;
   return ACE_CLARITY_RESPONSE_BALANCED;
}

function aceClarityResponseLabel(response) {
   response = aceNormalizeClarityResponse(response);
   if (response === ACE_CLARITY_RESPONSE_LIGHT)
      return "Light";
   if (response === ACE_CLARITY_RESPONSE_STRONG)
      return "Strong";
   return "Balanced";
}

function aceClarityResponseSelectorIndex(response) {
   response = aceNormalizeClarityResponse(response);
   if (response === ACE_CLARITY_RESPONSE_LIGHT)
      return 0;
   if (response === ACE_CLARITY_RESPONSE_STRONG)
      return 2;
   return 1;
}

function aceClarityResponseForSelectorIndex(index) {
   if (index === 0)
      return ACE_CLARITY_RESPONSE_LIGHT;
   if (index === 2)
      return ACE_CLARITY_RESPONSE_STRONG;
   return ACE_CLARITY_RESPONSE_BALANCED;
}

function aceClarityResponseProfile(response, slider) {
   response = aceNormalizeClarityResponse(response);
   var sliderValue = Math.max(0, slider || 0);
   if (response === ACE_CLARITY_RESPONSE_LIGHT) {
      return {
         response: response,
         label: "Light",
         highT: aceSmoothStep(90.0, 150.0, sliderValue),
         productGain: ACE_CLARITY_DUALZONE_PRODUCT_GAIN * 0.88,
         midtoneGainScale: 0.88,
         darkDustGainScale: 0.92,
         activityLow: 0.0050,
         activityHigh: 0.026,
         brightSuppressScale: 1.08,
         saturationSuppressScale: 1.08,
         positiveKeepScale: 0.96
      };
   }
   if (response === ACE_CLARITY_RESPONSE_STRONG) {
      return {
         response: response,
         label: "Strong",
         highT: aceSmoothStep(45.0, 125.0, sliderValue),
         productGain: ACE_CLARITY_DUALZONE_PRODUCT_GAIN * 1.14,
         midtoneGainScale: 1.18,
         darkDustGainScale: 1.16,
         activityLow: 0.0024,
         activityHigh: 0.017,
         brightSuppressScale: 0.92,
         saturationSuppressScale: 0.95,
         positiveKeepScale: 1.08
      };
   }
   return {
      response: ACE_CLARITY_RESPONSE_BALANCED,
      label: "Balanced",
      highT: aceClarityDualZoneHighendT(sliderValue),
      productGain: ACE_CLARITY_DUALZONE_PRODUCT_GAIN,
      midtoneGainScale: 1.0,
      darkDustGainScale: 1.0,
      activityLow: 0.0035,
      activityHigh: 0.022,
      brightSuppressScale: 1.0,
      saturationSuppressScale: 1.0,
      positiveKeepScale: 1.0
   };
}

function aceClarityDualZoneProfile(mode, slider, advanced) {
   mode = aceNormalizeClarityMode(mode);
   var responseProfile = aceClarityResponseProfile(advanced ? advanced.clarityResponse : DEFAULT_CLARITY_RESPONSE, slider);
   var highT = responseProfile.highT;
   if (mode === ACE_CLARITY_MODE_DUALZONE_BROADBAND_BOOST_GUARDED ||
       mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P30 ||
       mode === ACE_CLARITY_MODE_DUALZONE_SAFEZONE_EXTRA_DARKDUST ||
       mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P50) {
      var label = "+DZBoost";
      var algorithmId = ACE_CLARITY_ALGORITHM_ID_DUALZONE_BROADBAND_BOOST_GUARDED;
      var candidateId = "clarity_dualzone_broadband_boost_guarded";
      var midScale = 1.0;
      var darkScale = 1.0;
      var safeScale = 1.0;
      var highSat = CLARITY_DUALZONE_BOOST_HIGH_SAT_SUPPRESSION;
      if (mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P30) {
         label = "+DZBoost30";
         algorithmId = ACE_CLARITY_ALGORITHM_ID_DUALZONE_HIGHEND_1P30;
         candidateId = "clarity_dualzone_highend_1p30";
         safeScale = 1.0 + 0.30 * highT;
         midScale = safeScale;
         darkScale = safeScale;
      } else if (mode === ACE_CLARITY_MODE_DUALZONE_SAFEZONE_EXTRA_DARKDUST) {
         label = "+DZDust";
         algorithmId = ACE_CLARITY_ALGORITHM_ID_DUALZONE_SAFEZONE_EXTRA_DARKDUST;
         candidateId = "clarity_dualzone_safezone_extra_darkdust";
         midScale = 1.0 + 0.10 * highT;
         darkScale = 1.0 + 0.45 * highT;
         safeScale = darkScale;
         highSat = 0.33;
      } else if (mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P50) {
         label = "+DZBoost50";
         algorithmId = ACE_CLARITY_ALGORITHM_ID_DUALZONE_HIGHEND_1P50;
         candidateId = "clarity_dualzone_highend_1p50";
         safeScale = 1.0 + 0.50 * highT;
         midScale = safeScale;
         darkScale = safeScale;
      }
      return {
         uiLabel: label,
         response: responseProfile.response,
         responseLabel: responseProfile.label,
         mode: mode,
         algorithmId: algorithmId,
         candidateId: candidateId,
         midtoneGain: CLARITY_DUALZONE_BOOST_MIDTONE_GAIN * midScale * responseProfile.midtoneGainScale,
         darkDustGain: CLARITY_DUALZONE_BOOST_DARK_DUST_GAIN * darkScale * responseProfile.darkDustGainScale,
         brightZoneGain: CLARITY_DUALZONE_BOOST_BRIGHT_ZONE_GAIN,
         highLumaSuppression: CLARITY_DUALZONE_BOOST_HIGH_LUMA_SUPPRESSION * responseProfile.brightSuppressScale,
         highSatSuppression: highSat * responseProfile.saturationSuppressScale,
         plateauLimiter: CLARITY_DUALZONE_BOOST_PLATEAU_LIMITER,
         activityLow: responseProfile.activityLow,
         activityHigh: responseProfile.activityHigh,
         positiveKeepScale: responseProfile.positiveKeepScale,
         highHeadroomT: highT,
         safeZoneScale: safeScale,
         midtoneScale: midScale,
         darkDustScale: darkScale,
         diagnosticEnabled: CLARITY_DUALZONE_BOOST_DIAGNOSTIC_LOG_ENABLED,
         diagnosticIntervalMs: CLARITY_DUALZONE_BOOST_DIAGNOSTIC_LOG_INTERVAL_MS,
         saturationProminenceGuard: "high_saturation_suppression_0.31_plus_positive_delta_guard",
         productGain: responseProfile.productGain,
         finalCompositionFormulaId: "clarity_dualzone_high_headroom_direct_luminance_delta_composition_product_gain_1p32"
      };
   }
   return {
      uiLabel: "+DZOpt",
      response: responseProfile.response,
      responseLabel: responseProfile.label,
      mode: "dualzone_opt_safer_bright",
      algorithmId: ACE_CLARITY_ALGORITHM_ID_DUALZONE_OPT_SAFER_BRIGHT,
      candidateId: "clarity_dualzone_opt_safer_bright",
      midtoneGain: CLARITY_DUALZONE_OPT_MIDTONE_GAIN * responseProfile.midtoneGainScale,
      darkDustGain: CLARITY_DUALZONE_OPT_DARK_DUST_GAIN * responseProfile.darkDustGainScale,
      brightZoneGain: CLARITY_DUALZONE_OPT_BRIGHT_ZONE_GAIN,
      highLumaSuppression: CLARITY_DUALZONE_OPT_HIGH_LUMA_SUPPRESSION * responseProfile.brightSuppressScale,
      highSatSuppression: CLARITY_DUALZONE_OPT_HIGH_SAT_SUPPRESSION * responseProfile.saturationSuppressScale,
      plateauLimiter: CLARITY_DUALZONE_OPT_PLATEAU_LIMITER,
      activityLow: responseProfile.activityLow,
      activityHigh: responseProfile.activityHigh,
      positiveKeepScale: responseProfile.positiveKeepScale,
      highHeadroomT: 0,
      safeZoneScale: 1.0,
      midtoneScale: 1.0,
      darkDustScale: 1.0,
      diagnosticEnabled: CLARITY_DUALZONE_OPT_DIAGNOSTIC_LOG_ENABLED,
      diagnosticIntervalMs: CLARITY_DUALZONE_OPT_DIAGNOSTIC_LOG_INTERVAL_MS,
      saturationProminenceGuard: "high_saturation_suppression_0.23",
      productGain: responseProfile.productGain,
      finalCompositionFormulaId: "clarity_dualzone_opt_direct_luminance_delta_composition"
   };
}

MultiScaleContrastEngine.prototype.computeClarityDualZoneDelta = function(width, height, params, cache, starAllowedWeight, timing, timingPrefix, mode, advanced) {
   var profile = aceClarityDualZoneProfile(mode, params ? params.clarity : 0, advanced);
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   var totalStart = timingActive ? Date.now() : 0;
   var stage = timingActive ? Date.now() : 0;
   var count = width * height;
   var luminance = cache.luminance;
   var saturation = cache.sourceSaturation;
   var starAllowed = starAllowedWeight || null;
   var valueScale = Math.pow(aceClamp(params.clarity / 100, 0, 1.5), 0.82) * (profile.productGain || 1);
   var small = aceClarityDualZoneBlurFloat(width, height, luminance, 2);
   var mid = aceClarityDualZoneBlurFloat(width, height, luminance, 8);
   var large = aceClarityDualZoneBlurFloat(width, height, luminance, 28);
   var localBase = aceClarityDualZoneBlurFloat(width, height, luminance, 56);
   acePerfMark(timing, prefix + " detail - Clarity " + profile.uiLabel + " bases", stage);
   stage = timingActive ? Date.now() : 0;
   var bandMid = new Float32Array(count);
   var bandDust = new Float32Array(count);
   var brightWeight = new Float32Array(count);
   var midtoneWeight = new Float32Array(count);
   var darkWeight = new Float32Array(count);
   var highLuma = new Float32Array(count);
   var highSat = new Float32Array(count);
   var brightRisk = new Float32Array(count);
   var activity = cache.clarityV4Activity || cache.clarityV4ReliefSignal || cache.clarityLayer;
   var zoneStart = stage;
   var zoneFactor = aceClarityDualZoneZoneDownsampleFactor(width, height, prefix);
   var zoneBlurStart = stage;
   if (zoneFactor > 1) {
      var zoneLuminance = aceDownsampleFloatAverage(width, height, luminance, zoneFactor);
      var zoneSaturation = saturation ? aceDownsampleFloatAverage(width, height, saturation, zoneFactor) : null;
      var zoneStar = starAllowed ? aceDownsampleFloatAverage(width, height, starAllowed, zoneFactor) : null;
      var zoneActivity = activity ? aceDownsampleFloatAverage(width, height, activity, zoneFactor) : null;
      var zoneLocalBase = aceDownsampleFloatAverage(width, height, localBase, zoneFactor);
      var zoneCount = zoneLuminance.width * zoneLuminance.height;
      var zoneBrightWeight = new Float32Array(zoneCount);
      var zoneMidtoneWeight = new Float32Array(zoneCount);
      var zoneDarkWeight = new Float32Array(zoneCount);
      var zoneBrightRisk = new Float32Array(zoneCount);
      for (var zi = 0; zi < zoneCount; ++zi) {
         if ((zi & 32767) === 0)
            aceYieldToPixInsight();
         var zl = zoneLuminance.data[zi];
         var zsat = zoneSaturation ? zoneSaturation.data[zi] : 0;
         var zstar = zoneStar ? zoneStar.data[zi] : 1;
         var zact = Math.abs(zoneActivity ? zoneActivity.data[zi] : 0);
         var zbright = Math.max(
            aceSmoothStep(0.56, 0.88, zl) * aceSmoothStep(0.12, 0.36, zsat),
            aceSmoothStep(0.72, 0.96, zl) * aceSmoothStep(0.004, 0.025, zact)
         );
         var zactGate = aceSmoothStep(profile.activityLow, profile.activityHigh, zact);
         var zstarPower = Math.pow(aceClamp01(zstar), 1.20);
         var zhighLuma = aceSmoothStep(0.56, 0.90, zl);
         var zhighSat = aceSmoothStep(0.13, 0.40, zsat);
         var zmidTone =
            aceSmoothStep(0.055, 0.20, zl) *
            (1 - 0.72 * aceSmoothStep(0.72, 0.96, zl)) *
            zactGate * zstarPower * (1 - 0.76 * zbright);
         var zdarkSide = aceSmoothStep(0.004, 0.060, Math.max(zoneLocalBase.data[zi] - zl, 0));
         zoneBrightWeight[zi] = aceClamp01(zbright);
         zoneMidtoneWeight[zi] = aceClamp01(zmidTone);
         zoneDarkWeight[zi] = aceClamp01(zdarkSide * zactGate * zstarPower * (1 - 0.82 * zbright));
         zoneBrightRisk[zi] = aceClamp01(zoneBrightWeight[zi] + 0.55 * zhighLuma * zhighSat);
      }
      acePerfMark(timing, prefix + " detail - Clarity " + profile.uiLabel + " zone seed loop x" + zoneFactor, zoneStart);
      zoneBlurStart = timingActive ? Date.now() : 0;
      zoneBrightWeight = aceClarityDualZoneBlurFloat(zoneLuminance.width, zoneLuminance.height, zoneBrightWeight, Math.max(1, Math.round(4 / zoneFactor)));
      zoneMidtoneWeight = aceClarityDualZoneBlurFloat(zoneLuminance.width, zoneLuminance.height, zoneMidtoneWeight, Math.max(1, Math.round(2 / zoneFactor)));
      zoneDarkWeight = aceClarityDualZoneBlurFloat(zoneLuminance.width, zoneLuminance.height, zoneDarkWeight, Math.max(1, Math.round(2 / zoneFactor)));
      brightWeight = aceUpsampleFloatBilinear(zoneLuminance.width, zoneLuminance.height, zoneBrightWeight, width, height);
      midtoneWeight = aceUpsampleFloatBilinear(zoneLuminance.width, zoneLuminance.height, zoneMidtoneWeight, width, height);
      darkWeight = aceUpsampleFloatBilinear(zoneLuminance.width, zoneLuminance.height, zoneDarkWeight, width, height);
      brightRisk = aceUpsampleFloatBilinear(zoneLuminance.width, zoneLuminance.height, zoneBrightRisk, width, height);
      for (var fi = 0; fi < count; ++fi) {
         if ((fi & 131071) === 0)
            aceYieldToPixInsight();
         bandMid[fi] = small[fi] - large[fi];
         bandDust[fi] = mid[fi] - large[fi];
         highLuma[fi] = aceSmoothStep(0.56, 0.90, luminance[fi]);
         highSat[fi] = aceSmoothStep(0.13, 0.40, saturation ? saturation[fi] : 0);
      }
   } else {
      for (var i = 0; i < count; ++i) {
         if ((i & 131071) === 0)
            aceYieldToPixInsight();
         var l = luminance[i];
         var sat = saturation ? saturation[i] : 0;
         var star = starAllowed ? starAllowed[i] : 1;
         var act = Math.abs(activity ? activity[i] : (small[i] - large[i]));
         var bright = Math.max(
            aceSmoothStep(0.56, 0.88, l) * aceSmoothStep(0.12, 0.36, sat),
            aceSmoothStep(0.72, 0.96, l) * aceSmoothStep(0.004, 0.025, act)
         );
         var actGate = aceSmoothStep(profile.activityLow, profile.activityHigh, act);
         var midTone =
            aceSmoothStep(0.055, 0.20, l) *
            (1 - 0.72 * aceSmoothStep(0.72, 0.96, l)) *
            actGate * Math.pow(aceClamp01(star), 1.20) * (1 - 0.76 * bright);
         var darkSide = aceSmoothStep(0.004, 0.060, Math.max(localBase[i] - l, 0));
         var dust = darkSide * actGate * Math.pow(aceClamp01(star), 1.20) * (1 - 0.82 * bright);
         bandMid[i] = small[i] - large[i];
         bandDust[i] = mid[i] - large[i];
         brightWeight[i] = aceClamp01(bright);
         midtoneWeight[i] = aceClamp01(midTone);
         darkWeight[i] = aceClamp01(dust);
         highLuma[i] = aceSmoothStep(0.56, 0.90, l);
         highSat[i] = aceSmoothStep(0.13, 0.40, sat);
         brightRisk[i] = aceClamp01(brightWeight[i] + 0.55 * highLuma[i] * highSat[i]);
      }
      acePerfMark(timing, prefix + " detail - Clarity " + profile.uiLabel + " zone seed loop", stage);
      zoneBlurStart = timingActive ? Date.now() : 0;
      brightWeight = aceClarityDualZoneBlurFloat(width, height, brightWeight, 4);
      midtoneWeight = aceClarityDualZoneBlurFloat(width, height, midtoneWeight, 2);
      darkWeight = aceClarityDualZoneBlurFloat(width, height, darkWeight, 2);
   }
   acePerfMark(timing, prefix + " detail - Clarity " + profile.uiLabel + " zone weight blurs" + (zoneFactor > 1 ? " x" + zoneFactor : ""), zoneBlurStart);
   acePerfMark(timing, prefix + " detail - Clarity " + profile.uiLabel + " zone weights", zoneStart);
   stage = timingActive ? Date.now() : 0;
   var correctionStart = stage;
   var brightRaw = new Float32Array(count);
   var midRaw = new Float32Array(count);
   var darkRaw = new Float32Array(count);
   for (var j = 0; j < count; ++j) {
      brightRaw[j] = 0.076 * valueScale * bandMid[j] * profile.brightZoneGain;
      midRaw[j] = 0.070 * valueScale * bandMid[j];
      var signed = luminance[j] - localBase[j];
      var darkPush = -0.050 * valueScale * Math.max(-signed, 0);
      var darkTexture = 0.040 * valueScale * bandDust[j];
      darkRaw[j] = darkPush + darkTexture;
   }
   acePerfMark(timing, prefix + " detail - Clarity " + profile.uiLabel + " correction raw loop", stage);
   stage = timingActive ? Date.now() : 0;
   var brightMean = aceWeightedBlurMeanFloatFullResolutionFast(width, height, brightRaw, brightWeight, 18, prefix);
   var midMean = aceClarityDualZoneMeanBlurFullResolutionFast(width, height, midRaw, 26, prefix);
   var dustMean = aceClarityDualZoneMeanBlurFullResolutionFast(width, height, darkRaw, 22, prefix);
   acePerfMark(timing, prefix + " detail - Clarity " + profile.uiLabel + " correction mean maps", stage);
   stage = timingActive ? Date.now() : 0;
   var out = new Float32Array(count);
   var keepDzDiagnostics = !!profile.diagnosticEnabled;
   var brightCorr = keepDzDiagnostics ? new Float32Array(count) : null;
   var midCorr = keepDzDiagnostics ? new Float32Array(count) : null;
   var darkCorr = keepDzDiagnostics ? new Float32Array(count) : null;
   var stats = keepDzDiagnostics ? aceNewDzStats() : null;
   for (var k = 0; k < count; ++k) {
      if ((k & 131071) === 0)
         aceYieldToPixInsight();
      var bRawDelta = brightRaw[k] - brightMean[k];
      var b = (bRawDelta < -0.030 ? -0.030 : (bRawDelta > 0.023 ? 0.023 : bRawDelta)) * brightWeight[k];
      var m = (midRaw[k] - midMean[k]) * midtoneWeight[k] * profile.midtoneGain;
      var d = (darkRaw[k] - dustMean[k]) * darkWeight[k] * profile.darkDustGain;
      var correction = b + m + d;
      var suppression = profile.highLumaSuppression * highLuma[k] +
         profile.highSatSuppression * highSat[k] +
         profile.plateauLimiter * brightRisk[k];
      suppression = suppression < 0 ? 0 : (suppression > 1 ? 1 : suppression);
      if (correction > 0) {
         var posT = (correction - 0.001) / 0.019;
         posT = posT < 0 ? 0 : (posT > 1 ? 1 : posT);
         var posKeep = 1 - (0.82 / Math.max(0.5, profile.positiveKeepScale)) * suppression * posT * posT * (3 - 2 * posT);
         posKeep = posKeep < 0 ? 0 : (posKeep > 1 ? 1 : posKeep);
         correction *= posKeep;
      }
      correction = correction < -0.070 ? -0.070 : (correction > 0.052 ? 0.052 : correction);
      out[k] = correction;
      if (keepDzDiagnostics) {
         brightCorr[k] = b < -0.070 ? -0.070 : (b > 0.052 ? 0.052 : b);
         midCorr[k] = m < -0.070 ? -0.070 : (m > 0.052 ? 0.052 : m);
         darkCorr[k] = d < -0.070 ? -0.070 : (d > 0.052 ? 0.052 : d);
         aceAccumulateDzStats(stats, brightWeight[k], midtoneWeight[k], darkWeight[k], correction, suppression);
      }
   }
   acePerfMark(timing, prefix + " detail - Clarity " + profile.uiLabel + " correction final loop", stage);
   cache.clarityDualZoneOptBrightWeight = brightWeight;
   cache.clarityDualZoneOptMidtoneWeight = midtoneWeight;
   cache.clarityDualZoneOptDarkWeight = darkWeight;
   cache.clarityDualZoneOptBrightCorrection = keepDzDiagnostics ? brightCorr : null;
   cache.clarityDualZoneOptMidtoneCorrection = keepDzDiagnostics ? midCorr : null;
   cache.clarityDualZoneOptDarkCorrection = keepDzDiagnostics ? darkCorr : null;
   cache.clarityDualZoneOptCorrection = out;
   cache.clarityDualZoneOptStats = keepDzDiagnostics ? stats : null;
   if (mode === ACE_CLARITY_MODE_DUALZONE_BROADBAND_BOOST_GUARDED) {
      cache.clarityDualZoneBoostBrightWeight = brightWeight;
      cache.clarityDualZoneBoostMidtoneWeight = midtoneWeight;
      cache.clarityDualZoneBoostDarkWeight = darkWeight;
      cache.clarityDualZoneBoostBrightCorrection = keepDzDiagnostics ? brightCorr : null;
      cache.clarityDualZoneBoostMidtoneCorrection = keepDzDiagnostics ? midCorr : null;
      cache.clarityDualZoneBoostDarkCorrection = keepDzDiagnostics ? darkCorr : null;
      cache.clarityDualZoneBoostCorrection = out;
      cache.clarityDualZoneBoostStats = keepDzDiagnostics ? stats : null;
   }
   acePerfMark(timing, prefix + " detail - Clarity " + profile.uiLabel + " correction", correctionStart);
   if (keepDzDiagnostics)
      this.logClarityDualZoneDiagnostics(params, stats, prefix, mode, advanced);
   acePerfMark(timing, prefix + " detail - Clarity " + profile.uiLabel + " total", totalStart);
   return out;
};

MultiScaleContrastEngine.prototype.computeClarityDualZoneOptDelta = function(width, height, params, cache, starAllowedWeight, timing, timingPrefix, advanced) {
   return this.computeClarityDualZoneDeltaWithDetailCandidate(width, height, params, cache, starAllowedWeight, timing, timingPrefix, ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT, advanced);
};

MultiScaleContrastEngine.prototype.computeClarityDualZoneBoostDelta = function(width, height, params, cache, starAllowedWeight, timing, timingPrefix, mode, advanced) {
   return this.computeClarityDualZoneDeltaWithDetailCandidate(width, height, params, cache, starAllowedWeight, timing, timingPrefix, mode || ACE_CLARITY_MODE_DUALZONE_BROADBAND_BOOST_GUARDED, advanced);
};

MultiScaleContrastEngine.prototype.computeClarityDualZoneDeltaWithDetailCandidate = function(width, height, params, cache, starAllowedWeight, timing, timingPrefix, mode, advanced) {
   var prefix = timingPrefix || "Operation";
   var useDetailCandidate = aceIsNativeDetailPreviewPrefix(prefix) &&
      ACE_DETAIL_CLARITY_DZ_DOWNSAMPLE > 2 &&
      Math.max(width, height) >= ACE_DETAIL_CLARITY_DZ_FAST_MIN_EDGE;
   var useFullResCandidate = aceIsFullResolutionOperationPrefix(prefix) &&
      ACE_FULLRES_CLARITY_DZ_ZONE_DOWNSAMPLE > ACE_CLARITY_DUALZONE_FULLRES_ZONE_DOWNSAMPLE &&
      Math.max(width, height) > 2200;
   var useCandidate = useDetailCandidate || useFullResCandidate;
   if (!useCandidate || ACE_DETAIL_CLARITY_DZ_BASELINE_ACTIVE)
      return this.computeClarityDualZoneDelta(width, height, params, cache, starAllowedWeight, timing, prefix, mode, advanced);
   var baseline = null;
   var baselineMs = 0;
   if (ACE_DETAIL_CLARITY_DZ_AB_AUDIT_COUNT < ACE_DETAIL_CLARITY_DZ_AB_AUDIT_LIMIT) {
      ++ACE_DETAIL_CLARITY_DZ_AB_AUDIT_COUNT;
      var baselineStart = Date.now();
      ACE_DETAIL_CLARITY_DZ_BASELINE_ACTIVE = true;
      try {
         baseline = this.computeClarityDualZoneDelta(width, height, params, cache, starAllowedWeight, null, prefix, mode, advanced);
      } finally {
         ACE_DETAIL_CLARITY_DZ_BASELINE_ACTIVE = false;
      }
      baselineMs = Date.now() - baselineStart;
   }
   ACE_DETAIL_CLARITY_DZ_CANDIDATE_ACTIVE = true;
   var candidate = null;
   try {
      candidate = this.computeClarityDualZoneDelta(width, height, params, cache, starAllowedWeight, timing, prefix, mode, advanced);
   } finally {
      ACE_DETAIL_CLARITY_DZ_CANDIDATE_ACTIVE = false;
   }
   if (baseline) {
      aceDevelopmentConsoleWriteLine("[ACE] Detail Clarity DualZone A/B audit | candidate=x" + ACE_DETAIL_CLARITY_DZ_DOWNSAMPLE +
         " size=" + width + "x" + height +
         " baseline_ms=" + baselineMs +
         " candidate_note=displaying_candidate | " +
         aceCompareFloatBuffers("clarityDelta", baseline, candidate) +
         " | watch=bright_nebula_tone,dark_dust_edges,star_halo_rims,thin_nebula_texture");
   }
   return candidate;
};

function aceWeightedBlurMeanFloat(width, height, field, weight, radius) {
   var count = width * height;
   var weighted = new Float32Array(count);
   for (var i = 0; i < count; ++i)
      weighted[i] = field[i] * weight[i];
   var numerator = aceClarityDualZoneBlurFloat(width, height, weighted, radius);
   var denominator = aceClarityDualZoneBlurFloat(width, height, weight, radius);
   var out = new Float32Array(count);
   for (var j = 0; j < count; ++j)
      out[j] = numerator[j] / Math.max(1.0e-5, denominator[j]);
   return out;
}

function aceIsNativeDetailPreviewPrefix(prefix) {
   return String(prefix || "").indexOf("Detail preview") === 0;
}

function aceIsFullResolutionOperationPrefix(prefix) {
   var p = String(prefix || "");
   return p.indexOf("Global adjustment") === 0 || p.indexOf("Local edit ") === 0;
}

function aceClarityDualZoneMeanDownsampleFactor(width, height, radius, prefix) {
   if (ACE_CLARITY_DUALZONE_FULLRES_MEAN_DOWNSAMPLE <= 1)
      return 1;
   if (aceIsNativeDetailPreviewPrefix(prefix)) {
      if (Math.max(width, height) < ACE_DETAIL_CLARITY_DZ_FAST_MIN_EDGE)
         return 1;
      if (radius < 12)
         return 1;
      var detailMax = ACE_DETAIL_CLARITY_DZ_BASELINE_ACTIVE ? 2 :
         (ACE_DETAIL_CLARITY_DZ_CANDIDATE_ACTIVE ? ACE_DETAIL_CLARITY_DZ_DOWNSAMPLE : 2);
      return Math.min(detailMax, ACE_CLARITY_DUALZONE_FULLRES_MEAN_DOWNSAMPLE);
   }
   if (Math.max(width, height) <= 2200)
      return 1;
   if (radius < 12)
      return 1;
   return ACE_CLARITY_DUALZONE_FULLRES_MEAN_DOWNSAMPLE;
}

function aceClarityDualZoneZoneDownsampleFactor(width, height, prefix) {
   if (ACE_CLARITY_DUALZONE_FULLRES_ZONE_DOWNSAMPLE <= 1)
      return 1;
   if (aceIsNativeDetailPreviewPrefix(prefix)) {
      var detailMax = ACE_DETAIL_CLARITY_DZ_BASELINE_ACTIVE ? 2 :
         (ACE_DETAIL_CLARITY_DZ_CANDIDATE_ACTIVE ? ACE_DETAIL_CLARITY_DZ_DOWNSAMPLE : 2);
      return Math.max(width, height) >= ACE_DETAIL_CLARITY_DZ_FAST_MIN_EDGE ? detailMax : 1;
   }
   if (ACE_DETAIL_CLARITY_DZ_CANDIDATE_ACTIVE &&
       aceIsFullResolutionOperationPrefix(prefix) &&
       Math.max(width, height) > 2200)
      return Math.max(ACE_CLARITY_DUALZONE_FULLRES_ZONE_DOWNSAMPLE, ACE_FULLRES_CLARITY_DZ_ZONE_DOWNSAMPLE);
   if (Math.max(width, height) <= 2200)
      return 1;
   return ACE_CLARITY_DUALZONE_FULLRES_ZONE_DOWNSAMPLE;
}

function aceClarityDualZoneMeanBlurFullResolutionFast(width, height, field, radius, prefix) {
   var factor = aceClarityDualZoneMeanDownsampleFactor(width, height, radius, prefix);
   if (factor <= 1)
      return aceClarityDualZoneBlurFloat(width, height, field, radius);
   var small = aceDownsampleFloatAverage(width, height, field, factor);
   var smallRadius = Math.max(1, Math.round(radius / Math.max(1, small.factor)));
   var smallBlur = aceClarityDualZoneBlurFloat(small.width, small.height, small.data, smallRadius);
   return aceUpsampleFloatBilinear(small.width, small.height, smallBlur, width, height);
}

function aceWeightedBlurMeanFloatFullResolutionFast(width, height, field, weight, radius, prefix) {
   var factor = aceClarityDualZoneMeanDownsampleFactor(width, height, radius, prefix);
   if (factor <= 1)
      return aceWeightedBlurMeanFloat(width, height, field, weight, radius);
   var count = width * height;
   var weighted = new Float32Array(count);
   for (var i = 0; i < count; ++i)
      weighted[i] = field[i] * weight[i];
   var smallWeighted = aceDownsampleFloatAverage(width, height, weighted, factor);
   var smallWeight = aceDownsampleFloatAverage(width, height, weight, factor);
   var smallRadius = Math.max(1, Math.round(radius / Math.max(1, smallWeighted.factor)));
   var numerator = aceClarityDualZoneBlurFloat(smallWeighted.width, smallWeighted.height, smallWeighted.data, smallRadius);
   var denominator = aceClarityDualZoneBlurFloat(smallWeight.width, smallWeight.height, smallWeight.data, smallRadius);
   var smallMean = new Float32Array(smallWeighted.width * smallWeighted.height);
   for (var j = 0; j < smallMean.length; ++j)
      smallMean[j] = numerator[j] / Math.max(1.0e-5, denominator[j]);
   return aceUpsampleFloatBilinear(smallWeighted.width, smallWeighted.height, smallMean, width, height);
}

function aceNewDzStats() {
   return {
      count: 0,
      brightMin: 1, brightMax: 0, brightSum: 0,
      midMin: 1, midMax: 0, midSum: 0,
      darkMin: 1, darkMax: 0, darkSum: 0,
      corrMin: 1.0e9, corrMax: -1.0e9, corrSum: 0,
      suppMin: 1, suppMax: 0, suppSum: 0,
      clipCount: 0
   };
}

function aceAccumulateDzStats(s, bright, mid, dark, corr, suppression) {
   ++s.count;
   s.brightMin = Math.min(s.brightMin, bright);
   s.brightMax = Math.max(s.brightMax, bright);
   s.brightSum += bright;
   s.midMin = Math.min(s.midMin, mid);
   s.midMax = Math.max(s.midMax, mid);
   s.midSum += mid;
   s.darkMin = Math.min(s.darkMin, dark);
   s.darkMax = Math.max(s.darkMax, dark);
   s.darkSum += dark;
   s.corrMin = Math.min(s.corrMin, corr);
   s.corrMax = Math.max(s.corrMax, corr);
   s.corrSum += corr;
   s.suppMin = Math.min(s.suppMin, suppression);
   s.suppMax = Math.max(s.suppMax, suppression);
   s.suppSum += suppression;
   if (corr <= -0.0699 || corr >= 0.0519)
      ++s.clipCount;
}

MultiScaleContrastEngine.prototype.logClarityDualZoneDiagnostics = function(params, stats, timingPrefix, mode, advanced) {
   var profile = aceClarityDualZoneProfile(mode, params ? params.clarity : 0, advanced);
   var boostMode = aceIsClarityDualZoneBoostMode(mode);
   if (!profile.diagnosticEnabled || !params || params.clarity <= 0)
      return;
   var nowMs = Date.now();
   if (boostMode) {
      if (nowMs - gClarityDualZoneBoostDiagnosticLastLogMs < profile.diagnosticIntervalMs)
         return;
      gClarityDualZoneBoostDiagnosticLastLogMs = nowMs;
   } else {
      if (nowMs - gClarityDualZoneOptDiagnosticLastLogMs < profile.diagnosticIntervalMs)
         return;
      gClarityDualZoneOptDiagnosticLastLogMs = nowMs;
   }
   var inv = stats.count > 0 ? 1 / stats.count : 0;
   var report = "[ACE] Clarity " + profile.uiLabel + " diagnostics | ace_version=" + ACE_VERSION +
      " clarity_algorithm_id=" + profile.algorithmId +
      " clarity_algorithm_mode=" + profile.mode +
      " active_positive_clarity_path=" + profile.mode +
      " active_negative_clarity_path=" + ACE_CLARITY_ALGORITHM_ID_V4 +
      " candidate_id=" + profile.candidateId +
      " optimized_parameters=midtone_gain:" + profile.midtoneGain +
      ",dark_dust_gain:" + profile.darkDustGain +
      ",bright_zone_gain:" + profile.brightZoneGain +
      ",high_luma_suppression_strength:" + profile.highLumaSuppression +
      ",high_sat_suppression_strength:" + profile.highSatSuppression +
      ",plateau_limiter_strength:" + profile.plateauLimiter +
      " slider_value=" + params.clarity +
      " product_range_philosophy=0-75_normal_practical,75-100_strong_usable,100-150_intentional_overshoot_high_headroom" +
      " high_headroom_scale=" + aceValidationNumber(profile.safeZoneScale, 6) +
      " high_headroom_t=" + aceValidationNumber(profile.highHeadroomT, 6) +
      " midtone_scale=" + aceValidationNumber(profile.midtoneScale, 6) +
      " dark_dust_scale=" + aceValidationNumber(profile.darkDustScale, 6) +
      " bright_zone_weight_min=" + aceValidationNumber(stats.brightMin, 6) +
      " bright_zone_weight_max=" + aceValidationNumber(stats.brightMax, 6) +
      " bright_zone_weight_mean=" + aceValidationNumber(stats.brightSum * inv, 6) +
      " midtone_zone_weight_min=" + aceValidationNumber(stats.midMin, 6) +
      " midtone_zone_weight_max=" + aceValidationNumber(stats.midMax, 6) +
      " midtone_zone_weight_mean=" + aceValidationNumber(stats.midSum * inv, 6) +
      " dark_dust_weight_min=" + aceValidationNumber(stats.darkMin, 6) +
      " dark_dust_weight_max=" + aceValidationNumber(stats.darkMax, 6) +
      " dark_dust_weight_mean=" + aceValidationNumber(stats.darkSum * inv, 6) +
      " correction_min=" + aceValidationNumber(stats.corrMin, 6) +
      " correction_max=" + aceValidationNumber(stats.corrMax, 6) +
      " correction_mean=" + aceValidationNumber(stats.corrSum * inv, 6) +
      " high_luma_suppression_min=0" +
      " high_luma_suppression_max=" + profile.highLumaSuppression +
      " high_luma_suppression_mean=reported_in_combined_suppression" +
      " high_sat_suppression_min=0" +
      " high_sat_suppression_max=" + profile.highSatSuppression +
      " high_sat_suppression_mean=reported_in_combined_suppression" +
      " suppression_min=" + aceValidationNumber(stats.suppMin, 6) +
      " suppression_max=" + aceValidationNumber(stats.suppMax, 6) +
      " suppression_mean=" + aceValidationNumber(stats.suppSum * inv, 6) +
      " saturation_prominence_guard_active=" + (boostMode ? "yes" : "baseline_high_sat_suppression") +
      " saturation_prominence_guard=" + profile.saturationProminenceGuard +
      " saturation_prominence_guard_min=0" +
      " saturation_prominence_guard_max=" + profile.highSatSuppression +
      " saturation_prominence_guard_mean=reported_in_combined_suppression" +
      " clipping_fraction=" + aceValidationNumber(stats.clipCount * inv, 6) +
      " preview_vs_full_render_path=" + (timingPrefix || "Operation") +
      " rollback_switch_status=ACE_CLARITY_MODE_DEFAULT:" + ACE_CLARITY_MODE_DEFAULT +
      ",USE_CLARITY_DUALZONE_OPT_POSITIVE:" + USE_CLARITY_DUALZONE_OPT_POSITIVE +
      ",CLARITY_DUALZONE_OPT_INTERNAL_MODE:" + CLARITY_DUALZONE_OPT_INTERNAL_MODE +
      ",USE_CLARITY_DUALZONE_BOOST_POSITIVE:" + USE_CLARITY_DUALZONE_BOOST_POSITIVE +
      ",CLARITY_DUALZONE_BOOST_INTERNAL_MODE:" + CLARITY_DUALZONE_BOOST_INTERNAL_MODE;
   if (typeof console !== "undefined" && console && typeof console.writeln === "function")
      console.writeln(report);
   else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
      Console.writeln(report);
};

MultiScaleContrastEngine.prototype.applyClarityV5bBenchmarkComposition = function(width, height, output, broadDelta, v4Delta, timing, timingPrefix) {
   if (!broadDelta)
      return output;
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   var totalStart = timingActive ? Date.now() : 0;
   var count = width * height;
   var out = new Float32Array(output.length);
   var sourceMin = 1, sourceMax = 0, sourceSum = 0;
   var v4Min = 1.0e9, v4Max = -1.0e9, v4Sum = 0;
   var broadMin = 1.0e9, broadMax = -1.0e9, broadSum = 0;
   var combinedMin = 1.0e9, combinedMax = -1.0e9, combinedSum = 0;
   var preMin = 1.0e9, preMax = -1.0e9, preSum = 0;
   var postMin = 1, postMax = 0, postSum = 0;
   var clipCount = 0;
   for (var i = 0; i < count; ++i) {
      if ((i & 131071) === 0)
         aceYieldToPixInsight();
      var base = i * 3;
      var r = output[base];
      var g = output[base + 1];
      var b = output[base + 2];
      var l = 0.2126 * r + 0.7152 * g + 0.0722 * b;
      var bd = broadDelta[i];
      var v4 = v4Delta ? v4Delta[i] : 0;
      var combined = v4 + bd;
      var targetL = aceClamp(l + bd, 0, 1);
      var ratio = aceClamp(targetL / Math.max(l, ACE_EPSILON), 0.45, 2.1);
      var preR = r * ratio;
      var preG = g * ratio;
      var preB = b * ratio;
      var outR = aceClamp01(preR);
      var outG = aceClamp01(preG);
      var outB = aceClamp01(preB);
      out[base] = outR;
      out[base + 1] = outG;
      out[base + 2] = outB;
      sourceMin = Math.min(sourceMin, l);
      sourceMax = Math.max(sourceMax, l);
      sourceSum += l;
      v4Min = Math.min(v4Min, v4);
      v4Max = Math.max(v4Max, v4);
      v4Sum += v4;
      broadMin = Math.min(broadMin, bd);
      broadMax = Math.max(broadMax, bd);
      broadSum += bd;
      combinedMin = Math.min(combinedMin, combined);
      combinedMax = Math.max(combinedMax, combined);
      combinedSum += combined;
      preMin = Math.min(preMin, preR, preG, preB);
      preMax = Math.max(preMax, preR, preG, preB);
      preSum += preR + preG + preB;
      postMin = Math.min(postMin, outR, outG, outB);
      postMax = Math.max(postMax, outR, outG, outB);
      postSum += outR + outG + outB;
      if (preR < 0 || preR > 1 || preG < 0 || preG > 1 || preB < 0 || preB > 1)
         ++clipCount;
   }
   var invCount = count > 0 ? 1 / count : 0;
   var invSamples = count > 0 ? 1 / (count * 3) : 0;
   var report = "[ACE] Clarity V5b final composition diagnostics | " +
      "final_composition_mode=post_v4_luminance_delta" +
      " final_composition_formula_id=" + ACE_CLARITY_V5B_FINAL_COMPOSITION_FORMULA_ID +
      " source_range_min=" + aceValidationNumber(sourceMin, 6) +
      " source_range_max=" + aceValidationNumber(sourceMax, 6) +
      " source_range_mean=" + aceValidationNumber(sourceSum * invCount, 6) +
      " v4_delta_min=" + aceValidationNumber(v4Min, 6) +
      " v4_delta_max=" + aceValidationNumber(v4Max, 6) +
      " v4_delta_mean=" + aceValidationNumber(v4Sum * invCount, 6) +
      " scaled_broad_delta_min=" + aceValidationNumber(broadMin, 6) +
      " scaled_broad_delta_max=" + aceValidationNumber(broadMax, 6) +
      " scaled_broad_delta_mean=" + aceValidationNumber(broadSum * invCount, 6) +
      " combined_delta_min=" + aceValidationNumber(combinedMin, 6) +
      " combined_delta_max=" + aceValidationNumber(combinedMax, 6) +
      " combined_delta_mean=" + aceValidationNumber(combinedSum * invCount, 6) +
      " output_before_clipping_min=" + aceValidationNumber(preMin, 6) +
      " output_before_clipping_max=" + aceValidationNumber(preMax, 6) +
      " output_before_clipping_mean=" + aceValidationNumber(preSum * invSamples, 6) +
      " output_after_clipping_min=" + aceValidationNumber(postMin, 6) +
      " output_after_clipping_max=" + aceValidationNumber(postMax, 6) +
      " output_after_clipping_mean=" + aceValidationNumber(postSum * invSamples, 6) +
      " clipping_fraction=" + aceValidationNumber(clipCount * invCount, 6) +
      " rgb_reconstruction_used_source_chroma=yes_v4_output_chroma" +
      " protection_masks_applied_to_combined_delta=no_benchmark_post_v4_composition" +
      " broad_scurve_component_applied_once=yes";
   if (typeof console !== "undefined" && console && typeof console.writeln === "function")
      console.writeln(report);
   else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
      Console.writeln(report);
   acePerfMark(timing, prefix + " detail - Clarity V5b benchmark final composition", totalStart);
   return out;
};

MultiScaleContrastEngine.prototype.hasVisibleEffect = function(params) {
   return !!params && (params.texture !== 0 || params.clarity !== 0 || params.dehaze !== 0);
};

MultiScaleContrastEngine.prototype.applyTextureOnlyFast = function(width, height, rgb, params, cache, protection, textureLayer, textureAmount, textureModeGain, timing, prefix, totalStart) {
   var timingActive = !!(timing && timing.items);
   var stage = timingActive ? Date.now() : 0;
   protection = protection || {};
   var protectSky = protection.protectSky !== false;
   var starAllowedWeight = protection.starAllowedWeight || null;
   var rgbOnlyOutput = !!protection.rgbOnlyOutput;
   var count = width * height;
   var output = new Float32Array(rgb.length);
   var allowedOut = rgbOnlyOutput ? null : new Float32Array(count);
   for (var i = 0; i < count; ++i) {
      if ((i & 131071) === 0)
         aceYieldToPixInsight();
      var l = cache.luminance[i];
      var starAllowed = starAllowedWeight ? starAllowedWeight[i] : 1;
      var starProtection = starAllowedWeight ? aceClamp01(1 - starAllowed) : 0;
      var localStarProtection = aceSmoothStep(ACE_CONTRAST_STAR_PROTECTION_START, ACE_CONTRAST_STAR_PROTECTION_END, starProtection);
      var textureStarAllowed = starAllowedWeight ? aceClamp01(1 - ACE_TEXTURE_STAR_CORE_SUPPRESSION * localStarProtection) : 1;
      var confidence = cache.structureConfidence ? cache.structureConfidence[i] : 1;
      var backgroundAllowed = protectSky && cache.allowedWeight ? cache.allowedWeight[i] : 1;
      var textureValue = textureLayer[i];
      var textureDelta = textureAmount * textureModeGain * textureValue * textureStarAllowed;
      if (protectSky) {
         var scaleBackgroundKeep = aceClamp01(backgroundAllowed);
         var textureArtifactKeep = ACE_TEXTURE_BACKGROUND_ARTIFACT_KEEP_MIN +
            (1 - ACE_TEXTURE_BACKGROUND_ARTIFACT_KEEP_MIN) * scaleBackgroundKeep;
         var textureEdgeOpen = aceSmoothStep(0.010, 0.060, Math.abs(textureValue));
         textureArtifactKeep += (1 - textureArtifactKeep) * ACE_TEXTURE_EDGE_SUPPORT_OPEN * textureEdgeOpen;
         textureDelta *= textureArtifactKeep;
      }
      var enhancedL = l + textureDelta;
      var delta = aceClamp(enhancedL, 0, 1) - l;
      var absTextureDelta = Math.abs(textureDelta);
      var textureShare = absTextureDelta / (absTextureDelta + ACE_EPSILON);
      var effectiveBackgroundAllowed = protectSky ? Math.max(backgroundAllowed, ACE_TEXTURE_BACKGROUND_MIN * textureShare) : backgroundAllowed;
      if (protectSky && textureShare > 0.08) {
         var textureEdgeAllowed = aceSmoothStep(0.008, 0.052, Math.abs(textureValue)) * textureShare;
         effectiveBackgroundAllowed += (1 - effectiveBackgroundAllowed) * ACE_TEXTURE_EDGE_ALLOWED_OPEN * textureEdgeAllowed;
         effectiveBackgroundAllowed = aceClamp01(effectiveBackgroundAllowed);
      }
      var finalStarAllowed = textureStarAllowed;
      var allowed = effectiveBackgroundAllowed * finalStarAllowed;
      if (protectSky) {
         if (delta < 0) {
            var negativeAllow = effectiveBackgroundAllowed;
            negativeAllow *= (1 - 0.35 * (1 - confidence));
            delta *= aceClamp(negativeAllow * finalStarAllowed, 0, 1);
         } else if (delta > 0) {
            delta *= aceClamp(effectiveBackgroundAllowed * (1 - ACE_POSITIVE_BACKGROUND_SUPPRESSION * (1 - confidence)) * finalStarAllowed, 0, 1);
         }
      } else {
         delta *= finalStarAllowed;
      }
      if (allowedOut)
         allowedOut[i] = protectSky ? aceClamp01(allowed) : aceClamp01(finalStarAllowed);
      enhancedL = aceClamp(l + delta, 0, 1);
      var ratio = aceClamp(enhancedL / Math.max(l, ACE_EPSILON), 0.45, 2.2);
      var base = i * 3;
      output[base] = aceClamp01(rgb[base] * ratio);
      output[base + 1] = aceClamp01(rgb[base + 1] * ratio);
      output[base + 2] = aceClamp01(rgb[base + 2] * ratio);
   }
   acePerfMark(timing, prefix + " detail - texture-only fast pixel apply loop", stage);
   cache.lastAllowedWeight = allowedOut;
   acePerfMark(timing, prefix + " detail - engine apply total", totalStart);
   return output;
};

MultiScaleContrastEngine.prototype.apply = function(width, height, rgb, params, layerCache, protection, advanced, timing, timingPrefix) {
   if (!this.hasVisibleEffect(params))
      return new Float32Array(rgb);
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   var totalStart = timingActive ? Date.now() : 0;
   var stage = timingActive ? Date.now() : 0;
   advanced = aceCopyAdvancedParams(advanced);
   var cache = layerCache || this.buildLayerCache(width, height, rgb, advanced, timing, prefix);
   if (layerCache)
      acePerfMark(timing, prefix + " detail - layer cache reuse", stage);
   protection = protection || {};
   var protectSky = protection.protectSky !== false;
   var preventDark = protection.preventDark !== false;
   var starAllowedWeight = protection.starAllowedWeight || null;
   var lassoAllowedWeight = protection.lassoAllowedWeight || null;
   var rgbOnlyOutput = !!protection.rgbOnlyOutput;
   var textureAmount = aceClamp(params.texture / 100, -1.5, 1.5) * ACE_TEXTURE_AMOUNT;
   var clarityAmount = aceClamp(params.clarity / 100, -1.5, 1.5) * ACE_CLARITY_AMOUNT;
   var dehazeMode = aceNormalizeDehazeAppMode(params.dehazeMode);
   var dehazeSignedStrength = this.dehazeStrength(params.dehaze);
   var dehazeAmount = dehazeSignedStrength * ACE_DEHAZE_AMOUNT;
   var dehazePositiveStrength = Math.max(0, dehazeSignedStrength);
   var dehazeNegativeStrength = Math.max(0, -dehazeSignedStrength);
   var localEditActive = !!lassoAllowedWeight;
   var localPositiveDehaze = localEditActive && dehazePositiveStrength > 0;
   var nonVeilCompactProtectFactor = aceAdvancedFactor(advanced, "dehazeCompactProtect");
   var positiveDehazeActive = params.dehaze > 0;
   var clarityPositiveActive = params.clarity > 0;
   var textureMode = aceNormalizeTextureMode(params.textureMode);
   var textureLayer = aceTextureLayerForModeValue(cache, textureMode, params.texture);
   var textureModeGain = textureMode === ACE_TEXTURE_MODE_WIDE60 ? ACE_TEXTURE_WIDE60_GAIN : aceTextureModeStrengthMultiplier(textureMode);
   if (params.texture !== 0 && params.clarity === 0 && params.dehaze === 0 && !lassoAllowedWeight)
      return this.applyTextureOnlyFast(width, height, rgb, params, cache, protection, textureLayer, textureAmount, textureModeGain, timing, prefix, totalStart);
   var clarityMode = aceNormalizeClarityMode(params.clarityMode);
   var clarityV2Active = clarityMode === ACE_CLARITY_MODE_V2 || clarityMode === ACE_CLARITY_MODE_V2_DEPTH;
   var clarityV3Active = aceIsClarityV3Mode(clarityMode);
   var clarityFeatureFitActive = this.isClarityFeatureFitActive(params, clarityMode);
   var clarityDualZoneOptActive = this.isClarityDualZoneOptActive(params, clarityMode);
   var clarityDualZoneBoostActive = this.isClarityDualZoneBoostActive(params, clarityMode);
   var clarityDualZoneActive = clarityDualZoneOptActive || clarityDualZoneBoostActive;
   var clarityV4Active = clarityMode === ACE_CLARITY_MODE_V4 || clarityFeatureFitActive || clarityMode === ACE_CLARITY_MODE_FAILED_V5B_0945_CURRENT_DISABLED || ((clarityMode === ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT || aceIsClarityDualZoneBoostMode(clarityMode)) && params.clarity < 0);
   var clarityV2DepthActive = clarityMode === ACE_CLARITY_MODE_V2_DEPTH && CLARITY_V2_DEPTH_ENABLE && params.clarity !== 0;
   var clarityV5bPositiveActive = USE_CLARITY_V5B_POSITIVE && !FORCE_CLARITY_V4 && CLARITY_V5B_TONE_MODE !== "forced_v4" && clarityV4Active && params.clarity > 0;
   stage = timingActive ? Date.now() : 0;
   var dehazeFields = (params.dehaze !== 0 && ACE_DEHAZE_MODE === "veil") ?
      this.ensureDehazeVeilCache(width, height, rgb, cache, starAllowedWeight, advanced, timing, prefix) : null;
   acePerfMark(timing, prefix + " detail - dehaze field ready", stage);
   acePerfMark(timing, prefix + (clarityV2DepthActive ? " detail - Clarity V2 depth shaping active in apply loop" : " detail - Clarity V2 depth: skipped"), timingActive ? Date.now() : 0);
   stage = timingActive ? Date.now() : 0;
   var clarityV2AntiGlowDelta = clarityV2DepthActive ?
      this.computeClarityV2AntiGlowDelta(width, height, params, cache, starAllowedWeight, protectSky, timing, prefix) :
      null;
   if (!clarityV2DepthActive)
      acePerfMark(timing, prefix + " detail - Clarity V2 anti-glow: skipped", stage);
   stage = timingActive ? Date.now() : 0;
   var clarityV3Delta = clarityV3Active && params.clarity !== 0 ?
      this.computeClarityV3Delta(width, height, params, cache, starAllowedWeight, protectSky, timing, prefix) :
      null;
   if (!clarityV3Active)
      acePerfMark(timing, prefix + " detail - Clarity V3: skipped", stage);
   stage = timingActive ? Date.now() : 0;
   var clarityV4Delta = clarityV4Active && params.clarity !== 0 ?
      this.computeClarityV4Delta(width, height, params, cache, starAllowedWeight, protectSky, timing, prefix) :
      null;
   if (!clarityV4Active)
      acePerfMark(timing, prefix + " detail - Clarity V4: skipped", stage);
   stage = timingActive ? Date.now() : 0;
   var clarityV5bPositiveDelta = clarityV5bPositiveActive ?
      this.computeClarityV5bPositiveDelta(width, height, params, cache, starAllowedWeight, timing, prefix) :
      null;
   if (!clarityV5bPositiveActive)
      acePerfMark(timing, prefix + " detail - Clarity V5b positive: skipped", stage);
   stage = timingActive ? Date.now() : 0;
   var clarityFeatureFitDelta = clarityFeatureFitActive ?
      this.computeClarityFeatureFitGatedDelta(width, height, params, cache, starAllowedWeight, timing, prefix, clarityMode) :
      null;
   if (!clarityFeatureFitActive)
      acePerfMark(timing, prefix + " detail - Clarity +FFitGated: skipped", stage);
   stage = timingActive ? Date.now() : 0;
   var clarityDualZoneOptDelta = clarityDualZoneOptActive ?
      this.computeClarityDualZoneOptDelta(width, height, params, cache, starAllowedWeight, timing, prefix, advanced) :
      null;
   if (!clarityDualZoneOptActive)
      acePerfMark(timing, prefix + " detail - Clarity +DZOpt: skipped", stage);
   stage = timingActive ? Date.now() : 0;
   var clarityDualZoneBoostDelta = clarityDualZoneBoostActive ?
      this.computeClarityDualZoneBoostDelta(width, height, params, cache, starAllowedWeight, timing, prefix, clarityMode, advanced) :
      null;
   if (!clarityDualZoneBoostActive)
      acePerfMark(timing, prefix + " detail - Clarity +DZBoost: skipped", stage);
   if (params.clarity !== 0)
      this.logClarityPathProof(params, clarityMode, clarityV5bPositiveActive, clarityV5bPositiveActive ? this.clarityV5bPositiveScale(params.clarity) : 0, prefix, advanced);
   var veilStrengthFactor = aceAdvancedFactor(advanced, "dehazeVeilStrength");
   var veilConfidenceFactor = aceAdvancedFactor(advanced, "dehazeVeilConfidence");
   var colorRestoreFactor = aceAdvancedFactor(advanced, "dehazeColorRestore");
   var hazeAddBackFactor = aceAdvancedFactor(advanced, "dehazeHazeAddBack");
   var brightProtectFactor = aceAdvancedFactor(advanced, "dehazeHighlightProtect");
   var darkGuardFactor = aceAdvancedFactor(advanced, "darkPatchGuardStrength");
   var count = width * height;
   var output = new Float32Array(rgb.length);
   var allowedOut = rgbOnlyOutput ? null : new Float32Array(count);
   stage = timingActive ? Date.now() : 0;
   var useFullResGlobalRgbFastLoop = rgbOnlyOutput &&
      !lassoAllowedWeight &&
      prefix.indexOf("Global adjustment") === 0 &&
      !clarityV2Active &&
      !clarityV3Active &&
      !clarityV4Active &&
      !clarityV5bPositiveActive &&
      !clarityFeatureFitActive;
   if (useFullResGlobalRgbFastLoop) {
      for (var gi = 0; gi < count; ++gi) {
         if ((gi & 131071) === 0)
            aceYieldToPixInsight();
         var gl = cache.luminance[gi];
         var gStarAllowed = starAllowedWeight ? starAllowedWeight[gi] : 1;
         var gLocalStarProtection = 0;
         var gTextureStarAllowed = 1;
         var gClarityStarAllowed = 1;
         if (starAllowedWeight) {
            var gStarProtection = 1 - gStarAllowed;
            gStarProtection = gStarProtection < 0 ? 0 : (gStarProtection > 1 ? 1 : gStarProtection);
            var gStarT = (gStarProtection - ACE_CONTRAST_STAR_PROTECTION_START) /
               (ACE_CONTRAST_STAR_PROTECTION_END - ACE_CONTRAST_STAR_PROTECTION_START);
            gStarT = gStarT < 0 ? 0 : (gStarT > 1 ? 1 : gStarT);
            gLocalStarProtection = gStarT * gStarT * (3 - 2 * gStarT);
            gTextureStarAllowed = 1 - ACE_TEXTURE_STAR_CORE_SUPPRESSION * gLocalStarProtection;
            gTextureStarAllowed = gTextureStarAllowed < 0 ? 0 : (gTextureStarAllowed > 1 ? 1 : gTextureStarAllowed);
            gClarityStarAllowed = 1 - ACE_CLARITY_STAR_CORE_SUPPRESSION * gLocalStarProtection;
            gClarityStarAllowed = gClarityStarAllowed < 0 ? 0 : (gClarityStarAllowed > 1 ? 1 : gClarityStarAllowed);
         }
         var gConfidence = cache.structureConfidence ? cache.structureConfidence[gi] : 1;
         var gBackgroundAllowed = protectSky && cache.allowedWeight ? cache.allowedWeight[gi] : 1;
         var gTextureValue = textureLayer[gi];
         var gTextureDelta = textureAmount * textureModeGain * gTextureValue * gTextureStarAllowed;
         var gClarityDelta = clarityAmount * cache.clarityLayer[gi] * gClarityStarAllowed;
         if (clarityDualZoneOptDelta) {
            gClarityDelta = clarityDualZoneOptDelta[gi];
            gClarityStarAllowed = starAllowedWeight ?
               1 - CLARITY_V2_STAR_SUPPRESSION * gLocalStarProtection :
               1;
            gClarityStarAllowed = gClarityStarAllowed < 0 ? 0 : (gClarityStarAllowed > 1 ? 1 : gClarityStarAllowed);
         }
         if (clarityDualZoneBoostDelta) {
            gClarityDelta = clarityDualZoneBoostDelta[gi];
            gClarityStarAllowed = starAllowedWeight ?
               1 - CLARITY_V2_STAR_SUPPRESSION * gLocalStarProtection :
               1;
            gClarityStarAllowed = gClarityStarAllowed < 0 ? 0 : (gClarityStarAllowed > 1 ? 1 : gClarityStarAllowed);
         }
         var gDehazeDelta = dehazeAmount * cache.dehazeLayer[gi];
         if (protectSky) {
            var gScaleBackgroundKeep = gBackgroundAllowed < 0 ? 0 : (gBackgroundAllowed > 1 ? 1 : gBackgroundAllowed);
            var gTextureArtifactKeep = ACE_TEXTURE_BACKGROUND_ARTIFACT_KEEP_MIN +
               (1 - ACE_TEXTURE_BACKGROUND_ARTIFACT_KEEP_MIN) * gScaleBackgroundKeep;
            var gTextureEdgeOpen = (Math.abs(gTextureValue) - 0.010) / 0.050;
            gTextureEdgeOpen = gTextureEdgeOpen < 0 ? 0 : (gTextureEdgeOpen > 1 ? 1 : gTextureEdgeOpen);
            gTextureEdgeOpen = gTextureEdgeOpen * gTextureEdgeOpen * (3 - 2 * gTextureEdgeOpen);
            gTextureArtifactKeep += (1 - gTextureArtifactKeep) * ACE_TEXTURE_EDGE_SUPPORT_OPEN * gTextureEdgeOpen;
            var gClarityArtifactKeep = ACE_CLARITY_BACKGROUND_ARTIFACT_KEEP_MIN +
               (1 - ACE_CLARITY_BACKGROUND_ARTIFACT_KEEP_MIN) * gScaleBackgroundKeep;
            gTextureDelta *= gTextureArtifactKeep;
            gClarityDelta *= gClarityArtifactKeep;
         }
         var gDehazePositiveToneKeep = 1;
         if (dehazeFields) {
            var gHighlightAllowed = dehazeFields.highlightAllowed[gi];
            var gCompactAllowed = dehazeFields.compactAllowed[gi];
            if (dehazePositiveStrength > 0) {
               var gVeil = dehazeFields.veil[gi];
               var gDehazeConfidence = dehazeFields.confidence ? dehazeFields.confidence[gi] : 1;
               var gBroadDetail = gl - gVeil;
               var gMidContrast = ACE_DEHAZE_BROAD_CONTRAST_RESTORE *
                  dehazePositiveStrength * veilStrengthFactor * gBroadDetail;
               var gBlackSet = -ACE_DEHAZE_MAX_REDUCTION * dehazePositiveStrength * veilStrengthFactor *
                  (0.12 + 0.58 * gVeil) * (1 - aceSmoothStep(0.20, 0.68, gl));
               var gContrastRestore = ACE_DEHAZE_CONTRAST_RESTORE * dehazePositiveStrength * veilStrengthFactor * gBroadDetail;
               var gHighlightShoulder = -0.13 * dehazePositiveStrength *
                  aceSmoothStep(0.78, 0.995, gl) * Math.max(0, gl - 0.78);
               if (veilConfidenceFactor !== 1) {
                  var gConfidenceGate = veilConfidenceFactor > 1 ?
                     Math.pow(aceClamp01(gDehazeConfidence), veilConfidenceFactor) :
                     1 - Math.pow(1 - aceClamp01(gDehazeConfidence), 1 / Math.max(0.5, veilConfidenceFactor));
                  gBlackSet *= gConfidenceGate;
                  gContrastRestore *= gConfidenceGate;
                  gHighlightShoulder *= gConfidenceGate;
               }
               var gNoLiftT = (gl - ACE_DEHAZE_NO_LIFT_START) / (ACE_DEHAZE_NO_LIFT_END - ACE_DEHAZE_NO_LIFT_START);
               gNoLiftT = gNoLiftT < 0 ? 0 : (gNoLiftT > 1 ? 1 : gNoLiftT);
               var gDehazeNoLiftKeep = 1 - gNoLiftT * gNoLiftT * (3 - 2 * gNoLiftT);
               var gHighToneT = (gl - 0.70) / 0.26;
               gHighToneT = gHighToneT < 0 ? 0 : (gHighToneT > 1 ? 1 : gHighToneT);
               var gHighToneSmooth = gHighToneT * gHighToneT * (3 - 2 * gHighToneT);
               var gBroadHighToneKeep = Math.min(
                  gDehazeNoLiftKeep,
                  1 - ACE_DEHAZE_HIGHLIGHT_GUARD * brightProtectFactor * gHighToneSmooth
               );
               gDehazePositiveToneKeep = Math.max(ACE_DEHAZE_MIN_POSITIVE_KEEP, Math.min(gHighlightAllowed, gCompactAllowed, gBroadHighToneKeep));
               if (gMidContrast > 0)
                  gMidContrast *= gDehazePositiveToneKeep;
               if (gContrastRestore > 0)
                  gContrastRestore *= gDehazePositiveToneKeep;
               gDehazeDelta = gMidContrast + gBlackSet + gContrastRestore + gHighlightShoulder;
               if (dehazeMode !== ACE_DEHAZE_APP_MODE_CURRENT) {
                  var gAppModeProtection = Math.min(gHighlightAllowed, gCompactAllowed, 1 - 0.55 * aceSmoothStep(0.72, 0.98, gl));
                  var gAppModeVeilWeight = (0.65 + 0.45 * aceClamp01(gBackgroundAllowed));
                  var gAppModeTone = gDehazeDelta;
                  var gAppModeVeil = -0.105 * dehazePositiveStrength * gAppModeVeilWeight * aceClamp01(gVeil) * gAppModeProtection;
                  var gAppModeBroad = 0.22 * dehazePositiveStrength * gBroadDetail * gAppModeProtection;
                  if (dehazeMode === ACE_DEHAZE_APP_MODE_GAIN_MATCH)
                     gAppModeTone = gDehazeDelta * 2.25;
                  else if (dehazeMode === ACE_DEHAZE_APP_MODE_TONE_REDISTRIBUTION)
                     gAppModeTone = gDehazeDelta * 1.35 + gAppModeVeil + gAppModeBroad;
                  else if (dehazeMode === ACE_DEHAZE_APP_MODE_TONE_COLOR ||
                           dehazeMode === ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR ||
                           dehazeMode === ACE_DEHAZE_APP_MODE_COLOR_SEPARATION)
                     gAppModeTone = dehazeMode === ACE_DEHAZE_APP_MODE_COLOR_SEPARATION ? gDehazeDelta * 1.2 : gDehazeDelta * 1.35 + gAppModeVeil + gAppModeBroad;
                  if (dehazeMode === ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR)
                     gAppModeTone *= 1 - 0.35 * aceClamp01(gBackgroundAllowed) * aceSmoothStep(0.0, 0.025, Math.abs(cache.dehazeLayer[gi]));
                  gDehazeDelta = gAppModeTone;
               }
               if (gDehazeDelta > 0)
                  gDehazeDelta *= gDehazeNoLiftKeep;
            } else if (dehazeNegativeStrength > 0) {
               gDehazeDelta = 0;
            }
         } else if (positiveDehazeActive && gDehazeDelta > 0) {
            var gHighlightSignal = aceSmoothStep(0.66, 0.96, gl);
            var gCompactSignal = aceSmoothStep(0.006, 0.055, cache.textureLayer[gi]) *
               (1 - aceSmoothStep(0.010, 0.090, Math.abs(cache.dehazeLayer[gi])));
            var gHighlightKeep = 1 - ACE_DEHAZE_HIGHLIGHT_GUARD * gHighlightSignal;
            var gCompactKeep = 1 - ACE_DEHAZE_COMPACT_GUARD * nonVeilCompactProtectFactor * gHighlightSignal * gCompactSignal;
            gDehazeDelta *= Math.max(ACE_DEHAZE_MIN_POSITIVE_KEEP, Math.min(gHighlightKeep, gCompactKeep));
         }
         if (!clarityDualZoneActive && clarityPositiveActive && gClarityDelta > 0) {
            var gClarityBrightKeep = 1 - ACE_CLARITY_HIGHLIGHT_GUARD * brightProtectFactor * aceSmoothStep(0.72, 0.98, gl);
            gClarityDelta *= Math.max(ACE_CLARITY_MIN_POSITIVE_KEEP, gClarityBrightKeep);
         }
         if (preventDark && positiveDehazeActive && gDehazeDelta < 0) {
            var gDehazeRingSignal = aceSmoothStep(0.004, 0.055, -cache.dehazeLayer[gi]);
            if (!dehazeFields)
               gDehazeDelta *= 1 - ACE_DEHAZE_NEGATIVE_GUARD * gDehazeRingSignal;
         }
         var gEnhancedL = gl + gTextureDelta + gClarityDelta + gDehazeDelta;
         var gClampedEnhanced = gEnhancedL < 0 ? 0 : (gEnhancedL > 1 ? 1 : gEnhancedL);
         var gDelta = gClampedEnhanced - gl;
         var gAbsTextureDelta = Math.abs(gTextureDelta);
         var gAbsClarityDelta = Math.abs(gClarityDelta);
         var gAbsDehazeDelta = Math.abs(gDehazeDelta);
         var gAbsAllDelta = gAbsTextureDelta + gAbsClarityDelta + gAbsDehazeDelta + ACE_EPSILON;
         var gTextureShare = gAbsTextureDelta / gAbsAllDelta;
         var gClarityShare = gAbsClarityDelta / gAbsAllDelta;
         var gDehazeShare = gAbsDehazeDelta / gAbsAllDelta;
         var gDehazeBackgroundFloor = dehazeNegativeStrength > 0 ? 0.96 * gDehazeShare : 0.90 * gDehazeShare;
         var gClarityDzDominant = clarityDualZoneActive && gClarityShare > 0.35;
         var gEffectiveBackgroundAllowed = protectSky ? Math.max(gBackgroundAllowed, ACE_TEXTURE_BACKGROUND_MIN * gTextureShare, gDehazeBackgroundFloor) : gBackgroundAllowed;
         if (protectSky && !gClarityDzDominant && gTextureShare > 0.08) {
            var gTextureEdgeT = (Math.abs(gTextureValue) - 0.008) / 0.044;
            gTextureEdgeT = gTextureEdgeT < 0 ? 0 : (gTextureEdgeT > 1 ? 1 : gTextureEdgeT);
            var gTextureEdgeAllowed = gTextureEdgeT * gTextureEdgeT * (3 - 2 * gTextureEdgeT) * gTextureShare;
            gEffectiveBackgroundAllowed += (1 - gEffectiveBackgroundAllowed) * ACE_TEXTURE_EDGE_ALLOWED_OPEN * gTextureEdgeAllowed;
            gEffectiveBackgroundAllowed = gEffectiveBackgroundAllowed < 0 ? 0 : (gEffectiveBackgroundAllowed > 1 ? 1 : gEffectiveBackgroundAllowed);
         }
         var gFinalStarAllowed = 1;
         if (gClarityDzDominant) {
            gEffectiveBackgroundAllowed = 1;
         } else {
            var gDehazeStarAllowed = dehazeFields && gDehazeShare > 0 ? (gStarAllowed * (1 - gDehazeShare) + gDehazeShare) : gStarAllowed;
            var gContrastShare = gTextureShare + gClarityShare;
            var gContrastStarAllowed = gContrastShare > ACE_EPSILON ?
               (gTextureStarAllowed * gTextureShare + gClarityStarAllowed * gClarityShare) / gContrastShare :
               1;
            gFinalStarAllowed = gDehazeShare > 0 ? (gContrastStarAllowed * (1 - gDehazeShare) + gDehazeStarAllowed * gDehazeShare) : gContrastStarAllowed;
         }
         if (protectSky) {
            if (gDelta < 0) {
               var gSafetyConfidence = dehazeFields && gDehazeShare > 0.35 ? 1 : gConfidence;
               var gNegativeAllowFast = gEffectiveBackgroundAllowed * (1 - 0.35 * (1 - gSafetyConfidence)) * gFinalStarAllowed;
               gDelta *= gNegativeAllowFast < 0 ? 0 : (gNegativeAllowFast > 1 ? 1 : gNegativeAllowFast);
            } else if (gDelta > 0) {
               var gPositiveConfidence = dehazeFields && gDehazeShare > 0.35 ? 1 : gConfidence;
               var gPositiveAllowFast = gEffectiveBackgroundAllowed * (1 - ACE_POSITIVE_BACKGROUND_SUPPRESSION * (1 - gPositiveConfidence)) * gFinalStarAllowed;
               gDelta *= gPositiveAllowFast < 0 ? 0 : (gPositiveAllowFast > 1 ? 1 : gPositiveAllowFast);
            }
         } else {
            gDelta *= gFinalStarAllowed;
         }
         gEnhancedL = gl + gDelta;
         gEnhancedL = gEnhancedL < 0 ? 0 : (gEnhancedL > 1 ? 1 : gEnhancedL);
         var gRatio = gEnhancedL / (gl > ACE_EPSILON ? gl : ACE_EPSILON);
         gRatio = gRatio < 0.45 ? 0.45 : (gRatio > 2.2 ? 2.2 : gRatio);
         var gBase = gi * 3;
         var gOutR = rgb[gBase] * gRatio;
         var gOutG = rgb[gBase + 1] * gRatio;
         var gOutB = rgb[gBase + 2] * gRatio;
         gOutR = gOutR < 0 ? 0 : (gOutR > 1 ? 1 : gOutR);
         gOutG = gOutG < 0 ? 0 : (gOutG > 1 ? 1 : gOutG);
         gOutB = gOutB < 0 ? 0 : (gOutB > 1 ? 1 : gOutB);
         if (dehazeFields && dehazePositiveStrength > 0) {
            var gSatHighT = (gl - 0.78) / 0.21;
            gSatHighT = gSatHighT < 0 ? 0 : (gSatHighT > 1 ? 1 : gSatHighT);
            var gSatHighSmooth = gSatHighT * gSatHighT * (3 - 2 * gSatHighT);
            var gSatBoost = ACE_DEHAZE_COLOR_RESTORE * colorRestoreFactor * dehazePositiveStrength *
               gDehazePositiveToneKeep * (1 - 0.55 * gSatHighSmooth);
            if (dehazeMode === ACE_DEHAZE_APP_MODE_TONE_COLOR || dehazeMode === ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR || dehazeMode === ACE_DEHAZE_APP_MODE_COLOR_SEPARATION) {
               var gProtectedColorKeep = dehazeMode === ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR ? (1 - 0.55 * aceSmoothStep(0.72, 0.98, gl)) * (1 - 0.25 * aceClamp01(gBackgroundAllowed)) : 1;
               gSatBoost += 0.42 * dehazePositiveStrength * gProtectedColorKeep * (0.45 + 0.55 * aceSmoothStep(0.03, 0.22, Math.max(Math.abs(gOutR - gOutG), Math.max(Math.abs(gOutG - gOutB), Math.abs(gOutR - gOutB)))));
            }
            gOutR = gEnhancedL + (gOutR - gEnhancedL) * (1 + gSatBoost);
            gOutG = gEnhancedL + (gOutG - gEnhancedL) * (1 + gSatBoost);
            gOutB = gEnhancedL + (gOutB - gEnhancedL) * (1 + gSatBoost);
            gOutR = gOutR < 0 ? 0 : (gOutR > 1 ? 1 : gOutR);
            gOutG = gOutG < 0 ? 0 : (gOutG > 1 ? 1 : gOutG);
            gOutB = gOutB < 0 ? 0 : (gOutB > 1 ? 1 : gOutB);
         } else if (dehazeFields && dehazeNegativeStrength > 0) {
            var gFogShape = 0.74 + 0.26 * (1 - aceSmoothStep(0.70, 0.98, gl));
            var gFogMix = ACE_DEHAZE_NEGATIVE_HAZE_MIX * dehazeNegativeStrength * hazeAddBackFactor * gFogShape;
            var gFogLum = gl + (ACE_DEHAZE_NEGATIVE_HAZE_LIFT + 0.10 * (1 - gl)) *
               dehazeNegativeStrength * hazeAddBackFactor * (1 - aceSmoothStep(0.58, 0.98, gl));
            gFogLum = Math.min(0.82, gFogLum);
            var gFogR = gFogLum * 0.93 + 0.045;
            var gFogG = gFogLum * 0.99 + 0.055;
            var gFogB = gFogLum * 1.08 + 0.070;
            gOutR = gOutR * (1 - gFogMix) + gFogR * gFogMix;
            gOutG = gOutG * (1 - gFogMix) + gFogG * gFogMix;
            gOutB = gOutB * (1 - gFogMix) + gFogB * gFogMix;
            gOutR = gOutR < 0 ? 0 : (gOutR > 1 ? 1 : gOutR);
            gOutG = gOutG < 0 ? 0 : (gOutG > 1 ? 1 : gOutG);
            gOutB = gOutB < 0 ? 0 : (gOutB > 1 ? 1 : gOutB);
            var gHazeChroma = ACE_DEHAZE_NEGATIVE_CHROMA_VEIL * dehazeNegativeStrength * hazeAddBackFactor;
            var gHazeLuma = 0.2126 * gOutR + 0.7152 * gOutG + 0.0722 * gOutB;
            gOutR = gHazeLuma + (gOutR - gHazeLuma) * (1 - gHazeChroma);
            gOutG = gHazeLuma + (gOutG - gHazeLuma) * (1 - gHazeChroma);
            gOutB = gHazeLuma + (gOutB - gHazeLuma) * (1 - gHazeChroma);
            gOutR = gOutR < 0 ? 0 : (gOutR > 1 ? 1 : gOutR);
            gOutG = gOutG < 0 ? 0 : (gOutG > 1 ? 1 : gOutG);
            gOutB = gOutB < 0 ? 0 : (gOutB > 1 ? 1 : gOutB);
         }
         output[gBase] = gOutR;
         output[gBase + 1] = gOutG;
         output[gBase + 2] = gOutB;
      }
      acePerfMark(timing, prefix + " detail - fullres global RGB fast pixel apply loop", stage);
      cache.lastAllowedWeight = null;
      acePerfMark(timing, prefix + " detail - engine apply total", totalStart);
      return output;
   }
   for (var i = 0; i < count; ++i) {
      if ((i & 131071) === 0)
         aceYieldToPixInsight();
      var l = cache.luminance[i];
      var starAllowed = starAllowedWeight ? starAllowedWeight[i] : 1;
      var starProtection = starAllowedWeight ? aceClamp01(1 - starAllowed) : 0;
      var localStarProtection = aceSmoothStep(ACE_CONTRAST_STAR_PROTECTION_START, ACE_CONTRAST_STAR_PROTECTION_END, starProtection);
      var textureStarAllowed = starAllowedWeight ? aceClamp01(1 - ACE_TEXTURE_STAR_CORE_SUPPRESSION * localStarProtection) : 1;
      var clarityStarAllowed = starAllowedWeight ? aceClamp01(1 - ACE_CLARITY_STAR_CORE_SUPPRESSION * localStarProtection) : 1;
      var confidence = cache.structureConfidence ? cache.structureConfidence[i] : 1;
      var localSmallStarSignal = lassoAllowedWeight ?
         aceSmoothStep(0.006, 0.040, Math.max(0, cache.textureLayer[i])) *
            aceSmoothStep(0.16, 0.82, l) :
         0;
      var backgroundAllowed = protectSky && cache.allowedWeight ? cache.allowedWeight[i] : 1;
      var textureDelta = textureAmount * textureModeGain * textureLayer[i] * textureStarAllowed;
      var clarityDelta = clarityAmount * cache.clarityLayer[i] * clarityStarAllowed;
      if (clarityV3Delta) {
         clarityDelta = clarityV3Delta[i];
         clarityStarAllowed = starAllowedWeight ?
            aceClamp01(1 - CLARITY_V2_STAR_SUPPRESSION * localStarProtection) :
            1;
      }
      if (clarityV4Delta) {
         clarityDelta = clarityV4Delta[i];
         clarityStarAllowed = starAllowedWeight ?
            aceClamp01(1 - CLARITY_V2_STAR_SUPPRESSION * localStarProtection) :
            1;
      }
      if (clarityDualZoneOptDelta) {
         clarityDelta = clarityDualZoneOptDelta[i];
         clarityStarAllowed = starAllowedWeight ?
            aceClamp01(1 - CLARITY_V2_STAR_SUPPRESSION * localStarProtection) :
            1;
      }
      if (clarityDualZoneBoostDelta) {
         clarityDelta = clarityDualZoneBoostDelta[i];
         clarityStarAllowed = starAllowedWeight ?
            aceClamp01(1 - CLARITY_V2_STAR_SUPPRESSION * localStarProtection) :
            1;
      }
      if (clarityV2Active && params.clarity !== 0) {
         var clarityV2AllowedWeight = cache.clarityV2Allowed ? cache.clarityV2Allowed[i] : 1;
         var clarityV2StarAllowed = starAllowedWeight ?
            aceClamp01(1 - CLARITY_V2_STAR_SUPPRESSION * localStarProtection) :
            1;
         var clarityV2RawDelta = clarityAmount *
            (cache.clarityV2Layer ? cache.clarityV2Layer[i] : cache.clarityLayer[i]) *
            clarityV2StarAllowed *
            clarityV2AllowedWeight;
         var localFloorForClarity = cache.localFloor ? cache.localFloor[i] : 0;
         var upwardRoom = Math.max(0.002, (1 - l) * 0.55);
         var downwardRoom = Math.max(0.002, (l - localFloorForClarity + 0.025) * 0.72);
         var clarityV2Limit = Math.min(CLARITY_V2_MAX_DELTA, clarityV2RawDelta >= 0 ? upwardRoom : downwardRoom);
         var baseClarityDelta = aceSoftKneeLimitSigned(clarityV2RawDelta, clarityV2Limit, CLARITY_V2_SOFT_KNEE);
         var depthClarityDelta = 0;
         if (clarityV2AntiGlowDelta) {
            clarityDelta = clarityV2AntiGlowDelta[i];
         } else {
            if (clarityV2DepthActive) {
               var localDeviation = cache.clarityV2LocalDeviation ? cache.clarityV2LocalDeviation[i] : (cache.clarityV2Layer ? cache.clarityV2Layer[i] : cache.clarityLayer[i]);
               var brightSide = Math.max(0, localDeviation);
               var darkSide = Math.max(0, -localDeviation);
               var depthMidtone = cache.clarityV2MidtoneWeight ? cache.clarityV2MidtoneWeight[i] : aceSmoothStep(CLARITY_V2_SHADOW_START, CLARITY_V2_MID_LOW, l) * (1 - aceSmoothStep(CLARITY_V2_HIGH_START, CLARITY_V2_HIGHLIGHT_END, l));
               var depthActivity = cache.clarityV2ActivityWeight ? cache.clarityV2ActivityWeight[i] : aceSmoothStep(CLARITY_V2_ACTIVITY_LOW_START, CLARITY_V2_ACTIVITY_LOW_END, Math.abs(cache.clarityV2Layer ? cache.clarityV2Layer[i] : cache.clarityLayer[i]));
               var highlightDepthKeep = 1 - CLARITY_V2_HIGHLIGHT_SUPPRESSION * aceSmoothStep(CLARITY_V2_HIGH_START, CLARITY_V2_HIGHLIGHT_END, l);
               var depthWeight =
                  Math.pow(aceClamp01(depthMidtone), CLARITY_V2_DEPTH_MIDTONE_POWER) *
                  Math.pow(aceClamp01(depthActivity), CLARITY_V2_DEPTH_ACTIVITY_POWER) *
                  aceClamp01(backgroundAllowed) *
                  aceClamp01(confidence) *
                  aceClamp01(clarityV2StarAllowed) *
                  aceClamp01(highlightDepthKeep);
               var brightSideAllowed =
                  depthWeight *
                  Math.pow(aceClamp01(depthActivity), CLARITY_V2_DEPTH_POSITIVE_STRUCTURE_POWER) *
                  (1 - aceSmoothStep(CLARITY_V2_DEPTH_BRIGHT_START, CLARITY_V2_DEPTH_BRIGHT_END, l)) *
                  aceClamp01(highlightDepthKeep);
               var negativeDepthDelta = -CLARITY_V2_DEPTH_SHADOW_GAIN * darkSide * depthWeight;
               var positiveDepthDelta = CLARITY_V2_DEPTH_HIGHLIGHT_GAIN * brightSide * brightSideAllowed;
               var depthRawDelta = clarityAmount * (negativeDepthDelta + positiveDepthDelta);
               var depthUpRoom = Math.max(0.002, (1 - l) * 0.38);
               var depthDownRoom = Math.max(0.002, (l - localFloorForClarity + 0.020) * 0.58);
               var depthLimit = Math.min(CLARITY_V2_DEPTH_MAX_DELTA, depthRawDelta >= 0 ? depthUpRoom : depthDownRoom);
               depthClarityDelta = aceSoftKneeLimitSigned(depthRawDelta, depthLimit, CLARITY_V2_DEPTH_SOFT_KNEE);
            }
            clarityDelta = clarityV2DepthActive ?
               baseClarityDelta * CLARITY_V2_BASE_MIX + depthClarityDelta * CLARITY_V2_DEPTH_MIX :
               baseClarityDelta;
            if (clarityV2DepthActive && clarityDelta < 0 && cache.localFloor) {
               var protectedFloor = cache.localFloor[i] + CLARITY_V2_DEPTH_FLOOR_MARGIN;
               var floorRisk = aceSmoothStep(0.002, CLARITY_V2_DEPTH_FLOOR_SOFTNESS, protectedFloor - (l + clarityDelta));
               if (floorRisk > 0)
                  clarityDelta += (protectedFloor - (l + clarityDelta)) * floorRisk * 0.70;
            }
         }
         clarityStarAllowed = clarityV2StarAllowed;
      }
      var dehazeDelta = dehazeAmount * cache.dehazeLayer[i];
      if (protectSky) {
         var scaleBackgroundKeep = aceClamp01(backgroundAllowed);
         var textureArtifactKeep = ACE_TEXTURE_BACKGROUND_ARTIFACT_KEEP_MIN +
            (1 - ACE_TEXTURE_BACKGROUND_ARTIFACT_KEEP_MIN) * scaleBackgroundKeep;
         var textureEdgeOpen = aceSmoothStep(0.010, 0.060, Math.abs(textureLayer[i]));
         textureArtifactKeep += (1 - textureArtifactKeep) * ACE_TEXTURE_EDGE_SUPPORT_OPEN * textureEdgeOpen;
         var clarityBackgroundKeepMin = clarityV2Active ? CLARITY_V2_BACKGROUND_KEEP_MIN : ACE_CLARITY_BACKGROUND_ARTIFACT_KEEP_MIN;
         var clarityArtifactKeep = clarityBackgroundKeepMin +
            (1 - clarityBackgroundKeepMin) * scaleBackgroundKeep;
         textureDelta *= textureArtifactKeep;
         if (!clarityV3Active && !clarityV4Active)
            clarityDelta *= clarityArtifactKeep;
      }
      var dehazeConfidence = 1;
      var highlightAllowed = 1;
      var compactAllowed = 1;
      var dehazePositiveToneKeep = 1;
      if (dehazeFields) {
         highlightAllowed = dehazeFields.highlightAllowed[i];
         compactAllowed = dehazeFields.compactAllowed[i];
         if (dehazePositiveStrength > 0) {
            var veil = dehazeFields.veil[i];
            dehazeConfidence = dehazeFields.confidence ? dehazeFields.confidence[i] : 1;
            var broadDetail = l - veil;
            var midContrast = ACE_DEHAZE_BROAD_CONTRAST_RESTORE *
               dehazePositiveStrength * veilStrengthFactor * broadDetail;
            var blackSet = -ACE_DEHAZE_MAX_REDUCTION * dehazePositiveStrength * veilStrengthFactor *
               (0.12 + 0.58 * veil) * (1 - aceSmoothStep(0.20, 0.68, l));
            var contrastRestore = ACE_DEHAZE_CONTRAST_RESTORE * dehazePositiveStrength * veilStrengthFactor * broadDetail;
            var highlightShoulder = -0.13 * dehazePositiveStrength *
               aceSmoothStep(0.78, 0.995, l) * Math.max(0, l - 0.78);
            if (localPositiveDehaze) {
               var upperTone = aceSmoothStep(0.16, 0.72, l);
               var veilTone = aceSmoothStep(0.010, 0.120, Math.max(0, veil - (cache.localFloor ? cache.localFloor[i] : 0)));
               var localStarKeep = Math.max(0.88, Math.min(
                  Math.pow(starAllowed, 0.85),
                  Math.max(0.92, compactAllowed),
                  Math.max(0.90, highlightAllowed),
                  1 - 0.35 * ACE_DEHAZE_LOCAL_SMALL_STAR_GUARD * localSmallStarSignal
               ));
               blackSet *= ACE_DEHAZE_LOCAL_BLACK_SCALE * 1.55;
               midContrast *= ACE_DEHAZE_LOCAL_MID_SCALE * 1.45 * (0.50 + 0.50 * upperTone);
               contrastRestore *= ACE_DEHAZE_LOCAL_RESTORE_SCALE * 1.45 * (0.40 + 0.60 * Math.max(upperTone, veilTone));
               highlightShoulder *= ACE_DEHAZE_LOCAL_HIGHLIGHT_SCALE * 1.20;
               midContrast *= aceClamp01(localStarKeep);
               contrastRestore *= aceClamp01(localStarKeep);
               highlightShoulder *= aceClamp01(localStarKeep);
            }
            if (veilConfidenceFactor !== 1) {
               var confidenceGate = veilConfidenceFactor > 1 ?
                  Math.pow(aceClamp01(dehazeConfidence), veilConfidenceFactor) :
                  1 - Math.pow(1 - aceClamp01(dehazeConfidence), 1 / Math.max(0.5, veilConfidenceFactor));
               blackSet *= confidenceGate;
               contrastRestore *= confidenceGate;
               highlightShoulder *= confidenceGate;
            }
            if (!localPositiveDehaze) {
               var dehazeNoLiftKeep = 1 - aceSmoothStep(ACE_DEHAZE_NO_LIFT_START, ACE_DEHAZE_NO_LIFT_END, l);
               var broadHighToneKeep = Math.min(
                  dehazeNoLiftKeep,
                  1 - ACE_DEHAZE_HIGHLIGHT_GUARD * brightProtectFactor * aceSmoothStep(0.70, 0.96, l)
               );
               dehazePositiveToneKeep = Math.max(ACE_DEHAZE_MIN_POSITIVE_KEEP, Math.min(highlightAllowed, compactAllowed, broadHighToneKeep));
               if (midContrast > 0)
                  midContrast *= dehazePositiveToneKeep;
               if (contrastRestore > 0)
                  contrastRestore *= dehazePositiveToneKeep;
            } else {
               dehazePositiveToneKeep = Math.max(0.82, Math.max(ACE_DEHAZE_MIN_POSITIVE_KEEP, Math.min(highlightAllowed, compactAllowed)));
            }
            dehazeDelta = midContrast + blackSet + contrastRestore + highlightShoulder;
            if (!localPositiveDehaze && dehazeMode !== ACE_DEHAZE_APP_MODE_CURRENT) {
               var appModeProtection = Math.min(highlightAllowed, compactAllowed, 1 - 0.55 * aceSmoothStep(0.72, 0.98, l));
               var appModeVeilWeight = (0.65 + 0.45 * aceClamp01(backgroundAllowed));
               var appModeTone = dehazeDelta;
               var appModeVeil = -0.105 * dehazePositiveStrength * appModeVeilWeight * aceClamp01(veil) * appModeProtection;
               var appModeBroad = 0.22 * dehazePositiveStrength * broadDetail * appModeProtection;
               if (dehazeMode === ACE_DEHAZE_APP_MODE_GAIN_MATCH)
                  appModeTone = dehazeDelta * 2.25;
               else if (dehazeMode === ACE_DEHAZE_APP_MODE_TONE_REDISTRIBUTION)
                  appModeTone = dehazeDelta * 1.35 + appModeVeil + appModeBroad;
               else if (dehazeMode === ACE_DEHAZE_APP_MODE_TONE_COLOR ||
                        dehazeMode === ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR ||
                        dehazeMode === ACE_DEHAZE_APP_MODE_COLOR_SEPARATION)
                  appModeTone = dehazeMode === ACE_DEHAZE_APP_MODE_COLOR_SEPARATION ? dehazeDelta * 1.2 : dehazeDelta * 1.35 + appModeVeil + appModeBroad;
               if (dehazeMode === ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR)
                  appModeTone *= 1 - 0.35 * aceClamp01(backgroundAllowed) * aceSmoothStep(0.0, 0.025, Math.abs(cache.dehazeLayer[i]));
               dehazeDelta = appModeTone;
            }
            if (!localPositiveDehaze && dehazeDelta > 0)
               dehazeDelta *= 1 - aceSmoothStep(ACE_DEHAZE_NO_LIFT_START, ACE_DEHAZE_NO_LIFT_END, l);
         } else if (dehazeNegativeStrength > 0) {
            // Negative Dehaze simulates a broad fog veil. Keep it out of the
            // local luminance-delta safety path so masks cannot stamp artifacts
            // into what should be a smooth global tone/color blend.
            dehazeDelta = 0;
         }
      } else if (positiveDehazeActive && dehazeDelta > 0) {
         // Dehaze is broad contrast; do not let it behave like a star-core brightener.
         var highlightSignal = aceSmoothStep(0.66, 0.96, l);
         var compactSignal = aceSmoothStep(0.006, 0.055, cache.textureLayer[i]) *
            (1 - aceSmoothStep(0.010, 0.090, Math.abs(cache.dehazeLayer[i])));
         var highlightKeep = 1 - ACE_DEHAZE_HIGHLIGHT_GUARD * highlightSignal;
         var compactKeep = 1 - ACE_DEHAZE_COMPACT_GUARD * nonVeilCompactProtectFactor * highlightSignal * compactSignal;
         dehazeDelta *= Math.max(ACE_DEHAZE_MIN_POSITIVE_KEEP, Math.min(highlightKeep, compactKeep));
      }
      if (lassoAllowedWeight && clarityPositiveActive && clarityDelta !== 0) {
         var localClarityStarKeep = Math.min(
            Math.pow(starAllowed, ACE_CLARITY_LOCAL_STAR_POWER),
            1 - ACE_CLARITY_LOCAL_SMALL_STAR_GUARD * localSmallStarSignal
         );
         if (clarityV4Active || clarityFeatureFitActive)
            localClarityStarKeep = Math.max(0.84, localClarityStarKeep);
         if (clarityDualZoneActive)
            localClarityStarKeep = 1;
         clarityDelta *= aceClamp01(localClarityStarKeep);
         if (clarityDualZoneActive)
            clarityDelta *= 2.15;
         else if (clarityV4Active || clarityFeatureFitActive)
            clarityDelta *= 1.55;
      }
      if (!clarityV2Active && !clarityV3Active && !clarityV4Active && !clarityDualZoneActive && clarityPositiveActive && clarityDelta > 0) {
         var clarityBrightKeep = 1 - ACE_CLARITY_HIGHLIGHT_GUARD * brightProtectFactor * aceSmoothStep(0.72, 0.98, l);
         clarityDelta *= Math.max(ACE_CLARITY_MIN_POSITIVE_KEEP, clarityBrightKeep);
      }
      if (preventDark && localEditActive && clarityPositiveActive && clarityDelta < 0) {
         var clarityCandidate = l + clarityDelta;
         var clarityFloorRisk = 0;
         if (cache.localFloor) {
            var clarityFloorLimit = cache.localFloor[i] - ACE_LOCAL_FLOOR_TOLERANCE * 0.55;
            clarityFloorRisk = aceSmoothStep(0.002, 0.030, clarityFloorLimit - clarityCandidate);
         }
         var clarityRingSignal = aceSmoothStep(0.012, 0.060, -((clarityV2Active || clarityV3Active || clarityV4Active) && cache.clarityV2Layer ? cache.clarityV2Layer[i] : cache.clarityLayer[i]));
         var clarityNegativeProtect = clarityFloorRisk * clarityRingSignal;
         var clarityNegativeKeep = 1 - ACE_CLARITY_NEGATIVE_GUARD * darkGuardFactor * clarityNegativeProtect;
         clarityDelta *= Math.max(ACE_CLARITY_NEGATIVE_MIN_KEEP, clarityNegativeKeep);
      }
      if (preventDark && positiveDehazeActive && dehazeDelta < 0) {
         var dehazeRingSignal = aceSmoothStep(0.004, 0.055, -cache.dehazeLayer[i]);
         if (!dehazeFields)
            dehazeDelta *= 1 - ACE_DEHAZE_NEGATIVE_GUARD * dehazeRingSignal;
      }
      if (protectSky && localPositiveDehaze && dehazeDelta < 0) {
         var localBackgroundKeep = Math.pow(aceClamp01(backgroundAllowed), ACE_DEHAZE_LOCAL_BACKGROUND_POWER);
         localBackgroundKeep *= ACE_DEHAZE_LOCAL_CONFIDENCE_KEEP + (1 - ACE_DEHAZE_LOCAL_CONFIDENCE_KEEP) * confidence;
         localBackgroundKeep *= aceSmoothStep(0.45, 0.86, backgroundAllowed);
         localBackgroundKeep *= aceSmoothStep(0.42, 0.82, confidence);
         dehazeDelta *= aceClamp01(localBackgroundKeep);
      }
      var enhancedL = l + textureDelta + clarityDelta + dehazeDelta;
      var delta = aceClamp(enhancedL, 0, 1) - l;
      var lassoAllowed = lassoAllowedWeight ? lassoAllowedWeight[i] : 1;
      var absTextureDelta = Math.abs(textureDelta);
      var absClarityDelta = Math.abs(clarityDelta);
      var absAllDelta = absTextureDelta + absClarityDelta + Math.abs(dehazeDelta) + ACE_EPSILON;
      var textureShare = absTextureDelta / absAllDelta;
      var clarityShare = absClarityDelta / absAllDelta;
      var dehazeShare = Math.abs(dehazeDelta) / absAllDelta;
      var dehazeBackgroundFloor = localPositiveDehaze ? 0 : (dehazeNegativeStrength > 0 ? 0.96 * dehazeShare : 0.90 * dehazeShare);
      var effectiveBackgroundAllowed = protectSky ? Math.max(backgroundAllowed, ACE_TEXTURE_BACKGROUND_MIN * textureShare, dehazeBackgroundFloor) : backgroundAllowed;
      if (protectSky && textureShare > 0.08) {
         var textureEdgeAllowed = aceSmoothStep(0.008, 0.052, Math.abs(textureLayer[i])) * textureShare;
         effectiveBackgroundAllowed += (1 - effectiveBackgroundAllowed) * ACE_TEXTURE_EDGE_ALLOWED_OPEN * textureEdgeAllowed;
         effectiveBackgroundAllowed = aceClamp01(effectiveBackgroundAllowed);
      }
      var dehazeStarAllowed = localPositiveDehaze ? starAllowed :
         (dehazeFields && dehazeShare > 0 ? (starAllowed * (1 - dehazeShare) + dehazeShare) : starAllowed);
      var contrastShare = textureShare + clarityShare;
      var contrastStarAllowed = contrastShare > ACE_EPSILON ?
         (textureStarAllowed * textureShare + clarityStarAllowed * clarityShare) / contrastShare :
         1;
      var finalStarAllowed = dehazeShare > 0 ? (contrastStarAllowed * (1 - dehazeShare) + dehazeStarAllowed * dehazeShare) : contrastStarAllowed;
      if ((clarityV3Active || clarityV4Active || clarityDualZoneActive || clarityFeatureFitActive) && clarityShare > 0.35) {
         effectiveBackgroundAllowed = 1;
         finalStarAllowed = 1;
      }
      var allowed = 1;
      if (allowedOut) {
         allowed = effectiveBackgroundAllowed * finalStarAllowed;
         if (dehazeFields && dehazeShare > 0) {
            var dehazeToneAllowed = dehazeDelta > 0 ? dehazePositiveToneKeep : 1;
            allowed *= (1 - dehazeShare) + dehazeShare * dehazeToneAllowed;
         }
         allowed *= lassoAllowed;
      }
      if (protectSky) {
         if (delta < 0) {
            var negativeAllow = effectiveBackgroundAllowed;
            var safetyConfidence = dehazeFields && dehazeShare > 0.35 && !localPositiveDehaze ? 1 : confidence;
            if (preventDark && localEditActive)
               negativeAllow *= (1 - ACE_DARK_PATCH_SUPPRESSION * darkGuardFactor * (1 - safetyConfidence));
            else
               negativeAllow *= (1 - 0.35 * (1 - safetyConfidence));
            delta *= aceClamp(negativeAllow * finalStarAllowed * lassoAllowed, 0, 1);
         } else if (delta > 0) {
            var positiveConfidence = dehazeFields && dehazeShare > 0.35 ? 1 : confidence;
            if (localEditActive && clarityPositiveActive && clarityShare > 0.35 && (clarityDualZoneActive || clarityV4Active || clarityFeatureFitActive))
               positiveConfidence = 1;
            delta *= aceClamp(effectiveBackgroundAllowed * (1 - ACE_POSITIVE_BACKGROUND_SUPPRESSION * (1 - positiveConfidence)) * finalStarAllowed * lassoAllowed, 0, 1);
         }
         var provisional = l + delta;
      }
      if (!protectSky)
         delta *= finalStarAllowed * lassoAllowed;
      if (preventDark && localEditActive && cache.localFloor && delta < 0) {
         var guarded = l + delta;
         var floorLimit = localPositiveDehaze ?
            Math.min(l, cache.localFloor[i] + ACE_DEHAZE_LOCAL_FLOOR_BUFFER) :
            cache.localFloor[i] - ACE_LOCAL_FLOOR_TOLERANCE * 0.30;
         if (guarded < floorLimit) {
            var floorBlend = localPositiveDehaze ? 1 : (protectSky ? Math.max(0.24, aceClamp01(1 - confidence)) : 0.48);
            guarded = localPositiveDehaze ? floorLimit : guarded * (1 - floorBlend) + floorLimit * floorBlend;
            delta = guarded - l;
         }
      }
      if (allowedOut) {
         allowedOut[i] = protectSky ? aceClamp01(allowed) : 1;
         if (!protectSky)
            allowedOut[i] = aceClamp01(finalStarAllowed * lassoAllowed);
      }
      enhancedL = aceClamp(l + delta, 0, 1);
      var ratio = aceClamp(enhancedL / Math.max(l, ACE_EPSILON), 0.45, 2.2);
      var base = i * 3;
      var outR = aceClamp01(rgb[base] * ratio);
      var outG = aceClamp01(rgb[base + 1] * ratio);
      var outB = aceClamp01(rgb[base + 2] * ratio);
      if (dehazeFields && dehazePositiveStrength > 0) {
         var satBoost = ACE_DEHAZE_COLOR_RESTORE * colorRestoreFactor * dehazePositiveStrength *
            lassoAllowed * dehazePositiveToneKeep * (1 - 0.55 * aceSmoothStep(0.78, 0.99, l));
         if (dehazeMode === ACE_DEHAZE_APP_MODE_TONE_COLOR || dehazeMode === ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR || dehazeMode === ACE_DEHAZE_APP_MODE_COLOR_SEPARATION) {
            var protectedColorKeep = dehazeMode === ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR ? (1 - 0.55 * aceSmoothStep(0.72, 0.98, l)) * (1 - 0.25 * aceClamp01(backgroundAllowed)) : 1;
            satBoost += 0.42 * dehazePositiveStrength * protectedColorKeep * (0.45 + 0.55 * aceSmoothStep(0.03, 0.22, Math.max(Math.abs(outR - outG), Math.max(Math.abs(outG - outB), Math.abs(outR - outB)))));
         }
         outR = aceClamp01(enhancedL + (outR - enhancedL) * (1 + satBoost));
         outG = aceClamp01(enhancedL + (outG - enhancedL) * (1 + satBoost));
         outB = aceClamp01(enhancedL + (outB - enhancedL) * (1 + satBoost));
      } else if (dehazeFields && dehazeNegativeStrength > 0) {
         var fogShape = 0.74 + 0.26 * (1 - aceSmoothStep(0.70, 0.98, l));
         var fogMix = ACE_DEHAZE_NEGATIVE_HAZE_MIX * dehazeNegativeStrength * hazeAddBackFactor *
            fogShape * lassoAllowed;
         var fogLum = l + (ACE_DEHAZE_NEGATIVE_HAZE_LIFT + 0.10 * (1 - l)) *
            dehazeNegativeStrength * hazeAddBackFactor * (1 - aceSmoothStep(0.58, 0.98, l));
         fogLum = Math.min(0.82, fogLum);
         var fogR = fogLum * 0.93 + 0.045;
         var fogG = fogLum * 0.99 + 0.055;
         var fogB = fogLum * 1.08 + 0.070;
         outR = aceClamp01(outR * (1 - fogMix) + fogR * fogMix);
         outG = aceClamp01(outG * (1 - fogMix) + fogG * fogMix);
         outB = aceClamp01(outB * (1 - fogMix) + fogB * fogMix);
         var hazeChroma = ACE_DEHAZE_NEGATIVE_CHROMA_VEIL * dehazeNegativeStrength * hazeAddBackFactor *
            lassoAllowed;
         var hazeLuma = 0.2126 * outR + 0.7152 * outG + 0.0722 * outB;
         outR = aceClamp01(hazeLuma + (outR - hazeLuma) * (1 - hazeChroma));
         outG = aceClamp01(hazeLuma + (outG - hazeLuma) * (1 - hazeChroma));
         outB = aceClamp01(hazeLuma + (outB - hazeLuma) * (1 - hazeChroma));
      }
      output[base] = outR;
      output[base + 1] = outG;
      output[base + 2] = outB;
   }
   acePerfMark(timing, prefix + " detail - pixel apply loop", stage);
   if (clarityV5bPositiveDelta)
      output = this.applyClarityV5bBenchmarkComposition(width, height, output, clarityV5bPositiveDelta, clarityV4Delta, timing, prefix);
   if (clarityFeatureFitDelta)
      output = this.applyClarityFeatureFitBenchmarkComposition(width, height, output, clarityFeatureFitDelta, timing, prefix);
   cache.lastAllowedWeight = allowedOut;
   acePerfMark(timing, prefix + " detail - engine apply total", totalStart);
   return output;
};

function PreviewProcessor() {
   this.engine = new MultiScaleContrastEngine;
}

PreviewProcessor.prototype.getStarProtectionMaps = function(previewData, options, timing, timingPrefix) {
   if (!previewData || !previewData.rgb)
      return null;
   var prefix = timingPrefix || "Operation";
   var timingActive = !!(timing && timing.items);
   var totalStart = timingActive ? Date.now() : 0;
   options = options || {};
   var advanced = aceCopyAdvancedParams(options.advanced);
   var starsMode = options.inputType === "stars";
   var active = starsMode && options.protectStars !== false;
   var fastFullRes = !!options.fastFullResolutionStarMask;
   var fastStarMaps = fastFullRes || ACE_USE_FAST_STAR_PREVIEW;
   var key = active ? ("stars:" + (options.protectHalos !== false ? "halos" : "cores") + (fastStarMaps ? ":fast" : ":preview") + ":" + advanced.starProtectionStrength + ":" + advanced.haloProtectionStrength + ":" + advanced.protectionSoftness + ":" + advanced.overallProtectionStrength) : "starless";
   if (previewData.starProtectionKey === key && previewData.starProtectionMaps) {
      acePerfMark(timing, prefix + " detail - star maps cache hit", totalStart);
      return previewData.starProtectionMaps;
   }
   var layerRequirements = options.layerCacheRequirements || {};
   var needsTextureHybrid = layerRequirements.textureHybrid !== false;
   var textureHybridFlavor = layerRequirements.textureHybridFlavor === "fast" ? "fast" : "exact";
   if (!previewData.layerCache || (needsTextureHybrid && aceLayerCacheNeedsTextureHybrid(previewData.layerCache, textureHybridFlavor)))
      previewData.layerCache = this.engine.buildLayerCache(previewData.width, previewData.height, previewData.rgb, advanced, timing, prefix, previewData.scale, options.layerCacheRequirements);
   if (!active) {
      var emptyStart = timingActive ? Date.now() : 0;
      previewData.starProtectionMaps = aceEmptyStarProtectionMaps(previewData.width, previewData.height);
      previewData.starProtectionKey = key;
      acePerfMark(timing, prefix + " detail - empty star maps", emptyStart);
      acePerfMark(timing, prefix + " detail - star/protection total", totalStart);
      return previewData.starProtectionMaps;
   }
   if (!previewData.starProtectionBase || previewData.starProtectionBaseFast !== fastStarMaps) {
      var baseStart = timingActive ? Date.now() : 0;
      var detailStarFactor = 1;
      previewData.starProtectionBase = (!fastFullRes && fastStarMaps) ?
         aceWithSuppressedEventYields(function() {
            return aceBuildStarProtectionBaseFullResolutionFast(previewData.width, previewData.height, previewData.layerCache.luminance, detailStarFactor);
         }) :
         (fastStarMaps ?
            aceBuildStarProtectionBaseFullResolutionFast(previewData.width, previewData.height, previewData.layerCache.luminance) :
            aceBuildStarProtectionBase(previewData.width, previewData.height, previewData.layerCache.luminance));
      previewData.starProtectionBaseFast = fastStarMaps;
      var baseFactor = previewData.starProtectionBase && previewData.starProtectionBase.downsampleFactor && previewData.starProtectionBase.downsampleFactor > 1 ?
         " x" + previewData.starProtectionBase.downsampleFactor : "";
      acePerfMark(timing, prefix + " detail - star base" + (fastStarMaps ? " fast" : "") + baseFactor, baseStart);
   }
   var composeStart = timingActive ? Date.now() : 0;
   previewData.starProtectionMaps = (fastStarMaps ? aceComposeStarProtectionMapsFullResolutionFast : aceComposeStarProtectionMaps)(
      previewData.width,
      previewData.height,
      previewData.starProtectionBase,
      true,
      options.protectHalos !== false,
      advanced
   );
   var composeFactor = previewData.starProtectionBase && previewData.starProtectionBase.downsampleFactor && previewData.starProtectionBase.downsampleFactor > 1 ?
      " x" + previewData.starProtectionBase.downsampleFactor : "";
   acePerfMark(timing, prefix + " detail - star map compose" + (fastStarMaps ? " fast" : "") + composeFactor, composeStart);
   previewData.starProtectionKey = key;
   acePerfMark(timing, prefix + " detail - star/protection total", totalStart);
   return previewData.starProtectionMaps;
};

PreviewProcessor.prototype.processPreview = function(previewData, params, protection, advanced, timing, timingPrefix) {
   if (!previewData || !previewData.rgb)
      return null;
   var prefix = timingPrefix || "Preview";
   var timingActive = !!(timing && timing.items);
   var stage = timingActive ? Date.now() : 0;
   var needsTextureHybrid = acePreviewNeedsTextureHybrid(params);
   var layerRequirements = aceLayerCacheRequirementsForParams(params);
   var textureHybridFlavor = layerRequirements.textureHybridFlavor;
   if (!previewData.layerCache || (needsTextureHybrid && aceLayerCacheNeedsTextureHybrid(previewData.layerCache, textureHybridFlavor)))
      previewData.layerCache = this.engine.buildLayerCache(previewData.width, previewData.height, previewData.rgb, advanced, timing, prefix, previewData.scale, layerRequirements);
   else
      acePerfMark(timing, prefix + " detail - layer cache reuse", stage);
   stage = timingActive ? Date.now() : 0;
   protection = protection || {};
   protection.layerCacheRequirements = layerRequirements;
   var starMaps = this.getStarProtectionMaps(previewData, protection, timing, prefix);
   acePerfMark(timing, prefix + " detail - star maps ready", stage);
   var effectiveProtection = protection || {};
   effectiveProtection.starAllowedWeight = starMaps ? starMaps.allowedWeight : null;
   stage = timingActive ? Date.now() : 0;
   var processedRgb = this.engine.apply(previewData.width, previewData.height, previewData.rgb, params, previewData.layerCache, effectiveProtection, advanced, timing, prefix);
   acePerfMark(timing, prefix + " detail - engine apply wrapper", stage);
   if (aceIsNativeDetailPreviewPrefix(prefix) &&
       ACE_DETAIL_AB_COMPARE_EXPORT_COUNT < ACE_DETAIL_AB_COMPARE_EXPORT_LIMIT &&
       params && params.hasEffect && params.hasEffect() &&
       Math.max(previewData.width, previewData.height) > 520) {
      ++ACE_DETAIL_AB_COMPARE_EXPORT_COUNT;
      var baselineStart = Date.now();
      var baselineRgb = null;
      var baselineCache = null;
      ACE_DETAIL_TEXTURE_HYBRID_BASELINE_ACTIVE = true;
      ACE_DETAIL_CLARITY_DZ_BASELINE_ACTIVE = true;
      try {
         baselineRgb = this.engine.apply(previewData.width, previewData.height, previewData.rgb, params, baselineCache, effectiveProtection, advanced, null, prefix);
      } finally {
         ACE_DETAIL_TEXTURE_HYBRID_BASELINE_ACTIVE = false;
         ACE_DETAIL_CLARITY_DZ_BASELINE_ACTIVE = false;
      }
      var baselineMs = Date.now() - baselineStart;
      var rgbDiff = baselineRgb ? aceCompareFloatBuffers("rgb", baselineRgb, processedRgb) : "rgb_compare_unavailable";
      var tag = Date.now();
      if (baselineRgb) {
         aceCreateRgbImageWindow(previewData.width, previewData.height, baselineRgb, "ACE_Detail_AB_Old_" + tag);
         aceCreateRgbImageWindow(previewData.width, previewData.height, processedRgb, "ACE_Detail_AB_New_" + tag);
      }
      aceDevelopmentConsoleWriteLine("[ACE] Detail A/B comparison crops exported | old=baseline_detail_math new=candidate_detail_math" +
         " size=" + previewData.width + "x" + previewData.height +
         " baseline_ms=" + baselineMs +
         " windows=" + (baselineRgb ? "ACE_Detail_AB_Old_" + tag + ",ACE_Detail_AB_New_" + tag : "none") +
         " | " + rgbDiff +
         " | watch=fine_star_halos,dark_rings,thin_nebula_texture,bright_nebula_tone,pan_edge_consistency");
   }
   stage = timingActive ? Date.now() : 0;
   var bitmap = protection && protection.skipBitmapRender ? null : aceRenderBitmapFromRgb(previewData.width, previewData.height, processedRgb);
   acePerfMark(timing, prefix + (bitmap ? " detail - render processed bitmap" : " detail - render processed bitmap skipped"), stage);
   return {
      width: previewData.width,
      height: previewData.height,
      rgb: processedRgb,
      bitmap: bitmap,
      allowedWeight: previewData.layerCache ? previewData.layerCache.lastAllowedWeight : null,
      starProtectionMask: starMaps ? starMaps.protectionMask : null,
      starAllowedWeight: starMaps ? starMaps.allowedWeight : null
   };
};

PreviewProcessor.prototype.buildScaleMapBitmaps = function(previewData, params, processedRgb, advanced, requestedMode) {
   if (!previewData || !previewData.rgb)
      return null;
   var width = previewData.width;
   var height = previewData.height;
   var count = width * height;
   var mode = requestedMode || "";
   var wantAll = !mode;
   var wantTexture = wantAll || mode === "texture";
   var needsTextureHybrid = wantTexture && aceTextureModeUsesDogTensorHybrid(params ? params.textureMode : ACE_TEXTURE_MODE_DEFAULT);
   var layerRequirements = aceLayerCacheRequirementsForParams(params);
   layerRequirements.textureHybrid = needsTextureHybrid;
   var textureHybridFlavor = layerRequirements.textureHybridFlavor;
   if (!previewData.layerCache || (needsTextureHybrid && aceLayerCacheNeedsTextureHybrid(previewData.layerCache, textureHybridFlavor)))
      previewData.layerCache = this.engine.buildLayerCache(previewData.width, previewData.height, previewData.rgb, advanced, null, null, previewData.scale, layerRequirements);
   var cache = previewData.layerCache;
   var wantClarity = wantAll || mode === "clarity";
   var wantDehaze = wantAll || mode === "dehaze";
   var wantDelta = wantAll || mode === "delta";
   var textureAmount = aceClamp(params.texture / 100, -1.5, 1.5) * ACE_TEXTURE_AMOUNT;
   var clarityAmount = aceClamp(params.clarity / 100, -1.5, 1.5) * ACE_CLARITY_AMOUNT;
   var dehazeAmount = aceClamp(params.dehaze / 100, -1.25, 1.25) * ACE_DEHAZE_AMOUNT;
   var textureMap = wantTexture || wantDelta ? new Float32Array(count) : null;
   var clarityMap = wantClarity || wantDelta ? new Float32Array(count) : null;
   var dehazeMap = wantDehaze || wantDelta ? new Float32Array(count) : null;
   var deltaMap = wantDelta ? new Float32Array(count) : null;
   var effectiveTexture = Math.abs(params.texture) > 0 ? textureAmount : 1;
   var textureMode = aceNormalizeTextureMode(params.textureMode);
   var textureDiagnosticLayer = null;
   var textureLayer = aceTextureLayerForModeValue(cache, textureMode, params.texture);
   if (textureMap) {
      var textureDiagnosticRadius = Math.max(1, Math.round(ACE_TEXTURE_RADIUS * aceAdvancedFactor(advanced, "textureScale") * (previewData.scale || 1)));
      var textureDiagnosticBlur = aceTextureScaleBlurFloat(width, height, cache.luminance, textureDiagnosticRadius);
      textureDiagnosticLayer = new Float32Array(count);
      for (var td = 0; td < count; ++td)
         textureDiagnosticLayer[td] = cache.luminance[td] - textureDiagnosticBlur[td];
   }
   var textureModeGain = textureMode === ACE_TEXTURE_MODE_WIDE60 ? ACE_TEXTURE_WIDE60_GAIN : aceTextureModeStrengthMultiplier(textureMode);
   var effectiveClarity = Math.abs(params.clarity) > 0 ? clarityAmount : 1;
   var clarityMode = aceNormalizeClarityMode(params.clarityMode);
   var clarityV2Active = clarityMode === ACE_CLARITY_MODE_V2 || clarityMode === ACE_CLARITY_MODE_V2_DEPTH;
   var clarityV3Active = aceIsClarityV3Mode(clarityMode);
   var clarityFeatureFitActive = this.engine.isClarityFeatureFitActive(params, clarityMode);
   var clarityV4Active = clarityMode === ACE_CLARITY_MODE_V4 || clarityFeatureFitActive || clarityMode === ACE_CLARITY_MODE_FAILED_V5B_0945_CURRENT_DISABLED;
   var clarityV2DepthActive = clarityMode === ACE_CLARITY_MODE_V2_DEPTH && CLARITY_V2_DEPTH_ENABLE;
   var clarityV5bPositiveActive = USE_CLARITY_V5B_POSITIVE && !FORCE_CLARITY_V4 && CLARITY_V5B_TONE_MODE !== "forced_v4" && clarityV4Active && params.clarity > 0;
   var starAllowedForDehazeMap = previewData.starProtectionMaps ? previewData.starProtectionMaps.allowedWeight : null;
   var dehazeFields = (wantDehaze || wantDelta) ? this.engine.ensureDehazeVeilCache(width, height, previewData.rgb, cache, starAllowedForDehazeMap, advanced) : null;
   var clarityV2AntiGlowMap = (wantClarity || wantDelta) && clarityV2DepthActive && params.clarity !== 0 ?
      this.engine.computeClarityV2AntiGlowDelta(width, height, params, cache, starAllowedForDehazeMap, true, null, "Clarity map") :
      null;
   var clarityV3Map = (wantClarity || wantDelta) && clarityV3Active && params.clarity !== 0 ?
      this.engine.computeClarityV3Delta(width, height, params, cache, starAllowedForDehazeMap, true, null, "Clarity map") :
      null;
   var clarityV4Map = (wantClarity || wantDelta) && clarityV4Active && params.clarity !== 0 ?
      this.engine.computeClarityV4Delta(width, height, params, cache, starAllowedForDehazeMap, true, null, "Clarity map") :
      null;
   var clarityV5bPositiveMap = (wantClarity || wantDelta) && clarityV5bPositiveActive ?
      this.engine.computeClarityV5bPositiveDelta(width, height, params, cache, starAllowedForDehazeMap, null, "Clarity map") :
      null;
   var clarityFeatureFitMap = (wantClarity || wantDelta) && clarityFeatureFitActive ?
      this.engine.computeClarityFeatureFitGatedDelta(width, height, params, cache, starAllowedForDehazeMap, null, "Clarity map", clarityMode) :
      null;
   for (var i = 0; i < count; ++i) {
      if (textureMap)
         textureMap[i] = textureDiagnosticLayer[i] * effectiveTexture * textureModeGain;
      if (clarityMap && clarityV4Map) {
         clarityMap[i] = clarityV4Map[i];
         if (clarityV5bPositiveMap)
            clarityMap[i] += clarityV5bPositiveMap[i];
         if (clarityFeatureFitMap)
            clarityMap[i] += clarityFeatureFitMap[i];
      } else if (clarityMap && clarityV3Map) {
         clarityMap[i] = clarityV3Map[i];
      } else if (clarityMap && clarityV2AntiGlowMap) {
         clarityMap[i] = clarityV2AntiGlowMap[i];
      } else if (clarityMap && clarityV2Active && cache.clarityV2Response) {
         clarityMap[i] = aceClamp01(cache.clarityV2Response[i] * Math.max(1, Math.abs(effectiveClarity)) * 10);
      } else if (clarityMap) {
         clarityMap[i] = cache.clarityLayer[i] * effectiveClarity;
      }
      if (dehazeMap)
         dehazeMap[i] = dehazeFields ? dehazeFields.veil[i] : 0;
   }
   if (wantDelta && processedRgb) {
      var processedL = aceLuminanceFromRgb(width, height, processedRgb);
      for (var j = 0; j < count; ++j)
         deltaMap[j] = processedL[j] - cache.luminance[j];
   } else if (wantDelta) {
      for (var k = 0; k < count; ++k)
         deltaMap[k] =
            textureAmount * textureModeGain * textureLayer[k] +
            (clarityV4Active || clarityV3Active || clarityV2DepthActive ? (params.clarity !== 0 ? clarityMap[k] : 0) : clarityAmount * (clarityV2Active && cache.clarityV2Layer ? cache.clarityV2Layer[k] * (cache.clarityV2Allowed ? cache.clarityV2Allowed[k] : 1) : cache.clarityLayer[k])) +
            dehazeAmount * cache.dehazeLayer[k];
   }
   var result = {};
   if (wantTexture)
      result.texture = aceRenderSignedMapBitmap(width, height, textureMap, 3.2);
   if (wantClarity)
      result.clarity = clarityV2Active && !clarityV2DepthActive ? aceRenderBitmapFromGray(width, height, clarityMap) : aceRenderSignedMapBitmap(width, height, clarityMap);
   if (wantDehaze)
      result.dehaze = aceRenderBitmapFromGray(width, height, dehazeMap);
   if (wantDelta)
      result.delta = aceRenderSignedMapBitmap(width, height, deltaMap, 3.0);
   return result;
};

function aceMergeScaleMapBitmaps(existing, updated) {
   var merged = existing || {};
   if (!updated)
      return merged;
   if (updated.texture)
      merged.texture = updated.texture;
   if (updated.clarity)
      merged.clarity = updated.clarity;
   if (updated.dehaze)
      merged.dehaze = updated.dehaze;
   if (updated.delta)
      merged.delta = updated.delta;
   return merged;
}

function aceBuildInteractiveScaleMapPreviewData(width, height, rgb) {
   if (!rgb)
      return null;
   var small = aceDownsampleRgbAntialias(rgb, width, height, ACE_INTERACTIVE_ADVANCED_MAP_MAX_EDGE);
   return {
      width: small.width,
      height: small.height,
      rgb: small.rgb,
      layerCache: null,
      interactiveScaleMap: small.scale < 1
   };
}

function aceBuildLightweightInteractiveScaleMapBitmap(width, height, rgb, advanced, mode) {
   if (!rgb || (mode !== "texture" && mode !== "clarity" && mode !== "dehaze"))
      return null;
   var mapData = aceBuildInteractiveScaleMapPreviewData(width, height, rgb);
   if (!mapData || !mapData.rgb)
      return null;
   var w = mapData.width;
   var h = mapData.height;
   var count = w * h;
   var luminance = aceLuminanceFromRgb(w, h, mapData.rgb);
   if (mode === "texture") {
      var textureRadius = Math.max(1, Math.round(ACE_TEXTURE_RADIUS * aceAdvancedFactor(advanced, "textureScale") * 0.45));
      var textureBlur = aceBoxBlurFloat(w, h, luminance, textureRadius);
      var textureMap = new Float32Array(count);
      for (var ti = 0; ti < count; ++ti)
         textureMap[ti] = luminance[ti] - textureBlur[ti];
      return aceRenderSignedMapBitmap(w, h, textureMap, 3.2);
   }
   if (mode === "clarity") {
      var clarityRadius = Math.max(2, Math.round(ACE_CLARITY_RADIUS * aceAdvancedFactor(advanced, "clarityScale") * 0.55));
      var clarityBlur = aceBoxBlurFloat(w, h, luminance, clarityRadius);
      var clarityMap = new Float32Array(count);
      for (var ci = 0; ci < count; ++ci)
         clarityMap[ci] = luminance[ci] - clarityBlur[ci];
      return aceRenderSignedMapBitmap(w, h, clarityMap);
   }
   var dehazeRadius = Math.max(4, Math.round(ACE_DEHAZE_RADIUS * aceAdvancedFactor(advanced, "dehazeVeilSize") * 0.25));
   var veil = aceBoxBlurFloat(w, h, luminance, dehazeRadius);
   veil = aceBoxBlurFloat(w, h, veil, dehazeRadius);
   return aceRenderBitmapFromGray(w, h, veil);
}

function EffectParameters() {
   this.texture = 0;
   this.clarity = 0;
   this.dehaze = 0;
   this.textureMode = ACE_TEXTURE_MODE_DEFAULT;
   this.clarityMode = ACE_CLARITY_MODE_DEFAULT;
   this.dehazeMode = ACE_DEHAZE_APP_MODE_DEFAULT;
   this.clarityV2Tuning = CLARITY_V2_TUNING_DEFAULT;
}

EffectParameters.prototype.reset = function() {
   this.texture = 0;
   this.clarity = 0;
   this.dehaze = 0;
};

EffectParameters.prototype.hasEffect = function() {
   return this.texture !== 0 || this.clarity !== 0 || this.dehaze !== 0;
};

function AdvancedParameters() {
   this.textureScale = DEFAULT_TEXTURE_SCALE;
   this.clarityScale = DEFAULT_CLARITY_SCALE;
   this.clarityResponse = DEFAULT_CLARITY_RESPONSE;
   this.dehazeVeilSize = DEFAULT_DEHAZE_VEIL_SIZE;
   this.dehazeVeilStrength = DEFAULT_DEHAZE_VEIL_STRENGTH;
   this.dehazeHighlightProtect = DEFAULT_DEHAZE_HIGHLIGHT_PROTECT;
   this.dehazeCompactProtect = DEFAULT_DEHAZE_COMPACT_PROTECT;
   this.dehazeVeilConfidence = DEFAULT_DEHAZE_VEIL_CONFIDENCE;
   this.dehazeColorRestore = DEFAULT_DEHAZE_COLOR_RESTORE;
   this.dehazeHazeAddBack = DEFAULT_DEHAZE_HAZE_ADD_BACK;
   this.skyProtectionStrength = DEFAULT_SKY_PROTECTION_STRENGTH;
   this.darkPatchGuardStrength = DEFAULT_DARK_PATCH_GUARD_STRENGTH;
   this.starProtectionStrength = DEFAULT_STAR_PROTECTION_STRENGTH;
   this.haloProtectionStrength = DEFAULT_HALO_PROTECTION_STRENGTH;
   this.protectionSoftness = DEFAULT_PROTECTION_SOFTNESS;
   this.overallProtectionStrength = DEFAULT_OVERALL_PROTECTION_STRENGTH;
}

AdvancedParameters.prototype.reset = function() {
   this.textureScale = DEFAULT_TEXTURE_SCALE;
   this.clarityScale = DEFAULT_CLARITY_SCALE;
   this.clarityResponse = DEFAULT_CLARITY_RESPONSE;
   this.dehazeVeilSize = DEFAULT_DEHAZE_VEIL_SIZE;
   this.dehazeVeilStrength = DEFAULT_DEHAZE_VEIL_STRENGTH;
   this.dehazeHighlightProtect = DEFAULT_DEHAZE_HIGHLIGHT_PROTECT;
   this.dehazeCompactProtect = DEFAULT_DEHAZE_COMPACT_PROTECT;
   this.dehazeVeilConfidence = DEFAULT_DEHAZE_VEIL_CONFIDENCE;
   this.dehazeColorRestore = DEFAULT_DEHAZE_COLOR_RESTORE;
   this.dehazeHazeAddBack = DEFAULT_DEHAZE_HAZE_ADD_BACK;
   this.skyProtectionStrength = DEFAULT_SKY_PROTECTION_STRENGTH;
   this.darkPatchGuardStrength = DEFAULT_DARK_PATCH_GUARD_STRENGTH;
   this.starProtectionStrength = DEFAULT_STAR_PROTECTION_STRENGTH;
   this.haloProtectionStrength = DEFAULT_HALO_PROTECTION_STRENGTH;
   this.protectionSoftness = DEFAULT_PROTECTION_SOFTNESS;
   this.overallProtectionStrength = DEFAULT_OVERALL_PROTECTION_STRENGTH;
};

AdvancedParameters.prototype.isDefault = function() {
   return this.textureScale === DEFAULT_TEXTURE_SCALE &&
      this.clarityScale === DEFAULT_CLARITY_SCALE &&
      this.clarityResponse === DEFAULT_CLARITY_RESPONSE &&
      this.dehazeVeilSize === DEFAULT_DEHAZE_VEIL_SIZE &&
      this.dehazeVeilStrength === DEFAULT_DEHAZE_VEIL_STRENGTH &&
      this.dehazeHighlightProtect === DEFAULT_DEHAZE_HIGHLIGHT_PROTECT &&
      this.dehazeCompactProtect === DEFAULT_DEHAZE_COMPACT_PROTECT &&
      this.dehazeVeilConfidence === DEFAULT_DEHAZE_VEIL_CONFIDENCE &&
      this.dehazeColorRestore === DEFAULT_DEHAZE_COLOR_RESTORE &&
      this.dehazeHazeAddBack === DEFAULT_DEHAZE_HAZE_ADD_BACK &&
      this.skyProtectionStrength === DEFAULT_SKY_PROTECTION_STRENGTH &&
      this.darkPatchGuardStrength === DEFAULT_DARK_PATCH_GUARD_STRENGTH &&
      this.starProtectionStrength === DEFAULT_STAR_PROTECTION_STRENGTH &&
      this.haloProtectionStrength === DEFAULT_HALO_PROTECTION_STRENGTH &&
      this.protectionSoftness === DEFAULT_PROTECTION_SOFTNESS &&
      this.overallProtectionStrength === DEFAULT_OVERALL_PROTECTION_STRENGTH;
};

AdvancedParameters.prototype.isCuratedDefault = function() {
   return this.textureScale === DEFAULT_TEXTURE_SCALE &&
      this.clarityScale === DEFAULT_CLARITY_SCALE &&
      this.clarityResponse === DEFAULT_CLARITY_RESPONSE &&
      this.dehazeVeilSize === DEFAULT_DEHAZE_VEIL_SIZE &&
      this.dehazeVeilStrength === DEFAULT_DEHAZE_VEIL_STRENGTH &&
      this.dehazeHighlightProtect === DEFAULT_DEHAZE_HIGHLIGHT_PROTECT &&
      this.overallProtectionStrength === DEFAULT_OVERALL_PROTECTION_STRENGTH;
};

function aceCopyPointArray(points) {
   var out = [];
   if (!points)
      return out;
   for (var i = 0; i < points.length; ++i)
      out.push({ x: points[i].x, y: points[i].y });
   return out;
}

function aceCopyParams(params) {
   return {
      texture: params ? params.texture : 0,
      clarity: params ? params.clarity : 0,
      dehaze: params ? params.dehaze : 0,
      dehazeMode: aceNormalizeDehazeAppMode(params ? params.dehazeMode : null),
      textureMode: aceNormalizeTextureMode(params ? params.textureMode : null),
      clarityMode: aceNormalizeClarityMode(params ? params.clarityMode : null),
      clarityV2Tuning: aceNormalizeClarityV2Tuning(params ? params.clarityV2Tuning : null)
   };
}

function aceNormalizeTextureMode(mode) {
   if (mode === ACE_TEXTURE_MODE_ISOCORE_1P00)
      return ACE_TEXTURE_MODE_ISOCORE_1P00;
   if (mode === ACE_TEXTURE_MODE_ISOCORE_1P25)
      return ACE_TEXTURE_MODE_ISOCORE_1P25;
   if (mode === ACE_TEXTURE_MODE_ISOCORE_1P50)
      return ACE_TEXTURE_MODE_ISOCORE_1P50;
   if (mode === ACE_TEXTURE_MODE_ISOCORE_1P75)
      return ACE_TEXTURE_MODE_ISOCORE_1P75;
   if (mode === ACE_TEXTURE_MODE_COMPACT_BRIGHT_ONLY_1P50)
      return ACE_TEXTURE_MODE_COMPACT_BRIGHT_ONLY_1P50;
   if (mode === ACE_TEXTURE_MODE_ISOTROPIC_ONLY_1P50)
      return ACE_TEXTURE_MODE_ISOTROPIC_ONLY_1P50;
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_1P25)
      return ACE_TEXTURE_MODE_GRIDGUARD_1P25;
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_1P50)
      return ACE_TEXTURE_MODE_GRIDGUARD_1P50;
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_1P75)
      return ACE_TEXTURE_MODE_GRIDGUARD_1P75;
   if (mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P25)
      return ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P25;
   if (mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P50)
      return ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P50;
   if (mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P75)
      return ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P75;
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_LIGHT_1P50)
      return ACE_TEXTURE_MODE_GRIDGUARD_LIGHT_1P50;
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_STRONG_1P50)
      return ACE_TEXTURE_MODE_GRIDGUARD_STRONG_1P50;
   if (mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_LIGHT_1P50)
      return ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_LIGHT_1P50;
   if (mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_STRONG_1P50)
      return ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_STRONG_1P50;
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_AA_1P25)
      return ACE_TEXTURE_MODE_SIGNALFIX_AA_1P25;
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_AA_1P50)
      return ACE_TEXTURE_MODE_SIGNALFIX_AA_1P50;
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_SOURCE_1P50)
      return ACE_TEXTURE_MODE_SIGNALFIX_SOURCE_1P50;
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P25)
      return ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P25;
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P50)
      return ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P50;
   if (mode === ACE_TEXTURE_MODE_STRENGTH_1P25)
      return ACE_TEXTURE_MODE_STRENGTH_1P25;
   if (mode === ACE_TEXTURE_MODE_STRENGTH_1P50)
      return ACE_TEXTURE_MODE_STRENGTH_1P50;
   if (mode === ACE_TEXTURE_MODE_STRENGTH_1P75)
      return ACE_TEXTURE_MODE_STRENGTH_1P75;
   if (mode === ACE_TEXTURE_MODE_STRENGTH_2P00)
      return ACE_TEXTURE_MODE_STRENGTH_2P00;
   if (mode === ACE_TEXTURE_MODE_WIDE60)
      return ACE_TEXTURE_MODE_WIDE60;
   if (mode === ACE_TEXTURE_MODE_DOG_MIDBLEND_REF)
      return ACE_TEXTURE_MODE_DOG_MIDBLEND_REF;
   if (mode === ACE_TEXTURE_MODE_TENSOR_LIMITED_REF)
      return ACE_TEXTURE_MODE_TENSOR_LIMITED_REF;
   if (mode === ACE_TEXTURE_MODE_HYBRID_CONSERVATIVE)
      return ACE_TEXTURE_MODE_HYBRID_CONSERVATIVE;
   if (mode === ACE_TEXTURE_MODE_HYBRID_MEDIUM)
      return ACE_TEXTURE_MODE_HYBRID_MEDIUM;
   if (mode === ACE_TEXTURE_MODE_HYBRID_LIGHT)
      return ACE_TEXTURE_MODE_HYBRID_LIGHT;
   if (mode === ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST)
      return ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST;
   if (mode === ACE_TEXTURE_MODE_HYBRID_HIGH)
      return ACE_TEXTURE_MODE_HYBRID_HIGH;
   if (mode === ACE_TEXTURE_MODE_PRODUCT_MAP)
      return ACE_TEXTURE_MODE_PRODUCT_MAP;
   if (mode === ACE_TEXTURE_MODE_PRODUCT_MAP_STAR_HYGIENE)
      return ACE_TEXTURE_MODE_PRODUCT_MAP_STAR_HYGIENE;
   if (mode === ACE_TEXTURE_MODE_SAFE_PRODUCT_STAR_HYGIENE)
      return ACE_TEXTURE_MODE_SAFE_PRODUCT_STAR_HYGIENE;
   if (mode === ACE_TEXTURE_MODE_HIGH_PRODUCT_MAP)
      return ACE_TEXTURE_MODE_HIGH_PRODUCT_MAP;
   return ACE_TEXTURE_MODE_DEFAULT;
}

function aceTextureModeStrengthMultiplier(mode) {
   mode = aceNormalizeTextureMode(mode);
   if (mode === ACE_TEXTURE_MODE_ISOCORE_1P25)
      return 1.25;
   if (mode === ACE_TEXTURE_MODE_ISOCORE_1P50)
      return 1.50;
   if (mode === ACE_TEXTURE_MODE_ISOCORE_1P75)
      return 1.75;
   if (mode === ACE_TEXTURE_MODE_COMPACT_BRIGHT_ONLY_1P50)
      return 1.50;
   if (mode === ACE_TEXTURE_MODE_ISOTROPIC_ONLY_1P50)
      return 1.50;
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_1P25 || mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P25)
      return 1.25;
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_1P50 ||
      mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P50 ||
      mode === ACE_TEXTURE_MODE_GRIDGUARD_LIGHT_1P50 ||
      mode === ACE_TEXTURE_MODE_GRIDGUARD_STRONG_1P50 ||
      mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_LIGHT_1P50 ||
      mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_STRONG_1P50)
      return 1.50;
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_1P75 || mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P75)
      return 1.75;
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_AA_1P50 || mode === ACE_TEXTURE_MODE_SIGNALFIX_SOURCE_1P50 || mode === ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P50)
      return 1.50;
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_AA_1P25 || mode === ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P25)
      return 1.25;
   if (mode === ACE_TEXTURE_MODE_STRENGTH_1P25)
      return 1.25;
   if (mode === ACE_TEXTURE_MODE_STRENGTH_1P50)
      return 1.50;
   if (mode === ACE_TEXTURE_MODE_STRENGTH_1P75)
      return 1.75;
   if (mode === ACE_TEXTURE_MODE_STRENGTH_2P00)
      return 2.00;
   return 1.00;
}

function aceTextureModeUsesArtifactSafeCore(mode) {
   mode = aceNormalizeTextureMode(mode);
   return mode === ACE_TEXTURE_MODE_ISOCORE_1P00 ||
      mode === ACE_TEXTURE_MODE_ISOCORE_1P25 ||
      mode === ACE_TEXTURE_MODE_ISOCORE_1P50 ||
      mode === ACE_TEXTURE_MODE_ISOCORE_1P75;
}

function aceTextureModeUsesCompactBrightPreconditioning(mode) {
   mode = aceNormalizeTextureMode(mode);
   return aceTextureModeUsesArtifactSafeCore(mode) ||
      mode === ACE_TEXTURE_MODE_COMPACT_BRIGHT_ONLY_1P50 ||
      mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P25 ||
      mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P50 ||
      mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P75 ||
      mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_LIGHT_1P50 ||
      mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_STRONG_1P50;
}

function aceTextureModeUsesGridGuard(mode) {
   mode = aceNormalizeTextureMode(mode);
   return mode === ACE_TEXTURE_MODE_GRIDGUARD_1P25 ||
      mode === ACE_TEXTURE_MODE_GRIDGUARD_1P50 ||
      mode === ACE_TEXTURE_MODE_GRIDGUARD_1P75 ||
      mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P25 ||
      mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P50 ||
      mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P75 ||
      mode === ACE_TEXTURE_MODE_GRIDGUARD_LIGHT_1P50 ||
      mode === ACE_TEXTURE_MODE_GRIDGUARD_STRONG_1P50 ||
      mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_LIGHT_1P50 ||
      mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_STRONG_1P50;
}

function aceTextureModeUsesSignalFix(mode) {
   mode = aceNormalizeTextureMode(mode);
   return mode === ACE_TEXTURE_MODE_SIGNALFIX_AA_1P25 ||
      mode === ACE_TEXTURE_MODE_SIGNALFIX_AA_1P50 ||
      mode === ACE_TEXTURE_MODE_SIGNALFIX_SOURCE_1P50 ||
      mode === ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P25 ||
      mode === ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P50;
}

function aceTextureModeUsesDogTensorHybrid(mode) {
   mode = aceNormalizeTextureMode(mode);
   return mode === ACE_TEXTURE_MODE_DOG_MIDBLEND_REF ||
      mode === ACE_TEXTURE_MODE_TENSOR_LIMITED_REF ||
      mode === ACE_TEXTURE_MODE_HYBRID_CONSERVATIVE ||
      mode === ACE_TEXTURE_MODE_HYBRID_MEDIUM ||
      mode === ACE_TEXTURE_MODE_HYBRID_LIGHT ||
      mode === ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST ||
      mode === ACE_TEXTURE_MODE_HYBRID_HIGH ||
      mode === ACE_TEXTURE_MODE_PRODUCT_MAP ||
      mode === ACE_TEXTURE_MODE_PRODUCT_MAP_STAR_HYGIENE ||
      mode === ACE_TEXTURE_MODE_SAFE_PRODUCT_STAR_HYGIENE ||
      mode === ACE_TEXTURE_MODE_HIGH_PRODUCT_MAP;
}

function aceTextureHybridProfile(mode) {
   mode = aceNormalizeTextureMode(mode);
   if (mode === ACE_TEXTURE_MODE_DOG_MIDBLEND_REF)
      return "dog_fine_mid_reference";
   if (mode === ACE_TEXTURE_MODE_TENSOR_LIMITED_REF)
      return "structure_tensor_limited_reference";
   if (mode === ACE_TEXTURE_MODE_HYBRID_CONSERVATIVE)
      return "dog_midblend_tensor_gate_conservative";
   if (mode === ACE_TEXTURE_MODE_HYBRID_MEDIUM)
      return "dog_midblend_tensor_gate_medium";
   if (mode === ACE_TEXTURE_MODE_HYBRID_LIGHT)
      return "dog_midblend_tensor_gate_light";
   if (mode === ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST)
      return "dog_midblend_tensor_gate_light_fast_recursive_test";
   if (mode === ACE_TEXTURE_MODE_HYBRID_HIGH)
      return "dog_midblend_tensor_gate_high_strength";
   if (mode === ACE_TEXTURE_MODE_PRODUCT_MAP)
      return "product_slider_map_medium_to_light_to_high";
   if (mode === ACE_TEXTURE_MODE_PRODUCT_MAP_STAR_HYGIENE)
      return "product_slider_map_plus_smooth_compact_star_hygiene";
   if (mode === ACE_TEXTURE_MODE_SAFE_PRODUCT_STAR_HYGIENE)
      return "safe_product_map_medium_to_light_plus_smooth_compact_star_hygiene";
   if (mode === ACE_TEXTURE_MODE_HIGH_PRODUCT_MAP)
      return "high_product_map_light_to_high_stress";
   return "off";
}

function aceTextureProductMixProfile(textureValue, safeMap, highOnly) {
   var v = Math.min(150, Math.abs(textureValue || 0));
   var medium = 0;
   var light = 1;
   var high = 0;
   if (highOnly) {
      var ht = aceSmoothStep(50, 150, v);
      medium = 0;
      light = 1 - ht;
      high = ht;
   } else if (safeMap) {
      var st = aceSmoothStep(40, 125, v);
      medium = 1 - st;
      light = st;
      high = 0;
   } else if (v <= 100) {
      var lt = aceSmoothStep(20, 100, v);
      medium = 1 - lt;
      light = lt;
      high = 0;
   } else {
      var ut = aceSmoothStep(100, 150, v);
      medium = 0;
      light = 1 - ut;
      high = ut;
   }
   return { medium: medium, light: light, high: high };
}

function aceTextureStarHygieneStrength(textureValue, safeMap) {
   var v = Math.min(150, Math.abs(textureValue || 0));
   var base = safeMap ? 0.22 : 0.16;
   return base + (safeMap ? 0.28 : 0.24) * aceSmoothStep(25, 150, v);
}

function aceTextureProductLayerForMode(cache, mode, textureValue) {
   mode = aceNormalizeTextureMode(mode);
   var safeMap = mode === ACE_TEXTURE_MODE_SAFE_PRODUCT_STAR_HYGIENE;
   var highOnly = mode === ACE_TEXTURE_MODE_HIGH_PRODUCT_MAP;
   var starHygiene = mode === ACE_TEXTURE_MODE_PRODUCT_MAP_STAR_HYGIENE || mode === ACE_TEXTURE_MODE_SAFE_PRODUCT_STAR_HYGIENE;
   var profile = aceTextureProductMixProfile(textureValue, safeMap, highOnly);
   var count = cache.width * cache.height;
   var layer = new Float32Array(count);
   var medium = cache.textureHybridMediumLayer || cache.textureLayer;
   var light = cache.textureHybridLightLayer || cache.textureLayer;
   var high = cache.textureHybridHighLayer || light;
   var starMask = cache.textureHybridStarMask || null;
   var hygieneStrength = starHygiene ? aceTextureStarHygieneStrength(textureValue, safeMap) : 0;
   for (var i = 0; i < count; ++i) {
      var value = medium[i] * profile.medium + light[i] * profile.light + high[i] * profile.high;
      if (starHygiene && starMask)
         value *= aceClamp01(1 - hygieneStrength * aceClamp01(starMask[i]));
      layer[i] = value;
   }
   return layer;
}

function aceTextureSignalFixProfile(mode) {
   mode = aceNormalizeTextureMode(mode);
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_AA_1P25 || mode === ACE_TEXTURE_MODE_SIGNALFIX_AA_1P50)
      return "aa_reconstruction";
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_SOURCE_1P50)
      return "source_agreement_highpass";
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P25 || mode === ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P50)
      return "blend_0p55_aa_0p45_sourceagree";
   return "off";
}

function aceTextureGridGuardProfile(mode) {
   mode = aceNormalizeTextureMode(mode);
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_LIGHT_1P50 || mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_LIGHT_1P50)
      return "light";
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_STRONG_1P50 || mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_STRONG_1P50)
      return "strong";
   if (aceTextureModeUsesGridGuard(mode))
      return "normal";
   return "off";
}

function aceTextureLayerForMode(cache, mode) {
   mode = aceNormalizeTextureMode(mode);
   if (mode === ACE_TEXTURE_MODE_WIDE60 && cache.textureWide60Layer)
      return cache.textureWide60Layer;
   if (aceTextureModeUsesArtifactSafeCore(mode) && cache.textureArtifactSafeLayer)
      return cache.textureArtifactSafeLayer;
   if (mode === ACE_TEXTURE_MODE_COMPACT_BRIGHT_ONLY_1P50 && cache.textureCompactBrightOnlyLayer)
      return cache.textureCompactBrightOnlyLayer;
   if ((mode === ACE_TEXTURE_MODE_GRIDGUARD_LIGHT_1P50) && cache.textureGridGuardLightLayer)
      return cache.textureGridGuardLightLayer;
   if ((mode === ACE_TEXTURE_MODE_GRIDGUARD_STRONG_1P50) && cache.textureGridGuardStrongLayer)
      return cache.textureGridGuardStrongLayer;
   if ((mode === ACE_TEXTURE_MODE_GRIDGUARD_1P25 || mode === ACE_TEXTURE_MODE_GRIDGUARD_1P50 || mode === ACE_TEXTURE_MODE_GRIDGUARD_1P75) && cache.textureGridGuardLayer)
      return cache.textureGridGuardLayer;
   if ((mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_LIGHT_1P50) && cache.textureCompactGridGuardLightLayer)
      return cache.textureCompactGridGuardLightLayer;
   if ((mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_STRONG_1P50) && cache.textureCompactGridGuardStrongLayer)
      return cache.textureCompactGridGuardStrongLayer;
   if ((mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P25 || mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P50 || mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P75) && cache.textureCompactGridGuardLayer)
      return cache.textureCompactGridGuardLayer;
   if ((mode === ACE_TEXTURE_MODE_SIGNALFIX_AA_1P25 || mode === ACE_TEXTURE_MODE_SIGNALFIX_AA_1P50) && cache.textureSignalFixAALayer)
      return cache.textureSignalFixAALayer;
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_SOURCE_1P50 && cache.textureSignalFixSourceLayer)
      return cache.textureSignalFixSourceLayer;
   if ((mode === ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P25 || mode === ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P50) && cache.textureSignalFixBlendLayer)
      return cache.textureSignalFixBlendLayer;
   if (mode === ACE_TEXTURE_MODE_DOG_MIDBLEND_REF && cache.textureDogMidblendLayer)
      return cache.textureDogMidblendLayer;
   if (mode === ACE_TEXTURE_MODE_TENSOR_LIMITED_REF && cache.textureTensorLimitedLayer)
      return cache.textureTensorLimitedLayer;
   if (mode === ACE_TEXTURE_MODE_HYBRID_CONSERVATIVE && cache.textureHybridConservativeLayer)
      return cache.textureHybridConservativeLayer;
   if (mode === ACE_TEXTURE_MODE_HYBRID_MEDIUM && cache.textureHybridMediumLayer)
      return cache.textureHybridMediumLayer;
   if (mode === ACE_TEXTURE_MODE_HYBRID_LIGHT && cache.textureHybridLightLayer)
      return cache.textureHybridLightLayer;
   if (mode === ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST && cache.textureHybridLightLayer)
      return cache.textureHybridLightLayer;
   if (mode === ACE_TEXTURE_MODE_HYBRID_HIGH && cache.textureHybridHighLayer)
      return cache.textureHybridHighLayer;
   if (mode === ACE_TEXTURE_MODE_ISOTROPIC_ONLY_1P50 && cache.textureIsotropicOnlyLayer)
      return cache.textureIsotropicOnlyLayer;
   return cache.textureLayer;
}

function aceTextureLayerForModeValue(cache, mode, textureValue) {
   mode = aceNormalizeTextureMode(mode);
   if (mode === ACE_TEXTURE_MODE_PRODUCT_MAP ||
      mode === ACE_TEXTURE_MODE_PRODUCT_MAP_STAR_HYGIENE ||
      mode === ACE_TEXTURE_MODE_SAFE_PRODUCT_STAR_HYGIENE ||
      mode === ACE_TEXTURE_MODE_HIGH_PRODUCT_MAP)
      return aceTextureProductLayerForMode(cache, mode, textureValue);
   return aceTextureLayerForMode(cache, mode);
}

function aceTextureSelectorModes() {
   return [
      ACE_TEXTURE_MODE_CURRENT,
      ACE_TEXTURE_MODE_HYBRID_MEDIUM,
      ACE_TEXTURE_MODE_HYBRID_LIGHT,
      ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST,
      ACE_TEXTURE_MODE_HYBRID_HIGH,
      ACE_TEXTURE_MODE_PRODUCT_MAP,
      ACE_TEXTURE_MODE_PRODUCT_MAP_STAR_HYGIENE,
      ACE_TEXTURE_MODE_SAFE_PRODUCT_STAR_HYGIENE,
   ];
}

function aceTextureSelectorLabel(mode) {
   mode = aceNormalizeTextureMode(mode);
   if (mode === ACE_TEXTURE_MODE_ISOCORE_1P00)
      return "Texture IsoCore 1.00x";
   if (mode === ACE_TEXTURE_MODE_ISOCORE_1P25)
      return "Texture IsoCore 1.25x";
   if (mode === ACE_TEXTURE_MODE_ISOCORE_1P50)
      return "Texture IsoCore 1.50x";
   if (mode === ACE_TEXTURE_MODE_ISOCORE_1P75)
      return "Texture IsoCore 1.75x";
   if (mode === ACE_TEXTURE_MODE_COMPACT_BRIGHT_ONLY_1P50)
      return "Texture CompactBrightOnly 1.50x";
   if (mode === ACE_TEXTURE_MODE_ISOTROPIC_ONLY_1P50)
      return "Texture IsotropicOnly 1.50x";
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_1P25)
      return "Texture GridGuard 1.25x";
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_1P50)
      return "Texture GridGuard 1.50x";
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_1P75)
      return "Texture GridGuard 1.75x";
   if (mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P25)
      return "Texture Compact+GridGuard 1.25x";
   if (mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P50)
      return "Texture Compact+GridGuard 1.50x";
   if (mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_1P75)
      return "Texture Compact+GridGuard 1.75x";
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_LIGHT_1P50)
      return "Texture GridGuard light 1.50x";
   if (mode === ACE_TEXTURE_MODE_GRIDGUARD_STRONG_1P50)
      return "Texture GridGuard strong 1.50x";
   if (mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_LIGHT_1P50)
      return "Texture Compact+GridGuard light 1.50x";
   if (mode === ACE_TEXTURE_MODE_COMPACT_GRIDGUARD_STRONG_1P50)
      return "Texture Compact+GridGuard strong 1.50x";
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_AA_1P25)
      return "Texture SignalFix AA 1.25x";
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_AA_1P50)
      return "Texture SignalFix AA 1.50x";
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_SOURCE_1P50)
      return "Texture SignalFix SourceAgree 1.50x";
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P25)
      return "Texture SignalFix Blend 1.25x";
   if (mode === ACE_TEXTURE_MODE_SIGNALFIX_BLEND_1P50)
      return "Texture SignalFix Blend 1.50x";
   if (mode === ACE_TEXTURE_MODE_STRENGTH_1P25)
      return "Texture 1.25x";
   if (mode === ACE_TEXTURE_MODE_STRENGTH_1P50)
      return "Texture 1.50x";
   if (mode === ACE_TEXTURE_MODE_STRENGTH_1P75)
      return "Texture 1.75x";
   if (mode === ACE_TEXTURE_MODE_STRENGTH_2P00)
      return "Texture 2.00x";
   if (mode === ACE_TEXTURE_MODE_WIDE60)
      return "Texture Wide60 - legacy research comparison";
   if (mode === ACE_TEXTURE_MODE_DOG_MIDBLEND_REF)
      return "Texture DoG Ref";
   if (mode === ACE_TEXTURE_MODE_TENSOR_LIMITED_REF)
      return "Texture Tensor Ref";
   if (mode === ACE_TEXTURE_MODE_HYBRID_CONSERVATIVE)
      return "Texture Hybrid Conservative";
   if (mode === ACE_TEXTURE_MODE_HYBRID_MEDIUM)
      return "Texture Hybrid Medium";
   if (mode === ACE_TEXTURE_MODE_HYBRID_LIGHT)
      return (ACE_DEBUG_CONTROLS_ENABLED || ACE_TEXTURE_COMPARISON_CONTROLS_ENABLED) ? "Texture Hybrid Light EXACT" : "Product Texture";
   if (mode === ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST)
      return "Texture Hybrid Light FAST TEST";
   if (mode === ACE_TEXTURE_MODE_HYBRID_HIGH)
      return "Texture Hybrid High";
   if (mode === ACE_TEXTURE_MODE_PRODUCT_MAP)
      return "Texture ProductMap";
   if (mode === ACE_TEXTURE_MODE_PRODUCT_MAP_STAR_HYGIENE)
      return "Texture ProductMap+Stars";
   if (mode === ACE_TEXTURE_MODE_SAFE_PRODUCT_STAR_HYGIENE)
      return "Texture SafeMap+Stars";
   if (mode === ACE_TEXTURE_MODE_HIGH_PRODUCT_MAP)
      return "Texture High ProductMap";
   return ACE_DEBUG_CONTROLS_ENABLED ? "Texture Current" : "Legacy Texture";
}

function aceTextureSelectorIndexForMode(mode) {
   mode = aceNormalizeTextureMode(mode);
   var modes = aceTextureSelectorModes();
   for (var i = 0; i < modes.length; ++i)
      if (aceNormalizeTextureMode(modes[i]) === mode)
         return i;
   return 0;
}

function aceTextureSelectorModeForIndex(index) {
   var modes = aceTextureSelectorModes();
   if (index < 0 || index >= modes.length)
      return ACE_TEXTURE_MODE_DEFAULT;
   return modes[index];
}

function aceLogTextureModePath(mode) {
   if (!ACE_DEVELOPMENT_CONSOLE_LOGS_ENABLED)
      return;
   mode = aceNormalizeTextureMode(mode);
   var report = "[ACE] Texture path | ace_version=" + ACE_VERSION +
      " mode=" + aceTextureSelectorLabel(mode) +
      " algorithm_id=" + mode +
      " strength_multiplier=" + aceTextureModeStrengthMultiplier(mode).toFixed(2) +
      " artifactsafe_core_active=" + (aceTextureModeUsesArtifactSafeCore(mode) ? "true" : "false") +
      " compact_bright_precondition_active=" + (aceTextureModeUsesCompactBrightPreconditioning(mode) ? "true" : "false") +
      " gridguard_active=" + (aceTextureModeUsesGridGuard(mode) ? "true" : "false") +
      " gridguard_profile=" + aceTextureGridGuardProfile(mode) +
      " signalfix_active=" + (aceTextureModeUsesSignalFix(mode) ? "true" : "false") +
      " signalfix_profile=" + aceTextureSignalFixProfile(mode) +
      " signalfix_blend_formula=" + (aceTextureSignalFixProfile(mode).indexOf("blend") === 0 ? "0.55*aa_reconstruction+0.45*source_agreement" : "n/a") +
      " dog_tensor_hybrid_active=" + (aceTextureModeUsesDogTensorHybrid(mode) ? "true" : "false") +
      " dog_tensor_profile=" + aceTextureHybridProfile(mode) +
      " dog_map_active=" + (mode === ACE_TEXTURE_MODE_DOG_MIDBLEND_REF || mode === ACE_TEXTURE_MODE_HYBRID_CONSERVATIVE || mode === ACE_TEXTURE_MODE_HYBRID_MEDIUM || mode === ACE_TEXTURE_MODE_HYBRID_LIGHT || mode === ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST || mode === ACE_TEXTURE_MODE_HYBRID_HIGH ? "true" : "false") +
      " structure_tensor_confidence_active=" + (mode === ACE_TEXTURE_MODE_TENSOR_LIMITED_REF || mode === ACE_TEXTURE_MODE_HYBRID_CONSERVATIVE || mode === ACE_TEXTURE_MODE_HYBRID_MEDIUM || mode === ACE_TEXTURE_MODE_HYBRID_LIGHT || mode === ACE_TEXTURE_MODE_HYBRID_LIGHT_FAST_TEST || mode === ACE_TEXTURE_MODE_HYBRID_HIGH ? "true" : "false") +
      " tensor_gate_parameters=" + aceTextureHybridProfile(mode) +
      " blur_kernel=" + (aceTextureModeUsesFastHybrid(mode) ? "recursive_smooth_fast_test" : (aceTextureModeUsesDogTensorHybrid(mode) || aceTextureModeUsesArtifactSafeCore(mode) || mode === ACE_TEXTURE_MODE_ISOTROPIC_ONLY_1P50 ? "separable_gaussian_equal_sigma_xy" : "legacy_texture_recursive_smooth")) +
      " map_resolution=full resampling=none preview_final_shared_layer_cache=true tiled_rendering=false" +
      " wide60_active=" + (mode === ACE_TEXTURE_MODE_WIDE60 ? "true" : "false") +
      " clarity_unchanged=true dehaze_unchanged=true";
   if (typeof console !== "undefined" && console && typeof console.writeln === "function")
      console.writeln(report);
   else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
      Console.writeln(report);
}


function aceNormalizeDehazeAppMode(mode) {
   if (mode === ACE_DEHAZE_APP_MODE_GAIN_MATCH)
      return ACE_DEHAZE_APP_MODE_GAIN_MATCH;
   if (mode === ACE_DEHAZE_APP_MODE_TONE_COLOR)
      return ACE_DEHAZE_APP_MODE_TONE_COLOR;
   if (mode === ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR)
      return ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR;
   if (mode === ACE_DEHAZE_APP_MODE_COLOR_SEPARATION)
      return ACE_DEHAZE_APP_MODE_COLOR_SEPARATION;
   if (mode === ACE_DEHAZE_APP_MODE_TONE_REDISTRIBUTION)
      return ACE_DEHAZE_APP_MODE_TONE_REDISTRIBUTION;
   return ACE_DEHAZE_APP_MODE_CURRENT;
}

function aceDehazeAppSelectorModes() {
   return [
      ACE_DEHAZE_APP_MODE_CURRENT,
      ACE_DEHAZE_APP_MODE_GAIN_MATCH,
      ACE_DEHAZE_APP_MODE_TONE_COLOR,
      ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR,
      ACE_DEHAZE_APP_MODE_COLOR_SEPARATION,
      ACE_DEHAZE_APP_MODE_TONE_REDISTRIBUTION
   ];
}

function aceDehazeAppSelectorLabel(mode) {
   mode = aceNormalizeDehazeAppMode(mode);
   if (mode === ACE_DEHAZE_APP_MODE_GAIN_MATCH)
      return "Dehaze Gain Match Diagnostic";
   if (mode === ACE_DEHAZE_APP_MODE_TONE_COLOR)
      return "Dehaze Tone + Color";
   if (mode === ACE_DEHAZE_APP_MODE_PROTECTED_TONE_COLOR)
      return ACE_DEBUG_CONTROLS_ENABLED ? "Dehaze Protected Tone + Color" : "Product Dehaze";
   if (mode === ACE_DEHAZE_APP_MODE_COLOR_SEPARATION)
      return "Dehaze Color Separation";
   if (mode === ACE_DEHAZE_APP_MODE_TONE_REDISTRIBUTION)
      return "Dehaze Tone Redistribution";
   return ACE_DEBUG_CONTROLS_ENABLED ? "Dehaze Current" : "Legacy Dehaze";
}

function aceDehazeAppSelectorIndexForMode(mode) {
   mode = aceNormalizeDehazeAppMode(mode);
   var modes = aceDehazeAppSelectorModes();
   for (var i = 0; i < modes.length; ++i)
      if (aceNormalizeDehazeAppMode(modes[i]) === mode)
         return i;
   return 0;
}

function aceDehazeAppSelectorModeForIndex(index) {
   var modes = aceDehazeAppSelectorModes();
   if (index < 0 || index >= modes.length)
      return ACE_DEHAZE_APP_MODE_DEFAULT;
   return modes[index];
}

function aceLogDehazeAppModePath(mode) {
   if (!ACE_DEVELOPMENT_CONSOLE_LOGS_ENABLED)
      return;
   mode = aceNormalizeDehazeAppMode(mode);
   var report = "[ACE] Dehaze internal app-test path | ace_version=" + ACE_VERSION +
      " mode=" + aceDehazeAppSelectorLabel(mode) +
      " algorithm_id=" + mode +
      " current_dehaze_default=true positive_dehaze_candidate_only=true negative_dehaze_preserved=true texture_unchanged=true clarity_unchanged=true";
   if (typeof console !== "undefined" && console && typeof console.writeln === "function")
      console.writeln(report);
   else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
      Console.writeln(report);
}

function aceNormalizeClarityMode(mode) {
   if (mode === ACE_CLARITY_MODE_LEGACY)
      return ACE_CLARITY_MODE_LEGACY;
   if (mode === ACE_CLARITY_MODE_V2)
      return ACE_CLARITY_MODE_V2;
   if (mode === ACE_CLARITY_MODE_V3)
      return ACE_CLARITY_MODE_V3_FULL;
   if (mode === ACE_CLARITY_MODE_V3_RAW)
      return ACE_CLARITY_MODE_V3_RAW;
   if (mode === ACE_CLARITY_MODE_V3_WEIGHTED)
      return ACE_CLARITY_MODE_V3_WEIGHTED;
   if (mode === ACE_CLARITY_MODE_V3_BACKGROUND)
      return ACE_CLARITY_MODE_V3_BACKGROUND;
   if (mode === ACE_CLARITY_MODE_V3_STARS)
      return ACE_CLARITY_MODE_V3_STARS;
   if (mode === ACE_CLARITY_MODE_V3_FULL)
      return ACE_CLARITY_MODE_V3_FULL;
   if (mode === ACE_CLARITY_MODE_FEATUREFIT_SHARED_LUMA_SAT_GATE)
      return ACE_CLARITY_MODE_FEATUREFIT_SHARED_LUMA_SAT_GATE;
   if (mode === ACE_CLARITY_MODE_FEATUREFIT_TWO_TERM_LUMA_SAT_GATE)
      return ACE_CLARITY_MODE_FEATUREFIT_TWO_TERM_LUMA_SAT_GATE;
   if (mode === ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT)
      return ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT;
   if (mode === ACE_CLARITY_MODE_DUALZONE_BROADBAND_BOOST_GUARDED)
      return ACE_CLARITY_MODE_DUALZONE_BROADBAND_BOOST_GUARDED;
   if (mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P30)
      return ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P30;
   if (mode === ACE_CLARITY_MODE_DUALZONE_SAFEZONE_EXTRA_DARKDUST)
      return ACE_CLARITY_MODE_DUALZONE_SAFEZONE_EXTRA_DARKDUST;
   if (mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P50)
      return ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P50;
   if (mode === ACE_CLARITY_MODE_FAILED_V5B_0945_CURRENT_DISABLED)
      return ACE_CLARITY_MODE_FAILED_V5B_0945_CURRENT_DISABLED;
   if (mode === ACE_CLARITY_MODE_V4)
      return ACE_CLARITY_MODE_V4;
   return ACE_CLARITY_MODE_DEFAULT;
}

function aceIsClarityV4Mode(mode) {
   mode = aceNormalizeClarityMode(mode);
   return mode === ACE_CLARITY_MODE_V4 ||
      mode === ACE_CLARITY_MODE_FEATUREFIT_SHARED_LUMA_SAT_GATE ||
      mode === ACE_CLARITY_MODE_FEATUREFIT_TWO_TERM_LUMA_SAT_GATE ||
      mode === ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT ||
      mode === ACE_CLARITY_MODE_DUALZONE_BROADBAND_BOOST_GUARDED ||
      mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P30 ||
      mode === ACE_CLARITY_MODE_DUALZONE_SAFEZONE_EXTRA_DARKDUST ||
      mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P50 ||
      mode === ACE_CLARITY_MODE_FAILED_V5B_0945_CURRENT_DISABLED;
}

function aceIsClarityFeatureFitMode(mode) {
   mode = aceNormalizeClarityMode(mode);
   return mode === ACE_CLARITY_MODE_FEATUREFIT_SHARED_LUMA_SAT_GATE ||
      mode === ACE_CLARITY_MODE_FEATUREFIT_TWO_TERM_LUMA_SAT_GATE;
}

function aceIsClarityDualZoneOptMode(mode) {
   mode = aceNormalizeClarityMode(mode);
   return mode === ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT;
}

function aceIsClarityDualZoneBoostMode(mode) {
   mode = aceNormalizeClarityMode(mode);
   return mode === ACE_CLARITY_MODE_DUALZONE_BROADBAND_BOOST_GUARDED ||
      mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P30 ||
      mode === ACE_CLARITY_MODE_DUALZONE_SAFEZONE_EXTRA_DARKDUST ||
      mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P50;
}

function aceClarityFeatureFitModeLabel(mode) {
   mode = aceNormalizeClarityMode(mode);
   if (mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P30)
      return "+DZBoost30";
   if (mode === ACE_CLARITY_MODE_DUALZONE_SAFEZONE_EXTRA_DARKDUST)
      return "+DZDust";
   if (mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P50)
      return "+DZBoost50";
   if (mode === ACE_CLARITY_MODE_DUALZONE_BROADBAND_BOOST_GUARDED)
      return "+DZBoost";
   if (mode === ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT)
      return "+DZOpt";
   if (mode === ACE_CLARITY_MODE_FEATUREFIT_TWO_TERM_LUMA_SAT_GATE)
      return "+FFit2";
   if (mode === ACE_CLARITY_MODE_FEATUREFIT_SHARED_LUMA_SAT_GATE)
      return "+FFit";
   if (mode === ACE_CLARITY_MODE_FAILED_V5B_0945_CURRENT_DISABLED)
      return "V5bX";
   return "V4";
}

function aceClaritySelectorModes() {
   return [
      ACE_CLARITY_MODE_V4,
      ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P50,
      ACE_CLARITY_MODE_DUALZONE_BROADBAND_BOOST_GUARDED,
      ACE_CLARITY_MODE_DUALZONE_SAFEZONE_EXTRA_DARKDUST,
      ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT
   ];
}

function aceClaritySelectorLabel(mode) {
   mode = aceNormalizeClarityMode(mode);
   if (mode === ACE_CLARITY_MODE_V4)
      return ACE_DEBUG_CONTROLS_ENABLED ? "V4 default" : "Legacy Clarity V4";
   if (mode === ACE_CLARITY_MODE_DUALZONE_BROADBAND_BOOST_GUARDED)
      return "+DZBoost";
   if (mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P30)
      return "+DZBoost30";
   if (mode === ACE_CLARITY_MODE_DUALZONE_SAFEZONE_EXTRA_DARKDUST)
      return "+DZDust";
   if (mode === ACE_CLARITY_MODE_DUALZONE_HIGHEND_1P50)
      return ACE_DEBUG_CONTROLS_ENABLED ? "+DZBoost50 lead" : "Product Clarity";
   if (mode === ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT)
      return "+DZOpt safe";
   if (mode === ACE_CLARITY_MODE_FEATUREFIT_SHARED_LUMA_SAT_GATE)
      return "+FFit";
   if (mode === ACE_CLARITY_MODE_FEATUREFIT_TWO_TERM_LUMA_SAT_GATE)
      return "+FFit2";
   if (mode === ACE_CLARITY_MODE_V3_FULL)
      return "V3F";
   if (mode === ACE_CLARITY_MODE_V2_DEPTH)
      return "V2 Depth";
   if (mode === ACE_CLARITY_MODE_LEGACY)
      return "V1";
   return "V4 default";
}

function aceClaritySelectorIndexForMode(mode) {
   mode = aceNormalizeClarityMode(mode);
   var modes = aceClaritySelectorModes();
   for (var i = 0; i < modes.length; ++i)
      if (aceNormalizeClarityMode(modes[i]) === mode)
         return i;
   return 0;
}

function aceClaritySelectorModeForIndex(index) {
   var modes = aceClaritySelectorModes();
   if (index < 0 || index >= modes.length)
      return ACE_CLARITY_MODE_DEFAULT;
   return modes[index];
}

function aceIsClarityV3Mode(mode) {
   mode = aceNormalizeClarityMode(mode);
   return mode === ACE_CLARITY_MODE_V3_RAW ||
      mode === ACE_CLARITY_MODE_V3_WEIGHTED ||
      mode === ACE_CLARITY_MODE_V3_BACKGROUND ||
      mode === ACE_CLARITY_MODE_V3_STARS ||
      mode === ACE_CLARITY_MODE_V3_FULL;
}

function aceNextClarityV3Mode(mode) {
   mode = aceNormalizeClarityMode(mode);
   if (mode === ACE_CLARITY_MODE_V3_FULL)
      return ACE_CLARITY_MODE_V3_RAW;
   if (mode === ACE_CLARITY_MODE_V3_RAW)
      return ACE_CLARITY_MODE_V3_WEIGHTED;
   if (mode === ACE_CLARITY_MODE_V3_WEIGHTED)
      return ACE_CLARITY_MODE_V3_BACKGROUND;
   if (mode === ACE_CLARITY_MODE_V3_BACKGROUND)
      return ACE_CLARITY_MODE_V3_STARS;
   if (mode === ACE_CLARITY_MODE_V3_STARS)
      return ACE_CLARITY_MODE_V3_FULL;
   return ACE_CLARITY_MODE_V3_FULL;
}

function aceClarityV3ModeLabel(mode) {
   mode = aceNormalizeClarityMode(mode);
   if (mode === ACE_CLARITY_MODE_V3_RAW)
      return "V3 Raw";
   if (mode === ACE_CLARITY_MODE_V3_WEIGHTED)
      return "V3 Weighted";
   if (mode === ACE_CLARITY_MODE_V3_BACKGROUND)
      return "V3 Background";
   if (mode === ACE_CLARITY_MODE_V3_STARS)
      return "V3 Stars";
   if (mode === ACE_CLARITY_MODE_V3_FULL)
      return "V3 Full";
   return "V3";
}

function aceClarityV3ButtonLabel(mode) {
   mode = aceNormalizeClarityMode(mode);
   if (mode === ACE_CLARITY_MODE_V3_RAW)
      return "V3R";
   if (mode === ACE_CLARITY_MODE_V3_WEIGHTED)
      return "V3W";
   if (mode === ACE_CLARITY_MODE_V3_BACKGROUND)
      return "V3B";
   if (mode === ACE_CLARITY_MODE_V3_STARS)
      return "V3S";
   if (mode === ACE_CLARITY_MODE_V3_FULL)
      return "V3F";
   return "V3";
}

function aceNormalizeClarityV2Tuning(tuning) {
   if (tuning === CLARITY_V2_TUNING_B)
      return CLARITY_V2_TUNING_B;
   if (tuning === CLARITY_V2_TUNING_C)
      return CLARITY_V2_TUNING_C;
   return CLARITY_V2_TUNING_A;
}

function aceNextClarityV2Tuning(tuning) {
   tuning = aceNormalizeClarityV2Tuning(tuning);
   if (tuning === CLARITY_V2_TUNING_A)
      return CLARITY_V2_TUNING_B;
   if (tuning === CLARITY_V2_TUNING_B)
      return CLARITY_V2_TUNING_C;
   return CLARITY_V2_TUNING_A;
}

function aceClarityV2TuningProfile(params) {
   var tuning = aceNormalizeClarityV2Tuning(params ? params.clarityV2Tuning : null);
   if (tuning === CLARITY_V2_TUNING_B)
      return {
         id: CLARITY_V2_TUNING_B,
         positiveGain: 0.55,
         glowSuppression: 0.65,
         minPositiveRetention: 0.25,
         ratioLimitEnable: false,
         ratioLimit: CLARITY_V2_POSITIVE_RATIO_LIMIT,
         baseMix: 1.00,
         depthMix: 1.00
      };
   if (tuning === CLARITY_V2_TUNING_C)
      return {
         id: CLARITY_V2_TUNING_C,
         positiveGain: 0.65,
         glowSuppression: 0.70,
         minPositiveRetention: 0.20,
         ratioLimitEnable: false,
         ratioLimit: CLARITY_V2_POSITIVE_RATIO_LIMIT,
         baseMix: 1.00,
         depthMix: 1.00
      };
   return {
      id: CLARITY_V2_TUNING_A,
      positiveGain: CLARITY_V2_POSITIVE_GAIN,
      glowSuppression: CLARITY_V2_POSITIVE_GLOW_SUPPRESSION,
      minPositiveRetention: CLARITY_V2_MIN_POSITIVE_RETENTION,
      ratioLimitEnable: CLARITY_V2_POSITIVE_RATIO_LIMIT_ENABLE,
      ratioLimit: CLARITY_V2_POSITIVE_RATIO_LIMIT,
      baseMix: 1.00,
      depthMix: 1.00
   };
}

function aceCopyAdvancedParams(params) {
   var out = new AdvancedParameters;
   if (!params)
      return out;
   out.textureScale = params.textureScale !== undefined ? params.textureScale : DEFAULT_TEXTURE_SCALE;
   out.clarityScale = params.clarityScale !== undefined ? params.clarityScale : DEFAULT_CLARITY_SCALE;
   out.clarityResponse = aceNormalizeClarityResponse(params.clarityResponse);
   out.dehazeVeilSize = params.dehazeVeilSize !== undefined ? params.dehazeVeilSize : DEFAULT_DEHAZE_VEIL_SIZE;
   out.dehazeVeilStrength = params.dehazeVeilStrength !== undefined ? params.dehazeVeilStrength : DEFAULT_DEHAZE_VEIL_STRENGTH;
   out.dehazeHighlightProtect = params.dehazeHighlightProtect !== undefined ? params.dehazeHighlightProtect : DEFAULT_DEHAZE_HIGHLIGHT_PROTECT;
   out.dehazeCompactProtect = params.dehazeCompactProtect !== undefined ? params.dehazeCompactProtect : DEFAULT_DEHAZE_COMPACT_PROTECT;
   out.dehazeVeilConfidence = params.dehazeVeilConfidence !== undefined ? params.dehazeVeilConfidence : DEFAULT_DEHAZE_VEIL_CONFIDENCE;
   out.dehazeColorRestore = params.dehazeColorRestore !== undefined ? params.dehazeColorRestore : DEFAULT_DEHAZE_COLOR_RESTORE;
   out.dehazeHazeAddBack = params.dehazeHazeAddBack !== undefined ? params.dehazeHazeAddBack : DEFAULT_DEHAZE_HAZE_ADD_BACK;
   out.skyProtectionStrength = params.skyProtectionStrength !== undefined ? params.skyProtectionStrength :
      (params.skyProtection !== undefined ? params.skyProtection : DEFAULT_SKY_PROTECTION_STRENGTH);
   out.darkPatchGuardStrength = params.darkPatchGuardStrength !== undefined ? params.darkPatchGuardStrength :
      (params.darkPatchGuard !== undefined ? params.darkPatchGuard : DEFAULT_DARK_PATCH_GUARD_STRENGTH);
   out.starProtectionStrength = params.starProtectionStrength !== undefined ? params.starProtectionStrength :
      (params.starProtection !== undefined ? params.starProtection : DEFAULT_STAR_PROTECTION_STRENGTH);
   out.haloProtectionStrength = params.haloProtectionStrength !== undefined ? params.haloProtectionStrength :
      (params.haloProtection !== undefined ? params.haloProtection : DEFAULT_HALO_PROTECTION_STRENGTH);
   out.protectionSoftness = params.protectionSoftness !== undefined ? params.protectionSoftness : DEFAULT_PROTECTION_SOFTNESS;
   out.overallProtectionStrength = params.overallProtectionStrength !== undefined ? params.overallProtectionStrength : DEFAULT_OVERALL_PROTECTION_STRENGTH;
   return out;
}

function aceAdvancedFactor(params, name) {
   var value = params && params[name] !== undefined ? params[name] : 100;
   return aceClamp(value / 100, 0.5, 1.5);
}

function aceAdvancedRadiusPx(params, name, baseRadius) {
   return Math.max(1, Math.round(baseRadius * aceAdvancedFactor(params, name)));
}

function aceAdvancedPercentFromRadius(valuePx, baseRadius) {
   return Math.round(100 * Math.max(1, valuePx) / Math.max(1, baseRadius));
}

function aceAdvancedAllowedWithOverall(allowed, advanced) {
   var strength = aceAdvancedFactor(advanced, "overallProtectionStrength");
   if (strength === 1)
      return aceClamp01(allowed);
   return aceClamp01(1 - aceClamp01(1 - allowed) * strength);
}

function aceAdvancedKey(params) {
   return JSON.stringify(aceCopyAdvancedParams(params));
}

function aceCopyProtectionOptions(options) {
   return {
      protectSky: !options || options.protectSky !== false,
      preventDark: !options || options.preventDark !== false,
      inputType: options && options.inputType ? options.inputType : "starless",
      protectStars: !options || options.protectStars !== false,
      protectHalos: !options || options.protectHalos !== false
   };
}

function aceCopyEditRecipe(recipe) {
   var out = [];
   if (!recipe)
      return out;
   for (var i = 0; i < recipe.length; ++i) {
      var edit = recipe[i];
      out.push({
         type: edit.type,
         params: aceCopyParams(edit.params),
         advanced: aceCopyAdvancedParams(edit.advanced),
         protection: aceCopyProtectionOptions(edit.protection),
         lassoPoints: aceCopyPointArray(edit.lassoPoints),
         feather: edit.feather || 0,
         inverted: !!edit.inverted,
         algorithmVersion: edit.algorithmVersion || ACE_VERSION
      });
   }
   return out;
}

function SourceImage() {
   this.viewId = "";
   this.width = 0;
   this.height = 0;
   this.version = 0;
}

function PreviewState() {
   this.zoomMode = "fit";
   this.zoomScale = 1;
   this.panX = 0;
   this.panY = 0;
   this.tool = "preview";
   this.showBefore = false;
   this.showMask = false;
   this.viewMode = "preview";
   this.mode = "draft";
   this.status = "No active image";
}

function PreviewCache() {
   this.source = new SourceImage;
   this.sourceRgb = null;
   this.draft = null;
   this.draftBitmap = null;
   this.workingRgb = null;
   this.workingBitmap = null;
   this.workingLayerCache = null;
   this.pendingRgb = null;
   this.pendingBitmap = null;
   this.pendingDisplayRgb = null;
   this.pendingDisplayBitmap = null;
   this.pendingDisplayGain = 1;
   this.pendingDisplayProxy = "";
   this.pendingActive = false;
   this.pendingDraftStateKey = "";
   this.protectedOverlayBitmap = null;
   this.protectedOverlaySourceBitmap = null;
   this.protectedOverlayLassoKey = "";
   this.currentBitmap = null;
   this.currentRgb = null;
   this.maskBitmap = null;
   this.lassoMaskBitmap = null;
   this.starMaskBitmap = null;
   this.allowedMaskBitmap = null;
   this.mapBitmaps = null;
   this.originalBitmap = null;
   this.draftLayerCache = null;
   this.detail = null;
   this.detailTarget = null;
   this.lowZoomLoupe = null;
   this.futureProcessedPreview = null;
   this.detailStamp = 0;
   this.lassoMaskKey = "";
   this.localBoundedDraftCache = null;
   this.localBoundedDraftCacheKey = "";
}

PreviewCache.prototype.clear = function() {
   this.source = new SourceImage;
   this.sourceRgb = null;
   this.draft = null;
   this.draftBitmap = null;
   this.workingRgb = null;
   this.workingBitmap = null;
   this.workingLayerCache = null;
   this.pendingRgb = null;
   this.pendingBitmap = null;
   this.pendingDisplayRgb = null;
   this.pendingDisplayBitmap = null;
   this.pendingDisplayGain = 1;
   this.pendingDisplayProxy = "";
   this.pendingActive = false;
   this.pendingDraftStateKey = "";
   this.protectedOverlayBitmap = null;
   this.protectedOverlaySourceBitmap = null;
   this.protectedOverlayLassoKey = "";
   this.currentBitmap = null;
   this.currentRgb = null;
   this.maskBitmap = null;
   this.lassoMaskBitmap = null;
   this.starMaskBitmap = null;
   this.allowedMaskBitmap = null;
   this.mapBitmaps = null;
   this.originalBitmap = null;
   this.draftLayerCache = null;
   this.detail = null;
   this.detailTarget = null;
   this.lowZoomLoupe = null;
   this.futureProcessedPreview = null;
   this.lassoMaskKey = "";
   this.localBoundedDraftCache = null;
   this.localBoundedDraftCacheKey = "";
   ++this.detailStamp;
};

function AppState() {
   this.params = new EffectParameters;
   this.globalParams = new EffectParameters;
   this.advanced = new AdvancedParameters;
   this.globalAdvanced = new AdvancedParameters;
   this.globalProtection = aceCopyProtectionOptions(null);
   this.preview = new PreviewState;
   this.cache = new PreviewCache;
   this.processor = new PreviewProcessor;
   this.lassoPoints = [];
   this.lassoInverted = false;
   this.lassoVersion = 0;
   this.undoStack = [];
   this.redoStack = [];
   this.editRecipe = [];
   this.fullResolutionCache = null;
   this.fullResolutionCacheKey = "";
   this.fullResolutionGlobalCache = null;
   this.fullResolutionGlobalCacheKey = "";
}

function aceTitleLabel(parent, text) {
   var label = new Label(parent);
   aceSetLabel(label, text, true, ACE_COLORS.text);
   label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   label.scaledMinHeight = 26;
   return label;
}

function aceGradientTitleControl(parent) {
   var title = new Control(parent);
   title.scaledMinHeight = ACE_HOST_IS_WINDOWS ? 34 : 30;
   title.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 340 : 390;
   title.maxWidth = ACE_HOST_IS_WINDOWS ? 340 : 390;
   title.aceRoomyWindows = false;
   title.setRoomyWindows = function(roomy) {
      this.aceRoomyWindows = !!roomy;
      if (ACE_HOST_IS_WINDOWS) {
         this.scaledMinWidth = this.aceRoomyWindows ? 450 : 350;
         this.maxWidth = this.aceRoomyWindows ? 450 : 350;
      }
      this.update();
   };
   title.onPaint = function() {
      var g = new Graphics(this);
      var f = new Font;
      f.pixelSize = ACE_HOST_IS_WINDOWS ? (this.aceRoomyWindows ? 36 : 30) : ACE_FONT_TITLE;
      f.bold = true;
      g.font = f;
      var y = Math.round((this.height + f.ascent - f.descent) * 0.5);
      var x = 0;
      var prefix = "Astro";
      g.pen = new Pen(ACE_COLORS.text);
      g.drawText(x, y, prefix);
      x += f.width(prefix) + Math.round(f.width(" ") * 1.75);
      var words = "Contrast Enhancer";
      var tones = [
         0xffffffff, 0xffececec, 0xffcccccc, 0xff9f9f9f,
         0xff666666, 0xff2f2f2f, 0xff000000, 0xff181818,
         0xff404040, 0xff747474, 0xffa5a5a5, 0xffcfcfcf,
         0xffeeeeee, 0xffffffff, 0xfff5f5f5, 0xffdddddd,
         0xffbdbdbd
      ];
      var outlineOffsets = [[-1, 0], [0, -1]];
      for (var i = 0; i < words.length; ++i) {
         var ch = words.charAt(i);
         if (ch !== " ") {
            for (var oo = 0; oo < outlineOffsets.length; ++oo) {
               g.pen = new Pen(0x88ffffff);
               g.drawText(x + outlineOffsets[oo][0], y + outlineOffsets[oo][1], ch);
            }
         }
         g.pen = new Pen(ch === " " ? ACE_COLORS.text : tones[Math.min(i, tones.length - 1)]);
         g.drawText(x, y, ch);
         x += f.width(ch);
      }
      var vf = new Font;
      vf.pixelSize = ACE_HOST_IS_WINDOWS ? (this.aceRoomyWindows ? ACE_FONT_BODY : ACE_FONT_SMALL) : ACE_FONT_BODY;
      vf.bold = false;
      g.font = vf;
      g.pen = new Pen(ACE_COLORS.accent);
      g.drawText(x + 12, y, ACE_VERSION);
      g.end();
   };
   return title;
}

function aceSectionTitleLabel(parent, text) {
   var label = new Label(parent);
   aceSetLabel(label, text, true, ACE_COLORS.sectionTitle);
   var font = new Font;
   font.pixelSize = ACE_FONT_SECTION;
   font.bold = true;
   label.font = font;
   label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   label.scaledMinHeight = 24;
   return label;
}

function aceHintLabel(parent, text) {
   var label = new Label(parent);
   aceSetLabel(label, text, false, ACE_COLORS.muted);
   label.wordWrapping = true;
   label.textAlignment = TextAlign_Left | TextAlign_Top;
   return label;
}

function aceApplySliderHintFont(label) {
   if (!label)
      return;
   var font = new Font;
   font.pixelSize = ACE_FONT_HINT;
   font.bold = false;
   label.font = font;
}

function aceButton(parent, text, tooltip, callback) {
   var button = new Control(parent);
   button.aceText = text;
   button.aceCallback = callback || function() {
      aceMessage(text + " will be implemented in a later phase.", ACE_TOOL_NAME + " " + ACE_VERSION);
   };
   button.aceVisualEnabled = true;
   aceFixHeight(button, ACE_BUTTON_MIN_HEIGHT);
   button.toolTip = tooltip || text;
   button.onPaint = function() {
      var g = new Graphics(this);
      var isOn = this.aceVisualEnabled !== false;
      var isActive = this.aceActive === true;
      var fill = isActive ? 0xff4c4f3c : (isOn ? ACE_COLORS.inset : 0xff2c2c2c);
      var border = isActive ? ACE_COLORS.active : (isOn ? ACE_COLORS.line : 0xff555555);
      var textColor = isActive ? ACE_COLORS.sectionTitle : (isOn ? ACE_COLORS.text : 0xffa8a8a8);
      if (isOn && this.aceTone === "primary") {
         fill = isActive ? 0xff355849 : 0xff203b33;
         border = 0xff72d8b6;
         textColor = 0xffd8fff1;
      } else if (isOn && this.aceTone === "danger") {
         fill = isActive ? 0xff5a3931 : 0xff3a2724;
         border = 0xffffa083;
         textColor = 0xffffdfd2;
      } else if (isOn && this.aceTone === "gold") {
         fill = isActive ? 0xff5f542f : 0xff3a321e;
         border = ACE_COLORS.sectionTitle;
         textColor = ACE_COLORS.sectionTitle;
      } else if (isOn && this.aceTone === "zoom") {
         fill = isActive ? 0xff21475d : 0xff18384a;
         border = 0xff79cfff;
         textColor = 0xffd7f2ff;
      }
      g.brush = new Brush(fill);
      g.pen = new Pen(border);
      g.drawRect(this.boundsRect);
      var f = new Font;
      f.pixelSize = this.aceTone === "zoom" ? ACE_FONT_BUTTON + 2 : ACE_FONT_BUTTON;
      f.bold = isActive || this.aceTone === "zoom";
      g.font = f;
      g.pen = new Pen(textColor);
      var label = this.aceText;
      var tw = g.font.width(label);
      while (tw > this.width - 8 && f.pixelSize > 9) {
         f.pixelSize -= 1;
         g.font = f;
         tw = g.font.width(label);
      }
      while (tw > this.width - 8 && label.length > 4) {
         label = label.substring(0, label.length - 2);
         tw = g.font.width(label + ".");
      }
      if (label !== this.aceText)
         label += ".";
      var x = Math.max(4, Math.round((this.width - g.font.width(label)) * 0.5));
      var y = Math.round((this.height + g.font.ascent - g.font.descent) * 0.5) - 1;
      g.drawText(x, y, label);
      g.end();
   };
   button.onMousePress = function() {
      if (this.aceVisualEnabled !== false && typeof this.aceCallback === "function")
         this.aceCallback();
   };
   button.setVisualEnabled = function(enabled) {
      this.aceVisualEnabled = !!enabled;
      this.update();
   };
   button.setActive = function(active) {
      this.aceActive = !!active;
      this.update();
   };
   return button;
}

function aceSmallButton(parent, text, tooltip, callback) {
   var button = aceButton(parent, text, tooltip, callback);
   button.scaledMinWidth = ACE_SMALL_BUTTON_WIDTH;
   return button;
}

function aceHelpButton(parent, title, text) {
   var button = aceButton(parent, "?", text, null);
   button.aceText = "?";
   button.aceHelpText = text;
   button.aceHelpTarget = null;
   button.aceVisualEnabled = true;
   button.scaledMinWidth = 18;
   button.toolTip = text;
   button.onPaint = function() {
      var g = new Graphics(this);
      var held = this.aceHeld === true;
      g.brush = new Brush(held ? 0xffffffff : 0xff111111);
      g.pen = new Pen(held ? 0xff111111 : 0xffffffff, 1);
      g.drawRect(this.boundsRect);
      var f = new Font;
      f.pixelSize = ACE_FONT_SMALL;
      f.bold = true;
      g.font = f;
      g.pen = new Pen(held ? 0xff000000 : 0xffffffff);
      var x = Math.max(2, Math.round((this.width - f.width("?")) * 0.5));
      var y = Math.round((this.height + f.ascent - f.descent) * 0.5);
      g.drawText(x, y, "?");
      g.end();
   };
   button.onMousePress = function() {
      this.aceHeld = true;
      if (this.aceHelpTarget) {
         this.aceHelpTarget.text = this.aceHelpText || "";
         this.aceHelpTarget.visible = true;
      }
      this.update();
   };
   button.onMouseRelease = function() {
      this.aceHeld = false;
      if (this.aceHelpTarget) {
         this.aceHelpTarget.text = "";
         this.aceHelpTarget.visible = false;
      }
      this.update();
   };
   return button;
}

function aceToolbarSeparator(parent) {
   var separator = new Control(parent);
   separator.scaledMinWidth = 8;
   aceFixHeight(separator, ACE_TOOLBAR_HEIGHT);
   separator.onPaint = function() {
      var g = new Graphics(this);
      var x = Math.round(this.width * 0.5);
      g.pen = new Pen(ACE_COLORS.sectionTitle, 1);
      g.drawLine(x - 3, 5, x - 3, this.height - 5);
      g.pen = new Pen(ACE_COLORS.lineDim, 1);
      g.drawLine(x + 3, 5, x + 3, this.height - 5);
      g.end();
   };
   return separator;
}

function aceToolbarLabel(parent, text, color) {
   var label = new Label(parent);
   label.text = text;
   var labelColor = color || ACE_COLORS.sectionTitle;
   label.textColor = labelColor;
   label.foregroundColor = labelColor;
   label.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   label.scaledMinWidth = 36;
   var font = new Font;
   font.pixelSize = ACE_FONT_SMALL;
   font.bold = true;
   label.font = font;
   return label;
}

function aceCheck(parent, text, checked, callback) {
   var check = new CheckBox(parent);
   check.text = text;
   check.checked = !!checked;
   check.textColor = ACE_COLORS.text;
   check.foregroundColor = ACE_COLORS.text;
   check.scaledMinHeight = 27;
   var font = new Font;
   font.pixelSize = ACE_FONT_BODY;
   check.font = font;
   check.onCheck = callback || function() {};
   return check;
}

function aceRadio(parent, text, checked, callback) {
   var radio = new RadioButton(parent);
   radio.text = text;
   radio.checked = !!checked;
   radio.textColor = ACE_COLORS.text;
   radio.foregroundColor = ACE_COLORS.text;
   radio.scaledMinHeight = 27;
   var font = new Font;
   font.pixelSize = ACE_FONT_BODY;
   radio.font = font;
   radio.onCheck = callback || function() {};
   return radio;
}

function aceSection(parent, title) {
   var box = new GroupBox(parent);
   box.title = "";
   box.textColor = ACE_COLORS.text;
   box.foregroundColor = ACE_COLORS.text;
   acePaintPanel(box, ACE_COLORS.panel, ACE_COLORS.lineDim);
   box.sizer = new VerticalSizer;
   box.sizer.margin = ACE_PANEL_MARGIN;
   box.sizer.spacing = ACE_SECTION_SPACING;
   box.sizer.add(aceSectionTitleLabel(box, title));
   return box;
}

function aceCompactSection(parent, title) {
   var box = new GroupBox(parent);
   box.title = "";
   box.textColor = ACE_COLORS.text;
   box.foregroundColor = ACE_COLORS.text;
   acePaintPanel(box, ACE_COLORS.panel, ACE_COLORS.lineDim);
   box.sizer = new VerticalSizer;
   box.sizer.margin = ACE_ADVANCED_PANEL_MARGIN;
   box.sizer.spacing = ACE_ADVANCED_SECTION_SPACING;
   var titleRow = new HorizontalSizer;
   titleRow.spacing = 6;
   var titleLabel = aceSectionTitleLabel(box, title);
   titleLabel.scaledMinHeight = 24;
   titleLabel.maxHeight = 24;
   titleRow.add(titleLabel);
   titleRow.addStretch();
   box.aceTitleRow = titleRow;
   box.sizer.add(titleRow);
   return box;
}

function aceCompactStatusLine(parent, text, color) {
   var row = new Control(parent);
   row.aceText = text;
   row.aceColor = color || ACE_COLORS.active;
   row.aceBold = false;
   row.aceFill = ACE_COLORS.inset;
   row.setStatus = function(nextText, nextColor, nextBold, nextFill) {
      this.aceText = nextText;
      if (nextColor)
         this.aceColor = nextColor;
      this.aceBold = !!nextBold;
      this.aceFill = nextFill || ACE_COLORS.inset;
      this.update();
   };
   aceFixHeight(row, ACE_HOST_IS_WINDOWS ? 24 : 22);
   row.onPaint = function() {
      var g = new Graphics(this);
      g.brush = new Brush(this.aceFill || ACE_COLORS.inset);
      g.pen = new Pen(ACE_COLORS.lineDim);
      g.drawRect(this.boundsRect);
      g.brush = new Brush(this.aceColor);
      g.pen = new Pen(this.aceColor);
      g.drawRect(new Rect(6, 6, 12, Math.max(7, this.height - 6)));
      var f = new Font;
      f.pixelSize = ACE_FONT_SMALL;
      f.bold = !!this.aceBold;
      g.font = f;
      g.pen = new Pen(ACE_COLORS.text);
      var label = aceFitTextToWidth(f, this.aceText, Math.max(12, this.width - 22));
      g.drawText(18, Math.round((this.height + f.ascent - f.descent) * 0.5), label);
      g.end();
   };
   return row;
}

function aceStatusTile(parent, title, body, color) {
   var tile = new Control(parent);
   tile.scaledMinHeight = 52;
   tile.aceTitle = title;
   tile.aceBody = body;
   tile.aceColor = color || ACE_COLORS.active;
   tile.onPaint = function() {
      var g = new Graphics(this);
      g.brush = new Brush(ACE_COLORS.inset);
      g.pen = new Pen(ACE_COLORS.lineDim);
      g.drawRect(this.boundsRect);
      g.brush = new Brush(this.aceColor);
      g.pen = new Pen(this.aceColor);
      g.drawRect(new Rect(6, 8, 12, this.height - 8));
      var f1 = new Font;
      f1.pixelSize = ACE_FONT_SMALL;
      f1.bold = true;
      g.font = f1;
      g.pen = new Pen(ACE_COLORS.text);
      g.drawText(24, 26, this.aceTitle);
      var f2 = new Font;
      f2.pixelSize = ACE_FONT_SMALL;
      g.font = f2;
      g.pen = new Pen(ACE_COLORS.muted);
      g.drawText(24, 50, this.aceBody);
      g.end();
   };
   return tile;
}

function aceCreateColorSlider(parent, minValue, maxValue, defaultValue, knobColor) {
   var slider = new Control(parent);
   slider.minValue = minValue;
   slider.maxValue = maxValue;
   slider.value = defaultValue;
   slider.knobColor = knobColor || ACE_COLORS.accent;
   slider.dragging = false;
   slider.resetClicked = false;
   slider.hasZeroReset = minValue < 0 && maxValue > 0;
   slider.aceHideInlineReset = false;
   slider.scaledMinHeight = 28;
   slider.minWidth = 192;
   slider.resetZoneLeft = function() {
      return (this.hasZeroReset && !this.aceHideInlineReset) ? Math.max(0, this.width - 26) : this.width + 1;
   };
   slider.valueFromX = function(x) {
      var pad = 9;
      var x1 = (this.hasZeroReset && !this.aceHideInlineReset) ? Math.max(pad + 1, this.resetZoneLeft() - 10) : this.width - pad;
      var usable = Math.max(1, x1 - pad);
      var t = aceClamp01((x - pad) / usable);
      return Math.round(this.minValue + t * (this.maxValue - this.minValue));
   };
   slider.applyValue = function(value) {
      var next = aceClamp(Math.round(value), this.minValue, this.maxValue);
      if (next === this.value)
         return;
      this.value = next;
      this.update();
      if (typeof this.onValueUpdated === "function")
         this.onValueUpdated(next);
   };
   slider.setValue = function(value) {
      this.value = aceClamp(Math.round(value), this.minValue, this.maxValue);
      this.update();
   };
   slider.onPaint = function() {
      var g = new Graphics(this);
      var pad = 9;
      var y = Math.round(this.height * 0.5);
      var x0 = pad;
      var x1 = (this.hasZeroReset && !this.aceHideInlineReset) ? Math.max(x0 + 1, this.resetZoneLeft() - 10) : Math.max(x0 + 1, this.width - pad);
      var t = (this.value - this.minValue) / Math.max(1, this.maxValue - this.minValue);
      var kx = Math.round(x0 + aceClamp01(t) * (x1 - x0));
      var zeroT = (0 - this.minValue) / Math.max(1, this.maxValue - this.minValue);
      var zeroX = Math.round(x0 + aceClamp01(zeroT) * (x1 - x0));
      if (this.acePrecisionMain) {
         var accent = this.enabled ? this.knobColor : ACE_COLORS.lineDim;
         var trackTop = y - 5;
         var trackBottom = y + 5;
         g.brush = new Brush(ACE_COLORS.controlBayRail);
         g.pen = new Pen(ACE_COLORS.controlBayRailEdge, 1);
         g.drawRect(new Rect(x0, trackTop, x1, trackBottom));
         g.pen = new Pen(0x68596f7e, 1);
         g.drawLine(x0 + 1, trackTop + 1, x1 - 1, trackTop + 1);
         g.pen = new Pen(0x70000000, 1);
         g.drawLine(x0 + 1, trackBottom - 1, x1 - 1, trackBottom - 1);
         g.pen = new Pen(0xff1b2a35, 2);
         g.drawLine(x0 + 2, y, x1 - 2, y);
         var normal0 = x0 + Math.round((x1 - x0) * aceClamp01((-50 - this.minValue) / Math.max(1, this.maxValue - this.minValue)));
         var normal1 = x0 + Math.round((x1 - x0) * aceClamp01((50 - this.minValue) / Math.max(1, this.maxValue - this.minValue)));
         g.pen = new Pen(0x28000000 | (accent & 0x00ffffff), 2);
         g.drawLine(normal0, y, normal1, y);
         var active0 = Math.min(zeroX, kx);
         var active1 = Math.max(zeroX, kx);
         if (active1 > active0 + 1) {
            g.pen = new Pen(0x32000000 | (accent & 0x00ffffff), 9);
            g.drawLine(active0, y, active1, y);
            g.pen = new Pen(0xb8000000 | (accent & 0x00ffffff), 5);
            g.drawLine(active0, y, active1, y);
            g.pen = new Pen(0xff000000 | (accent & 0x00ffffff), 2);
            g.drawLine(active0, y, active1, y);
         }
         var tickStep = Math.max(1, Math.round((this.maxValue - this.minValue) / 8));
         for (var mt = this.minValue; mt <= this.maxValue; mt += tickStep) {
            if (mt === this.minValue || mt === this.maxValue || mt === 0)
               continue;
            var minorT = (mt - this.minValue) / Math.max(1, this.maxValue - this.minValue);
            var minorX = x0 + Math.round(aceClamp01(minorT) * (x1 - x0));
            g.pen = new Pen(0x6260707c, 1);
            g.drawLine(minorX, y - 6, minorX, y + 6);
         }
         var ticks = [this.minValue, Math.round(this.minValue * 0.5), 0, Math.round(this.maxValue * 0.5), this.maxValue];
         for (var ti = 0; ti < ticks.length; ++ti) {
            var tickValue = ticks[ti];
            if (tickValue < this.minValue || tickValue > this.maxValue)
               continue;
            var tickT = (tickValue - this.minValue) / Math.max(1, this.maxValue - this.minValue);
            var tx = x0 + Math.round(aceClamp01(tickT) * (x1 - x0));
            var major = tickValue === 0 || tickValue === this.minValue || tickValue === this.maxValue;
            if (tickValue === 0) {
               g.pen = new Pen(0x70b99734, 3);
               g.drawLine(tx, y - 13, tx, y + 13);
               g.pen = new Pen(0xffffc24a, 1);
               g.drawLine(tx, y - 14, tx, y + 14);
            } else {
               g.pen = new Pen(major ? ACE_COLORS.controlBayTickMajor : ACE_COLORS.controlBayTick, major ? 2 : 1);
               g.drawLine(tx, y - (major ? 11 : 8), tx, y + (major ? 11 : 8));
            }
         }
         var tickFont = new Font;
         tickFont.pixelSize = ACE_FONT_HINT;
         g.font = tickFont;
         g.pen = new Pen(ACE_COLORS.controlBayLabel);
         var labelY = Math.max(9, y - 15);
         var minLabel = String(this.minValue);
         g.drawText(x0 + 8, labelY, minLabel);
         g.drawText(Math.max(x0, zeroX - Math.round(tickFont.width("0") * 0.5)), labelY, "0");
         var maxLabel = this.maxValue > 0 ? "+" + String(this.maxValue) : String(this.maxValue);
         g.drawText(Math.max(x0, x1 - tickFont.width(maxLabel) - 8), labelY, maxLabel);
         g.brush = new Brush(0x22000000 | (accent & 0x00ffffff));
         g.pen = new Pen(0x48000000 | (accent & 0x00ffffff), 1);
         g.drawEllipse(kx - 14, y - 14, kx + 14, y + 14);
         g.brush = new Brush(accent);
         g.pen = new Pen(0xffeef3f8, 1);
         g.drawEllipse(kx - 9, y - 9, kx + 9, y + 9);
         g.brush = new Brush(0x36ffffff);
         g.pen = new Pen(0x00ffffff);
         g.drawEllipse(kx - 5, y - 6, kx + 3, y + 2);
         g.pen = new Pen(0x90000000, 1);
         g.drawEllipse(kx - 9, y - 9, kx + 9, y + 9);
      } else {
         g.pen = new Pen(0xffb7b7b7, 3);
         g.drawLine(x0, y, x1, y);
         if (this.hasZeroReset) {
            g.pen = new Pen(ACE_COLORS.sectionTitle, 1);
            g.drawLine(zeroX, y - 8, zeroX, y + 8);
         }
         g.pen = new Pen(this.enabled ? this.knobColor : ACE_COLORS.lineDim, 4);
         g.drawLine(x0, y, kx, y);
         g.brush = new Brush(this.enabled ? this.knobColor : 0xff777777);
         g.pen = new Pen(0xfff1f1f1, 1);
         g.drawEllipse(kx - 7, y - 7, kx + 7, y + 7);
      }
      if (this.hasZeroReset && !this.aceHideInlineReset) {
         var cx = this.width - 13;
         var cy = y;
         var activeReset = this.value !== 0;
         if (this.acePrecisionMain) {
            g.brush = new Brush(activeReset ? 0xff302818 : (this.aceControlBay ? 0xff151b22 : 0xff252525));
            g.pen = new Pen(activeReset ? ACE_COLORS.sectionTitle : 0xff6f7480, 1);
            g.drawRect(new Rect(cx - 12, cy - 10, cx + 12, cy + 10));
            var rf = new Font;
            rf.pixelSize = 14;
            rf.bold = true;
            g.font = rf;
            var glyph = "\u21ba";
            g.pen = new Pen(activeReset ? ACE_COLORS.sectionTitle : 0xffc4c8d0);
            g.drawText(cx - Math.round(rf.width(glyph) * 0.5), cy + 5, glyph);
         } else {
            g.brush = new Brush(activeReset ? 0xff3a3220 : 0xff262626);
            g.pen = new Pen(activeReset ? ACE_COLORS.sectionTitle : 0xff777777, 1);
            g.drawEllipse(cx - 8, cy - 8, cx + 8, cy + 8);
            g.pen = new Pen(activeReset ? ACE_COLORS.sectionTitle : 0xffb0b0b0, 2);
            g.drawLine(cx - 4, cy - 4, cx + 4, cy + 4);
            g.drawLine(cx - 4, cy + 4, cx + 4, cy - 4);
         }
      }
      g.end();
   };
   slider.onMousePress = function(x, y) {
      if (!this.enabled)
         return;
      if (this.hasZeroReset && x >= this.resetZoneLeft()) {
         this.dragging = false;
         this.resetClicked = true;
         if (typeof this.onZeroReset === "function")
            this.onZeroReset();
         else
            this.applyValue(0);
         this.update();
         return;
      }
      this.resetClicked = false;
      this.dragging = true;
      this.applyValue(this.valueFromX(x));
   };
   slider.onMouseMove = function(x, y) {
      if (!this.enabled || !this.dragging)
         return;
      this.applyValue(this.valueFromX(x));
   };
   slider.onMouseRelease = function(x, y) {
      if (!this.enabled)
         return;
      if (this.resetClicked) {
         this.resetClicked = false;
         this.dragging = false;
         return;
      }
      if (!this.dragging)
         return;
      this.applyValue(this.valueFromX(x));
      this.dragging = false;
      if (typeof this.onDragFinished === "function")
         this.onDragFinished(this.value);
   };
   return slider;
}

function aceSliderDisplayText(host, value) {
   var v = Math.round(value);
   var prefix = host && host.aceSignedDisplay && v > 0 ? "+" : "";
   return prefix + String(v) + ((host && host.suffix) ? host.suffix : "");
}

function aceCreateMainSliderResetControl(parent, host, labelText, accentColor) {
   var control = new Control(parent);
   control.aceHost = host;
   control.aceLabelText = labelText || "slider";
   control.aceAccentColor = accentColor || ACE_COLORS.sectionTitle;
   control.scaledMinWidth = 24;
   control.maxWidth = 26;
   control.toolTip = "Reset " + control.aceLabelText + " to 0";
   control.onPaint = function() {
      var active = this.aceHost && this.aceHost.value !== 0;
      var g = new Graphics(this);
      var cx = Math.round(this.width * 0.5);
      var cy = Math.round(this.height * 0.5);
      var border = active ? (0xc0000000 | (this.aceAccentColor & 0x00ffffff)) : 0xff68737d;
      var textColor = active ? (0xe0000000 | (this.aceAccentColor & 0x00ffffff)) : 0xff8f9aa4;
      g.brush = new Brush(active ? 0x20101820 : 0x00101820);
      g.pen = new Pen(border, 1);
      g.drawEllipse(cx - 8, cy - 8, cx + 8, cy + 8);
      var f = new Font;
      f.pixelSize = 12;
      f.bold = true;
      g.font = f;
      var glyph = "\u21ba";
      g.pen = new Pen(textColor);
      g.drawText(cx - Math.round(f.width(glyph) * 0.5), cy + 4, glyph);
      g.end();
   };
   control.onMousePress = function() {
      if (!this.enabled || !this.aceHost)
         return;
      this.aceHost.setValue(0);
      if (typeof this.aceHost.onPreviewValueUpdated === "function")
         this.aceHost.onPreviewValueUpdated(0, false);
      if (this.aceHost.sliderControl)
         this.aceHost.sliderControl.update();
      this.update();
   };
   return control;
}

function aceCreateValueSlider(parent, labelText, hintText, minValue, maxValue, defaultValue, suffix, knobColor, helpText) {
   var host = new Control(parent);
   host.value = defaultValue;
   host.suffix = suffix || "";
   host.aceSignedDisplay = false;
   var isMainEnhancement = parent && parent.aceMainEnhancementBay;
   if (helpText) {
      host.aceExpandedScaledMinHeight = 24;
      host.aceExpandedMaxHeight = 60;
      host.scaledMinHeight = host.aceExpandedScaledMinHeight;
      host.minHeight = host.aceExpandedScaledMinHeight;
      host.maxHeight = host.aceExpandedMaxHeight;
      host.sizer = new VerticalSizer;
      host.sizer.margin = 0;
      host.sizer.spacing = 2;
      var compactRow = new HorizontalSizer;
      compactRow.spacing = 2;

      host.label = new Label(host);
      aceSetLabel(host.label, labelText, true, ACE_COLORS.text);
      host.label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      host.label.scaledMinWidth = 72;

      host.helpLine = aceHintLabel(host, "");
      host.helpLine.visible = false;
      host.helpLine.wordWrapping = true;
      host.helpLine.scaledMinHeight = 34;
      host.helpLine.backgroundColor = ACE_COLORS.inset;
      host.helpLine.foregroundColor = ACE_COLORS.text;
      host.helpButton = aceHelpButton(host, labelText, helpText);
      host.helpButton.aceHelpTarget = host.helpLine;
      host.helpButton.scaledMinWidth = 14;

      host.valueEdit = new Edit(host);
      host.valueEdit.setFixedWidth(ACE_VALUE_WIDTH);
      host.valueEdit.text = aceSliderDisplayText(host, defaultValue);
      host.valueEdit.toolTip = "Enter an exact value.";
      var compactEditFont = new Font;
      compactEditFont.pixelSize = ACE_FONT_OVERLAY_BODY;
      host.valueEdit.font = compactEditFont;

      host.sliderControl = aceCreateColorSlider(host, minValue, maxValue, defaultValue, knobColor);
      host.sliderControl.minWidth = 92;
      host.hint = aceHintLabel(host, "");
      host.hint.visible = false;

      host.setValue = function(value) {
         this.value = aceClamp(Math.round(value), minValue, maxValue);
         this.sliderControl.setValue(this.value);
         this.valueEdit.text = aceSliderDisplayText(this, this.value);
         this.update();
      };

      host.setEnabled = function(enabled) {
         this.enabled = enabled;
         this.sliderControl.enabled = enabled;
         this.label.enabled = enabled;
         this.valueEdit.enabled = enabled;
         this.hint.enabled = enabled;
         this.sliderControl.update();
      };

      host.sliderControl.onValueUpdated = function(value) {
         host.value = Math.round(value);
         host.valueEdit.text = aceSliderDisplayText(host, host.value);
         host.update();
         if (typeof host.onPreviewValueUpdated === "function")
            host.onPreviewValueUpdated(host.value, this.dragging);
      };
      host.sliderControl.onZeroReset = function() {
         host.setValue(0);
         if (typeof host.onPreviewValueUpdated === "function")
            host.onPreviewValueUpdated(0, false);
      };
      host.sliderControl.onDragFinished = function(value) {
         host.value = Math.round(value);
         host.valueEdit.text = aceSliderDisplayText(host, host.value);
         host.update();
         if (typeof host.onPreviewDragFinished === "function")
            host.onPreviewDragFinished(host.value);
      };
      host.valueEdit.onEditCompleted = function() {
         var value = parseFloat(host.valueEdit.text);
         if (isNaN(value)) {
            host.setValue(host.value);
            return;
         }
         host.setValue(value);
         if (typeof host.onPreviewValueUpdated === "function")
            host.onPreviewValueUpdated(host.value, false);
      };
      host.valueEdit.onReturn = host.valueEdit.onEditCompleted;

      compactRow.add(host.label);
      compactRow.add(host.helpButton);
      compactRow.add(host.valueEdit);
      compactRow.add(host.sliderControl, 100);
      host.sizer.add(compactRow);
      host.sizer.add(host.helpLine);
      return host;
   }
   host.aceExpandedScaledMinHeight = isMainEnhancement ? 82 : 56;
   host.scaledMinHeight = host.aceExpandedScaledMinHeight;
   host.minHeight = host.aceExpandedScaledMinHeight;
   host.sizer = new VerticalSizer;
   host.sizer.margin = 0;
   host.sizer.spacing = isMainEnhancement ? 1 : 2;

   var top = new HorizontalSizer;
   top.spacing = 4;

   host.label = new Label(host);
   aceSetLabel(host.label, labelText, true, ACE_COLORS.text);
   host.label.minWidth = ACE_LABEL_WIDTH;
   host.label.textAlignment = TextAlign_Left | TextAlign_VertCenter;

   top.add(host.label);
   host.helpLine = aceHintLabel(host, "");
   host.helpLine.visible = false;
   host.helpLine.wordWrapping = true;
   host.helpLine.scaledMinHeight = 34;
   if (helpText) {
      host.helpButton = aceHelpButton(host, labelText, helpText);
      host.helpButton.aceHelpTarget = host.helpLine;
      top.add(host.helpButton);
   }
   top.addStretch();

   host.sliderControl = aceCreateColorSlider(host, minValue, maxValue, defaultValue, knobColor);
   host.valueEdit = new Edit(host);
   host.valueEdit.setFixedWidth(ACE_VALUE_WIDTH);
   host.valueEdit.text = aceSliderDisplayText(host, defaultValue);
   host.valueEdit.toolTip = "Enter an exact value.";
   var editFont = new Font;
   editFont.pixelSize = ACE_FONT_OVERLAY_BODY;
   host.valueEdit.font = editFont;
   if (isMainEnhancement) {
      host.valueEdit.backgroundColor = ACE_COLORS.controlBayValue;
      host.valueEdit.foregroundColor = ACE_COLORS.text;
      host.valueEdit.textColor = ACE_COLORS.text;
   }

   if (isMainEnhancement) {
      top.add(host.valueEdit);
      host.resetControl = aceCreateMainSliderResetControl(host, host, labelText, knobColor);
      top.add(host.resetControl);
   }

   var controlRow = new HorizontalSizer;
   controlRow.spacing = 5;
   if (!isMainEnhancement)
      controlRow.add(host.valueEdit);
   controlRow.add(host.sliderControl, 100);

   host.hint = aceHintLabel(host, hintText);
   aceApplySliderHintFont(host.hint);
   host.hint.scaledMinHeight = 16;

   host.setValue = function(value) {
      this.value = aceClamp(Math.round(value), minValue, maxValue);
      this.sliderControl.setValue(this.value);
      this.valueEdit.text = aceSliderDisplayText(this, this.value);
      if (this.resetControl)
         this.resetControl.update();
      this.update();
   };

   host.setEnabled = function(enabled) {
      this.enabled = enabled;
      this.sliderControl.enabled = enabled;
      this.label.enabled = enabled;
      this.valueEdit.enabled = enabled;
      if (this.resetControl)
         this.resetControl.enabled = enabled;
      this.hint.enabled = enabled;
      this.sliderControl.update();
   };

   host.sliderControl.onValueUpdated = function(value) {
      host.value = Math.round(value);
      host.valueEdit.text = aceSliderDisplayText(host, host.value);
      if (host.resetControl)
         host.resetControl.update();
      host.update();
      if (typeof host.onPreviewValueUpdated === "function")
         host.onPreviewValueUpdated(host.value, this.dragging);
   };
   host.sliderControl.onZeroReset = function() {
      host.setValue(0);
      if (typeof host.onPreviewValueUpdated === "function")
         host.onPreviewValueUpdated(0, false);
   };
   host.sliderControl.onDragFinished = function(value) {
      host.value = Math.round(value);
      host.valueEdit.text = aceSliderDisplayText(host, host.value);
      if (host.resetControl)
         host.resetControl.update();
      host.update();
      if (typeof host.onPreviewDragFinished === "function")
         host.onPreviewDragFinished(host.value);
   };
   host.valueEdit.onEditCompleted = function() {
      var value = parseFloat(host.valueEdit.text);
      if (isNaN(value)) {
         host.setValue(host.value);
         return;
      }
      host.setValue(value);
      if (typeof host.onPreviewValueUpdated === "function")
         host.onPreviewValueUpdated(host.value, false);
   };
   host.valueEdit.onReturn = host.valueEdit.onEditCompleted;

   host.sizer.add(top);
   host.sizer.add(controlRow);
   host.sizer.add(host.helpLine);
   host.sizer.add(host.hint);
   return host;
}

function aceConfigureMainEnhancementSlider(host, accentColor) {
   if (!host || !host.sliderControl)
      return;
   host.aceSignedDisplay = true;
   host.aceExpandedScaledMinHeight = 82;
   host.scaledMinHeight = 82;
   host.minHeight = 82;
   host.aceMainAccent = accentColor;
   host.onPaint = function() {
      var active = this.value !== 0;
      var g = new Graphics(this);
      g.brush = new Brush(ACE_COLORS.controlBayBlueDeep);
      g.pen = new Pen(ACE_COLORS.controlBayBlueDeep, 1);
      g.drawRect(this.boundsRect);
      g.brush = new Brush(active ? 0x561b3b59 : 0x361b3b59);
      g.drawRect(new Rect(6, 6, Math.max(7, this.width - 6), Math.max(8, this.height - 8)));
      g.brush = new Brush(active ? 0x34284b6d : 0x20284b6d);
      g.drawRect(new Rect(Math.round(this.width * 0.38), 8, Math.max(9, this.width - 10), Math.max(9, this.height - 12)));
      var step = 18;
      for (var gx = -this.height; gx < this.width; gx += step) {
         g.pen = new Pen(active ? 0x241b3b59 : 0x181b3b59, 2);
         g.drawLine(gx, Math.max(0, this.height - 8), gx + this.height, 8);
      }
      if (active) {
         g.brush = new Brush(0x1c000000 | (this.aceMainAccent & 0x00ffffff));
         g.pen = new Pen(0x00101820);
         g.drawRect(new Rect(8, 12, Math.max(9, this.width - 8), Math.max(13, this.height - 10)));
      }
      g.pen = new Pen(0x681c2a35, 1);
      g.drawLine(8, this.height - 1, Math.max(8, this.width - 8), this.height - 1);
      g.end();
   };
   host.sliderControl.acePrecisionMain = true;
   host.sliderControl.aceControlBay = true;
   host.sliderControl.aceHideInlineReset = true;
   host.sliderControl.knobColor = accentColor;
   host.sliderControl.scaledMinHeight = 42;
   host.sliderControl.minWidth = 250;
   host.sliderControl.aceResetLabel = host.label ? host.label.text : "slider";
   host.sliderControl.toolTip = "Signed precision adjustment. Drag from zero; use the value box for exact entry.";
   host.valueEdit.setFixedWidth(44);
   host.valueEdit.text = aceSliderDisplayText(host, host.value);
   host.valueEdit.toolTip = "Enter a signed value. Positive values use +, negative values use -.";
   host.valueEdit.backgroundColor = ACE_COLORS.controlBayValue;
   host.valueEdit.foregroundColor = ACE_COLORS.text;
   host.valueEdit.textColor = ACE_COLORS.text;
   if (host.hint)
      aceApplySliderHintFont(host.hint);
   if (host.resetControl)
      host.resetControl.update();
   host.sliderControl.update();
}

function aceCreateLogo(parent, dialog) {
   var logo = new Control(parent);
   logo.aceDialog = dialog;
   logo.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 112 : 184;
   aceFixHeight(logo, ACE_HEADER_HEIGHT - ACE_HEADER_MARGIN * 2);
   logo.onMousePress = function() {
      if (this.aceDialog && typeof this.aceDialog.handleValidationLogoClick === "function")
         this.aceDialog.handleValidationLogoClick();
   };
   logo.onPaint = function() {
      var g = new Graphics(this);
      g.brush = new Brush(ACE_COLORS.header);
      g.pen = new Pen(ACE_COLORS.header);
      g.drawRect(this.boundsRect);
      if (this.aceDialog && this.aceDialog.logoBitmap) {
         var bmp = this.aceDialog.logoBitmap;
         var pad = ACE_HOST_IS_WINDOWS ? 0 : 1;
         var usableW = ACE_HOST_IS_WINDOWS ? Math.max(1, this.width) : Math.max(1, this.width - pad * 2);
         var usableH = Math.max(1, this.height - pad * 2);
         var scale = Math.min(usableW / Math.max(1, bmp.width), usableH / Math.max(1, bmp.height));
         var drawW = Math.max(1, Math.round(bmp.width * scale));
         var drawH = Math.max(1, Math.round(bmp.height * scale));
         var x = ACE_HOST_IS_WINDOWS ? 0 : Math.round((this.width - drawW) * 0.5);
         var y = Math.round((this.height - drawH) * 0.5);
         g.drawScaledBitmap(new Rect(x, y, x + drawW, y + drawH), bmp);
      } else {
         g.pen = new Pen(0xffd8dcff);
         var titleFont = new Font;
         titleFont.pixelSize = ACE_FONT_OVERLAY_TITLE;
         titleFont.bold = true;
         g.font = titleFont;
         g.drawText(14, 31, "Cosgrove's Cosmos");
         var subFont = new Font;
         subFont.pixelSize = ACE_FONT_OVERLAY_BODY;
         g.font = subFont;
         g.pen = new Pen(0xffd2d2d2);
         g.drawText(14, 50, "Astro imaging tools");
      }
      g.end();
   };
   return logo;
}

function aceCreateTogglePill(parent, text, active) {
   var pill = new Control(parent);
   pill.aceText = text;
   pill.aceShortcutText = "";
   pill.aceActive = !!active;
   pill.aceCallback = null;
   pill.scaledMinWidth = text.length > 13 ? 128 : 104;
   aceFixHeight(pill, ACE_BUTTON_MIN_HEIGHT);
   pill.onPaint = function() {
      var fill = this.aceActive ? 0xff4c4f3c : ACE_COLORS.inset;
      var border = this.aceActive ? ACE_COLORS.active : ACE_COLORS.lineDim;
      var textColor = ACE_COLORS.text;
      if (this.aceGold) {
         fill = this.aceActive ? 0xff5f542f : 0xff2f2a1b;
         border = ACE_COLORS.sectionTitle;
         textColor = ACE_COLORS.sectionTitle;
      }
      var g = new Graphics(this);
      g.brush = new Brush(fill);
      g.pen = new Pen(border);
      g.drawRect(this.boundsRect);
      var f = new Font;
      f.pixelSize = ACE_FONT_BUTTON;
      f.bold = this.aceActive || !!this.aceGold;
      var shortcutWidth = 0;
      var shortcutFont = null;
      if (this.aceShortcutText) {
         shortcutFont = new Font;
         shortcutFont.pixelSize = ACE_FONT_BUTTON;
         shortcutFont.bold = false;
      }
      var gap = this.aceShortcutText ? (ACE_HOST_IS_WINDOWS ? 8 : 4) : 0;
      var maxTextW = Math.max(12, this.width - 16);
      var labelWidth = f.width(this.aceText);
      if (shortcutFont)
         shortcutWidth = shortcutFont.width(this.aceShortcutText);
      while (labelWidth + shortcutWidth + gap > maxTextW && f.pixelSize > 10) {
         f.pixelSize -= 1;
         if (shortcutFont)
            shortcutFont.pixelSize = f.pixelSize;
         labelWidth = f.width(this.aceText);
         shortcutWidth = shortcutFont ? shortcutFont.width(this.aceShortcutText) : 0;
      }
      g.font = f;
      g.pen = new Pen(textColor);
      var textY = Math.round((this.height + f.ascent - f.descent) * 0.5);
      var textX = Math.round((this.width - labelWidth - shortcutWidth - gap) * 0.5);
      if (this.aceTextOffsetX)
         textX += this.aceTextOffsetX;
      g.drawText(textX, textY, this.aceText);
      if (this.aceShortcutText && shortcutFont) {
         g.font = shortcutFont;
         g.pen = new Pen(textColor);
         g.drawText(textX + labelWidth + gap, textY, this.aceShortcutText);
      }
      g.end();
   };
   pill.setActive = function(active) {
      this.aceActive = !!active;
      this.update();
   };
   pill.onMousePress = function() {
      if (typeof this.aceCallback === "function")
         this.aceCallback();
      else
         aceMessage(this.aceText + " is a Phase 7 status/action placeholder.", ACE_TOOL_NAME + " " + ACE_VERSION);
   };
   return pill;
}

function aceCreateAdvancedDiagnostic(parent, dialog) {
   var graphic = new Control(parent);
   graphic.aceDialog = dialog;
   graphic.scaledMinHeight = 112;
   graphic.onPaint = function() {
      var g = new Graphics(this);
      g.brush = new Brush(ACE_COLORS.inset);
      g.pen = new Pen(ACE_COLORS.lineDim);
      g.drawRect(this.boundsRect);
      var mode = this.aceDialog ? this.aceDialog.advancedMode : "scale";
      var title = mode === "clarity" ? "Clarity Response" : (mode === "dehaze" ? "Dehaze Response Curve" : (mode === "protection" ? "Protection Curve" : "Spatial Scale Separation"));
      var f = new Font;
      f.pixelSize = ACE_FONT_SMALL;
      f.bold = true;
      g.font = f;
      g.pen = new Pen(ACE_COLORS.sectionTitle);
      g.drawText(8, 17, title);
      var body = new Font;
      body.pixelSize = ACE_FONT_HINT;
      g.font = body;
      if (mode === "scale") {
         var advanced = this.aceDialog && this.aceDialog.appState ? this.aceDialog.appState.advanced : null;
         var texturePx = aceAdvancedRadiusPx(advanced, "textureScale", ACE_TEXTURE_RADIUS);
         var clarityPx = aceAdvancedRadiusPx(advanced, "clarityScale", ACE_CLARITY_RADIUS);
         var veilPx = aceAdvancedRadiusPx(advanced, "dehazeVeilSize", ACE_DEHAZE_VEIL_RADIUS);
         var labels = ["Texture", "Clarity", "Dehaze"];
         var colors = [ACE_COLORS.texture, ACE_COLORS.clarity, ACE_COLORS.dehaze];
         var radii = [texturePx, clarityPx, veilPx];
         var minPx = 2;
         var maxPx = 256;
         var logMin = Math.log(minPx);
         var logMax = Math.log(maxPx);
         var logPosition = function(px) {
            return aceClamp01((Math.log(aceClamp(px, minPx, maxPx)) - logMin) / Math.max(ACE_EPSILON, logMax - logMin));
         };
         var centers = [
            logPosition(texturePx),
            logPosition(clarityPx),
            logPosition(veilPx)
         ];
         var spans = [0.12, 0.16, 0.18];
         var x0 = 84;
         var w = Math.max(1, this.width - 142);
         g.pen = new Pen(ACE_COLORS.muted);
         g.drawText(x0, 36, "2");
         g.drawText(x0 + Math.round(w * logPosition(32)) - 8, 36, "32");
         g.drawText(Math.max(8, this.width - 30), 36, "px");
         for (var i = 0; i < labels.length; ++i) {
            var y = 44 + i * 18;
            g.pen = new Pen(ACE_COLORS.muted);
            g.drawText(8, y + 8, labels[i]);
            g.brush = new Brush(0xff242424);
            g.pen = new Pen(ACE_COLORS.lineDim);
            g.drawRect(new Rect(x0, y + 3, x0 + w, y + 11));
            var ticks = [2, 8, 32, 128, 256];
            g.pen = new Pen(0xff555555, 1);
            for (var ti = 0; ti < ticks.length; ++ti) {
               var tx = x0 + Math.round(w * logPosition(ticks[ti]));
               g.drawLine(tx, y, tx, y + 13);
            }
            var cx = x0 + Math.round(w * centers[i]);
            var influence0 = x0 + Math.round(w * aceClamp01(centers[i] - spans[i] * 0.5));
            var influence1 = x0 + Math.round(w * aceClamp01(centers[i] + spans[i] * 0.5));
            g.brush = new Brush(0x40202020 | (colors[i] & 0x00ffffff));
            g.pen = new Pen(colors[i]);
            g.drawRect(new Rect(influence0, y + 2, influence1, y + 12));
            g.pen = new Pen(colors[i], 2);
            g.drawLine(cx, y - 1, cx, y + 14);
            g.brush = new Brush(colors[i]);
            g.pen = new Pen(0xffffffff, 1);
            g.drawEllipse(cx - 4, y + 2, cx + 4, y + 12);
            g.pen = new Pen(ACE_COLORS.text);
            g.drawText(Math.max(8, this.width - 42), y + 8, String(radii[i]));
         }
      } else if (mode === "clarity") {
         var clarityAdvanced = this.aceDialog && this.aceDialog.appState ? this.aceDialog.appState.advanced : null;
         var responseProfile = aceClarityResponseProfile(clarityAdvanced ? clarityAdvanced.clarityResponse : DEFAULT_CLARITY_RESPONSE, 100);
         var graphX = 10;
         var graphY = 36;
         var graphW = Math.max(1, this.width - 20);
         var graphH = Math.max(48, this.height - graphY - 14);
         g.brush = new Brush(0xff202020);
         g.pen = new Pen(ACE_COLORS.lineDim);
         g.drawRect(new Rect(graphX, graphY, graphX + graphW, graphY + graphH));
         g.pen = new Pen(0xff555555, 1);
         g.drawLine(graphX, graphY + graphH, graphX + graphW, graphY + graphH);
         g.drawLine(graphX, graphY, graphX, graphY + graphH);
         g.pen = new Pen(ACE_COLORS.muted);
         g.drawText(graphX + 4, graphY + graphH - 5, "0");
         g.drawText(Math.max(graphX + 4, graphX + graphW - body.width("150") - 5), graphY + graphH - 5, "150");
         g.drawText(graphX + 4, graphY + 13, responseProfile.label);
         var lastX = graphX;
         var lastY = graphY + graphH - 3;
         g.pen = new Pen(ACE_COLORS.clarity, 2);
         for (var cx = 1; cx < graphW; ++cx) {
            var sliderValue = 150 * cx / Math.max(1, graphW - 1);
            var curveProfile = aceClarityResponseProfile(responseProfile.response, sliderValue);
            var sliderCurve = Math.pow(aceClamp(sliderValue / 100, 0, 1.5), 0.82) / Math.pow(1.5, 0.82);
            var response = aceClamp01(sliderCurve * (0.55 + 0.45 * curveProfile.highT) * (curveProfile.productGain / ACE_CLARITY_DUALZONE_PRODUCT_GAIN));
            var yy = graphY + Math.round((1 - response) * (graphH - 6)) + 3;
            g.drawLine(lastX, lastY, graphX + cx, yy);
            lastX = graphX + cx;
            lastY = yy;
         }
      } else if (mode === "dehaze") {
         var dehazeAdvanced = this.aceDialog && this.aceDialog.appState ? this.aceDialog.appState.advanced : null;
         var safety = aceAdvancedFactor(dehazeAdvanced, "dehazeHighlightProtect");
         var veilStrength = aceAdvancedFactor(dehazeAdvanced, "dehazeVeilStrength");
         var stripX = 10;
         var stripY = 36;
         var stripW = Math.max(1, this.width - 20);
         var curveH = Math.max(48, this.height - stripY - 14);
         var protectedStart = aceClamp(0.70 - (safety - 1) * 0.18, 0.56, 0.84);
         g.brush = new Brush(0xff202020);
         g.pen = new Pen(ACE_COLORS.lineDim);
         g.drawRect(new Rect(stripX, stripY, stripX + stripW, stripY + curveH));
         g.pen = new Pen(0xff555555, 1);
         g.drawLine(stripX, stripY + curveH, stripX + stripW, stripY + curveH);
         g.drawLine(stripX, stripY, stripX, stripY + curveH);
         g.pen = new Pen(ACE_COLORS.muted);
         g.drawText(stripX + 4, stripY + curveH - 5, "dark");
         g.drawText(Math.max(stripX + 4, stripX + stripW - body.width("bright") - 5), stripY + curveH - 5, "bright");
         g.drawText(stripX + 4, stripY + 13, "effect");
         var kneeX = stripX + Math.round(stripW * protectedStart);
         g.pen = new Pen(ACE_COLORS.dehaze, 1);
         g.drawLine(kneeX, stripY + 1, kneeX, stripY + curveH - 1);
         var prevX = stripX;
         var prevY = stripY + 3;
         g.pen = new Pen(ACE_COLORS.dehaze, 2);
         for (var x = 1; x < stripW; ++x) {
            var t = x / Math.max(1, stripW - 1);
            var response = aceClamp01((1 - aceSmoothStep(protectedStart, 0.98, t)) * aceClamp(veilStrength, 0.5, 1.5));
            var cy = stripY + Math.round((1 - response) * (curveH - 6)) + 3;
            g.drawLine(prevX, prevY, stripX + x, cy);
            prevX = stripX + x;
            prevY = cy;
         }
      } else {
         var protectionAdvanced = this.aceDialog && this.aceDialog.appState ? this.aceDialog.appState.advanced : null;
         var guard = aceAdvancedFactor(protectionAdvanced, "overallProtectionStrength");
         var sx = 10;
         var sy = 36;
         var sw = Math.max(1, this.width - 20);
         var sh = Math.max(48, this.height - sy - 14);
         g.brush = new Brush(0xff202020);
         g.pen = new Pen(ACE_COLORS.lineDim);
         g.drawRect(new Rect(sx, sy, sx + sw, sy + sh));
         g.pen = new Pen(0xff555555, 1);
         g.drawLine(sx, sy + sh, sx + sw, sy + sh);
         g.drawLine(sx, sy, sx, sy + sh);
         g.pen = new Pen(ACE_COLORS.muted);
         g.drawText(sx + 4, sy + sh - 5, "low");
         g.drawText(Math.max(sx + 4, sx + sw - body.width("protected") - 5), sy + sh - 5, "protected");
         var displayGuard = Math.pow(guard, 3.2);
         var px0 = sx;
         var py0 = sy + sh - 3;
         g.pen = new Pen(ACE_COLORS.active, 2);
         for (var px = 1; px < sw; ++px) {
            var p = px / Math.max(1, sw - 1);
            var allow = Math.pow(p, displayGuard);
            var py = sy + Math.round((1 - allow) * (sh - 6)) + 3;
            g.drawLine(px0, py0, sx + px, py);
            px0 = sx + px;
            py0 = py;
         }
         var markerX = sx + Math.round(sw * aceClamp01((guard - 0.5) / 1.0));
         g.pen = new Pen(ACE_COLORS.sectionTitle, 1);
         g.drawLine(markerX, sy + 1, markerX, sy + sh - 1);
      }
      g.end();
   };
   return graphic;
}

function aceCreatePreview(parent, dialog) {
   var preview = new Control(parent);
   preview.aceImageBackedPreview = true;
   preview.scaledMinWidth = 420;
   preview.scaledMinHeight = 390;
   preview.tracking = true;
   preview.mouseTracking = true;
   preview.toolTip = ACE_HOST_IS_WINDOWS ? "Cmd-C toggles Before/After. In Lasso Local: drag to draw, drag inside selection to move, drag outside to pan." : "\u2318C toggles Before/After. In Lasso Local: drag to draw, drag inside selection to move, drag outside to pan.";
   preview.onPaint = function() {
      var g = new Graphics(this);
      var w = Math.max(1, this.width);
      var h = Math.max(1, this.height);
      g.brush = new Brush(ACE_COLORS.inset);
      g.pen = new Pen(ACE_COLORS.line);
      g.drawRect(this.boundsRect);

      for (var y = 1; y < h - 1; ++y) {
         var t = y / Math.max(1, h - 1);
         var r = Math.round(28 + 25 * t);
         var gg = Math.round(29 + 24 * t);
         var b = Math.round(32 + 30 * t);
         var color = 0xff000000 | (r << 16) | (gg << 8) | b;
         g.pen = new Pen(color);
         g.drawLine(1, y, w - 2, y);
      }

      var bmp = dialog.getCurrentPreviewBitmap();
      if (bmp) {
         var detailRectForPaint = null;
         if (dialog.shouldSuppressResponsiveGlobalDetailInMainPreview(bmp)) {
            bmp = dialog.getDraftPreviewBitmapForCurrentMode();
         }
         if (bmp && dialog.isDetailBitmap(bmp)) {
            var underlay = dialog.getDraftPreviewBitmapForCurrentMode();
            if (underlay && underlay !== bmp) {
               var underlayRect = dialog.getCurrentViewportRect(underlay);
               if (underlayRect) {
                  dialog.previewDisplayRect = underlayRect;
                  g.drawScaledBitmap(underlayRect, underlay);
               }
            }
            detailRectForPaint = dialog.getCurrentViewportRect(bmp);
         }
         if (bmp && !dialog.isDetailBitmap(bmp))
            dialog.previewDisplayRect = dialog.previewGestureBitmap && bmp === dialog.previewGestureBitmap && dialog.previewGestureDisplayRect ?
               dialog.previewGestureDisplayRect :
               dialog.getCurrentViewportRect(bmp);
         var paintRect = detailRectForPaint || dialog.previewDisplayRect;
         if (paintRect)
            g.drawScaledBitmap(paintRect, bmp);
      } else if (!dialog.appState.preview.showMask) {
         g.pen = new Pen(0x60d8dcff, 1);
         for (var i = 0; i < 70; ++i) {
            var x = (i * 73) % Math.max(1, w - 20) + 10;
            var sy = (i * 47) % Math.max(1, h - 40) + 20;
            g.drawPoint(x, sy);
            if (i % 11 === 0)
               g.drawPoint(x + 1, sy);
         }
      }

      dialog.drawProtectedOverlayLayer(g, bmp);
      dialog.drawLassoOverlay(g, bmp);
      dialog.drawLowZoomLoupe(g);

      dialog.drawPreviewOverlay(g, bmp);
      g.end();
   };
   preview.onMousePress = function(x, y) {
      dialog.handlePreviewMousePress(x, y);
   };
   preview.onMouseMove = function(x, y) {
      dialog.handlePreviewMouseMove(x, y);
   };
   preview.onMouseRelease = function(x, y) {
      dialog.handlePreviewMouseRelease(x, y);
   };
   preview.onMouseWheel = function(x, y, delta) {
      dialog.handlePreviewMouseWheel(x, y, delta);
   };
   preview.onKeyPress = function(key, modifiers) {
      return dialog.handlePreviewKeyPress(key, modifiers);
   };
   preview.onKeyRelease = function(key, modifiers) {
      return dialog.handlePreviewKeyRelease(key, modifiers);
   };
   return preview;
}

class AstroContrastEnhancerDialog extends Dialog {
constructor() {
   super();

   var self = this;
   this.windowTitle = ACE_TOOL_NAME + " " + ACE_VERSION;
   this.userResizable = true;
   this.onKeyPress = function(key, modifiers) {
      return self.handlePreviewKeyPress(key, modifiers);
   };
   this.onKeyRelease = function(key, modifiers) {
      return self.handlePreviewKeyRelease(key, modifiers);
   };
   this.processingMode = "full";
   this.inputType = "stars";
   this.appState = new AppState;
   this.previewDisplayRect = null;
   this.previewMouseDown = false;
   this.previewDragging = false;
   this.previewCompareArmed = false;
   this.previewMomentaryBefore = false;
   this.previewMoveThreshold = 5;
   this.previewCanPanFromPress = false;
   this.previewDragStartX = 0;
   this.previewDragStartY = 0;
   this.previewPanStartX = 0;
   this.previewPanStartY = 0;
   this.previewLastMouseX = 0;
   this.previewLastMouseY = 0;
   this.zoomCycleDirection = 1;
   this.refreshingSourceCombo = false;
   this.viewModeButtons = {};
   this.lassoDrawing = false;
   this.lassoMoving = false;
   this.lassoHoverInside = false;
   this.lassoDragOperation = "none";
   this.lassoDrawPoints = [];
   this.lassoMoveStartPoint = null;
   this.lassoMoveOriginalPoints = [];
   this.featherAdjusting = false;
   this.interactiveSliderDrag = false;
   this.startupAttachTimer = null;
   this.previewHoldTimer = null;
   this.previewWarmupTimer = null;
   this.protectionRefreshTimer = null;
   this.overlayRestoreTimer = null;
   this.interactivePreviewTimer = null;
   this.deferredLassoUpdateTimer = null;
   this.detailAdjustmentIdleTimer = null;
   this.lowZoomLoupeTimer = null;
   this.detailRefreshGeneration = 0;
   this.lowZoomLoupeGeneration = 0;
   this.lowZoomLoupeTimerToken = null;
   this.lowZoomLoupePending = false;
   this.lowZoomLoupeActive = false;
   this.lowZoomLoupeEnabled = false;
   this.lowZoomLoupeShiftDown = false;
   this.lowZoomLoupeShowBefore = false;
   this.lowZoomLoupeMouseValid = false;
   this.lowZoomLoupeMouseX = 0;
   this.lowZoomLoupeMouseY = 0;
   this.detailRefreshTimerGeneration = 0;
   this.detailAdjustmentTimerGeneration = 0;
   this.editGeneration = 0;
   this.geometryGeneration = 0;
   this.commitGeneration = 0;
   this.detailWorkActive = false;
   this.detailWorkToken = null;
   this.lastInteractivePreviewMs = 0;
   this.lastInteractivePreviewName = "";
   this.lastInteractivePreviewValue = 0;
   this.pendingInteractivePreviewLabel = "";
   this.pendingInteractivePreviewStatus = "";
   this.pendingInteractivePreviewInvalidateAdvanced = false;
   this.pendingLassoStatusText = "";
   this.pendingLassoAutoFocus = false;
   this.selectionTransitionBusy = false;
   this.selectionTransitionReason = "";
   this.selectionTransitionGeneration = 0;
   this.scaleMapRebuildPending = false;
   this.scaleMapRebuildViewMode = "";
   this.scaleMapRebuildLabel = "";
   this.scaleMapDisplayQuality = "";
   this.overlaySuppressedUntilMs = 0;
   this.beforeAfterShortcutDown = false;
   this.beforeAfterComparisonActive = false;
   this.lastLocalAction = "";
   this.lastCommitFlashMs = 0;
   this.outputRendering = false;
   this.lastOutputRenderFinishedMs = 0;
   this.outputWaitTitle = "";
   this.outputWaitSubtitle = "";
   this.debugControlsVisible = !!ACE_DEBUG_CONTROLS_ENABLED;
   this.startupAttachComplete = false;
   this.targetImageLoading = false;
   this.previewWarmupDone = false;
   this.previewWarmupActive = false;
   this.previewFirstAdjustmentDone = false;
   this.localSelectionNewActive = false;
   this.detailPreviewPendingAdjustment = false;
   this.committedDetailPreviewFrozen = false;
   this.suppressNextDetailRefresh = false;
   if (typeof Timer !== "undefined") {
      this.startupAttachTimer = new Timer;
      this.startupAttachTimer.interval = 0.12;
      this.startupAttachTimer.periodic = false;
      this.startupAttachTimer.dialog = this;
      this.startupAttachTimer.onTimeout = function() {
         var dialog = this.dialog;
         if (!dialog || dialog.startupAttachComplete)
            return;
         dialog.startupAttachComplete = true;
         dialog.tryAttachActiveViewAtStartup();
      };
      this.previewHoldTimer = new Timer;
      this.previewHoldTimer.interval = 0.18;
      this.previewHoldTimer.periodic = false;
      this.previewHoldTimer.dialog = this;
      this.previewHoldTimer.onTimeout = function() {
         var dialog = this.dialog;
         if (dialog.previewMouseDown && dialog.previewCompareArmed && !dialog.previewDragging)
            dialog.beginMomentaryBefore();
      };
      this.previewWarmupTimer = new Timer;
      this.previewWarmupTimer.interval = 0.04;
      this.previewWarmupTimer.periodic = false;
      this.previewWarmupTimer.dialog = this;
      this.previewWarmupTimer.onTimeout = function() {
         this.dialog.performPreviewWarmup();
      };
      this.interactivePreviewTimer = new Timer;
      this.interactivePreviewTimer.interval = 0.05;
      this.interactivePreviewTimer.periodic = false;
      this.interactivePreviewTimer.dialog = this;
      this.interactivePreviewTimer.onTimeout = function() {
         this.dialog.performQueuedInteractivePreview();
      };
      this.deferredLassoUpdateTimer = new Timer;
      this.deferredLassoUpdateTimer.interval = 0.06;
      this.deferredLassoUpdateTimer.periodic = false;
      this.deferredLassoUpdateTimer.dialog = this;
      this.deferredLassoUpdateTimer.onTimeout = function() {
         this.dialog.performDeferredLassoUpdate();
      };
      this.detailAdjustmentIdleTimer = new Timer;
      this.detailAdjustmentIdleTimer.interval = 0.65;
      this.detailAdjustmentIdleTimer.periodic = false;
      this.detailAdjustmentIdleTimer.dialog = this;
      this.detailAdjustmentIdleTimer.onTimeout = function() {
         var dialog = this.dialog;
         if (!dialog)
            return;
         var token = dialog.detailAdjustmentTimerToken;
         if (dialog.detailAdjustmentTimerGeneration !== dialog.detailRefreshGeneration) {
            dialog.detailAdjustmentTimerToken = null;
            return;
         }
         if (!dialog.previewStateTokenIsCurrent(token)) {
            dialog.detailAdjustmentTimerToken = null;
            return;
         }
         if (dialog.selectionTransitionBusy || dialog.lassoDrawing || dialog.lassoMoving || dialog.pendingLassoStatusText) {
            dialog.detailAdjustmentTimerToken = token;
            this.start();
            return;
         }
         dialog.detailAdjustmentTimerToken = null;
         dialog.performPendingDetailAdjustmentRefresh("idle");
      };
      this.lowZoomLoupeTimer = new Timer;
      this.lowZoomLoupeTimer.interval = ACE_LOW_ZOOM_GLOBAL_LOUPE_TIMER_SECONDS;
      this.lowZoomLoupeTimer.periodic = false;
      this.lowZoomLoupeTimer.dialog = this;
      this.lowZoomLoupeTimer.onTimeout = function() {
         var dialog = this.dialog;
         if (!dialog)
            return;
         var token = dialog.lowZoomLoupeTimerToken;
         dialog.lowZoomLoupeTimerToken = null;
         if (!dialog.lowZoomLoupeStateTokenIsCurrent(token))
            return;
         dialog.performLowZoomLoupeRefresh(token);
      };
      this.protectionRefreshTimer = new Timer;
      this.protectionRefreshTimer.interval = 0.03;
      this.protectionRefreshTimer.periodic = false;
      this.protectionRefreshTimer.dialog = this;
      this.protectionRefreshTimer.onTimeout = function() {
         this.dialog.performProtectionRebuild();
      };
      this.overlayRestoreTimer = new Timer;
      this.overlayRestoreTimer.interval = 5.0;
      this.overlayRestoreTimer.periodic = false;
      this.overlayRestoreTimer.dialog = this;
      this.overlayRestoreTimer.onTimeout = function() {
         var dialog = this.dialog;
         dialog.overlaySuppressedUntilMs = 0;
         dialog.invalidateProtectedOverlay();
         if (dialog.preview)
            dialog.preview.update();
      };
      this.detailRefreshTimer = new Timer;
      this.detailRefreshTimer.interval = 0.85;
      this.detailRefreshTimer.periodic = false;
      this.detailRefreshTimer.dialog = this;
      this.detailRefreshTimer.onTimeout = function() {
         var dialog = this.dialog;
         if (!dialog)
            return;
         var token = dialog.detailRefreshTimerToken;
         if (dialog.detailRefreshTimerGeneration !== dialog.detailRefreshGeneration) {
            dialog.detailRefreshTimerToken = null;
            return;
         }
         if (!dialog.previewStateTokenIsCurrent(token)) {
            dialog.detailRefreshTimerToken = null;
            return;
         }
         if (dialog.selectionTransitionBusy || dialog.lassoDrawing || dialog.lassoMoving || dialog.pendingLassoStatusText) {
            dialog.detailRefreshTimerToken = token;
            this.start();
            return;
         }
         dialog.detailRefreshTimerToken = null;
         dialog.refreshDetailPreviewIfNeeded(false);
         dialog.refreshPreviewStatus(dialog.describeLoadedSource(), dialog.appState.cache.detail ? "Preview: detail crop" : "Preview: draft");
         if (dialog.preview)
            dialog.preview.update();
      };
   }
   this.logoBitmap = aceTryLoadFirstBitmap([
      "C:/Users/patri/Dropbox/Astronomy/Webpage Codeblocks/Astro effect Tool/logo.png",
      "C:/Users/patri/Dropbox/Astronomy/Webpage Codeblocks/Astro effect Tool/ace-logo.png",
      "/Users/patrickcosgrove/Library/CloudStorage/Dropbox/Astronomy/Webpage Codeblocks/Astro effect Tool/logo.png",
      "/Users/patrickcosgrove/Library/CloudStorage/Dropbox/Astronomy/Webpage Codeblocks/Astro effect Tool/ace-logo.png",
      "/Users/patrickcosgrove/Documents/Playground/astro-color-mixer-web-prototype/pixinsight/logo.png",
      "/Users/patrickcosgrove/Library/CloudStorage/Dropbox/Astronomy/Webpage Codeblocks/Colormixer/pixinsight_repo/rsc/AstroColorMixer/logo/logo.png",
      "/Applications/PixInsight/rsc/AstroContrastEnhancer/logo/logo.png",
      "C:/Program Files/PixInsight/rsc/AstroContrastEnhancer/logo/logo.png"
   ]);

   this.beforeAfterPill = aceCreateTogglePill(this, ACE_HOST_IS_WINDOWS ? "Before/After" : "Before/After", false);
   this.beforeAfterPill.aceShortcutText = ACE_HOST_IS_WINDOWS ? "" : " \u2318C";
   this.beforeAfterPill.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 160 : 142;
   if (ACE_HOST_IS_WINDOWS) {
      this.beforeAfterPill.minWidth = 160;
      this.beforeAfterPill.maxWidth = 160;
   }
   this.beforeAfterPill.aceGold = true;
   this.beforeAfterPill.toolTip = ACE_HOST_IS_WINDOWS ? "Hold for comparison. Shortcut: hold Cmd-C." : "Hold for comparison. Shortcut: hold \u2318C.";
   this.beforeAfterPill.aceCallback = null;
   this.beforeAfterPill.onMousePress = function() {
      self.setBeforeAfter(true);
   };
   this.beforeAfterPill.onMouseRelease = function() {
      self.setBeforeAfter(false);
   };
   var header = new Control(this);
   aceFixHeight(header, ACE_HOST_IS_WINDOWS ? ACE_HEADER_HEIGHT + 6 : ACE_HEADER_HEIGHT);
   acePaintPanel(header, ACE_COLORS.headerDark, ACE_COLORS.lineDim);
   header.sizer = new HorizontalSizer;
   header.sizer.margin = ACE_HOST_IS_WINDOWS ? 2 : ACE_HEADER_MARGIN;
   header.sizer.spacing = ACE_HOST_IS_WINDOWS ? 2 : 8;

   var logo = aceCreateLogo(header, this);
   header.sizer.add(logo);

   var identity = new Control(header);
   identity.sizer = new VerticalSizer;
   identity.sizer.margin = 0;
   identity.sizer.spacing = 3;
   identity.sizer.addStretch();
   var titleRow = new HorizontalSizer;
   titleRow.spacing = ACE_HOST_IS_WINDOWS ? 6 : 5;
   var title = aceGradientTitleControl(identity);
   this.titleControl = title;
   var subtitle = null;
   if (ACE_HOST_IS_WINDOWS) {
      var titleStack = new Control(identity);
      titleStack.sizer = new VerticalSizer;
      titleStack.sizer.margin = 0;
      titleStack.sizer.spacing = 0;
      titleStack.sizer.add(title);
      subtitle = aceHintLabel(titleStack, ACE_SUBTITLE);
      subtitle.scaledMinHeight = 18;
      titleStack.sizer.add(subtitle);
      titleRow.add(titleStack);
   } else {
      titleRow.add(title);
   }
   var modeGroup = new Control(identity);
   this.inputModeGroup = modeGroup;
   modeGroup.sizer = new VerticalSizer;
   modeGroup.sizer.margin = ACE_HOST_IS_WINDOWS ? 4 : 5;
   modeGroup.sizer.spacing = ACE_HOST_IS_WINDOWS ? 1 : 2;
   modeGroup.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 204 : 188;
   if (ACE_HOST_IS_WINDOWS)
      aceFixHeight(modeGroup, 62);
   acePaintGroupBox(modeGroup, ACE_COLORS.headerDark, ACE_COLORS.sectionTitle);
   this.imageTypeModeLine = aceCompactStatusLine(modeGroup, "Mode: Stars Present", ACE_COLORS.warning);
   this.imageTypeModeLine.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 192 : 176;
   aceFixHeight(this.imageTypeModeLine, ACE_HOST_IS_WINDOWS ? 22 : 20);
   modeGroup.sizer.add(this.imageTypeModeLine);
   var modeChoiceRow = new HorizontalSizer;
   modeChoiceRow.spacing = ACE_HOST_IS_WINDOWS ? 4 : 4;
   this.starlessRadio = aceRadio(modeGroup, "Starless", false, function(checked) {
      if (checked)
         self.setInputType("starless");
   });
   this.starsPresentRadio = aceRadio(modeGroup, "Stars Present", true, function(checked) {
      if (checked)
         self.setInputType("stars");
   });
   this.starlessRadio.toolTip = "Source has already had stars removed.";
   this.starsPresentRadio.toolTip = "Source includes stars; star protection will be available.";
   var modeRadioFont = new Font;
   modeRadioFont.pixelSize = ACE_FONT_SMALL;
   this.starlessRadio.font = modeRadioFont;
   this.starsPresentRadio.font = modeRadioFont;
   this.starlessRadio.scaledMinHeight = ACE_HOST_IS_WINDOWS ? 20 : 20;
   this.starsPresentRadio.scaledMinHeight = ACE_HOST_IS_WINDOWS ? 20 : 20;
   this.starlessRadio.maxHeight = ACE_HOST_IS_WINDOWS ? 20 : 20;
   this.starsPresentRadio.maxHeight = ACE_HOST_IS_WINDOWS ? 20 : 20;
   if (ACE_HOST_IS_WINDOWS) {
      this.starlessRadio.scaledMinWidth = 68;
      this.starlessRadio.maxWidth = 68;
      this.starsPresentRadio.scaledMinWidth = 102;
      this.starsPresentRadio.maxWidth = 102;
   }
   modeChoiceRow.add(this.starlessRadio);
   modeChoiceRow.add(this.starsPresentRadio);
   modeGroup.sizer.add(modeChoiceRow);
   titleRow.add(modeGroup);
   var windowSizeGroup = new Control(identity);
   this.windowSizeGroup = windowSizeGroup;
   windowSizeGroup.sizer = new VerticalSizer;
   windowSizeGroup.sizer.margin = 5;
   windowSizeGroup.sizer.spacing = 2;
   windowSizeGroup.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 154 : 150;
   if (ACE_HOST_IS_WINDOWS)
      aceFixHeight(windowSizeGroup, 66);
   acePaintGroupBox(windowSizeGroup, ACE_COLORS.headerDark, ACE_COLORS.sectionTitle);
   var initialWindowSize = aceDefaultDialogSize();
   this.windowSizeLine = aceCompactStatusLine(windowSizeGroup, "Win " + initialWindowSize.width + " x " + initialWindowSize.height, ACE_COLORS.accent);
   this.windowSizeLine.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 140 : 136;
   this.windowSizeLine.toolTip = "Current dialog size in PixInsight logical pixels.";
   windowSizeGroup.sizer.add(this.windowSizeLine);
   var windowSizeButtons = new HorizontalSizer;
   windowSizeButtons.spacing = 4;
   this.saveWindowSizeButton = aceSmallButton(windowSizeGroup, "Save", "Save this window size and position for the next launch.", function() {
      self.saveWindowSizePreference();
   });
   this.resetWindowSizeButton = aceSmallButton(windowSizeGroup, "Reset", "Reset saved ACE window size and position.", function() {
      self.resetWindowSizeDefault();
   });
   this.saveWindowSizeButton.scaledMinWidth = 52;
   this.resetWindowSizeButton.scaledMinWidth = 56;
   aceFixHeight(this.saveWindowSizeButton, 22);
   aceFixHeight(this.resetWindowSizeButton, 22);
   windowSizeButtons.add(this.saveWindowSizeButton);
   windowSizeButtons.add(this.resetWindowSizeButton);
   windowSizeGroup.sizer.add(windowSizeButtons);
   titleRow.addSpacing(ACE_HOST_IS_WINDOWS ? 8 : 10);
   titleRow.add(windowSizeGroup);
   titleRow.addStretch();
   identity.sizer.add(titleRow);
   if (!ACE_HOST_IS_WINDOWS) {
      subtitle = aceHintLabel(identity, ACE_SUBTITLE);
      identity.sizer.add(subtitle);
   }
   identity.sizer.addStretch();
   header.sizer.add(identity, 100);

   var headerRight = new Control(header);
   headerRight.sizer = new VerticalSizer;
   headerRight.sizer.margin = 0;
   headerRight.sizer.spacing = 6;

   var docs = new Control(headerRight);
   docs.sizer = new HorizontalSizer;
   docs.sizer.spacing = 5;
   docs.sizer.addStretch();
   docs.sizer.add(aceSmallButton(docs, "FAQ", "Open FAQ", function() {
      aceShowDocument("FAQ", aceFaqDocument());
   }));
   var displayButton = aceSmallButton(docs, ACE_HOST_IS_WINDOWS ? "Disp" : "Display", "Show ACE display diagnostics", function() {
      self.showDisplayDiagnostics();
   });
   this.displayDiagnosticsButton = displayButton;
   displayButton.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 46 : 62;
   docs.sizer.add(displayButton);
   var techButton = aceButton(docs, ACE_HOST_IS_WINDOWS ? "Tech" : "Tech Appx", "Open Technical Appendix", function() {
      aceShowDocument("Technical Appendix", aceTechnicalDocument());
   });
   this.techAppendixButton = techButton;
   techButton.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 72 : 96;
   docs.sizer.add(techButton);
   docs.sizer.add(aceSmallButton(docs, "About", "About Astro Contrast Enhancer", function() {
      aceShowDocument("About", aceAboutDocument());
   }));
   headerRight.sizer.add(docs);

   var headerActions = new Control(headerRight);
   headerActions.sizer = new HorizontalSizer;
   headerActions.sizer.spacing = 6;
   headerActions.sizer.add(aceToolbarLabel(headerActions, "Target"));
   this.sourceCombo = new ComboBox(headerActions);
   this.sourceCombo.toolTip = "Select an open PixInsight RGB view as the source image.";
   this.sourceCombo.minWidth = ACE_HOST_IS_WINDOWS ? 280 : 250;
   var comboFont = new Font;
   comboFont.pixelSize = ACE_FONT_BODY;
   this.sourceCombo.font = comboFont;
   this.sourceCombo.onItemSelected = function(index) {
      if (self.refreshingSourceCombo)
         return;
      var viewId = self.sourceCombo.itemText(index);
      if (viewId && viewId !== "No RGB views")
         self.refreshSourceFromViewId(viewId);
   };
   headerActions.sizer.add(this.sourceCombo);
   this.headerProtectionLine = null;
   headerRight.sizer.add(headerActions);
   header.sizer.add(headerRight);

   var leftPanel = new Control(this);
   leftPanel.scaledMinWidth = ACE_LEFT_PANEL_WIDTH;
   leftPanel.maxWidth = ACE_LEFT_PANEL_WIDTH + 12;
   acePaintPanel(leftPanel, ACE_COLORS.panelAlt, ACE_COLORS.panelAlt);
   leftPanel.sizer = new VerticalSizer;
   leftPanel.sizer.margin = 0;
   leftPanel.sizer.spacing = 6;
   var leftContent = leftPanel;

   var enhancement = aceSection(leftContent, "Enhancement");
   this.enhancementControlBay = new Control(enhancement);
   this.enhancementControlBay.aceMainEnhancementBay = true;
   this.enhancementControlBay.sizer = new VerticalSizer;
   this.enhancementControlBay.sizer.margin = 5;
   this.enhancementControlBay.sizer.spacing = 1;
   acePaintEnhancementControlBay(this.enhancementControlBay, this);
   this.textureSlider = aceCreateValueSlider(this.enhancementControlBay, "Texture", "Fine detail and crisp structure", ACE_TEXTURE_SLIDER_MIN, ACE_TEXTURE_SLIDER_MAX, 0, "", ACE_COLORS.texture);
   this.claritySlider = aceCreateValueSlider(this.enhancementControlBay, "Clarity", "Midtone depth and structure", ACE_TEXTURE_CLARITY_SLIDER_MIN, ACE_CLARITY_SLIDER_MAX, 0, "", ACE_COLORS.clarity);
   this.dehazeSlider = aceCreateValueSlider(this.enhancementControlBay, "Dehaze", "Broad veil, contrast, and color depth", ACE_DEHAZE_SLIDER_MIN, ACE_DEHAZE_SLIDER_MAX, 0, "", ACE_COLORS.dehaze);
   aceConfigureMainEnhancementSlider(this.textureSlider, ACE_COLORS.texture);
   aceConfigureMainEnhancementSlider(this.claritySlider, ACE_COLORS.clarity);
   aceConfigureMainEnhancementSlider(this.dehazeSlider, ACE_COLORS.dehaze);
   this.enhancementControlBay.sizer.add(this.textureSlider);
   this.enhancementControlBay.sizer.add(this.claritySlider);
   this.enhancementControlBay.sizer.add(this.dehazeSlider);
   enhancement.sizer.add(this.enhancementControlBay);
   this.textureSlider.onPreviewValueUpdated = function(value, isDragging) {
      self.handleEffectParameterChange("texture", value, isDragging);
   };
   this.textureSlider.onPreviewDragFinished = function(value) {
      self.handleEffectParameterChange("texture", value, false);
   };
   this.claritySlider.onPreviewValueUpdated = function(value, isDragging) {
      self.handleEffectParameterChange("clarity", value, isDragging);
   };
   this.claritySlider.onPreviewDragFinished = function(value) {
      self.handleEffectParameterChange("clarity", value, false);
   };
   this.dehazeSlider.onPreviewValueUpdated = function(value, isDragging) {
      self.handleEffectParameterChange("dehaze", value, isDragging);
   };
   this.dehazeSlider.onPreviewDragFinished = function(value) {
      self.handleEffectParameterChange("dehaze", value, false);
   };
   this.dehazeModeSelector = new ComboBox(enhancement);
   this.dehazeModeSelector.toolTip = ACE_DEBUG_CONTROLS_ENABLED ?
      "Select internal positive Dehaze app-test mode. Product Dehaze remains the normal default; negative Dehaze is preserved." :
      "Select Product Dehaze or the legacy Dehaze fallback.";
   var dehazeSelectorModes = aceDehazeAppSelectorModes();
   for (var dm = 0; dm < dehazeSelectorModes.length; ++dm)
      this.dehazeModeSelector.addItem(aceDehazeAppSelectorLabel(dehazeSelectorModes[dm]));
   this.dehazeModeSelector.currentItem = aceDehazeAppSelectorIndexForMode(ACE_DEHAZE_APP_MODE_DEFAULT);
   this.dehazeModeSelector.onItemSelected = function(index) {
      self.setDehazeAppMode(aceDehazeAppSelectorModeForIndex(index));
   };
   var enhancementButtons = new HorizontalSizer;
   enhancementButtons.spacing = 6;
   this.resetEnhancementButton = aceSmallButton(enhancement, "Reset", "Reset enhancement sliders", function() {
      self.resetEnhancementAdjustments();
   });
   this.resetEnhancementButton.scaledMinWidth = 54;
   enhancementButtons.add(this.resetEnhancementButton);
   this.advancedExpanded = false;
   this.advancedMode = "scale";
   this.advancedButton = aceButton(enhancement, "Advanced >", "Show advanced tuning controls", function() {
      self.toggleAdvancedPanel();
   });
   this.advancedButton.scaledMinWidth = 82;
   enhancementButtons.add(this.advancedButton);
   this.clarityModeLegacyButton = aceSmallButton(enhancement, "V1", "Use legacy Clarity computation.", function() {
      self.setClarityMode(ACE_CLARITY_MODE_LEGACY);
   });
   this.clarityModeV2Button = aceSmallButton(enhancement, "V2A", "Use Clarity V2; click again while active to cycle A/B/C tuning.", function() {
      if (self.currentClarityMode() === ACE_CLARITY_MODE_V2_DEPTH)
         self.cycleClarityV2Tuning();
      else
         self.setClarityMode(ACE_CLARITY_MODE_V2_DEPTH);
   });
   this.clarityModeV3Button = aceSmallButton(enhancement, "V3F", "Use Clarity V3 Full; click again while active to cycle Raw/Weighted/Background/Stars/Full diagnostics.", function() {
      if (aceIsClarityV3Mode(self.currentClarityMode()))
         self.setClarityMode(aceNextClarityV3Mode(self.currentClarityMode()));
      else
         self.setClarityMode(ACE_CLARITY_MODE_V3_FULL);
   });
   this.clarityModeV4Button = aceSmallButton(enhancement, "V4", "Use production Clarity V4. V5b is disabled by default and remains an internal debug path.", function() {
      self.setClarityMode(ACE_CLARITY_MODE_V4);
   });
   this.clarityModeFeatureFitButton = aceSmallButton(enhancement, "+FFit", "Internal test only: V4 plus source-derived gated feature-fit Clarity correction. Not default.", function() {
      if (self.currentClarityMode() === ACE_CLARITY_MODE_FEATUREFIT_SHARED_LUMA_SAT_GATE)
         self.setClarityMode(ACE_CLARITY_MODE_FEATUREFIT_TWO_TERM_LUMA_SAT_GATE);
      else
         self.setClarityMode(ACE_CLARITY_MODE_FEATUREFIT_SHARED_LUMA_SAT_GATE);
   });
   this.clarityModeDualZoneOptButton = aceSmallButton(enhancement, "+DZOpt", "Internal test only: optimized DualZone positive Clarity. V4 remains default; negative Clarity remains V4.", function() {
      self.setClarityMode(ACE_CLARITY_MODE_DUALZONE_OPT_SAFER_BRIGHT);
   });
   this.clarityModeDualZoneBoostButton = aceSmallButton(enhancement, "+DZBoost", "Internal test only: boosted guarded DualZone positive Clarity. V4 remains default; negative Clarity remains V4.", function() {
      self.setClarityMode(ACE_CLARITY_MODE_DUALZONE_BROADBAND_BOOST_GUARDED);
   });
   this.clarityModeSelector = new ComboBox(enhancement);
   this.clarityModeSelector.toolTip = ACE_DEBUG_CONTROLS_ENABLED ?
      "Select Clarity algorithm. Product Clarity uses the +DZBoost50 high-headroom path; V4 remains fallback." :
      "Select Product Clarity or the legacy V4 fallback.";
   var claritySelectorModes = aceClaritySelectorModes();
   for (var cm = 0; cm < claritySelectorModes.length; ++cm)
      this.clarityModeSelector.addItem(aceClaritySelectorLabel(claritySelectorModes[cm]));
   this.clarityModeSelector.currentItem = aceClaritySelectorIndexForMode(this.currentClarityMode());
   this.clarityModeSelector.onItemSelected = function(index) {
      self.setClarityMode(aceClaritySelectorModeForIndex(index));
   };
   this.textureModeSelector = new ComboBox(enhancement);
   this.textureModeSelector.toolTip = ACE_DEBUG_CONTROLS_ENABLED || ACE_TEXTURE_COMPARISON_CONTROLS_ENABLED ?
      "Select Texture hybrid implementation for exact versus fast visual and timing comparison." :
      "Select Product Texture or the legacy Texture fallback.";
   var textureSelectorModes = aceTextureSelectorModes();
   for (var tm = 0; tm < textureSelectorModes.length; ++tm)
      this.textureModeSelector.addItem(aceTextureSelectorLabel(textureSelectorModes[tm]));
   this.textureModeSelector.currentItem = aceTextureSelectorIndexForMode(ACE_TEXTURE_MODE_DEFAULT);
   this.textureModeSelector.onItemSelected = function(index) {
      self.setTextureMode(aceTextureSelectorModeForIndex(index));
   };
   this.clarityModeLegacyButton.scaledMinWidth = 34;
   this.clarityModeV2Button.scaledMinWidth = 46;
   this.clarityModeV3Button.scaledMinWidth = 38;
   this.clarityModeV4Button.scaledMinWidth = 54;
   this.clarityModeFeatureFitButton.scaledMinWidth = 70;
   this.clarityModeDualZoneOptButton.scaledMinWidth = 78;
   this.clarityModeDualZoneBoostButton.scaledMinWidth = 92;
   this.clarityDebugButtons = [
      this.clarityModeLegacyButton,
      this.clarityModeV2Button,
      this.clarityModeV3Button,
      this.clarityModeV4Button,
      this.clarityModeFeatureFitButton,
      this.clarityModeDualZoneOptButton,
      this.clarityModeDualZoneBoostButton
   ];
   for (var cb = 0; cb < this.clarityDebugButtons.length; ++cb)
      aceSetCollapsed(this.clarityDebugButtons[cb], true);
   this.textureModeSelector.scaledMinWidth = 250;
   this.clarityModeSelector.scaledMinWidth = 150;
   this.algorithmDebugPanel = new Control(enhancement);
   this.algorithmDebugPanel.sizer = new VerticalSizer;
   this.algorithmDebugPanel.sizer.margin = 0;
   this.algorithmDebugPanel.sizer.spacing = 3;
   this.algorithmDebugPanel.sizer.add(this.textureModeSelector);
   this.algorithmDebugPanel.sizer.add(this.clarityModeSelector);
   this.algorithmDebugPanel.sizer.add(this.dehazeModeSelector);
   enhancement.sizer.add(this.algorithmDebugPanel);
   aceSetCollapsed(this.algorithmDebugPanel, !this.debugControlsVisible);
   aceSetCollapsed(this.textureModeSelector, !this.debugControlsVisible);
   aceSetCollapsed(this.clarityModeSelector, !this.debugControlsVisible);
   aceSetCollapsed(this.dehazeModeSelector, !this.debugControlsVisible);
   enhancementButtons.addStretch();
   enhancement.sizer.add(enhancementButtons);
   this.advancedPanel = aceCompactSection(leftContent, "Advanced");
   this.advancedPanel.visible = false;
   this.advancedDefaultsButton = aceSmallButton(this.advancedPanel, "Defaults", "Reset current Advanced tab only", function() { self.resetAdvancedDefaults(); });
   this.advancedDefaultsButton.scaledMinWidth = 72;
   aceFixHeight(this.advancedDefaultsButton, 24);
   if (this.advancedPanel.aceTitleRow)
      this.advancedPanel.aceTitleRow.add(this.advancedDefaultsButton);
   var advancedTabs = new HorizontalSizer;
   advancedTabs.spacing = 3;
   this.advancedScaleButton = aceSmallButton(this.advancedPanel, "Scale", "Scale response controls", function() { self.setAdvancedMode("scale"); });
   this.advancedClarityButton = aceSmallButton(this.advancedPanel, "Clarity", "Clarity response controls", function() { self.setAdvancedMode("clarity"); });
   this.advancedDehazeButton = aceSmallButton(this.advancedPanel, "Dehaze", "Dehaze veil behavior controls", function() { self.setAdvancedMode("dehaze"); });
   this.advancedProtectionButton = aceSmallButton(this.advancedPanel, "Protection", "Protection strength controls", function() { self.setAdvancedMode("protection"); });
   this.advancedScaleButton.scaledMinWidth = 50;
   this.advancedClarityButton.scaledMinWidth = 58;
   this.advancedDehazeButton.scaledMinWidth = 62;
   this.advancedProtectionButton.scaledMinWidth = 82;
   aceFixHeight(this.advancedScaleButton, 24);
   aceFixHeight(this.advancedClarityButton, 24);
   aceFixHeight(this.advancedDehazeButton, 24);
   aceFixHeight(this.advancedProtectionButton, 24);
   advancedTabs.add(this.advancedScaleButton);
   advancedTabs.add(this.advancedClarityButton);
   advancedTabs.add(this.advancedDehazeButton);
   advancedTabs.add(this.advancedProtectionButton);
   advancedTabs.addStretch();
   this.advancedPanel.sizer.add(advancedTabs);
   this.advancedTextureScale = aceCreateValueSlider(this.advancedPanel, "Texture", "Fine-detail scale used by Texture.", 2, 5, ACE_TEXTURE_RADIUS, " px", null, "Controls the fine-detail scale used by Texture.");
   this.advancedClarityScale = aceCreateValueSlider(this.advancedPanel, "Clarity", "Midtone structure scale used by Clarity.", 6, 18, ACE_CLARITY_RADIUS, " px", null, "Controls the midtone structure scale used by Clarity.");
   this.advancedClarityResponseRow = new Control(this.advancedPanel);
   this.advancedClarityResponseRow.sizer = new HorizontalSizer;
   this.advancedClarityResponseRow.sizer.margin = 0;
   this.advancedClarityResponseRow.sizer.spacing = 6;
   this.advancedClarityResponseRow.sizer.add(aceToolbarLabel(this.advancedClarityResponseRow, "Response"));
   this.advancedClarityResponseSelector = new ComboBox(this.advancedClarityResponseRow);
   this.advancedClarityResponseSelector.toolTip = "Controls Product Clarity response. Light is safest, Balanced is default, Strong opens galaxy/dust response earlier while retaining star and highlight protection.";
   this.advancedClarityResponseSelector.addItem("Light");
   this.advancedClarityResponseSelector.addItem("Balanced");
   this.advancedClarityResponseSelector.addItem("Strong");
   this.advancedClarityResponseSelector.currentItem = aceClarityResponseSelectorIndex(this.appState.advanced.clarityResponse);
   this.advancedClarityResponseSelector.onItemSelected = function(index) {
      self.handleAdvancedClarityResponseChange(aceClarityResponseForSelectorIndex(index));
   };
   this.advancedClarityResponseSelector.scaledMinWidth = 150;
   this.advancedClarityResponseRow.sizer.add(this.advancedClarityResponseSelector);
   this.advancedClarityResponseRow.sizer.addStretch();
   this.advancedDehazeVeilSize = aceCreateValueSlider(this.advancedPanel, "Dehaze", "Broad veil / depth scale used by Dehaze.", 60, 180, ACE_DEHAZE_VEIL_RADIUS, " px", null, "Controls the broad veil / depth scale used by Dehaze.");
   this.advancedVeilStrength = aceCreateValueSlider(this.advancedPanel, "Veil Strength", "Strength of protected veil correction.", ACE_ADVANCED_MIN, ACE_ADVANCED_MAX, DEFAULT_DEHAZE_VEIL_STRENGTH, "", null, "Controls the strength of protected Dehaze veil correction and tone/color depth.");
   this.advancedHighlightProtect = aceCreateValueSlider(this.advancedPanel, "Highlight Guard", "Guard bright nebulosity and star cores.", ACE_ADVANCED_MIN, ACE_ADVANCED_MAX, DEFAULT_DEHAZE_HIGHLIGHT_PROTECT, "", null, "Controls where bright-region protection begins for highlights, bright nebula, and star cores.");
   this.advancedProtectionStrength = aceCreateValueSlider(this.advancedPanel, "Protection Strength", "Master strength for protected regions.", ACE_ADVANCED_MIN, ACE_ADVANCED_MAX, DEFAULT_OVERALL_PROTECTION_STRENGTH, "", null, "Controls how strongly sky, stars, highlights, and artifact-prone regions are protected.");
   this.advancedControls = [
      this.advancedTextureScale,
      this.advancedClarityScale,
      this.advancedDehazeVeilSize,
      this.advancedVeilStrength,
      this.advancedHighlightProtect,
      this.advancedProtectionStrength
   ];
   this.advancedTextureScale.aceAdvancedName = "textureScale";
   this.advancedTextureScale.aceAdvancedBaseRadius = ACE_TEXTURE_RADIUS;
   this.advancedClarityScale.aceAdvancedName = "clarityScale";
   this.advancedClarityScale.aceAdvancedBaseRadius = ACE_CLARITY_RADIUS;
   this.advancedDehazeVeilSize.aceAdvancedName = "dehazeVeilSize";
   this.advancedDehazeVeilSize.aceAdvancedBaseRadius = ACE_DEHAZE_VEIL_RADIUS;
   this.advancedVeilStrength.aceAdvancedName = "dehazeVeilStrength";
   this.advancedHighlightProtect.aceAdvancedName = "dehazeHighlightProtect";
   this.advancedProtectionStrength.aceAdvancedName = "overallProtectionStrength";
   for (var ac = 0; ac < this.advancedControls.length; ++ac) {
      this.advancedControls[ac].hint.visible = false;
      this.advancedControls[ac].onPreviewValueUpdated = function(value, isDragging) {
         var nextValue = this.aceAdvancedBaseRadius ? aceAdvancedPercentFromRadius(value, this.aceAdvancedBaseRadius) : value;
         self.handleAdvancedParameterChange(this.aceAdvancedName, nextValue, isDragging);
      };
      this.advancedControls[ac].onPreviewDragFinished = function(value) {
         var nextValue = this.aceAdvancedBaseRadius ? aceAdvancedPercentFromRadius(value, this.aceAdvancedBaseRadius) : value;
         self.handleAdvancedParameterChange(this.aceAdvancedName, nextValue, false);
      };
      this.advancedPanel.sizer.add(this.advancedControls[ac]);
   }
   this.advancedPanel.sizer.add(this.advancedClarityResponseRow);
   this.advancedGraphic = aceCreateAdvancedDiagnostic(this.advancedPanel, this);
   this.advancedPanel.sizer.add(this.advancedGraphic);
   leftContent.sizer.add(enhancement);
   leftContent.sizer.add(this.advancedPanel);

   var lasso = aceSection(leftContent, "Local Selection");
   this.localSelectionPanel = lasso;
   var lassoButtons = new HorizontalSizer;
   lassoButtons.spacing = 5;
   this.newLassoButton = aceSmallButton(lasso, "New", "Start a new lasso selection", function() {
      self.newLassoSelection();
   });
   this.newLassoButton.scaledMinWidth = 58;
   this.newLassoButton.aceTone = "primary";
   this.clearButton = aceSmallButton(lasso, "Clear", "Clear lasso selection", function() {
      self.clearLassoSelection();
   });
   this.clearButton.scaledMinWidth = 58;
   this.clearButton.aceTone = "danger";
   this.commitButton = aceSmallButton(lasso, "Commit", "Commit the current full-image or lasso edit", function() {
      self.commitCurrentEdit();
   });
   this.commitButton.scaledMinWidth = 62;
   this.commitButton.aceTone = "primary";
   this.invertButton = aceSmallButton(lasso, "Invert", "Invert lasso selection", function() {
      self.invertLassoSelection();
   });
   this.invertButton.scaledMinWidth = 58;
   this.refineButton = aceSmallButton(lasso, "Refine", "Smooth lasso boundary", function() {
      self.refineLassoSelection();
   });
   this.refineButton.scaledMinWidth = 58;
   lassoButtons.add(this.newLassoButton);
   lassoButtons.add(this.clearButton);
   lassoButtons.add(this.commitButton);
   lassoButtons.addStretch();
   lasso.sizer.add(lassoButtons);
   var lassoRefineButtons = new HorizontalSizer;
   lassoRefineButtons.spacing = 8;
   lassoRefineButtons.add(this.invertButton);
   lassoRefineButtons.add(this.refineButton);
   lassoRefineButtons.addStretch();
   lasso.sizer.add(lassoRefineButtons);
   var lassoShapeButtons = new HorizontalSizer;
   lassoShapeButtons.spacing = 8;
   this.expandLassoButton = aceSmallButton(lasso, "Expand", "Grow the lasso boundary", function() {
      self.offsetLassoSelection(12);
   });
   this.expandLassoButton.scaledMinWidth = 82;
   this.contractLassoButton = aceSmallButton(lasso, "Contract", "Shrink the lasso boundary", function() {
      self.offsetLassoSelection(-12);
   });
   this.contractLassoButton.scaledMinWidth = 88;
   lassoShapeButtons.add(this.expandLassoButton);
   lassoShapeButtons.add(this.contractLassoButton);
   lassoShapeButtons.addStretch();
   lasso.sizer.add(lassoShapeButtons);
   lasso.sizer.addSpacing(8);
   this.featherSlider = aceCreateValueSlider(lasso, "Feather / Roll-off", "Smooth mask transition", ACE_FEATHER_MIN, ACE_FEATHER_MAX, ACE_FEATHER_DEFAULT, " px");
   if (this.featherSlider.valueEdit)
      this.featherSlider.valueEdit.setFixedWidth(58);
   this.featherSlider.onPreviewValueUpdated = function(value, isDragging) {
      self.featherAdjusting = !!isDragging;
      if (isDragging)
         self.handleFeatherPreviewChanged("Feather adjusting - release to update");
      else
         self.handleLassoChanged("Feather updated");
   };
   this.featherSlider.onPreviewDragFinished = function(value) {
      self.featherAdjusting = false;
      self.scheduleLassoChanged("Feather updated", false);
   };
   lasso.sizer.add(this.featherSlider);
   this.protectedOverlayCheck = aceCheck(lasso, "Protected Overlay", true, function() {
      self.invalidateProtectedOverlay();
      if (self.preview)
         self.preview.update();
   });
   this.protectedOverlayCheck.toolTip = "Show a subtle frost over the protected side of the lasso in normal Preview mode.";
   var overlayRow = new HorizontalSizer;
   overlayRow.spacing = 6;
   overlayRow.add(this.protectedOverlayCheck);
   this.protectedOverlayIntensity = new ComboBox(lasso);
   this.protectedOverlayIntensity.toolTip = "Protected overlay intensity.";
   this.protectedOverlayIntensity.addItem("Low");
   this.protectedOverlayIntensity.addItem("Med");
   this.protectedOverlayIntensity.addItem("High");
   this.protectedOverlayIntensity.currentItem = 1;
   this.protectedOverlayIntensity.minWidth = 78;
   var overlayComboFont = new Font;
   overlayComboFont.pixelSize = ACE_FONT_BODY;
   this.protectedOverlayIntensity.font = overlayComboFont;
   this.protectedOverlayIntensity.onItemSelected = function() {
      self.invalidateProtectedOverlay();
      if (self.preview)
         self.preview.update();
   };
   overlayRow.add(this.protectedOverlayIntensity);
   overlayRow.addStretch();
   lasso.sizer.add(overlayRow);
   this.detailLoupeCheck = aceCheck(lasso, "Detail Loupe (hold Shift)", false, function() {
      self.lowZoomLoupeEnabled = !!self.detailLoupeCheck.checked;
      if (self.lowZoomLoupeEnabled && self.lowZoomLoupeShouldBeActive())
         self.scheduleLowZoomLoupeRefresh("Detail loupe enabled");
      else
         self.clearLowZoomLoupe();
      if (self.preview)
         self.preview.update();
   });
   this.detailLoupeCheck.toolTip = "Arm the optional cursor-following native-detail loupe at Fit or 100%. Hold Shift over the preview; press C while holding Shift to toggle the loupe Before/After.";
   lasso.sizer.add(this.detailLoupeCheck);
   var localEditButtons = new HorizontalSizer;
   localEditButtons.spacing = 5;
   this.cancelEditButton = aceSmallButton(lasso, "Cancel Edit", "Discard pending adjustment but keep the lasso", function() {
      self.cancelLocalEdit();
   });
   this.cancelEditButton.scaledMinWidth = 68;
   this.undoButton = aceSmallButton(lasso, "Undo", "Undo committed local edit", function() {
      self.undoLocalEdit();
   });
   this.undoButton.scaledMinWidth = 56;
   this.redoButton = aceSmallButton(lasso, "Redo", "Redo committed local edit", function() {
      self.redoLocalEdit();
   });
   this.redoButton.scaledMinWidth = 56;
   localEditButtons.add(this.cancelEditButton);
   localEditButtons.add(this.undoButton);
   localEditButtons.add(this.redoButton);
   localEditButtons.addStretch();
   lasso.sizer.add(localEditButtons);
   leftContent.sizer.add(lasso);

   leftContent.sizer.addStretch();

   var centerPanel = new Control(this);
   acePaintPanel(centerPanel, ACE_COLORS.panelAlt, ACE_COLORS.panelAlt);
   centerPanel.sizer = new VerticalSizer;
   centerPanel.sizer.margin = 0;
   centerPanel.sizer.spacing = 6;

   var toolbarHost = new Control(centerPanel);
   aceFixHeight(toolbarHost, ACE_TOOLBAR_HEIGHT);
   acePaintPanel(toolbarHost, ACE_COLORS.panelDark, ACE_COLORS.lineDim);
   toolbarHost.sizer = new HorizontalSizer;
   toolbarHost.sizer.margin = 0;
   toolbarHost.sizer.spacing = ACE_HOST_IS_WINDOWS ? 1 : 2;
   var previewButtonNames = ["Preview", "Texture", "Clarity", "Dehaze", "Delta", "Lasso", "Star", "Edit"];
   var previewButtonLabels = {
      Preview: ACE_HOST_IS_WINDOWS ? "Prev" : "Preview",
      Texture: ACE_HOST_IS_WINDOWS ? "Tex" : "Texture",
      Clarity: ACE_HOST_IS_WINDOWS ? "Clar" : "Clarity",
      Dehaze: ACE_HOST_IS_WINDOWS ? "Deh" : "Dehaze",
      Delta: ACE_HOST_IS_WINDOWS ? "\u0394" : "Delta",
      Lasso: ACE_HOST_IS_WINDOWS ? "Lasso" : "Lasso",
      Star: ACE_HOST_IS_WINDOWS ? "Star" : "Star",
      Edit: ACE_HOST_IS_WINDOWS ? "Edit" : "Edit"
   };
   var previewButtonCompactWidths = {
      Preview: 38,
      Texture: 44,
      Clarity: 38,
      Dehaze: 38,
      Delta: 28,
      Lasso: 42,
      Star: 34,
      Edit: 34
   };
   var previewButtonRoomyWidths = {
      Preview: 58,
      Texture: 64,
      Clarity: 50,
      Dehaze: 58,
      Delta: 40,
      Lasso: 44,
      Star: 38,
      Edit: 40
   };
   this.responsiveToolbarButtons = [];
   for (var i = 0; i < previewButtonNames.length; ++i) {
      (function(name) {
         var callback = function() {
            if (name === "Preview")
               self.setViewMode("preview");
            else if (name === "Texture")
               self.setViewMode("texture");
            else if (name === "Clarity")
               self.setViewMode("clarity");
            else if (name === "Dehaze")
               self.setViewMode("dehaze");
            else if (name === "Delta")
               self.setViewMode("delta");
            else if (name === "Lasso")
               self.setViewMode("lasso");
            else if (name === "Star")
               self.setViewMode("star");
            else if (name === "Edit")
               self.setViewMode("allowed");
            else if (name === "-")
               self.zoomPreviewStep(-1);
            else if (name === "+")
               self.zoomPreviewStep(1);
            else if (name === "Fit")
               self.fitPreviewToView();
         };
         var label = previewButtonLabels[name] || name;
         var button = aceSmallButton(toolbarHost, label, name === "-" ? "Zoom out" : name === "+" ? "Zoom in" : (name === "Edit" ? "Edit Area preview control" : name + " preview control"), callback);
         button.aceToolbarName = name;
         button.aceCompactText = previewButtonLabels[name] || name;
         button.aceRoomyText = name;
         button.aceCompactWidth = previewButtonCompactWidths[name] || 38;
         button.aceRoomyWidth = previewButtonRoomyWidths[name] || 44;
         if (name === "Preview")
            button.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 38 : 58;
         else if (name === "Texture")
            button.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 44 : 64;
         else if (name === "Clarity")
            button.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 38 : 46;
         else if (name === "Dehaze")
            button.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 38 : 58;
         else if (name === "Delta")
            button.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 28 : 40;
         else if (name === "Lasso")
            button.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 42 : 44;
         else if (name === "Star")
            button.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 34 : 38;
         else if (name === "Edit")
            button.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 34 : 40;
         self.responsiveToolbarButtons.push(button);
         if (name === "-" || name === "+") {
            button.scaledMinWidth = 50;
            button.aceTone = "zoom";
         }
         if (name === "Preview")
            self.viewModeButtons.preview = button;
         else if (name === "Texture")
            self.viewModeButtons.texture = button;
         else if (name === "Clarity")
            self.viewModeButtons.clarity = button;
         else if (name === "Dehaze")
            self.viewModeButtons.dehaze = button;
         else if (name === "Delta")
            self.viewModeButtons.delta = button;
         else if (name === "Lasso")
            self.viewModeButtons.lasso = button;
         else if (name === "Star")
            self.viewModeButtons.star = button;
         else if (name === "Edit")
            self.viewModeButtons.allowed = button;
         toolbarHost.sizer.add(button);
      })(previewButtonNames[i]);
   }
   if (ACE_HOST_IS_WINDOWS)
      toolbarHost.sizer.addSpacing(8);
   else
      toolbarHost.sizer.add(aceToolbarSeparator(toolbarHost));
   toolbarHost.sizer.add(this.beforeAfterPill);
   if (ACE_HOST_IS_WINDOWS) {
      toolbarHost.sizer.addSpacing(10);
   } else {
      toolbarHost.sizer.addSpacing(2);
   }
   this.zoomToolbarLabel = null;
   if (!ACE_HOST_IS_WINDOWS) {
      var zoomLabel = aceToolbarLabel(toolbarHost, "Zoom", 0xffd7f2ff);
      zoomLabel.scaledMinWidth = 52;
      toolbarHost.sizer.add(zoomLabel);
      this.zoomToolbarLabel = zoomLabel;
   }
   this.zoomToolbarButtons = [];
   var zoomButtonNames = ["+", "-", "Fit"];
   for (var z = 0; z < zoomButtonNames.length; ++z) {
      (function(name) {
         var callback = function() {
            if (name === "-")
               self.zoomPreviewStep(-1);
            else if (name === "+")
               self.zoomPreviewStep(1);
            else
               self.fitPreviewToView();
         };
         var button = aceSmallButton(toolbarHost, name, name === "-" ? "Zoom out" : name === "+" ? "Zoom in" : "Fit preview", callback);
         button.aceToolbarName = name;
         if (name === "-" || name === "+" || name === "Fit") {
            button.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 44 : 54;
            button.aceTone = "zoom";
         }
         if (name === "Fit")
            button.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 52 : 62;
         self.zoomToolbarButtons.push(button);
         toolbarHost.sizer.add(button);
      })(zoomButtonNames[z]);
   }
   toolbarHost.sizer.addStretch();
   centerPanel.sizer.add(toolbarHost);

   this.preview = aceCreatePreview(centerPanel, this);
   centerPanel.sizer.add(this.preview, 100);

   this.previewStatusLeftText = "Ready";
   this.previewStatusRightText = "Preview draft";

   var rightPanel = new Control(this);
   rightPanel.scaledMinWidth = ACE_RIGHT_PANEL_WIDTH;
   rightPanel.maxWidth = ACE_RIGHT_PANEL_WIDTH + 12;
   acePaintPanel(rightPanel, ACE_COLORS.panelAlt, ACE_COLORS.panelAlt);
   rightPanel.sizer = new VerticalSizer;
   rightPanel.sizer.margin = 0;
   rightPanel.sizer.spacing = 6;
   var rightContent = rightPanel;

   var protection = aceSection(rightContent, "Protection");
   this.starProtectionDesired = true;
   this.backgroundProtection = aceCheck(protection, "Background Protection", true, function() {
      self.handleProtectionFamilyChange("background");
   });
   this.starProtection = aceCheck(protection, "Star Protection", true, function() {
      self.handleProtectionFamilyChange("stars");
   });
   protection.sizer.add(this.backgroundProtection);
   protection.sizer.add(this.starProtection);
   this.protectSky = aceCheck(protection, "Protect Sky Background", true, function() {});
   this.preventDark = aceCheck(protection, "Prevent Local Dark Patches", true, function() {});
   this.protectStars = aceCheck(protection, "Protect Stars", true, function() {});
   this.protectHalos = aceCheck(protection, "Protect Star Halos", true, function() {});
   aceSetCollapsed(this.protectSky, true);
   aceSetCollapsed(this.preventDark, true);
   aceSetCollapsed(this.protectStars, true);
   aceSetCollapsed(this.protectHalos, true);
   this.protectionSummaryLine = aceCompactStatusLine(protection, "BG protected - Stars protected", ACE_COLORS.active);
   protection.sizer.add(this.protectionSummaryLine);
   rightContent.sizer.add(protection);

   var viewLegend = aceSection(rightContent, "View Legend");
   this.viewLegendPanel = viewLegend;
   this.viewLegendTitleLine = aceCompactStatusLine(viewLegend, "View: Preview", ACE_COLORS.sectionTitle);
   this.viewLegendBodyLine = aceCompactStatusLine(viewLegend, "Protected contrast result.", ACE_COLORS.accent);
   viewLegend.sizer.add(this.viewLegendTitleLine);
   viewLegend.sizer.add(this.viewLegendBodyLine);
   rightContent.sizer.add(viewLegend);

   var localEdit = aceSection(rightContent, "Local Edit");
   this.localEditModeLine = aceCompactStatusLine(localEdit, "Mode: Full Image", ACE_COLORS.sectionTitle);
   this.localEditStateLine = aceCompactStatusLine(localEdit, "No local selection active.", ACE_COLORS.accent);
   this.localEditNextLine = aceCompactStatusLine(localEdit, "", ACE_COLORS.active);
   localEdit.sizer.add(this.localEditModeLine);
   localEdit.sizer.add(this.localEditStateLine);
   localEdit.sizer.add(this.localEditNextLine);
   aceSetCollapsed(this.localEditNextLine, true);
   rightContent.sizer.add(localEdit);

   var output = aceSection(rightContent, "Output");
   var outputButtons1 = new HorizontalSizer;
   outputButtons1.spacing = 5;
   this.newImageButton = aceButton(output, "Save New Image", "Save the committed recipe as a new full-resolution image", function() {
      self.createNewImageOutput();
   });
   this.newImageButton.scaledMinWidth = 136;
   this.applyButton = aceButton(output, "Apply to Target", "Apply working result to the target source view when safe", function() {
      self.applyWorkingResultToView();
   });
   this.applyButton.scaledMinWidth = 112;
   outputButtons1.add(this.newImageButton);
   outputButtons1.add(this.applyButton);
   output.sizer.add(outputButtons1);
   this.saveCurrentMaskButton = aceButton(output, "Save Current Mask", "Save the mask relevant to the current view", function() {
      self.saveCurrentMaskOutput();
   });
   this.saveCurrentMaskButton.scaledMinWidth = 152;
   output.sizer.add(this.saveCurrentMaskButton);
   this.saveMaskAuditButton = aceButton(output, "Mask Audit", "Save full-resolution diagnostic masks for artifact inspection", function() {
      self.saveMaskAuditOutput();
   });
   this.saveMaskAuditButton.scaledMinWidth = 152;
   output.sizer.add(this.saveMaskAuditButton);
   aceSetCollapsed(this.saveMaskAuditButton, !ACE_DEBUG_CONTROLS_ENABLED);
   this.saveComputeAuditButton = aceButton(output, "Compute Audit", "Save full-resolution signed computation maps for artifact attribution", function() {
      self.saveComputeAuditOutput();
   });
   this.saveComputeAuditButton.scaledMinWidth = 152;
   output.sizer.add(this.saveComputeAuditButton);
   aceSetCollapsed(this.saveComputeAuditButton, !ACE_DEBUG_CONTROLS_ENABLED);
   this.fullTimingAuditButton = aceButton(output, "Full Timing", "Run a fresh full-resolution timing audit without writing an output image", function() {
      self.runFullResolutionTimingAudit();
   });
   this.fullTimingAuditButton.scaledMinWidth = 152;
   output.sizer.add(this.fullTimingAuditButton);
   aceSetCollapsed(this.fullTimingAuditButton, !ACE_DEBUG_CONTROLS_ENABLED);
   this.performanceFlowAuditButton = aceButton(output, "Perf Audit", "Run automated preview/detail/local-flow performance instrumentation", function() {
      self.runPerformanceFlowAudit();
   });
   this.performanceFlowAuditButton.scaledMinWidth = 152;
   output.sizer.add(this.performanceFlowAuditButton);
   aceSetCollapsed(this.performanceFlowAuditButton, !ACE_DEBUG_CONTROLS_ENABLED);
   var outputButtons2 = new HorizontalSizer;
   outputButtons2.spacing = 5;
   this.revertButton = aceButton(output, "Revert", "Return the working result to the starting source image", function() {
      self.revertToSource();
   });
   this.revertButton.scaledMinWidth = 88;
   this.closeButton = aceButton(output, "Close", "Close Astro Contrast Enhancer", function() {
      self.ok();
   });
   this.closeButton.scaledMinWidth = 88;
   outputButtons2.add(this.revertButton);
   outputButtons2.add(this.closeButton);
   output.sizer.add(outputButtons2);
   rightContent.sizer.add(output);

   rightContent.sizer.addStretch();

   var body = new HorizontalSizer;
   body.spacing = 8;
   body.add(leftPanel);
   body.add(centerPanel, 100);
   body.add(rightPanel);

   var footer = new Control(this);
   aceFixHeight(footer, ACE_FOOTER_HEIGHT);
   acePaintPanel(footer, ACE_COLORS.header, ACE_COLORS.lineDim);
   footer.sizer = new HorizontalSizer;
   footer.sizer.margin = 4;
   footer.sizer.spacing = 8;
   var readyLabel = aceHintLabel(footer, "Ready");
   readyLabel.wordWrapping = false;
   this.footerLeft = readyLabel;
   footer.sizer.add(readyLabel);
   footer.sizer.addStretch();
   var copyrightLabel = aceHintLabel(footer, ACE_FOOTER_NOTICE);
   copyrightLabel.wordWrapping = false;
   copyrightLabel.textAlignment = TextAlign_Center | TextAlign_VertCenter;
   var copyrightFont = new Font;
   copyrightFont.pixelSize = ACE_HOST_IS_WINDOWS ? 10 : 9;
   copyrightLabel.font = copyrightFont;
   copyrightLabel.scaledMinWidth = ACE_HOST_IS_WINDOWS ? 360 : 340;
   this.footerCopyright = copyrightLabel;
   footer.sizer.add(copyrightLabel);
   footer.sizer.addStretch();
   var renderLabel = aceHintLabel(footer, "Preview: draft");
   renderLabel.wordWrapping = false;
   renderLabel.scaledMinWidth = 280;
   this.footerRight = renderLabel;
   renderLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   footer.sizer.add(renderLabel);

   this.sizer = new VerticalSizer;
   this.sizer.margin = 8;
   this.sizer.spacing = 8;
   this.sizer.add(header);
   this.sizer.add(body, 100);
   this.sizer.add(footer);
   this.setMinWidth(ACE_MIN_DIALOG_WIDTH);
   this.setMinHeight(ACE_MIN_DIALOG_HEIGHT);

   this.setProcessingMode("full");
   this.setInputType("stars");
   this.refreshTextureModeUi();
   this.refreshClarityModeUi();
   this.refreshAdvancedUi();
   this.applySavedWindowSize();
   this.refreshWindowSizeReadout();
   this.refreshResponsiveWindowsPresentation();
   this.refreshSourceCombo();
   this.targetImageLoading = true;
   this.previewWarmupActive = true;
   this.refreshPreviewStatus("Preparing shell", "Preparing first preview response...");
   this.setFooterStatus("Preparing first preview response...", ACE_COLORS.warning);
   if (this.preview)
      aceRefreshNow(this.preview);
   if (this.startupAttachTimer)
      this.startupAttachTimer.start();
   else
      this.tryAttachActiveViewAtStartup();
   this.refreshViewModeButtons();

   this.onResize = function() {
      self.displayClassification = aceClassifyWorkspace(aceGetDialogAvailableScreenSize(self));
      self.refreshWindowSizeReadout();
      self.refreshResponsiveWindowsPresentation();
      if (self.preview)
         self.preview.update();
   };
}
}

AstroContrastEnhancerDialog.prototype.refreshLocalSelectionControls = function() {
   var lassoEnabled = this.processingMode === "lasso";
   var hasSelection = this.hasLassoSelection();
   var hasSource = this.hasActiveSource();
   var hasPending = !!(this.appState && this.appState.cache && this.appState.cache.pendingActive);
   var committedLocalCount = this.appState && this.appState.editRecipe ? this.appState.editRecipe.length : 0;
   var canUndo = !!(this.appState && this.appState.undoStack && this.appState.undoStack.length);
   var canRedo = !!(this.appState && this.appState.redoStack && this.appState.redoStack.length);
   var canCommit = lassoEnabled &&
      hasSelection &&
      this.appState &&
      this.appState.cache &&
      this.appState.cache.pendingActive &&
      this.appState.params &&
      this.appState.params.hasEffect();
   var geometryActionsReady = hasSelection &&
      !this.selectionTransitionBusy &&
      !this.pendingLassoStatusText &&
      !this.lassoDrawing &&
      !this.lassoMoving;
   if (this.newLassoButton)
      this.newLassoButton.setVisualEnabled(hasSource);
   if (this.newLassoButton)
      this.newLassoButton.setActive(!!this.localSelectionNewActive);
   if (this.clearButton)
      this.clearButton.setVisualEnabled(hasSource && (lassoEnabled || hasSelection || !!this.localSelectionNewActive || hasPending || committedLocalCount > 0));
   if (this.invertButton)
      this.invertButton.setVisualEnabled(geometryActionsReady);
   if (this.refineButton)
      this.refineButton.setVisualEnabled(geometryActionsReady);
   if (this.expandLassoButton)
      this.expandLassoButton.setVisualEnabled(geometryActionsReady);
   if (this.contractLassoButton)
      this.contractLassoButton.setVisualEnabled(geometryActionsReady);
   if (this.commitButton)
      this.commitButton.setVisualEnabled(canCommit);
   if (this.commitButton && !canCommit)
      this.commitButton.setActive(false);
   if (this.cancelEditButton)
      this.cancelEditButton.setVisualEnabled(hasPending);
   if (this.undoButton)
      this.undoButton.setVisualEnabled(canUndo);
   if (this.redoButton)
      this.redoButton.setVisualEnabled(canRedo);
   if (this.protectedOverlayCheck)
      this.protectedOverlayCheck.enabled = lassoEnabled;
   if (this.protectedOverlayIntensity)
      this.protectedOverlayIntensity.enabled = lassoEnabled;
   if (this.featherSlider)
      this.featherSlider.setEnabled(lassoEnabled);
   if (this.saveCurrentMaskButton)
      this.saveCurrentMaskButton.setVisualEnabled(this.currentMaskViewCanSave() && this.viewModeAvailability(this.appState.preview.viewMode || "preview").available);
};

AstroContrastEnhancerDialog.prototype.refreshWindowSizeReadout = function() {
   if (!this.windowSizeLine)
      return;
   var defaultSize = aceDefaultDialogSize();
   var w = this.width || defaultSize.width;
   var h = this.height || defaultSize.height;
   this.windowSizeLine.setStatus("Win " + w + " x " + h, ACE_COLORS.accent);
};

AstroContrastEnhancerDialog.prototype.refreshResponsiveWindowsPresentation = function() {
   if (!ACE_HOST_IS_WINDOWS)
      return;
   var width = this.width || aceDefaultDialogSize().width;
   var roomy = width >= 1540;
   if (this.aceWindowsRoomyPresentation === roomy)
      return;
   this.aceWindowsRoomyPresentation = roomy;
   if (this.titleControl && typeof this.titleControl.setRoomyWindows === "function")
      this.titleControl.setRoomyWindows(roomy);
   if (this.inputModeGroup) {
      this.inputModeGroup.scaledMinWidth = roomy ? 216 : 204;
      this.inputModeGroup.update();
   }
   if (this.imageTypeModeLine) {
      this.imageTypeModeLine.scaledMinWidth = roomy ? 204 : 192;
      this.imageTypeModeLine.update();
   }
   if (this.windowSizeGroup) {
      this.windowSizeGroup.scaledMinWidth = roomy ? 174 : 154;
      this.windowSizeGroup.update();
   }
   if (this.windowSizeLine) {
      this.windowSizeLine.scaledMinWidth = roomy ? 160 : 140;
      this.windowSizeLine.update();
   }
   if (this.sourceCombo) {
      this.sourceCombo.minWidth = roomy ? 300 : 280;
      this.sourceCombo.update();
   }
   if (this.beforeAfterPill) {
      this.beforeAfterPill.aceText = "Before/After";
      this.beforeAfterPill.aceShortcutText = "";
      this.beforeAfterPill.scaledMinWidth = 160;
      this.beforeAfterPill.minWidth = 160;
      this.beforeAfterPill.maxWidth = 160;
      this.beforeAfterPill.aceTextOffsetX = 0;
      this.beforeAfterPill.update();
   }
   if (this.zoomToolbarButtons) {
      for (var z = 0; z < this.zoomToolbarButtons.length; ++z) {
         var button = this.zoomToolbarButtons[z];
         if (!button)
            continue;
         button.scaledMinWidth = button.aceToolbarName === "Fit" ? (roomy ? 56 : 52) : (roomy ? 48 : 44);
         button.update();
      }
   }
   if (this.displayDiagnosticsButton) {
      this.displayDiagnosticsButton.aceText = roomy ? "Display" : "Disp";
      this.displayDiagnosticsButton.scaledMinWidth = roomy ? 62 : 46;
      this.displayDiagnosticsButton.update();
   }
   if (this.techAppendixButton) {
      this.techAppendixButton.aceText = roomy ? "Tech Appx" : "Tech";
      this.techAppendixButton.scaledMinWidth = roomy ? 96 : 72;
      this.techAppendixButton.update();
   }
   if (this.responsiveToolbarButtons) {
      for (var i = 0; i < this.responsiveToolbarButtons.length; ++i) {
         var button = this.responsiveToolbarButtons[i];
         if (!button)
            continue;
         button.aceText = roomy ? button.aceRoomyText : button.aceCompactText;
         button.scaledMinWidth = roomy ? button.aceRoomyWidth : button.aceCompactWidth;
         button.update();
      }
   }
};

AstroContrastEnhancerDialog.prototype.readWindowSizePreference = function() {
   if (typeof Settings === "undefined")
      return null;
   try {
      var w = Settings.read(ACE_SETTING_WINDOW_WIDTH, DataType_Int32);
      var h = Settings.read(ACE_SETTING_WINDOW_HEIGHT, DataType_Int32);
      if (w && h)
      {
         var x = aceReadSettingInt(ACE_SETTING_WINDOW_X);
         var y = aceReadSettingInt(ACE_SETTING_WINDOW_Y);
         return {
            width: Math.round(w),
            height: Math.round(h),
            x: x !== null && x >= 0 ? x : null,
            y: y !== null && y >= 0 ? y : null
         };
      }
   } catch (error) {
   }
   return null;
};

AstroContrastEnhancerDialog.prototype.restoreWindowPositionIfSafe = function(saved, size, workspace) {
   if (!saved || saved.x === null || saved.y === null)
      return false;
   if (!aceWindowPositionFitsWorkspace({ x: saved.x, y: saved.y }, size, workspace))
      return false;
   try {
      if (typeof this.move === "function") {
         this.move(saved.x, saved.y);
         return true;
      }
   } catch (error) {
   }
   return false;
};

AstroContrastEnhancerDialog.prototype.applySavedWindowSize = function() {
   var workspace = aceGetDialogAvailableScreenSize(this);
   var defaultSize = aceAcmCompactDialogSizeForWorkspace(workspace);
   var saved = this.readWindowSizePreference();
   var selected = null;
   if (aceSavedWindowSizeIsUsableForPlatform(saved) && aceWindowSizeFitsWorkspace(saved, workspace))
      selected = { width: saved.width, height: saved.height };
   else if (aceWindowSizeFitsWorkspace(defaultSize, workspace))
      selected = defaultSize;
   else
      selected = aceLargestUsableDialogSize(workspace);
   if (selected.width < ACE_DISPLAY_MIN_WIDTH || selected.height < ACE_DISPLAY_MIN_HEIGHT) {
      this.setMinWidth(Math.max(320, selected.width));
      this.setMinHeight(Math.max(320, selected.height));
   }
   this.resize(selected.width, selected.height);
   if (saved && selected.width === saved.width && selected.height === saved.height)
      this.restoreWindowPositionIfSafe(saved, selected, workspace);
};

AstroContrastEnhancerDialog.prototype.currentWindowSize = function() {
   var defaultSize = aceDefaultDialogSize();
   return {
      width: Math.round(this.width || defaultSize.width),
      height: Math.round(this.height || defaultSize.height)
   };
};

AstroContrastEnhancerDialog.prototype.saveWindowSizePreference = function() {
   var size = this.currentWindowSize();
   if (size.width < ACE_DISPLAY_MIN_WIDTH || size.height < ACE_DISPLAY_MIN_HEIGHT) {
      aceMessage("ACE cannot save this window size because it is below the supported minimum interface size.", ACE_TOOL_NAME + " Window Layout", StdIcon_Warning);
      this.setFooterStatus("Window size not saved: below supported minimum");
      return;
   }
   if (size.width < aceMinimumSavedWindowWidthForPlatform()) {
      aceMessage("ACE cannot save this Windows window width because the toolbar and header controls become crowded at this size. Please widen the ACE window before saving the layout.", ACE_TOOL_NAME + " Window Layout", StdIcon_Warning);
      this.setFooterStatus("Window size not saved: too narrow for Windows layout");
      return;
   }
   if (typeof Settings !== "undefined") {
      try {
         Settings.write(ACE_SETTING_WINDOW_WIDTH, DataType_Int32, size.width);
         Settings.write(ACE_SETTING_WINDOW_HEIGHT, DataType_Int32, size.height);
         var pos = aceGetDialogPosition(this);
         if (pos) {
            Settings.write(ACE_SETTING_WINDOW_X, DataType_Int32, pos.x);
            Settings.write(ACE_SETTING_WINDOW_Y, DataType_Int32, pos.y);
         }
         this.setFooterStatus("Window layout saved");
      } catch (error) {
         this.setFooterStatus("Window size set for this session");
      }
   } else {
      this.setFooterStatus("Window size set for this session");
   }
   this.refreshWindowSizeReadout();
};

AstroContrastEnhancerDialog.prototype.resetWindowSizeDefault = function() {
   var workspace = aceGetDialogAvailableScreenSize(this);
   var defaultSize = aceAcmCompactDialogSizeForWorkspace(workspace);
   var selected = aceWindowSizeFitsWorkspace(defaultSize, workspace) ? defaultSize : aceLargestUsableDialogSize(workspace);
   if (selected.width < ACE_DISPLAY_MIN_WIDTH || selected.height < ACE_DISPLAY_MIN_HEIGHT) {
      this.setMinWidth(Math.max(320, selected.width));
      this.setMinHeight(Math.max(320, selected.height));
   } else {
      this.setMinWidth(ACE_DISPLAY_MIN_WIDTH);
      this.setMinHeight(ACE_DISPLAY_MIN_HEIGHT);
   }
   this.resize(selected.width, selected.height);
   if (typeof Settings !== "undefined") {
      try {
         Settings.write(ACE_SETTING_WINDOW_WIDTH, DataType_Int32, defaultSize.width);
         Settings.write(ACE_SETTING_WINDOW_HEIGHT, DataType_Int32, defaultSize.height);
         Settings.write(ACE_SETTING_WINDOW_X, DataType_Int32, -1);
         Settings.write(ACE_SETTING_WINDOW_Y, DataType_Int32, -1);
      } catch (error) {
      }
   }
   this.refreshWindowSizeReadout();
   if (this.preview)
      this.preview.update();
   this.setFooterStatus("Default window layout restored");
};

AstroContrastEnhancerDialog.prototype.showDisplayDiagnostics = function() {
   aceShowDocument("Display Diagnostics", aceBuildDisplayDiagnosticsLines(this, !!this.displayWarningShown));
};

AstroContrastEnhancerDialog.prototype.showWorkspaceWarningIfNeeded = function() {
   var workspace = aceGetDialogAvailableScreenSize(this);
   var classification = aceClassifyWorkspace(workspace);
   this.displayClassification = classification;
   this.displayWarningShown = false;
   if (classification === "OK" || classification === "UNKNOWN")
      return;
   if (classification === "MARGINAL" && aceReadSettingBool(ACE_SETTING_MARGINAL_WARNING_DISMISSED))
      return;
   this.displayWarningShown = true;
   if (classification === "MARGINAL") {
      var answer = (new MessageBox(
         aceBuildWorkspaceWarning(this, classification) + "\n\nDismiss this marginal workspace warning for future launches?",
         ACE_TOOL_NAME + " Display Notice",
         StdIcon_Information,
         StdButton_Yes,
         StdButton_No
      )).execute();
      if (answer === StdButton_Yes)
         aceWriteSettingBool(ACE_SETTING_MARGINAL_WARNING_DISMISSED, true);
   } else {
      aceMessage(aceBuildWorkspaceWarning(this, classification), ACE_TOOL_NAME + " Display Warning", StdIcon_Warning);
   }
};

AstroContrastEnhancerDialog.prototype.refreshImageTypeReadout = function() {
   if (!this.imageTypeModeLine)
      return;
   var starsMode = this.inputType === "stars";
   this.imageTypeModeLine.setStatus(
      starsMode ? "Mode: Stars Present" : "Mode: Starless",
      starsMode ? ACE_COLORS.warning : ACE_COLORS.accent,
      true,
      starsMode ? 0xff3a2e14 : 0xff242f38
   );
};

AstroContrastEnhancerDialog.prototype.refreshDebugControlsVisibility = function() {
   var visible = !!this.debugControlsVisible;
   if (this.algorithmDebugPanel)
      aceSetCollapsed(this.algorithmDebugPanel, !visible);
   if (this.textureModeSelector)
      aceSetCollapsed(this.textureModeSelector, !visible);
   if (this.clarityModeSelector)
      aceSetCollapsed(this.clarityModeSelector, !visible);
   if (this.dehazeModeSelector)
      aceSetCollapsed(this.dehazeModeSelector, !visible);
   if (this.clarityDebugButtons) {
      for (var cb = 0; cb < this.clarityDebugButtons.length; ++cb)
         aceSetCollapsed(this.clarityDebugButtons[cb], true);
   }
   if (this.saveMaskAuditButton)
      aceSetCollapsed(this.saveMaskAuditButton, !visible);
   if (this.saveComputeAuditButton)
      aceSetCollapsed(this.saveComputeAuditButton, !visible);
   if (this.fullTimingAuditButton)
      aceSetCollapsed(this.fullTimingAuditButton, !visible);
   if (this.performanceFlowAuditButton)
      aceSetCollapsed(this.performanceFlowAuditButton, !visible);
   this.refreshTextureModeUi();
   this.refreshClarityModeUi();
   this.refreshDehazeAppModeUi();
   this.refreshPreviewStatus(this.describeLoadedSource(), visible ? "Debug controls shown" : "Debug controls hidden");
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.toggleDebugControls = function() {
   this.debugControlsVisible = !this.debugControlsVisible;
   this.refreshDebugControlsVisibility();
   this.adjustToContents();
   this.refreshWindowSizeReadout();
};

AstroContrastEnhancerDialog.prototype.currentClarityMode = function() {
   return aceNormalizeClarityMode(this.appState && this.appState.params ? this.appState.params.clarityMode : null);
};

AstroContrastEnhancerDialog.prototype.currentTextureMode = function() {
   return aceNormalizeTextureMode(this.appState && this.appState.params ? this.appState.params.textureMode : null);
};

AstroContrastEnhancerDialog.prototype.refreshTextureModeUi = function() {
   var mode = this.currentTextureMode();
   if (this.textureModeSelector) {
      this.textureModeSelector.currentItem = aceTextureSelectorIndexForMode(mode);
      this.textureModeSelector.toolTip = this.debugControlsVisible || ACE_TEXTURE_COMPARISON_CONTROLS_ENABLED ?
         "Active Texture algorithm: " + aceTextureSelectorLabel(mode) + " | algorithm_id " + mode + " | hybrid flavor " + aceTextureHybridFlavorForMode(mode) + " | DoG/tensor hybrid " + (aceTextureModeUsesDogTensorHybrid(mode) ? "active" : "inactive") + "." :
         "Texture algorithm selector is available in debug mode.";
   }
};

AstroContrastEnhancerDialog.prototype.currentDehazeAppMode = function() {
   return aceNormalizeDehazeAppMode(this.appState && this.appState.params ? this.appState.params.dehazeMode : null);
};

AstroContrastEnhancerDialog.prototype.refreshDehazeAppModeUi = function() {
   var mode = this.currentDehazeAppMode();
   if (this.dehazeModeSelector) {
      this.dehazeModeSelector.currentItem = aceDehazeAppSelectorIndexForMode(mode);
      this.dehazeModeSelector.toolTip = this.debugControlsVisible ?
         "Active Dehaze algorithm: " + aceDehazeAppSelectorLabel(mode) + " | algorithm_id " + mode + "." :
         "Dehaze algorithm selector is available in debug mode.";
   }
};

AstroContrastEnhancerDialog.prototype.setDehazeAppMode = function(mode) {
   if (this.outputRendering)
      return;
   var next = aceNormalizeDehazeAppMode(mode);
   if (!this.appState || !this.appState.params)
      return;
   if (aceNormalizeDehazeAppMode(this.appState.params.dehazeMode) === next)
      return;
   this.appState.params.dehazeMode = next;
   if (this.processingMode === "full") {
      this.appState.globalParams = aceCopyParams(this.appState.params);
      this.appState.globalAdvanced = aceCopyAdvancedParams(this.appState.advanced);
   }
   this.appState.fullResolutionCache = null;
   this.appState.fullResolutionCacheKey = "";
   this.refreshDehazeAppModeUi();
   if (this.commitButton)
      this.commitButton.setActive(false);
   aceLogDehazeAppModePath(next);
   if (!this.appState.cache.draft || !this.appState.cache.draft.rgb) {
      this.refreshPreviewStatus("No active image", "Open an image and select its view.");
      return;
   }
   this.invalidateScaleMapBitmaps();
   this.appState.cache.detail = null;
   this.rebuildProcessedDraftPreview();
   this.refreshPreviewStatus(this.describeLoadedSource(), "Dehaze mode selected: " + aceDehazeAppSelectorLabel(next));
   if (this.shouldUseDetailPreview())
      this.refreshDetailPreviewIfNeeded(false);
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.currentClarityV2Tuning = function() {
   return aceNormalizeClarityV2Tuning(this.appState && this.appState.params ? this.appState.params.clarityV2Tuning : null);
};

AstroContrastEnhancerDialog.prototype.refreshClarityModeUi = function() {
   var mode = this.currentClarityMode();
   if (this.clarityModeLegacyButton)
      this.clarityModeLegacyButton.setActive(mode === ACE_CLARITY_MODE_LEGACY);
   if (this.clarityModeV2Button) {
      var tuning = this.currentClarityV2Tuning();
      this.clarityModeV2Button.aceText = "V2" + tuning;
      this.clarityModeV2Button.toolTip = "Use Clarity V2 tuning " + tuning + "; click again while active to cycle A/B/C.";
      this.clarityModeV2Button.setActive(mode === ACE_CLARITY_MODE_V2 || mode === ACE_CLARITY_MODE_V2_DEPTH);
   }
   if (this.clarityModeV3Button)
   {
      this.clarityModeV3Button.aceText = aceClarityV3ButtonLabel(mode);
      this.clarityModeV3Button.toolTip = "Use " + aceClarityV3ModeLabel(mode) + "; click cycles diagnostics and keeps the current preview view.";
      this.clarityModeV3Button.setActive(aceIsClarityV3Mode(mode));
   }
   if (this.clarityModeV4Button) {
      this.clarityModeV4Button.aceText = "V4";
      this.clarityModeV4Button.toolTip = "Clarity path: production V4. This remains the default positive Clarity path.";
      this.clarityModeV4Button.setActive(mode === ACE_CLARITY_MODE_V4);
   }
   if (this.clarityModeFeatureFitButton) {
      this.clarityModeFeatureFitButton.aceText = aceClarityFeatureFitModeLabel(mode);
      this.clarityModeFeatureFitButton.toolTip = "Internal Clarity app-test path: " + aceClarityFeatureFitModeLabel(mode) + ". Click while active to toggle shared/two-term feature-fit gated modes. V4 remains default.";
      this.clarityModeFeatureFitButton.setActive(aceIsClarityFeatureFitMode(mode));
   }
   if (this.clarityModeDualZoneOptButton) {
      this.clarityModeDualZoneOptButton.aceText = "+DZOpt";
      this.clarityModeDualZoneOptButton.toolTip = "Internal Clarity app-test path: optimized DualZone safer-bright candidate. V4 remains default; negative Clarity remains V4.";
      this.clarityModeDualZoneOptButton.setActive(aceIsClarityDualZoneOptMode(mode));
   }
   if (this.clarityModeDualZoneBoostButton) {
      this.clarityModeDualZoneBoostButton.aceText = "+DZBoost";
      this.clarityModeDualZoneBoostButton.toolTip = "Internal Clarity app-test path: boosted guarded DualZone candidate. V4 remains default; negative Clarity remains V4.";
      this.clarityModeDualZoneBoostButton.setActive(aceIsClarityDualZoneBoostMode(mode));
   }
   if (this.clarityModeSelector) {
      this.clarityModeSelector.currentItem = aceClaritySelectorIndexForMode(mode);
      this.clarityModeSelector.toolTip = this.debugControlsVisible ?
         "Active Clarity algorithm: " + aceClaritySelectorLabel(mode) + ". 0-50 useful, 50-100 strong/controllable, 100-150 intentional overshoot/headroom." :
         "Clarity algorithm selector is available in debug mode.";
   }
};

AstroContrastEnhancerDialog.prototype.setTextureMode = function(mode) {
   if (this.outputRendering)
      return;
   var next = aceNormalizeTextureMode(mode);
   if (!this.appState || !this.appState.params)
      return;
   if (aceNormalizeTextureMode(this.appState.params.textureMode) === next)
      return;
   this.appState.params.textureMode = next;
   if (this.processingMode === "full") {
      this.appState.globalParams = aceCopyParams(this.appState.params);
      this.appState.globalAdvanced = aceCopyAdvancedParams(this.appState.advanced);
   }
   this.appState.fullResolutionCache = null;
   this.appState.fullResolutionCacheKey = "";
   this.refreshTextureModeUi();
   if (this.commitButton)
      this.commitButton.setActive(false);
   this.lastLocalAction = "";
   aceLogTextureModePath(next);
   if (!this.appState.cache.draft || !this.appState.cache.draft.rgb) {
      this.refreshPreviewStatus("No active image", "Open an image and select its view.");
      return;
   }
   this.invalidateScaleMapBitmaps();
   this.appState.cache.detail = null;
   this.rebuildProcessedDraftPreview();
   this.refreshPreviewStatus(this.describeLoadedSource(), "Texture mode selected: " + aceTextureSelectorLabel(next));
   if (this.shouldUseDetailPreview())
      this.refreshDetailPreviewIfNeeded(false);
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.setClarityMode = function(mode) {
   if (this.outputRendering)
      return;
   var next = aceNormalizeClarityMode(mode);
   if (!this.appState || !this.appState.params)
      return;
   if (aceNormalizeClarityMode(this.appState.params.clarityMode) === next)
      return;
   this.appState.params.clarityMode = next;
   this.appState.params.clarityV2Tuning = this.currentClarityV2Tuning();
   if (this.processingMode === "full") {
      this.appState.globalParams = aceCopyParams(this.appState.params);
      this.appState.globalAdvanced = aceCopyAdvancedParams(this.appState.advanced);
   }
   this.appState.fullResolutionCache = null;
   this.appState.fullResolutionCacheKey = "";
   this.refreshClarityModeUi();
   if (this.commitButton)
      this.commitButton.setActive(false);
   this.lastLocalAction = "";
   if (!this.appState.cache.draft || !this.appState.cache.draft.rgb) {
      this.refreshPreviewStatus("No active image", "Open an image and select its view.");
      return;
   }
   this.rebuildProcessedPreviews(next === ACE_CLARITY_MODE_LEGACY ? "Clarity V1 selected" :
      (next === ACE_CLARITY_MODE_V4 ? "Clarity V4 selected" :
      (aceIsClarityFeatureFitMode(next) ? "Clarity " + aceClarityFeatureFitModeLabel(next) + " internal test selected" :
      (aceIsClarityDualZoneBoostMode(next) ? "Clarity " + aceClarityFeatureFitModeLabel(next) + " internal test selected" :
      (aceIsClarityDualZoneOptMode(next) ? "Clarity +DZOpt internal test selected" :
      (aceIsClarityV3Mode(next) ? aceClarityV3ModeLabel(next) + " selected" :
      (next === ACE_CLARITY_MODE_V2 ? "Clarity V2 selected" : "Clarity V2 Depth selected")))))));
};

AstroContrastEnhancerDialog.prototype.setClarityV2Tuning = function(tuning) {
   if (this.outputRendering)
      return;
   if (!this.appState || !this.appState.params)
      return;
   var next = aceNormalizeClarityV2Tuning(tuning);
   if (aceNormalizeClarityV2Tuning(this.appState.params.clarityV2Tuning) === next)
      return;
   this.appState.params.clarityV2Tuning = next;
   this.appState.params.clarityMode = ACE_CLARITY_MODE_V2_DEPTH;
   if (this.processingMode === "full") {
      this.appState.globalParams = aceCopyParams(this.appState.params);
      this.appState.globalAdvanced = aceCopyAdvancedParams(this.appState.advanced);
   }
   this.appState.fullResolutionCache = null;
   this.appState.fullResolutionCacheKey = "";
   this.refreshClarityModeUi();
   if (this.commitButton)
      this.commitButton.setActive(false);
   this.lastLocalAction = "";
   if (!this.appState.cache.draft || !this.appState.cache.draft.rgb) {
      this.refreshPreviewStatus("No active image", "Open an image and select its view.");
      return;
   }
   this.rebuildProcessedPreviews("Clarity V2" + next + " tuning selected");
};

AstroContrastEnhancerDialog.prototype.cycleClarityV2Tuning = function() {
   this.setClarityV2Tuning(aceNextClarityV2Tuning(this.currentClarityV2Tuning()));
};

AstroContrastEnhancerDialog.prototype.toggleAdvancedPanel = function() {
   this.advancedExpanded = !this.advancedExpanded;
   this.refreshAdvancedUi();
   this.refreshWindowSizeReadout();
};

AstroContrastEnhancerDialog.prototype.setAdvancedMode = function(mode) {
   this.advancedMode = mode === "clarity" || mode === "dehaze" || mode === "protection" ? mode : "scale";
   this.refreshAdvancedUi();
};

AstroContrastEnhancerDialog.prototype.refreshAdvancedUi = function() {
   aceSetCollapsed(this.advancedPanel, !this.advancedExpanded);
   aceSetCollapsed(this.localSelectionPanel, !!this.advancedExpanded);
   if (this.advancedButton)
   {
      var customAdvanced = !this.appState.advanced.isCuratedDefault();
      this.advancedButton.aceText = this.advancedExpanded ? (customAdvanced ? "Advanced *" : "Advanced v") : (customAdvanced ? "Advanced *" : "Advanced >");
      this.advancedButton.aceTone = (this.advancedExpanded || customAdvanced) ? "gold" : "";
      this.advancedButton.setActive(this.advancedExpanded);
      this.advancedButton.toolTip = customAdvanced ?
         "Advanced tuning is using custom values. Open to review or reset defaults." :
         "Show advanced tuning controls.";
   }
   if (this.advancedDefaultsButton)
      aceSetCollapsed(this.advancedDefaultsButton, false);
   if (this.advancedScaleButton)
      this.advancedScaleButton.setActive(this.advancedMode === "scale");
   if (this.advancedClarityButton)
      this.advancedClarityButton.setActive(this.advancedMode === "clarity");
   if (this.advancedDehazeButton)
      this.advancedDehazeButton.setActive(this.advancedMode === "dehaze");
   if (this.advancedProtectionButton)
      this.advancedProtectionButton.setActive(this.advancedMode === "protection");
   var scaleVisible = this.advancedMode === "scale";
   var clarityVisible = this.advancedMode === "clarity";
   var dehazeVisible = this.advancedMode === "dehaze";
   var protectionVisible = this.advancedMode === "protection";
   if (this.advancedTextureScale)
      aceSetCollapsed(this.advancedTextureScale, !scaleVisible);
   if (this.advancedClarityScale)
      aceSetCollapsed(this.advancedClarityScale, !scaleVisible);
   if (this.advancedDehazeVeilSize)
      aceSetCollapsed(this.advancedDehazeVeilSize, !scaleVisible);
   if (this.advancedClarityResponseRow)
      aceSetCollapsed(this.advancedClarityResponseRow, !clarityVisible);
   if (this.advancedVeilStrength)
      aceSetCollapsed(this.advancedVeilStrength, !dehazeVisible);
   if (this.advancedHighlightProtect)
      aceSetCollapsed(this.advancedHighlightProtect, !(dehazeVisible || protectionVisible));
   if (this.advancedProtectionStrength)
      aceSetCollapsed(this.advancedProtectionStrength, !protectionVisible);
   var anyProtectionEnabled =
      (!!this.protectSky && this.protectSky.checked) ||
      (!!this.preventDark && this.preventDark.checked) ||
      (!!this.protectStars && this.protectStars.checked) ||
      (!!this.protectHalos && this.protectHalos.checked);
   if (this.advancedProtectionStrength)
      this.advancedProtectionStrength.setEnabled(anyProtectionEnabled);
   if (this.advancedHighlightProtect)
      this.advancedHighlightProtect.setEnabled(anyProtectionEnabled || dehazeVisible);
   if (this.advancedGraphic) {
      aceSetCollapsed(this.advancedGraphic, false);
      this.advancedGraphic.update();
   }
   if (this.advancedButton)
      this.advancedButton.update();
};

AstroContrastEnhancerDialog.prototype.setAdvancedSlidersSilently = function(params) {
   var advanced = aceCopyAdvancedParams(params);
   if (this.advancedTextureScale) this.advancedTextureScale.setValue(aceAdvancedRadiusPx(advanced, "textureScale", ACE_TEXTURE_RADIUS));
   if (this.advancedClarityScale) this.advancedClarityScale.setValue(aceAdvancedRadiusPx(advanced, "clarityScale", ACE_CLARITY_RADIUS));
   if (this.advancedDehazeVeilSize) this.advancedDehazeVeilSize.setValue(aceAdvancedRadiusPx(advanced, "dehazeVeilSize", ACE_DEHAZE_VEIL_RADIUS));
   if (this.advancedVeilStrength) this.advancedVeilStrength.setValue(advanced.dehazeVeilStrength);
   if (this.advancedHighlightProtect) this.advancedHighlightProtect.setValue(advanced.dehazeHighlightProtect);
   if (this.advancedProtectionStrength) this.advancedProtectionStrength.setValue(advanced.overallProtectionStrength);
   if (this.advancedClarityResponseSelector) this.advancedClarityResponseSelector.currentItem = aceClarityResponseSelectorIndex(advanced.clarityResponse);
};

AstroContrastEnhancerDialog.prototype.invalidateAdvancedCaches = function() {
   var cache = this.appState.cache;
   var preserveVisibleMaps = this.scaleMapRebuildPending && this.currentViewNeedsScaleMaps();
   cache.draftLayerCache = null;
   cache.workingLayerCache = null;
   if (!preserveVisibleMaps)
      cache.mapBitmaps = null;
   cache.maskBitmap = null;
   cache.starMaskBitmap = null;
   cache.allowedMaskBitmap = null;
   if (cache.draft)
      cache.draft.layerCache = null;
   if (cache.detail) {
      cache.detail.layerCache = null;
      if (!preserveVisibleMaps)
         cache.detail.mapBitmaps = null;
      cache.detail.maskBitmap = null;
      cache.detail.starMaskBitmap = null;
      cache.detail.allowedMaskBitmap = null;
   }
   cache.detailTarget = null;
   this.invalidateProtectedOverlay();
   this.appState.fullResolutionCache = null;
   this.appState.fullResolutionCacheKey = "";
};

AstroContrastEnhancerDialog.prototype.advancedPreviewModeFor = function(name) {
   if (name === "textureScale")
      return "texture";
   if (name === "clarityScale")
      return "clarity";
   if (name === "clarityResponse")
      return "clarity";
   if (name === "dehazeVeilSize")
      return "dehaze";
   return "";
};

AstroContrastEnhancerDialog.prototype.handleAdvancedClarityResponseChange = function(response) {
   if (this.outputRendering)
      return;
   this.handleAdvancedParameterChange("clarityResponse", aceNormalizeClarityResponse(response), false);
};

AstroContrastEnhancerDialog.prototype.handleAdvancedParameterChange = function(name, value, isDragging) {
   if (this.outputRendering || !name)
      return;
   this.appState.advanced[name] = value;
   if (this.processingMode === "full")
      this.appState.globalAdvanced = aceCopyAdvancedParams(this.appState.advanced);
   var preferredView = this.advancedExpanded && this.appState.preview.viewMode !== "preview" ? this.advancedPreviewModeFor(name) : "";
   if (preferredView && this.viewModeAvailability(preferredView).available)
      this.appState.preview.viewMode = preferredView;
   this.refreshAdvancedUi();
   this.refreshViewModeButtons();
   var interactive = !!isDragging;
   if (!this.appState.cache.draft || !this.appState.cache.draft.rgb) {
      this.refreshPreviewStatus("No active image", "Advanced updated");
      return;
   }
   if (interactive) {
      this.markScaleMapRebuildPending("Advanced");
      if (this.currentViewNeedsScaleMaps() && this.appState.preview.viewMode !== "delta") {
         this.updateInteractiveAdvancedScaleMap("Advanced");
         return;
      }
      this.appState.cache.detail = null;
      this.queueInteractivePreview("Advanced", "Advanced updated", true);
      return;
   }
   if (this.currentViewNeedsScaleMaps())
      this.markScaleMapRebuildPending("Advanced");
   this.invalidateScaleMapBitmaps();
   this.invalidateAdvancedCaches();
   if (this.interactivePreviewTimer)
      this.interactivePreviewTimer.stop();
   this.pendingInteractivePreviewLabel = "";
   this.pendingInteractivePreviewStatus = "";
   this.pendingInteractivePreviewInvalidateAdvanced = false;
   if (this.currentViewNeedsScaleMaps()) {
      this.setPendingPreviewStage("Building accurate high-res " + this.currentScaleMapLabel() + "...");
      this.refreshPreviewStatus(this.describeLoadedSource(), "Building accurate high-res " + this.currentScaleMapLabel());
      aceRefreshNow(this.preview);
   }
   this.interactiveSliderDrag = interactive;
   this.rebuildProcessedDraftPreview();
   this.interactiveSliderDrag = false;
   if (this.shouldUseDetailPreview()) {
      this.setPendingPreviewStage("Advanced updated | building accurate detail map...");
      this.refreshDetailPreviewIfNeeded(true);
   }
   if (this.currentViewNeedsScaleMaps())
      this.refreshPreviewStatus(this.describeLoadedSource(), this.scaleMapDisplayQuality || ("Accurate " + this.currentScaleMapLabel()));
   else
      this.refreshPreviewStatus(this.describeLoadedSource(), "Advanced updated");
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.resetAdvancedDefaults = function() {
   if (this.outputRendering)
      return;
   var defaults = new AdvancedParameters;
   if (this.advancedMode === "scale") {
      this.appState.advanced.textureScale = defaults.textureScale;
      this.appState.advanced.clarityScale = defaults.clarityScale;
      this.appState.advanced.dehazeVeilSize = defaults.dehazeVeilSize;
   } else if (this.advancedMode === "clarity") {
      this.appState.advanced.clarityResponse = defaults.clarityResponse;
   } else if (this.advancedMode === "dehaze") {
      this.appState.advanced.dehazeVeilStrength = defaults.dehazeVeilStrength;
      this.appState.advanced.dehazeHighlightProtect = defaults.dehazeHighlightProtect;
   } else {
      this.appState.advanced.overallProtectionStrength = defaults.overallProtectionStrength;
      this.appState.advanced.dehazeHighlightProtect = defaults.dehazeHighlightProtect;
   }
   if (this.processingMode === "full")
      this.appState.globalAdvanced = aceCopyAdvancedParams(this.appState.advanced);
   this.setAdvancedSlidersSilently(this.appState.advanced);
   this.invalidateAdvancedCaches();
   this.refreshAdvancedUi();
   this.rebuildProcessedPreviews("Advanced tab defaults restored");
};

AstroContrastEnhancerDialog.prototype.setProcessingMode = function(mode) {
   var previousMode = this.processingMode || "full";
   var nextMode = mode === "lasso" ? "lasso" : "full";
   var changedMode = previousMode !== nextMode;
   if (changedMode) {
      if (nextMode === "lasso" && this.appState && this.appState.cache && this.appState.cache.detail)
         this.resetPreviewInteractionStateKeepDetail();
      else
         this.resetPreviewInteractionState(false);
   }
   if (changedMode && previousMode === "full") {
      this.appState.globalParams = aceCopyParams(this.appState.params);
      this.appState.globalAdvanced = aceCopyAdvancedParams(this.appState.advanced);
   }
   this.processingMode = nextMode;
   if (this.fullImageRadio)
      this.fullImageRadio.checked = this.processingMode === "full";
   if (this.lassoRadio)
      this.lassoRadio.checked = this.processingMode === "lasso";
   var lassoEnabled = this.processingMode === "lasso";
   if (changedMode) {
      if (this.processingMode === "lasso")
         this.clearCommittedDetailPreview();
      this.clearPendingLocalPreview(true);
      if (this.processingMode === "lasso")
         this.resetEffectSlidersSilently();
      else {
         this.setEffectSlidersSilently(this.appState.globalParams);
         this.appState.advanced = aceCopyAdvancedParams(this.appState.globalAdvanced);
         this.setAdvancedSlidersSilently(this.appState.advanced);
      }
      this.refreshAdvancedUi();
      this.lastLocalAction = "";
      if (this.commitButton)
         this.commitButton.setActive(false);
   }
   if (this.undoButton)
      this.undoButton.setVisualEnabled(true);
   if (this.redoButton)
      this.redoButton.setVisualEnabled(true);
   this.refreshLocalSelectionControls();
   if (!changedMode) {
      this.lassoDrawing = false;
      this.lassoMoving = false;
      this.lassoHoverInside = false;
      this.lassoDragOperation = "none";
      this.lassoDrawPoints = [];
   }
   this.invalidateLassoMasks();
   var suppressDetailRefresh = !!this.suppressNextDetailRefresh;
   this.suppressNextDetailRefresh = false;
   if (this.appState && this.appState.cache && this.appState.cache.draft) {
      if (suppressDetailRefresh) {
         this.rebuildProcessedDraftPreview();
         this.refreshPreviewStatus(this.describeLoadedSource(), lassoEnabled ? (this.hasLassoSelection() ? "Lasso: active" : "Lasso: draw selection") : "Full Image active");
      } else {
         this.rebuildProcessedPreviews(lassoEnabled ? (this.hasLassoSelection() ? "Lasso: active" : "Lasso: draw selection") : "Full Image active");
      }
   }
   if (!suppressDetailRefresh && this.shouldUseDetailPreview())
      this.refreshDetailPreviewIfNeeded(false);
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.getActiveSourceView = function() {
   var viewId = this.appState.cache.source.viewId;
   if (viewId) {
      var found = aceFindViewForViewId(viewId);
      if (found && found.view)
         return found.view;
   }
   var activeWindow = ImageWindow.activeWindow;
   if (!activeWindow || activeWindow.isNull)
      return null;
   return activeWindow.currentView;
};

AstroContrastEnhancerDialog.prototype.refreshSourceCombo = function(selectedViewId) {
   if (!this.sourceCombo)
      return;
   this.refreshingSourceCombo = true;
   var views = aceListOpenRgbViews();
   if (typeof this.sourceCombo.clear === "function")
      this.sourceCombo.clear();
   else if (typeof this.sourceCombo.clearItems === "function")
      this.sourceCombo.clearItems();
   if (views.length === 0) {
      this.sourceCombo.addItem("No RGB views");
      this.sourceCombo.currentItem = 0;
      this.refreshingSourceCombo = false;
      return;
   }
   var selectedIndex = 0;
   for (var i = 0; i < views.length; ++i) {
      this.sourceCombo.addItem(views[i].id);
      if (selectedViewId && views[i].id === selectedViewId)
         selectedIndex = i;
   }
   this.sourceCombo.currentItem = selectedIndex;
   this.refreshingSourceCombo = false;
};

AstroContrastEnhancerDialog.prototype.loadSourceImage = function(source) {
   var loadStart = Date.now();
   var loadStage = loadStart;
   this.targetImageLoading = true;
   this.previewWarmupActive = true;
   this.refreshPreviewStatus("Loading: " + source.viewId, "Building preview caches...");
   this.setFooterStatus("Building preview caches...", ACE_COLORS.warning);
   if (this.preview)
      aceRefreshNow(this.preview);
   var draft = aceDownsampleRgbAntialias(source.rgb, source.width, source.height, ACE_DRAFT_MAX_EDGE);
   var downsampleMs = Date.now() - loadStage;
   loadStage = Date.now();
   this.appState.cache.clear();
   this.appState.lassoPoints = [];
   this.appState.lassoInverted = false;
   this.localSelectionNewActive = false;
   ++this.appState.lassoVersion;
   this.lassoDrawing = false;
   this.lassoDrawPoints = [];
   this.appState.cache.source.viewId = source.viewId;
   this.appState.cache.source.width = source.width;
   this.appState.cache.source.height = source.height;
   ++this.appState.cache.source.version;
   this.appState.cache.sourceRgb = source.rgb;
   this.appState.cache.draft = draft;
   this.appState.cache.draftBitmap = aceRenderBitmapFromRgb(draft.width, draft.height, draft.rgb);
   var bitmapMs = Date.now() - loadStage;
   loadStage = Date.now();
   this.appState.cache.originalBitmap = this.appState.cache.draftBitmap;
   this.appState.cache.workingRgb = new Float32Array(draft.rgb);
   this.appState.cache.workingBitmap = this.appState.cache.draftBitmap;
   this.appState.cache.currentBitmap = this.appState.cache.draftBitmap;
   this.appState.cache.currentRgb = this.appState.cache.workingRgb;
   this.appState.cache.draftLayerCache = null;
   this.appState.undoStack = [];
   this.appState.redoStack = [];
   this.appState.editRecipe = [];
   this.appState.globalParams = new EffectParameters;
   this.appState.advanced = new AdvancedParameters;
   this.appState.globalAdvanced = new AdvancedParameters;
   this.previewWarmupDone = false;
   this.previewFirstAdjustmentDone = false;
   this.setAdvancedSlidersSilently(this.appState.advanced);
   this.refreshAdvancedUi();
   this.appState.globalProtection = aceCopyProtectionOptions(this.getProtectionOptions());
   this.appState.fullResolutionCache = null;
   this.appState.fullResolutionCacheKey = "";
   this.appState.preview.zoomMode = "fit";
   this.appState.preview.zoomScale = 1;
   this.appState.preview.panX = 0;
   this.appState.preview.panY = 0;
   this.appState.preview.showBefore = false;
   this.beforeAfterPill.setActive(false);
   this.rebuildProcessedPreviews("Preview cache rebuilt");
   this.refreshDetailPreviewIfNeeded(false);
   var previewPrepMs = Date.now() - loadStage;
   loadStage = Date.now();
   this.refreshSourceCombo(source.viewId);
   this.targetImageLoading = false;
   this.refreshPreviewStatus("Loaded: " + source.viewId + " | " + source.width + " x " + source.height + " | Fit", this.viewModeStatusText(this.appState.preview.viewMode));
   this.preview.update();
   aceDevelopmentConsoleWriteLine("[ACE] Source load timing | total=" + (Date.now() - loadStart) + " ms" +
      " source=" + source.width + "x" + source.height +
      " draft=" + draft.width + "x" + draft.height +
      " downsample=" + downsampleMs + " ms" +
      " bitmap=" + bitmapMs + " ms" +
      " previewPrep=" + previewPrepMs + " ms" +
      " combo=" + (Date.now() - loadStage) + " ms");
   this.schedulePreviewWarmup("Preparing first preview response...");
};

AstroContrastEnhancerDialog.prototype.refreshSourceFromViewId = function(viewId) {
   if (this.outputRendering)
      return;
   try {
      this.targetImageLoading = true;
      this.setFooterStatus("Loading selected image...");
      this.refreshPreviewStatus("Loading target image", "Building preview cache...");
      if (this.preview)
         this.preview.update();
      var found = aceFindViewForViewId(viewId);
      if (!found || !found.view)
         throw new Error("Selected source view is no longer available: " + viewId);
      var resolvedView = aceResolveSelectedSourceView(found.view);
      var resolvedId = resolvedView ? (resolvedView.fullId || resolvedView.id) : "";
      if (resolvedView && resolvedId && resolvedId !== viewId) {
         this.setFooterStatus("Using original source: " + resolvedId);
         this.loadSourceImage(aceReadRgbImageFromView(resolvedView));
         return;
      }
      var generatedBaseId = aceBaseSourceIdForGeneratedAceOutput(viewId);
      if (generatedBaseId) {
         var answer = (new MessageBox(
            "The selected target appears to be an ACE-generated output:\n\n" +
            viewId + "\n\n" +
            "Processing it will stack a second ACE pass on top of a processed image. For comparison testing, open/select the original source image instead.\n\n" +
            "Continue with this generated output as the source?",
            ACE_TOOL_NAME + " " + ACE_VERSION,
            StdIcon_Warning,
            StdButton_No,
            StdButton_Yes
         )).execute();
         if (answer !== StdButton_Yes) {
            this.targetImageLoading = false;
            this.refreshSourceCombo(this.appState.cache.source.viewId);
            this.refreshPreviewStatus(this.describeLoadedSource(), "Source unchanged.");
            if (this.preview)
               this.preview.update();
            return;
         }
      }
      this.loadSourceImage(aceReadRgbImageFromView(found.view));
   } catch (error) {
      this.targetImageLoading = false;
      this.appState.cache.clear();
      this.refreshPreviewStatus("No active image", "No active image. Open an image and select its view.");
      if (this.preview)
         this.preview.update();
      aceMessage(error && error.message ? error.message : String(error), ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
   }
};

AstroContrastEnhancerDialog.prototype.refreshSourceFromActiveView = function() {
   if (this.outputRendering)
      return;
   try {
      this.targetImageLoading = true;
      this.setFooterStatus("Loading active image...");
      this.refreshPreviewStatus("Loading target image", "Building preview cache...");
      if (this.preview)
         this.preview.update();
      this.refreshSourceCombo();
      this.loadSourceImage(aceReadActiveRgbImage());
   } catch (error) {
      this.targetImageLoading = false;
      this.appState.cache.clear();
      this.refreshSourceCombo();
      this.refreshPreviewStatus("No active image", "No active image. Open an image and select its view.");
      if (this.preview)
         this.preview.update();
      aceMessage(error && error.message ? error.message : String(error), ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
   }
};

AstroContrastEnhancerDialog.prototype.tryAttachActiveViewAtStartup = function() {
   try {
      var activeWindow = ImageWindow.activeWindow;
      if (!activeWindow || activeWindow.isNull) {
         this.targetImageLoading = false;
         this.refreshPreviewStatus("No active image", "Open an image and select its view.");
         return;
      }
      this.refreshSourceFromActiveView();
   } catch (error) {
      this.targetImageLoading = false;
      this.refreshPreviewStatus("No active image", "Open an RGB image and select its view.");
      if (this.preview)
         this.preview.update();
   }
};

AstroContrastEnhancerDialog.prototype.getDraftPreviewBitmapForCurrentMode = function() {
   var dragMode = this.appState.preview.viewMode;
   if (dragMode === "lasso" && this.appState.cache.lassoMaskBitmap)
      return this.appState.cache.lassoMaskBitmap;
   if (dragMode === "star" && this.appState.cache.starMaskBitmap)
      return this.appState.cache.starMaskBitmap;
   if (dragMode === "allowed" && (this.appState.cache.allowedMaskBitmap || this.appState.cache.maskBitmap))
      return this.appState.cache.allowedMaskBitmap || this.appState.cache.maskBitmap;
   if (dragMode && dragMode !== "preview" && dragMode !== "mask" && this.appState.cache.mapBitmaps && this.appState.cache.mapBitmaps[dragMode])
      return this.appState.cache.mapBitmaps[dragMode];
   if (this.appState.preview.showMask && this.appState.cache.maskBitmap)
      return this.appState.cache.maskBitmap;
   if (this.appState.preview.showBefore && this.processingMode === "lasso" && this.appState.cache.workingBitmap)
      return this.appState.cache.workingBitmap;
   if (this.appState.preview.showBefore && this.appState.cache.originalBitmap)
      return this.appState.cache.originalBitmap;
   if (this.processingMode === "lasso" &&
       this.appState.cache.pendingActive &&
       this.appState.cache.pendingBitmap) {
      var responsivePendingDisplay =
         this.appState.cache.pendingDisplayBitmap &&
         !this.beforeAfterComparisonActive &&
         !this.appState.preview.showBefore &&
         this.shouldUseDetailPreview() &&
         !this.appState.cache.detail &&
         (this.detailPreviewPendingNavigation || this.detailPreviewPendingAdjustment || this.detailWorkActive);
      if (responsivePendingDisplay)
         return this.appState.cache.pendingDisplayBitmap;
      var faithfulLocalPreview =
         this.beforeAfterComparisonActive ||
         this.appState.preview.showBefore ||
         this.localPreviewRequiresFaithfulDisplay() ||
         this.shouldUseDetailPreview() ||
         this.detailPreviewPendingNavigation ||
         this.detailPreviewPendingAdjustment;
      return faithfulLocalPreview ? this.appState.cache.pendingBitmap :
         (this.appState.cache.pendingDisplayBitmap || this.appState.cache.pendingBitmap);
   }
   return this.appState.cache.currentBitmap || this.appState.cache.draftBitmap;
};

AstroContrastEnhancerDialog.prototype.localPreviewRequiresFaithfulDisplay = function() {
   if (this.processingMode !== "lasso")
      return false;
   var protection = this.getProtectionOptions ? this.getProtectionOptions() : null;
   return !!(protection && protection.inputType === "stars" && protection.protectStars);
};

AstroContrastEnhancerDialog.prototype.getDetailBeforeBitmap = function() {
   var detail = this.appState && this.appState.cache ? this.appState.cache.detail : null;
   if (!detail)
      return null;
   return this.processingMode === "lasso" ?
      detail.localBeforeBitmap || detail.originalBitmap || null :
      detail.originalBitmap || null;
};

AstroContrastEnhancerDialog.prototype.prepareDetailBeforeBitmap = function() {
   var detail = this.appState && this.appState.cache ? this.appState.cache.detail : null;
   if (!detail)
      return null;
   if (this.processingMode === "lasso") {
      if (detail.rgb)
         detail.localBeforeBitmap = aceRenderBitmapFromRgb(detail.width, detail.height, detail.rgb);
      return detail.localBeforeBitmap || null;
   }
   if (!detail.originalBitmap) {
      var beforeRgb = detail.sourceRgb || detail.rgb;
      if (beforeRgb)
         detail.originalBitmap = aceRenderBitmapFromRgb(detail.width, detail.height, beforeRgb);
   }
   return detail.originalBitmap || null;
};

AstroContrastEnhancerDialog.prototype.exitBeforeAfterForEditChange = function() {
   this.beforeAfterComparisonActive = false;
   this.previewMomentaryBefore = false;
   this.beforeAfterShortcutDown = false;
   if (this.appState && this.appState.preview)
      this.appState.preview.showBefore = false;
   if (this.beforeAfterPill)
      this.beforeAfterPill.setActive(false);
   if (this.appState && this.appState.cache && this.appState.cache.detail)
      this.appState.cache.detail.localBeforeBitmap = null;
};

AstroContrastEnhancerDialog.prototype.clearPreviewGestureBitmap = function() {
   this.previewGestureBitmap = null;
   this.previewGestureDisplayRect = null;
   this.previewGestureInputBitmap = null;
   this.previewGestureInputDisplayRect = null;
   this.previewGestureDetail = null;
};

AstroContrastEnhancerDialog.prototype.updatePreviewThrottled = function(fieldName, minIntervalMs) {
   if (!this.preview)
      return;
   var now = Date.now();
   var field = fieldName || "lastPreviewThrottleUpdateMs";
   var interval = minIntervalMs || 40;
   if (!this[field] || now - this[field] >= interval) {
      this[field] = now;
      this.preview.update();
   }
};

AstroContrastEnhancerDialog.prototype.setPreviewCursorShape = function(shape) {
   if (!this.preview)
      return;
   if (this.previewCursorShape === shape)
      return;
   this.preview.cursor = new Cursor(shape);
   this.previewCursorShape = shape;
};

AstroContrastEnhancerDialog.prototype.updatePreviewCursor = function(insideLasso) {
   var shape = StdCursor_Arrow;
   if (this.outputRendering)
      shape = StdCursor_Wait;
   else if (this.processingMode === "lasso" && this.appState.preview.viewMode !== "star") {
      if (this.lassoMoving)
         shape = StdCursor_ClosedHand;
      else if (this.lassoDrawing || !this.hasLassoSelection())
         shape = StdCursor_Cross;
      else if (insideLasso !== undefined ? insideLasso : this.lassoHoverInside)
         shape = StdCursor_OpenHand;
      else if (this.appState.preview.zoomMode !== "fit")
         shape = StdCursor_OpenHand;
   } else if (this.appState.preview.zoomMode !== "fit")
      shape = this.previewDragging ? StdCursor_ClosedHand : StdCursor_OpenHand;
   this.setPreviewCursorShape(shape);
};

AstroContrastEnhancerDialog.prototype.getStablePreviewBitmapForGesture = function(preferDraft) {
   if (preferDraft) {
      var draftGesture = this.getDraftPreviewBitmapForCurrentMode();
      if (draftGesture)
         return draftGesture;
   }
   var detail = this.appState && this.appState.cache ? this.appState.cache.detail : null;
   var usingDetail = this.shouldUseDetailPreview() && detail;
   if (!usingDetail &&
       detail &&
       detail.currentBitmap &&
       this.appState.preview.zoomMode !== "fit" &&
       !this.appState.preview.showMask &&
       this.appState.preview.viewMode === "preview")
      usingDetail = true;
   if (this.appState.preview.showBefore && usingDetail) {
      var beforeDetail = this.getDetailBeforeBitmap();
      if (beforeDetail)
         return beforeDetail;
   }
   if (usingDetail && detail.currentBitmap)
      return detail.currentBitmap;
   if (this.appState.preview.showBefore) {
      if (this.processingMode === "lasso" && this.appState.cache.workingBitmap)
         return this.appState.cache.workingBitmap;
      return this.appState.cache.originalBitmap;
   }
   return this.appState.cache.currentBitmap || this.appState.cache.draftBitmap;
};

AstroContrastEnhancerDialog.prototype.beginPreviewGestureBitmap = function(preferDraft, useDraftInputGeometry) {
   var bmp = this.getStablePreviewBitmapForGesture(!!preferDraft);
   if (!bmp)
      return null;
   this.previewGestureDetail = null;
   this.previewGestureBitmap = bmp;
   this.previewGestureDisplayRect = this.getCurrentViewportRect(bmp);
   this.previewGestureInputBitmap = null;
   this.previewGestureInputDisplayRect = null;
   if (useDraftInputGeometry) {
      var inputBmp = this.getDraftPreviewBitmapForCurrentMode();
      if (inputBmp) {
         this.previewGestureInputBitmap = inputBmp;
         this.previewGestureInputDisplayRect = this.getCurrentViewportRect(inputBmp);
      }
   }
   var detail = this.appState && this.appState.cache ? this.appState.cache.detail : null;
   var isDetailGesture = detail && (
      bmp === detail.currentBitmap ||
      bmp === detail.originalBitmap ||
      bmp === detail.localBeforeBitmap ||
      bmp === detail.maskBitmap ||
      bmp === detail.lassoMaskBitmap ||
      bmp === detail.starMaskBitmap ||
      bmp === detail.allowedMaskBitmap ||
      bmp === detail.protectedOverlayBitmap ||
      (detail.mapBitmaps &&
         (bmp === detail.mapBitmaps.texture ||
          bmp === detail.mapBitmaps.clarity ||
          bmp === detail.mapBitmaps.dehaze ||
          bmp === detail.mapBitmaps.delta)));
   this.previewGestureDetail = isDetailGesture ? {
      bitmap: bmp,
      x0: detail.x0 || 0,
      y0: detail.y0 || 0,
      width: detail.width,
      height: detail.height
   } : null;
   return bmp;
};

AstroContrastEnhancerDialog.prototype.getPreviewInputDisplayRect = function(bitmap) {
   if (this.previewGestureInputBitmap && bitmap === this.previewGestureInputBitmap && this.previewGestureInputDisplayRect)
      return this.previewGestureInputDisplayRect;
   if (this.previewGestureBitmap && bitmap === this.previewGestureBitmap && this.previewGestureDisplayRect)
      return this.previewGestureDisplayRect;
   if (this.isDetailBitmap(bitmap)) {
      var detailRect = this.getDetailViewportRect(bitmap);
      if (detailRect)
         return detailRect;
   }
   return this.previewDisplayRect;
};

AstroContrastEnhancerDialog.prototype.isResponsiveGlobalDetailBitmap = function(bitmap) {
   var detail = this.appState && this.appState.cache ? this.appState.cache.detail : null;
   if (!bitmap || !detail || detail.detailPreviewMode !== "processed-global")
      return false;
   if (!detail.computeTarget || !detail.computeTarget.responsiveGlobalPreview)
      return false;
   return this.isDetailBitmap(bitmap);
};

AstroContrastEnhancerDialog.prototype.shouldSuppressResponsiveGlobalDetailForComparison = function(bitmap) {
   return this.shouldSuppressResponsiveGlobalDetailInMainPreview(bitmap);
};

AstroContrastEnhancerDialog.prototype.shouldSuppressResponsiveGlobalDetailInMainPreview = function(bitmap) {
   return this.isResponsiveGlobalDetailBitmap(bitmap);
};

AstroContrastEnhancerDialog.prototype.getCurrentPreviewBitmap = function() {
   if (this.previewGestureBitmap && this.processingMode === "lasso" && (this.lassoDrawing || this.lassoMoving))
      return this.previewGestureBitmap;
   var armedLassoDetail =
      this.processingMode === "lasso" &&
      this.localSelectionNewActive &&
      !this.hasLassoSelection() &&
      this.appState.preview.viewMode === "preview" &&
      !this.appState.preview.showMask &&
      this.appState.preview.zoomMode !== "fit" &&
      this.appState.cache.detail;
   var usingDetail = (this.shouldUseDetailPreview() || armedLassoDetail) && this.appState.cache.detail;
   var responsiveGlobalDetail = usingDetail &&
      this.appState.cache.detail.detailPreviewMode === "processed-global" &&
      this.appState.cache.detail.computeTarget &&
      this.appState.cache.detail.computeTarget.responsiveGlobalPreview;
   if (this.processingMode === "lasso" && (this.lassoDrawing || this.lassoMoving)) {
      if (usingDetail && this.appState.cache.detail.currentBitmap)
         return this.appState.cache.detail.currentBitmap;
      var lassoDraft = this.getDraftPreviewBitmapForCurrentMode();
      if (lassoDraft)
         return lassoDraft;
   }
   if (this.appState.preview.showBefore && usingDetail && !responsiveGlobalDetail) {
      var beforeDetail = this.getDetailBeforeBitmap();
      if (beforeDetail)
         return beforeDetail;
   }
   if ((this.previewDragging ||
        this.detailPreviewPendingNavigation ||
        (this.detailPreviewPendingAdjustment && !(this.appState.cache.detail && this.appState.cache.detail.currentBitmap))) &&
       this.shouldUseDetailPreview()) {
      var draftFallback = this.getDraftPreviewBitmapForCurrentMode();
      if (draftFallback)
         return draftFallback;
   }
   if (this.appState.preview.viewMode === "lasso") {
      return this.appState.cache.lassoMaskBitmap;
   }
   if (this.appState.preview.viewMode === "star") {
      return this.appState.cache.starMaskBitmap;
   }
   if (this.appState.preview.viewMode === "allowed") {
      return this.appState.cache.allowedMaskBitmap || this.appState.cache.maskBitmap;
   }
   if (this.appState.preview.viewMode && this.appState.preview.viewMode !== "preview" && this.appState.preview.viewMode !== "mask") {
      var mode = this.appState.preview.viewMode;
      if (this.appState.cache.mapBitmaps && this.appState.cache.mapBitmaps[mode])
         return this.appState.cache.mapBitmaps[mode];
   }
   if (this.appState.preview.showMask) {
      return this.appState.cache.maskBitmap;
   }
   if (this.appState.preview.showBefore) {
      if (usingDetail && !responsiveGlobalDetail) {
         var detailBefore = this.getDetailBeforeBitmap();
         if (detailBefore)
            return detailBefore;
      }
      if (this.processingMode === "lasso" && this.appState.cache.workingBitmap)
         return this.appState.cache.workingBitmap;
      return this.appState.cache.originalBitmap;
   }
   if (this.processingMode === "lasso" &&
       this.appState.cache.pendingActive &&
       this.appState.cache.pendingBitmap &&
       !usingDetail) {
      var faithfulPending =
         this.beforeAfterComparisonActive ||
         this.appState.preview.showBefore ||
         this.localPreviewRequiresFaithfulDisplay() ||
         this.shouldUseDetailPreview() ||
         this.detailPreviewPendingNavigation ||
         this.detailPreviewPendingAdjustment;
      if (!faithfulPending && this.appState.cache.pendingDisplayBitmap)
         return this.appState.cache.pendingDisplayBitmap;
      return this.appState.cache.pendingBitmap;
   }
   if (responsiveGlobalDetail) {
      var comparisonDraft = this.getDraftPreviewBitmapForCurrentMode();
      if (comparisonDraft)
         return comparisonDraft;
   }
   if (usingDetail && this.appState.cache.detail.currentBitmap && !this.shouldSuppressResponsiveGlobalDetailInMainPreview(this.appState.cache.detail.currentBitmap)) {
      return this.appState.cache.detail.currentBitmap;
   }
   var current = this.appState.cache.currentBitmap || this.appState.cache.draftBitmap;
   return current;
};

AstroContrastEnhancerDialog.prototype.getPreviewBitmapDimensions = function(bitmap) {
   if (!bitmap)
      return { width: 1, height: 1 };
   return { width: bitmap.width, height: bitmap.height };
};

AstroContrastEnhancerDialog.prototype.getCurrentViewportScale = function(bitmap) {
   if (!bitmap)
      return 1;
   if (this.isDetailBitmap(bitmap)) {
      var detailRect = this.getDetailViewportRect(bitmap);
      if (detailRect)
         return Math.max(ACE_EPSILON, (detailRect.x1 - detailRect.x0) / Math.max(1, bitmap.width));
      return aceGetFitScale(this.preview.width, this.preview.height, bitmap.width, bitmap.height);
   }
   if (this.appState.preview.zoomMode === "fit")
      return aceGetFitScale(this.preview.width, this.preview.height, bitmap.width, bitmap.height);
   return this.appState.preview.zoomScale;
};

AstroContrastEnhancerDialog.prototype.getCurrentViewportRect = function(bitmap) {
   if (!bitmap)
      return null;
   if (this.isDetailBitmap(bitmap)) {
      var detailRect = this.getDetailViewportRect(bitmap);
      if (detailRect)
         return detailRect;
   }
   var scale = this.getCurrentViewportScale(bitmap);
   var detailBitmap = this.isDetailBitmap(bitmap);
   var panX = detailBitmap ? 0 : this.appState.preview.panX;
   var panY = detailBitmap ? 0 : this.appState.preview.panY;
   return aceGetViewportRectForScale(this.preview.width, this.preview.height, bitmap.width, bitmap.height, scale, panX, panY);
};

AstroContrastEnhancerDialog.prototype.getDetailViewportRect = function(bitmap) {
   if (!bitmap || !this.appState || !this.appState.cache || !this.appState.cache.detail)
      return null;
   var detail = this.appState.cache.detail;
   var draft = this.appState.cache.draft;
   var source = this.appState.cache.source;
   if (!draft || !source || !source.width || !source.height || this.appState.preview.zoomMode === "fit")
      return null;
   var draftRect = aceGetViewportRectForScale(
      this.preview.width,
      this.preview.height,
      draft.width,
      draft.height,
      this.appState.preview.zoomScale,
      this.appState.preview.panX,
      this.appState.preview.panY
   );
   if (!draftRect)
      return null;
   var sourceToDraftX = draft.width / Math.max(1, source.width);
   var sourceToDraftY = draft.height / Math.max(1, source.height);
   var scale = this.appState.preview.zoomScale;
   var x0 = draftRect.x0 + (detail.x0 || 0) * sourceToDraftX * scale;
   var y0 = draftRect.y0 + (detail.y0 || 0) * sourceToDraftY * scale;
   var x1 = x0 + detail.width * sourceToDraftX * scale;
   var y1 = y0 + detail.height * sourceToDraftY * scale;
   return new Rect(Math.round(x0), Math.round(y0), Math.round(x1), Math.round(y1));
};

AstroContrastEnhancerDialog.prototype.isDetailBitmap = function(bitmap) {
   if (this.previewGestureDetail && bitmap === this.previewGestureDetail.bitmap)
      return true;
   if (!bitmap || !this.appState.cache.detail)
      return false;
   return bitmap === this.appState.cache.detail.currentBitmap ||
      bitmap === this.appState.cache.detail.originalBitmap ||
      bitmap === this.appState.cache.detail.localBeforeBitmap ||
      bitmap === this.appState.cache.detail.maskBitmap ||
      bitmap === this.appState.cache.detail.lassoMaskBitmap ||
      bitmap === this.appState.cache.detail.starMaskBitmap ||
      bitmap === this.appState.cache.detail.allowedMaskBitmap ||
      bitmap === this.appState.cache.detail.protectedOverlayBitmap ||
      (this.appState.cache.detail.mapBitmaps &&
         (bitmap === this.appState.cache.detail.mapBitmaps.texture ||
          bitmap === this.appState.cache.detail.mapBitmaps.clarity ||
          bitmap === this.appState.cache.detail.mapBitmaps.dehaze ||
          bitmap === this.appState.cache.detail.mapBitmaps.delta));
};

AstroContrastEnhancerDialog.prototype.getPreviewOverlayTitle = function() {
   if (this.appState.preview.showMask)
      return "Composite Contrast Mask";
   if (this.appState.preview.viewMode === "star")
      return "Star Protection Mask";
   if (this.appState.preview.viewMode === "allowed")
      return "Editable Areas";
   if (this.appState.preview.viewMode === "lasso")
      return "Lasso Mask";
   if (this.appState.preview.viewMode === "texture")
      return "Texture Map";
   if (this.appState.preview.viewMode === "clarity")
      return "Clarity Map";
   if (this.appState.preview.viewMode === "dehaze")
      return "Dehaze Map";
   if (this.appState.preview.viewMode === "delta")
      return "Luminance Change Map";
   return this.appState.cache.source.viewId || "Preview";
};

AstroContrastEnhancerDialog.prototype.getPreviewOverlaySubtitle = function() {
   if (this.appState.preview.showMask)
      return this.protectSky && this.protectSky.checked ? "Lasso x sky x stars | white allowed" : "Protection off | lasso only";
   if (this.appState.preview.viewMode === "star")
      return this.inputType === "stars" && this.protectStars && this.protectStars.checked ? "White protected | black unaffected" : "Starless mode | select Stars Present";
   if (this.appState.preview.viewMode === "allowed")
      return "White editable | black protected";
   if (this.appState.preview.viewMode === "lasso")
      return this.hasLassoSelection() ? "White local | black blocked" : "Draw a lasso selection";
   if (this.appState.preview.viewMode === "texture")
      return (this.scaleMapDisplayQuality ? this.scaleMapDisplayQuality + " | " : "") + (this.appState.params.texture === 0 ? "Underlying fine scale | " : "Scaled fine contribution | ") + "gray neutral";
   if (this.appState.preview.viewMode === "clarity")
      return (this.scaleMapDisplayQuality ? this.scaleMapDisplayQuality + " | " : "") + (this.appState.params.clarity === 0 ? "Underlying mid scale | " : "Scaled mid contribution | ") + "gray neutral";
   if (this.appState.preview.viewMode === "dehaze")
      return (this.scaleMapDisplayQuality ? this.scaleMapDisplayQuality + " | " : "") + "Smooth veil-field estimate | white = stronger haze";
   if (this.appState.preview.viewMode === "delta")
      return "White brighter | black darker | gray unchanged";
   var zoom = this.getZoomReadout();
   var armedLassoDetail =
      this.processingMode === "lasso" &&
      this.localSelectionNewActive &&
      !this.hasLassoSelection() &&
      this.appState.preview.viewMode === "preview" &&
      !this.appState.preview.showMask &&
      this.appState.preview.zoomMode !== "fit" &&
      this.appState.cache.detail;
   if (armedLassoDetail)
      return "Detail | draw lasso | " + zoom;
   if (this.shouldUseDetailPreview()) {
      var liveDetail = this.hasLiveDetailRequest();
      if (this.previewDragging || (this.detailPreviewPendingNavigation && liveDetail))
         return "Draft | detail pending | " + zoom;
      if (this.detailPreviewPendingAdjustment && this.appState.cache.detail)
         return "Detail | adjustment pending | " + zoom;
      if (this.appState.cache.detail)
         return "Detail | " + zoom;
      return liveDetail ? "Draft | detail pending | " + zoom : "Draft | " + zoom;
   }
   return "Draft preview | " + zoom;
};

AstroContrastEnhancerDialog.prototype.hasLiveDetailRequest = function() {
   return !!(this.detailWorkActive ||
      this.detailRefreshTimerToken ||
      this.detailAdjustmentTimerToken ||
      (this.detailWorkActive &&
       (this.detailPreviewRefreshAfterActiveWork ||
        this.detailAdjustmentRefreshAfterActiveWork)));
};

AstroContrastEnhancerDialog.prototype.drawPreviewTextPanel = function(g, x, y, width, height, lines, alignRight) {
   g.brush = new Brush(0x8a202020);
   g.pen = new Pen(0x30303030, 1);
   g.drawRect(new Rect(x, y, x + width, y + height));
   var titleFont = new Font;
   titleFont.pixelSize = ACE_FONT_OVERLAY_TITLE;
   titleFont.bold = true;
   var bodyFont = new Font;
   bodyFont.pixelSize = ACE_FONT_OVERLAY_BODY;
   for (var i = 0; i < lines.length; ++i) {
      g.font = i === 0 ? titleFont : bodyFont;
      g.pen = new Pen(i === 0 ? ACE_COLORS.text : ACE_COLORS.muted);
      var text = aceFitTextToWidth(g.font, String(lines[i] || ""), width - 10);
      var tx = alignRight ? Math.max(x + 5, x + width - 5 - g.font.width(text)) : x + 5;
      var lineStep = ACE_FONT_OVERLAY_BODY + 4;
      var ty = lines.length === 1 ? y + Math.max(13, Math.floor((height + g.font.ascent) / 2) - 1) : y + 13 + i * lineStep;
      g.drawText(tx, ty, text);
   }
};

AstroContrastEnhancerDialog.prototype.drawLowZoomLoupe = function(g) {
   if (!this.lowZoomLoupeShouldBeActive())
      return;
   var loupe = this.appState && this.appState.cache ? this.appState.cache.lowZoomLoupe : null;
   var loupeShowBefore = !!(this.appState.preview.showBefore || this.lowZoomLoupeShowBefore);
   var bmp = loupe ? (loupeShowBefore ? loupe.beforeBitmap : loupe.afterBitmap) : null;
   var pending = this.lowZoomLoupePending || !bmp;
   var panelW = Math.min(ACE_LOW_ZOOM_GLOBAL_LOUPE_WIDTH + 16, Math.max(150, this.preview.width - 36));
   var panelH = Math.min(ACE_LOW_ZOOM_GLOBAL_LOUPE_HEIGHT + 34, Math.max(130, this.preview.height - 92));
   if (panelW < 150 || panelH < 130)
      return;
   var cursorX = this.lowZoomLoupeMouseValid ? this.lowZoomLoupeMouseX : Math.round(this.preview.width * 0.55);
   var cursorY = this.lowZoomLoupeMouseValid ? this.lowZoomLoupeMouseY : Math.round(this.preview.height * 0.45);
   var x = cursorX + 18;
   var y = cursorY + 18;
   if (x + panelW > this.preview.width - 12)
      x = cursorX - panelW - 18;
   if (y + panelH > this.preview.height - 34)
      y = cursorY - panelH - 18;
   x = aceClamp(x, 12, Math.max(12, this.preview.width - panelW - 12));
   y = aceClamp(y, 46, Math.max(46, this.preview.height - panelH - 34));
   var imageX = x + 8;
   var imageY = y + 26;
   var imageW = panelW - 16;
   var imageH = panelH - 34;
   g.brush = new Brush(0xc8202020);
   g.pen = new Pen(ACE_COLORS.warning, 1);
   g.drawRect(new Rect(x, y, x + panelW, y + panelH));
   var titleFont = new Font;
   titleFont.pixelSize = ACE_FONT_OVERLAY_BODY;
   titleFont.bold = true;
   var bodyFont = new Font;
   bodyFont.pixelSize = ACE_FONT_OVERLAY_BODY;
   g.font = titleFont;
   g.pen = new Pen(ACE_COLORS.warning);
   var title = "Loupe";
   g.drawText(x + 9, y + 19, title);
   g.font = bodyFont;
   g.pen = new Pen(ACE_COLORS.muted);
   var label = pending ? "building..." : ((loupeShowBefore ? "before" : "after") + " | native 100%");
   var fitted = aceFitTextToWidth(bodyFont, label, panelW - titleFont.width(title) - 28);
   g.drawText(Math.max(x + 9 + titleFont.width(title) + 12, x + panelW - 9 - bodyFont.width(fitted)), y + 19, fitted);
   g.brush = new Brush(0xff101010);
   g.pen = new Pen(ACE_COLORS.lineDim, 1);
   g.drawRect(new Rect(imageX, imageY, imageX + imageW, imageY + imageH));
   if (bmp) {
      var scale = Math.min(imageW / Math.max(1, bmp.width), imageH / Math.max(1, bmp.height));
      var drawW = Math.max(1, Math.round(bmp.width * scale));
      var drawH = Math.max(1, Math.round(bmp.height * scale));
      var bx = imageX + Math.floor((imageW - drawW) * 0.5);
      var by = imageY + Math.floor((imageH - drawH) * 0.5);
      g.drawScaledBitmap(new Rect(bx, by, bx + drawW, by + drawH), bmp);
   } else {
      g.font = bodyFont;
      g.pen = new Pen(ACE_COLORS.text);
      var msg = aceFitTextToWidth(bodyFont, "Building native detail crop", imageW - 18);
      g.drawText(imageX + Math.round((imageW - bodyFont.width(msg)) * 0.5), imageY + Math.round(imageH * 0.5), msg);
   }
};

AstroContrastEnhancerDialog.prototype.drawPreviewLoadingPanel = function(g) {
   var title = this.previewWarmupActive ? "Preparing first preview response..." : "Target image loading...";
   var subtitle = this.previewWarmupActive ? "Building preview caches. Controls will respond shortly." : "Building preview cache";
   var titleFont = new Font;
   titleFont.pixelSize = ACE_FONT_SECTION;
   titleFont.bold = true;
   var bodyFont = new Font;
   bodyFont.pixelSize = ACE_FONT_BODY;
   var titleW = titleFont.width(title);
   var subtitleW = bodyFont.width(subtitle);
   var panelW = Math.min(Math.max(ACE_HOST_IS_WINDOWS ? 560 : 420, Math.max(titleW, subtitleW) + (ACE_HOST_IS_WINDOWS ? 110 : 52)), Math.max(320, this.preview.width - 70));
   var panelH = ACE_HOST_IS_WINDOWS ? 96 : 82;
   var x = Math.round((this.preview.width - panelW) * 0.5);
   var y = Math.round((this.preview.height - panelH) * 0.5);
   g.brush = new Brush(0xd0202020);
   g.pen = new Pen(ACE_COLORS.warning, 2);
   g.drawRect(new Rect(x, y, x + panelW, y + panelH));
   g.font = titleFont;
   g.pen = new Pen(ACE_COLORS.warning);
   var fittedTitle = aceFitTextToWidth(titleFont, title, panelW - 32);
   g.drawText(x + Math.round((panelW - titleFont.width(fittedTitle)) * 0.5), y + (ACE_HOST_IS_WINDOWS ? 38 : 32), fittedTitle);
   g.font = bodyFont;
   g.pen = new Pen(ACE_COLORS.text);
   var fittedSubtitle = aceFitTextToWidth(bodyFont, subtitle, panelW - 32);
   g.drawText(x + Math.round((panelW - bodyFont.width(fittedSubtitle)) * 0.5), y + (ACE_HOST_IS_WINDOWS ? 68 : 58), fittedSubtitle);
};

AstroContrastEnhancerDialog.prototype.drawPreviewOutputWaitPanel = function(g) {
   var title = this.outputWaitTitle || "Writing output...";
   var subtitle = this.outputWaitSubtitle || "PixInsight is writing data. Please wait.";
   var titleFont = new Font;
   titleFont.pixelSize = ACE_FONT_SECTION;
   titleFont.bold = true;
   var bodyFont = new Font;
   bodyFont.pixelSize = ACE_FONT_BODY;
   var titleW = titleFont.width(title);
   var subtitleW = bodyFont.width(subtitle);
   var panelW = Math.min(Math.max(360, Math.max(titleW, subtitleW) + 52), Math.max(320, this.preview.width - 70));
   var panelH = 82;
   var x = Math.round((this.preview.width - panelW) * 0.5);
   var y = Math.round((this.preview.height - panelH) * 0.5);
   g.brush = new Brush(0xd0202020);
   g.pen = new Pen(ACE_COLORS.warning, 2);
   g.drawRect(new Rect(x, y, x + panelW, y + panelH));
   g.font = titleFont;
   g.pen = new Pen(ACE_COLORS.warning);
   var fittedTitle = aceFitTextToWidth(titleFont, title, panelW - 32);
   g.drawText(x + Math.round((panelW - titleFont.width(fittedTitle)) * 0.5), y + 32, fittedTitle);
   g.font = bodyFont;
   g.pen = new Pen(ACE_COLORS.text);
   var fittedSubtitle = aceFitTextToWidth(bodyFont, subtitle, panelW - 32);
   g.drawText(x + Math.round((panelW - bodyFont.width(fittedSubtitle)) * 0.5), y + 58, fittedSubtitle);
};

AstroContrastEnhancerDialog.prototype.drawPreviewMapUpdatePanel = function(g) {
   var title = "Updating " + this.currentScaleMapLabel();
   var subtitle = "Building accurate high-res map; previous map remains visible.";
   var titleFont = new Font;
   titleFont.pixelSize = ACE_FONT_SECTION;
   titleFont.bold = true;
   var bodyFont = new Font;
   bodyFont.pixelSize = ACE_FONT_BODY;
   var panelW = Math.min(Math.max(410, Math.max(titleFont.width(title), bodyFont.width(subtitle)) + 52), Math.max(320, this.preview.width - 70));
   var panelH = 82;
   var x = Math.round((this.preview.width - panelW) * 0.5);
   var y = Math.round((this.preview.height - panelH) * 0.5);
   g.brush = new Brush(0xd0202020);
   g.pen = new Pen(ACE_COLORS.warning, 2);
   g.drawRect(new Rect(x, y, x + panelW, y + panelH));
   g.font = titleFont;
   g.pen = new Pen(ACE_COLORS.warning);
   var fittedTitle = aceFitTextToWidth(titleFont, title, panelW - 32);
   g.drawText(x + Math.round((panelW - titleFont.width(fittedTitle)) * 0.5), y + 32, fittedTitle);
   g.font = bodyFont;
   g.pen = new Pen(ACE_COLORS.text);
   var fittedSubtitle = aceFitTextToWidth(bodyFont, subtitle, panelW - 32);
   g.drawText(x + Math.round((panelW - bodyFont.width(fittedSubtitle)) * 0.5), y + 58, fittedSubtitle);
};

AstroContrastEnhancerDialog.prototype.drawPreviewWarmupPanel = function(g) {
   var title = "Preparing first preview response...";
   var subtitle = "Building preview caches. Controls will respond shortly.";
   var titleFont = new Font;
   titleFont.pixelSize = ACE_FONT_SECTION;
   titleFont.bold = true;
   var bodyFont = new Font;
   bodyFont.pixelSize = ACE_FONT_BODY;
   var panelW = Math.min(Math.max(ACE_HOST_IS_WINDOWS ? 560 : 420, Math.max(titleFont.width(title), bodyFont.width(subtitle)) + (ACE_HOST_IS_WINDOWS ? 110 : 52)), Math.max(320, this.preview.width - 70));
   var panelH = ACE_HOST_IS_WINDOWS ? 96 : 82;
   var x = Math.round((this.preview.width - panelW) * 0.5);
   var y = Math.round((this.preview.height - panelH) * 0.5);
   g.brush = new Brush(0xd0202020);
   g.pen = new Pen(ACE_COLORS.warning, 2);
   g.drawRect(new Rect(x, y, x + panelW, y + panelH));
   g.font = titleFont;
   g.pen = new Pen(ACE_COLORS.warning);
   var fittedTitle = aceFitTextToWidth(titleFont, title, panelW - 32);
   g.drawText(x + Math.round((panelW - titleFont.width(fittedTitle)) * 0.5), y + (ACE_HOST_IS_WINDOWS ? 38 : 32), fittedTitle);
   g.font = bodyFont;
   g.pen = new Pen(ACE_COLORS.text);
   var fittedSubtitle = aceFitTextToWidth(bodyFont, subtitle, panelW - 32);
   g.drawText(x + Math.round((panelW - bodyFont.width(fittedSubtitle)) * 0.5), y + (ACE_HOST_IS_WINDOWS ? 68 : 58), fittedSubtitle);
};

AstroContrastEnhancerDialog.prototype.previewOverlayLeftStatusText = function() {
   if (!this.hasActiveSource())
      return "No image";
   if (this.processingMode === "lasso" &&
       this.localSelectionNewActive &&
       !this.hasLassoSelection() &&
       this.appState.cache.detail)
      return "Loaded | " + this.getZoomReadout();
   if (this.shouldUseDetailPreview() && (this.previewDragging || (this.detailPreviewPendingNavigation && this.hasLiveDetailRequest())))
      return "Low-res draft | " + this.getZoomReadout();
   if (this.shouldUseDetailPreview() && this.detailPreviewPendingAdjustment && this.appState.cache.detail)
      return "Detail pending | " + this.getZoomReadout();
   return "Loaded | " + this.getZoomReadout();
};

AstroContrastEnhancerDialog.prototype.previewOverlayRightStatusText = function() {
   var armedLassoDetail = this.processingMode === "lasso" &&
      this.localSelectionNewActive &&
      !this.hasLassoSelection() &&
      this.appState && this.appState.cache && this.appState.cache.detail;
   var detailActive = this.appState && this.appState.cache && this.appState.cache.detail && (this.shouldUseDetailPreview() || armedLassoDetail);
   if (this.currentViewNeedsScaleMaps() && this.scaleMapDisplayQuality)
      return this.scaleMapDisplayQuality.indexOf("Quick") === 0 ? "quick map" : "accurate map";
   if (this.shouldUseDetailPreview() && (this.previewDragging || (this.detailPreviewPendingNavigation && this.hasLiveDetailRequest())))
      return "low-res draft";
   if (detailActive && this.detailPreviewPendingAdjustment)
      return "detail pending";
   if (detailActive)
      return "detail";
   var text = this.previewStatusRightText || "Preview draft";
   var pipe = text.indexOf(" | ");
   if (pipe >= 0)
      text = text.substring(0, pipe);
   text = text.replace(/\.\.\.$/, "");
   if (text.indexOf("Preview: ") === 0)
      text = text.substring(9);
   text = text.toLowerCase();
   if (text === "Preview draft")
      text = "draft";
   if (text === "Preview: draft")
      text = "draft";
   if (text === "Preview: detail crop" || text === "detail crop")
      text = "detail";
   if (text.indexOf("texture") >= 0)
      return "texture";
   if (text.indexOf("clarity") >= 0)
      return "clarity";
   if (text.indexOf("dehaze") >= 0)
      return "dehaze";
   if (text.indexOf("advanced") >= 0)
      return "advanced";
   if (text.indexOf("full image") >= 0)
      return "full";
   if (text.indexOf("lasso") >= 0)
      return "lasso";
   if (text.indexOf("before") >= 0)
      return "before";
   if (text.indexOf("after") >= 0)
      return "after";
   if (text.indexOf("draft") >= 0 || text.indexOf("preview") >= 0)
      return "draft";
   if (text.indexOf("zoom") >= 0)
      return this.getZoomReadout();
   if (text.length > 12)
      text = text.substring(0, 12);
   return text || "draft";
};

AstroContrastEnhancerDialog.prototype.drawPreviewOverlay = function(g, bmp) {
   var loading = this.targetImageLoading && !bmp && !this.appState.preview.showMask;
   if (loading) {
      this.drawPreviewLoadingPanel(g);
      return;
   }
   var title = loading ? "Preparing first preview response..." : ((bmp || this.appState.preview.showMask) ? this.getPreviewOverlayTitle() : "No active image");
   var subtitle = loading ? "Building preview caches. Controls will respond shortly." : ((bmp || this.appState.preview.showMask) ? this.getPreviewOverlaySubtitle() : "Open an image and select its view.");
   if (!loading && this.scaleMapRebuildPending && this.currentViewNeedsScaleMaps()) {
      title = "Updating " + this.currentScaleMapLabel();
      subtitle = "Building accurate high-res map; previous map remains visible.";
   }
   var titleFont = new Font;
   titleFont.pixelSize = ACE_FONT_OVERLAY_TITLE;
   titleFont.bold = true;
   var bodyFont = new Font;
   bodyFont.pixelSize = ACE_FONT_OVERLAY_BODY;
   var pad = 10;
   var safeX0 = pad;
   var safeY0 = pad;
   var safeX1 = Math.max(safeX0 + 1, this.preview.width - pad);
   var safeY1 = Math.max(safeY0 + 1, this.preview.height - pad);
   if (bmp && this.previewDisplayRect) {
      safeX0 = aceClamp(Math.max(pad, this.previewDisplayRect.x0 + pad), pad, Math.max(pad, this.preview.width - pad));
      safeY0 = aceClamp(Math.max(pad, this.previewDisplayRect.y0 + pad), pad, Math.max(pad, this.preview.height - pad));
      safeX1 = aceClamp(Math.min(this.preview.width - pad, this.previewDisplayRect.x1 - pad), safeX0 + 1, this.preview.width - pad);
      safeY1 = aceClamp(Math.min(this.preview.height - pad, this.previewDisplayRect.y1 - pad), safeY0 + 1, this.preview.height - pad);
   }

   var titleW = Math.max(titleFont.width(title), bodyFont.width(subtitle)) + 18;
   var overlayMaxW = this.appState.preview.viewMode === "dehaze" || this.scaleMapRebuildPending ? 520 : 360;
   var topW = Math.min(Math.max(115, titleW), Math.max(115, Math.min(overlayMaxW, safeX1 - safeX0)));
   var topH = 42;
   var topX = aceClamp(safeX0, pad, Math.max(pad, this.preview.width - topW - pad));
   var topY = aceClamp(safeY0, pad, Math.max(pad, this.preview.height - topH - pad));
   this.drawPreviewTextPanel(g, topX, topY, topW, topH, [title, subtitle], false);
   if (loading)
      this.drawPreviewLoadingPanel(g);
   if (this.outputWaitTitle)
      this.drawPreviewOutputWaitPanel(g);
   else if (!loading && this.previewWarmupActive)
      this.drawPreviewWarmupPanel(g);
   else if (!loading && this.scaleMapRebuildPending && this.currentViewNeedsScaleMaps())
      this.drawPreviewMapUpdatePanel(g);

   var leftText = this.previewOverlayLeftStatusText();
   var rightText = this.previewOverlayRightStatusText();
   var panelH = 24;
   var rightW = Math.min(Math.max(120, bodyFont.width(rightText) + 28), Math.min(520, this.preview.width - 2 * pad));
   var leftMax = Math.max(140, this.preview.width - rightW - 3 * pad);
   var leftW = Math.min(Math.max(175, bodyFont.width(leftText) + 34), Math.min(650, leftMax));
   var bottomInset = 10;
   var bottomY = aceClamp(safeY1 - panelH - bottomInset, topY + topH + pad, Math.max(topY + topH + pad, this.preview.height - panelH - pad));
   var leftX = aceClamp(safeX0, pad, Math.max(pad, this.preview.width - leftW - pad));
   var rightX = aceClamp(safeX1 - rightW, leftX + leftW + pad, Math.max(leftX + leftW + pad, this.preview.width - rightW - pad));
   if (rightX + rightW > this.preview.width - pad)
      rightX = this.preview.width - rightW - pad;
   this.drawPreviewTextPanel(g, leftX, bottomY, leftW, panelH, [leftText], false);
   this.drawPreviewTextPanel(g, rightX, bottomY, rightW, panelH, [rightText], true);
};

AstroContrastEnhancerDialog.prototype.getZoomReadout = function() {
   if (this.appState.preview.zoomMode === "fit")
      return "Fit";
   return Math.round(this.appState.preview.zoomScale * 100) + "%";
};

AstroContrastEnhancerDialog.prototype.refreshPreviewStatus = function(left, right) {
   this.previewStatusLeftText = aceShortText(left || "", 78);
   this.previewStatusRightText = aceShortText(right || "", 64);
   if (this.footerLeft) {
      this.footerLeft.text = this.previewStatusLeftText || "Ready";
      if (!this.outputWaitTitle) {
         this.footerLeft.textColor = ACE_COLORS.muted;
         this.footerLeft.foregroundColor = ACE_COLORS.muted;
      }
   }
   if (this.footerRight) {
      this.footerRight.text = this.previewStatusRightText || "Preview draft";
      if (!this.outputWaitTitle) {
         this.footerRight.textColor = ACE_COLORS.muted;
         this.footerRight.foregroundColor = ACE_COLORS.muted;
      }
   }
   if (typeof this.refreshRightPanelContext === "function")
      this.refreshRightPanelContext();
};

AstroContrastEnhancerDialog.prototype.setFooterStatus = function(text, color) {
   if (this.footerLeft) {
      this.footerLeft.text = aceShortText(text, 92);
      this.footerLeft.textColor = color || ACE_COLORS.muted;
      this.footerLeft.foregroundColor = color || ACE_COLORS.muted;
      aceRefreshNow(this.footerLeft);
   }
};

AstroContrastEnhancerDialog.prototype.setPendingPreviewStage = function(stageText) {
   var text = stageText || "Preparing preview...";
   this.refreshPreviewStatus(this.describeLoadedSource(), text);
   this.setFooterStatus(text, ACE_COLORS.warning);
   if (this.preview)
      this.preview.update();
   if (!this.detailPreviewPendingAdjustment &&
       !this.detailPreviewPendingNavigation &&
       !this.interactiveSliderDrag &&
       !this.pendingInteractivePreviewLabel &&
       typeof CoreApplication !== "undefined" &&
       typeof CoreApplication.processEvents === "function")
      CoreApplication.processEvents();
};

AstroContrastEnhancerDialog.prototype.effectLabelForName = function(name) {
   if (name === "texture")
      return "Texture";
   if (name === "clarity")
      return "Clarity";
   if (name === "dehaze")
      return "Dehaze";
   return "Preview";
};

AstroContrastEnhancerDialog.prototype.setNavigationTool = function(tool) {
   this.appState.preview.tool = tool || "preview";
   this.refreshPreviewStatus(this.describeLoadedSource(), "Tool: " + this.appState.preview.tool + " | Zoom: " + this.getZoomReadout());
};

AstroContrastEnhancerDialog.prototype.viewModeStatusText = function(mode) {
   if (mode === "texture")
      return "View: Texture Map";
   if (mode === "clarity")
      return "View: Clarity Map";
   if (mode === "dehaze")
      return "View: Dehaze Map";
   if (mode === "delta")
      return "View: Change Map";
   if (mode === "lasso")
      return this.hasLassoSelection() ? "View: Lasso Mask" : "View: Lasso Mask - draw selection";
   if (mode === "star")
      return this.inputType === "stars" ? "View: Star Mask" : "View: Star Mask - select Stars Present";
   if (mode === "allowed")
      return "View: Editable Areas";
   if (mode === "mask")
      return "View: Mask";
   return "Preview: draft";
};

AstroContrastEnhancerDialog.prototype.hasActiveSource = function() {
   var source = this.appState && this.appState.cache ? this.appState.cache.source : null;
   return !!(source && source.viewId && source.width > 0 && source.height > 0);
};

AstroContrastEnhancerDialog.prototype.hasMeaningfulAllowedMask = function() {
   if (!this.hasActiveSource())
      return false;
   return this.processingMode === "lasso" && this.hasLassoSelection();
};

AstroContrastEnhancerDialog.prototype.currentMaskViewCanSave = function() {
   if (!this.hasActiveSource() || !this.appState || !this.appState.preview)
      return false;
   if (this.appState.preview.showMask)
      return true;
   var mode = this.appState.preview.viewMode || "preview";
   return mode === "texture" || mode === "clarity" || mode === "dehaze" || mode === "delta" ||
      mode === "lasso" || mode === "star" || mode === "allowed" || mode === "mask";
};

AstroContrastEnhancerDialog.prototype.syncProtectionFamilyControls = function() {
   var backgroundOn = !this.backgroundProtection || this.backgroundProtection.checked;
   var starsMode = this.inputType === "stars";
   var starOn = starsMode && (!this.starProtection || this.starProtectionDesired !== false);
   if (this.protectSky)
      this.protectSky.checked = backgroundOn;
   if (this.preventDark)
      this.preventDark.checked = backgroundOn;
   if (this.starProtection) {
      this.starProtection.enabled = starsMode && !this.outputRendering;
      this.starProtection.checked = starOn;
      this.starProtection.textColor = starsMode ? ACE_COLORS.text : ACE_COLORS.muted;
      this.starProtection.foregroundColor = this.starProtection.textColor;
   }
   if (this.protectStars)
      this.protectStars.checked = starOn;
   if (this.protectHalos)
      this.protectHalos.checked = starOn;
};

AstroContrastEnhancerDialog.prototype.handleProtectionFamilyChange = function(family) {
   if (family === "stars" && this.starProtection)
      this.starProtectionDesired = this.starProtection.checked;
   this.syncProtectionFamilyControls();
   this.handleProtectionChange();
};

AstroContrastEnhancerDialog.prototype.protectionSummaryText = function() {
   var backgroundOn = this.protectSky && this.protectSky.checked && this.preventDark && this.preventDark.checked;
   var starsActive = this.getStarProtectionActive();
   if (!backgroundOn && !starsActive)
      return this.inputType === "stars" ? "Protections off" : "BG open - Starless mode";
   return (backgroundOn ? "BG protected" : "BG open") + " - " +
      (this.inputType === "stars" ? (starsActive ? "Stars protected" : "Stars open") : "Starless mode");
};

AstroContrastEnhancerDialog.prototype.viewModeAvailability = function(mode) {
   var next = mode === "mask" ? "allowed" : (mode || "preview");
   var params = this.appState ? this.appState.params : null;
   if (next === "preview")
      return { available: true, reason: "" };
   if (!this.hasActiveSource())
      return { available: false, reason: "Open an image before using diagnostic views." };
   if (next === "texture")
      return { available: true, reason: "" };
   if (next === "clarity")
      return { available: true, reason: "" };
   if (next === "dehaze")
      return { available: true, reason: "" };
   if (next === "delta")
      return { available: !!(params && params.hasEffect()), reason: "Delta view is available when an adjustment is active." };
   if (next === "lasso")
      return { available: this.hasLassoSelection(), reason: "Draw a lasso before using Lasso view." };
   if (next === "star")
      return {
         available: this.getStarProtectionActive(),
         reason: this.inputType === "stars" ? "Star mask unavailable because Star Protection is inactive." : "Star mask unavailable in Starless mode."
      };
   if (next === "allowed")
      return { available: this.hasMeaningfulAllowedMask(), reason: "Editable Areas is available while editing a lasso selection." };
   return { available: false, reason: "" };
};

AstroContrastEnhancerDialog.prototype.normalizeActiveViewMode = function() {
   if (!this.appState || !this.appState.preview)
      return;
   var mode = this.appState.preview.viewMode || "preview";
   if (mode === "mask")
      mode = "allowed";
   if (!this.viewModeAvailability(mode).available)
      mode = "preview";
   this.appState.preview.viewMode = mode;
   this.appState.preview.showMask = false;
};

AstroContrastEnhancerDialog.prototype.viewLegendText = function(mode) {
   if (mode === "texture")
      return { title: "Texture Map", body: "Bright = stronger fine-scale structure" };
   if (mode === "clarity") {
      var clarityMode = this.currentClarityMode();
      if (aceIsClarityFeatureFitMode(clarityMode))
         return { title: "Clarity " + aceClarityFeatureFitModeLabel(clarityMode), body: "Signed V4 plus gated feature-fit delta; internal app-test path" };
      if (aceIsClarityDualZoneBoostMode(clarityMode))
         return { title: "Clarity " + aceClarityFeatureFitModeLabel(clarityMode), body: "Internal DualZone high-headroom test path; 100-150 is intentional overshoot" };
      if (aceIsClarityDualZoneOptMode(clarityMode))
         return { title: "Clarity +DZOpt", body: "Internal optimized DualZone test path; V4 remains default" };
      if (aceIsClarityV4Mode(clarityMode))
         return { title: "Clarity V4", body: "Signed multi-scale relief delta; display scaled for visibility" };
      if (aceIsClarityV3Mode(clarityMode))
         return { title: aceClarityV3ModeLabel(clarityMode), body: "Signed final delta; display scaled for visibility" };
      if (clarityMode === ACE_CLARITY_MODE_V2_DEPTH)
         return { title: "Clarity V2 Depth", body: "Signed delta: bright lifts, dark deepens" };
      return clarityMode === ACE_CLARITY_MODE_V2 ?
         { title: "Clarity V2 Map", body: "Bright = active midtone structure" } :
         { title: "Clarity Map", body: "Bright = stronger mid-scale structure" };
   }
   if (mode === "dehaze")
      return { title: "Dehaze Veil Field", body: "Smooth broad haze estimate; white = stronger veil" };
   if (mode === "delta")
      return { title: "Delta", body: "Bright = lighter - Dark = darker" };
   if (mode === "lasso")
      return { title: "Lasso Mask", body: "White = active - Gray = feather" };
   if (mode === "star")
      return { title: "Star Mask", body: "White = protected stars / halos" };
   if (mode === "allowed" || mode === "mask")
      return { title: "Edit Area", body: "White = editable - Dark = protected" };
   return { title: "View: Preview", body: "" };
};

AstroContrastEnhancerDialog.prototype.localEditText = function() {
   if (this.targetImageLoading)
      return { mode: "Loading target...", state: "", next: "" };
   if (!this.appState || !this.appState.cache || !this.appState.cache.source || !this.appState.cache.source.viewId)
      return { mode: "No active image", state: "", next: "" };
   var committedCount = this.appState.editRecipe ? this.appState.editRecipe.length : 0;
   var pendingCount = this.appState.cache.pendingActive ? 1 : 0;
   var liveText = committedCount > 0 || pendingCount > 0 ?
      ("Live local edits: " + committedCount + (pendingCount ? " + pending" : "")) :
      "";
   if (this.processingMode !== "lasso") {
      if (this.appState.params.hasEffect())
         return { mode: "Mode: Full Image", state: "Adjustment active", next: liveText };
      if (this.lastLocalAction === "committed")
         return { mode: "Committed", state: "Move selection or New", next: liveText };
      return { mode: "Mode: Full Image", state: "No pending adjustment", next: liveText };
   }
   if (!this.hasLassoSelection())
      return { mode: "Mode: Lasso", state: "Draw selection", next: liveText };
   var inverted = this.appState.lassoInverted;
   var state = inverted ? "Lasso: inverted" : "Lasso: active";
   var next = "";
   if (this.appState.cache.pendingActive)
      return { mode: "Edit pending", state: "Commit or Cancel", next: liveText };
   else if (this.lastLocalAction === "committed")
      return { mode: "Committed", state: "Move selection or New", next: liveText };
   else if (this.lastLocalAction === "canceled")
      next = "Canceled";
   if (inverted && !this.appState.cache.pendingActive)
      next = "Outside active";
   if (!next)
      next = liveText;
   else if (liveText)
      next += " | " + liveText;
   return { mode: "Mode: Lasso", state: state, next: next };
};

AstroContrastEnhancerDialog.prototype.refreshRightPanelContext = function() {
   this.normalizeActiveViewMode();
   this.syncProtectionFamilyControls();
   var backgroundOn = this.protectSky && this.protectSky.checked && this.preventDark && this.preventDark.checked;
   var starsActive = this.getStarProtectionActive();
   if (this.protectionSummaryLine)
      this.protectionSummaryLine.setStatus(this.protectionSummaryText(), (backgroundOn || starsActive) ? ACE_COLORS.active : ACE_COLORS.warning);
   var viewMode = this.appState && this.appState.preview ? this.appState.preview.viewMode : "preview";
   var legend = this.viewLegendText(viewMode);
   aceSetCollapsed(this.viewLegendPanel, viewMode === "preview");
   if (this.viewLegendTitleLine)
      this.viewLegendTitleLine.setStatus(legend.title, ACE_COLORS.sectionTitle);
   if (this.viewLegendBodyLine) {
      this.viewLegendBodyLine.setStatus(legend.body, ACE_COLORS.accent);
      aceSetCollapsed(this.viewLegendBodyLine, !legend.body);
   }
   var local = this.localEditText();
   if (this.localEditModeLine)
      this.localEditModeLine.setStatus(local.mode, ACE_COLORS.sectionTitle);
   var adjustmentActive = local.state === "Adjustment active" || local.mode === "Edit pending";
   if (this.localEditStateLine)
      this.localEditStateLine.setStatus(
         local.state,
         adjustmentActive ? ACE_COLORS.warning : ACE_COLORS.accent,
         adjustmentActive,
         adjustmentActive ? 0xff2f2818 : ACE_COLORS.inset
      );
   aceSetCollapsed(this.localEditStateLine, !local.state);
   if (this.localEditNextLine)
      this.localEditNextLine.setStatus(local.next, ACE_COLORS.active);
   aceSetCollapsed(this.localEditNextLine, !local.next);
   this.refreshViewModeButtons();
};

AstroContrastEnhancerDialog.prototype.refreshViewModeButtons = function() {
   if (!this.viewModeButtons)
      return;
   var mode = this.appState.preview.viewMode || "preview";
   for (var key in this.viewModeButtons) {
      if (!this.viewModeButtons.hasOwnProperty(key) || !this.viewModeButtons[key])
         continue;
      var button = this.viewModeButtons[key];
      var availability = this.viewModeAvailability(key);
      button.visible = true;
      if (typeof button.setActive === "function")
         button.setActive(key === mode);
      if (typeof button.setVisualEnabled === "function")
         button.setVisualEnabled(availability.available);
   }
};

AstroContrastEnhancerDialog.prototype.setViewMode = function(mode) {
   var next = mode || "preview";
   if (next === "mask")
      next = "allowed";
   if (next !== "texture" && next !== "clarity" && next !== "dehaze" && next !== "delta" && next !== "lasso" && next !== "star" && next !== "allowed")
      next = "preview";
   var availability = this.viewModeAvailability(next);
   if (!availability.available) {
      this.refreshViewModeButtons();
      this.refreshPreviewStatus(this.describeLoadedSource(), availability.reason || "View unavailable");
      if (this.preview)
         this.preview.update();
      return;
   }
   this.appState.preview.viewMode = next;
   this.appState.preview.showMask = false;
   if (this.currentViewNeedsScaleMaps())
      this.forceCurrentScaleMapBuild("view-mode");
   else
      this.ensureCurrentViewDiagnostics();
   if (this.shouldUseDetailPreview() && this.appState.cache.detail && this.detailPreviewNeedsMaskBitmaps() &&
       (!this.appState.cache.detail.starMaskBitmap || !this.appState.cache.detail.maskBitmap))
      this.refreshDetailPreviewIfNeeded(true);
   this.refreshViewModeButtons();
   this.refreshLocalSelectionControls();
   this.refreshPreviewStatus(this.describeLoadedSource(), this.viewModeStatusText(next));
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.currentViewNeedsScaleMaps = function() {
   var mode = this.appState && this.appState.preview ? this.appState.preview.viewMode : "preview";
   return mode === "texture" || mode === "clarity" || mode === "delta" || mode === "dehaze";
};

AstroContrastEnhancerDialog.prototype.currentScaleMapLabel = function() {
   var mode = this.appState && this.appState.preview ? this.appState.preview.viewMode : "preview";
   if (mode === "texture")
      return "Texture Map";
   if (mode === "clarity")
      return "Clarity Map";
   if (mode === "dehaze")
      return "Dehaze Map";
   if (mode === "delta")
      return "Delta Map";
   return "Map";
};

AstroContrastEnhancerDialog.prototype.buildDisplayScaleMapBitmaps = function(previewData, mode, reason) {
   if (!previewData || !previewData.rgb)
      return null;
   var processedRgb = previewData.currentRgb || null;
   if (mode === "delta" && this.appState && this.appState.params && this.appState.params.hasEffect()) {
      var options = this.applyLassoWeightToOptions(previewData, this.getProtectionOptions());
      options.skipBitmapRender = true;
      var processed = this.appState.processor.processPreview(
         previewData,
         this.appState.params,
         options,
         this.appState.advanced,
         null,
         "Delta map"
      );
      processedRgb = processed && processed.rgb ? processed.rgb : null;
   }
   return this.appState.processor.buildScaleMapBitmaps(
      previewData,
      this.appState.params,
      processedRgb,
      this.appState.advanced,
      mode
   );
};

AstroContrastEnhancerDialog.prototype.forceCurrentScaleMapBuild = function(reason) {
   if (!this.currentViewNeedsScaleMaps() || !this.appState || !this.appState.cache)
      return false;
   var cache = this.appState.cache;
   var mode = this.appState.preview.viewMode;
   var start = Date.now();
   var built = false;
   if (cache.draft && cache.draft.rgb) {
      if (cache.mapBitmaps)
         cache.mapBitmaps[mode] = null;
      cache.draft.currentRgb = cache.currentRgb || null;
      cache.mapBitmaps = aceMergeScaleMapBitmaps(cache.mapBitmaps, this.buildDisplayScaleMapBitmaps(cache.draft, mode, reason));
      cache.draft.currentRgb = null;
      built = !!(cache.mapBitmaps && cache.mapBitmaps[mode]);
      this.scaleMapDisplayQuality = built ? "Accurate map" : "Map unavailable";
      if (cache.detail && cache.detail.mapBitmaps)
         cache.detail.mapBitmaps[mode] = null;
   }
   if (built)
      this.clearScaleMapRebuildPending();
   else
      this.markScaleMapRebuildPending(this.currentScaleMapLabel());
   aceDevelopmentConsoleWriteLine("[ACE] Scale map build timing | total=" + (Date.now() - start) + " ms" +
      " mode=" + mode +
      " reason=" + (reason || "request") +
      " source=draft-canvas" +
      " built=" + (built ? "yes" : "no"));
   return built;
};

AstroContrastEnhancerDialog.prototype.markScaleMapRebuildPending = function(label) {
   if (!this.currentViewNeedsScaleMaps())
      return;
   this.scaleMapRebuildPending = true;
   this.scaleMapRebuildViewMode = this.appState.preview.viewMode;
   this.scaleMapRebuildLabel = label || this.currentScaleMapLabel();
};

AstroContrastEnhancerDialog.prototype.clearScaleMapRebuildPending = function() {
   this.scaleMapRebuildPending = false;
   this.scaleMapRebuildViewMode = "";
   this.scaleMapRebuildLabel = "";
};

AstroContrastEnhancerDialog.prototype.invalidateScaleMapBitmaps = function() {
   if (!this.appState || !this.appState.cache)
      return;
   if (this.scaleMapRebuildPending && this.currentViewNeedsScaleMaps())
      return;
   this.appState.cache.mapBitmaps = null;
   if (this.appState.cache.detail)
      this.appState.cache.detail.mapBitmaps = null;
};

AstroContrastEnhancerDialog.prototype.updateInteractiveAdvancedScaleMap = function(label) {
   if (!this.currentViewNeedsScaleMaps() || this.appState.preview.viewMode === "delta")
      return false;
   var cache = this.appState.cache;
   if (!cache || !cache.draft || !cache.draft.rgb)
      return false;
   var baseRgb = cache.workingRgb ? cache.workingRgb : cache.draft.rgb;
   var sourceWidth = cache.draft.width;
   var sourceHeight = cache.draft.height;
   var mode = this.appState.preview.viewMode;
   var quickBitmap = aceBuildLightweightInteractiveScaleMapBitmap(sourceWidth, sourceHeight, baseRgb, this.appState.advanced, mode);
   if (!quickBitmap)
      return false;
   var quickMaps = {};
   quickMaps[mode] = quickBitmap;
   cache.mapBitmaps = aceMergeScaleMapBitmaps(cache.mapBitmaps, quickMaps);
   if (cache.detail && cache.detail.mapBitmaps)
      cache.detail.mapBitmaps[this.appState.preview.viewMode] = null;
   this.clearScaleMapRebuildPending();
   this.scaleMapDisplayQuality = "Quick low-res map";
   this.refreshPreviewStatus(this.describeLoadedSource(), "Quick low-res " + this.currentScaleMapLabel());
   this.refreshLocalSelectionControls();
   if (this.preview)
      this.preview.update();
   return true;
};

AstroContrastEnhancerDialog.prototype.ensureCurrentViewDiagnostics = function() {
   if (!this.currentViewNeedsScaleMaps() || !this.appState || !this.appState.cache)
      return;
   var cache = this.appState.cache;
   var mode = this.appState.preview.viewMode;
   if (cache.draft && cache.draft.rgb && (!cache.mapBitmaps || !cache.mapBitmaps[mode])) {
      cache.draft.currentRgb = cache.currentRgb || null;
      cache.mapBitmaps = aceMergeScaleMapBitmaps(cache.mapBitmaps, this.buildDisplayScaleMapBitmaps(cache.draft, mode, "ensure"));
      cache.draft.currentRgb = null;
      this.scaleMapDisplayQuality = "Accurate map";
      if (cache.detail && cache.detail.mapBitmaps)
         cache.detail.mapBitmaps[mode] = null;
   }
   if (cache.draft && cache.draft.rgb && cache.mapBitmaps)
      this.clearScaleMapRebuildPending();
};

AstroContrastEnhancerDialog.prototype.describeLoadedSource = function() {
   var source = this.appState.cache.source;
   if (!source || !source.viewId)
      return "No active image";
   return "Loaded: " + source.viewId + " | " + source.width + " x " + source.height + " | " + this.getZoomReadout();
};

AstroContrastEnhancerDialog.prototype.fitPreviewToView = function() {
   this.bumpDetailRefreshGeneration();
   this.clearPreviewGestureBitmap();
   this.clearDetailProtectedOverlay();
   this.committedDetailPreviewFrozen = false;
   this.appState.preview.zoomMode = "fit";
   this.appState.preview.zoomScale = 1;
   this.appState.preview.panX = 0;
   this.appState.preview.panY = 0;
   this.appState.cache.detail = null;
   this.appState.cache.detailTarget = null;
   this.detailPreviewPendingNavigation = false;
   this.detailPreviewPendingAdjustment = false;
   if (this.detailAdjustmentIdleTimer)
      this.detailAdjustmentIdleTimer.stop();
   if (this.detailRefreshTimer)
      this.detailRefreshTimer.stop();
   this.invalidateProtectedOverlay();
   this.refreshPreviewStatus(this.describeLoadedSource(), "Preview: draft");
   if (this.lowZoomLoupeShouldBeActive())
      this.scheduleLowZoomLoupeRefresh("Fit view | detail loupe queued");
   else
      this.clearLowZoomLoupe();
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.bumpDetailRefreshGeneration = function() {
   this.detailRefreshGeneration = (this.detailRefreshGeneration || 0) + 1;
};

AstroContrastEnhancerDialog.prototype.bumpLowZoomLoupeGeneration = function() {
   this.lowZoomLoupeGeneration = (this.lowZoomLoupeGeneration || 0) + 1;
};

AstroContrastEnhancerDialog.prototype.bumpEditGeneration = function() {
   this.editGeneration = (this.editGeneration || 0) + 1;
   this.bumpDetailRefreshGeneration();
   this.bumpLowZoomLoupeGeneration();
};

AstroContrastEnhancerDialog.prototype.bumpGeometryGeneration = function() {
   this.geometryGeneration = (this.geometryGeneration || 0) + 1;
   this.bumpDetailRefreshGeneration();
   this.bumpLowZoomLoupeGeneration();
};

AstroContrastEnhancerDialog.prototype.bumpCommitGeneration = function() {
   this.commitGeneration = (this.commitGeneration || 0) + 1;
   this.bumpDetailRefreshGeneration();
   this.bumpLowZoomLoupeGeneration();
};

AstroContrastEnhancerDialog.prototype.invalidateDetailForNavigation = function() {
   this.bumpDetailRefreshGeneration();
   this.stopPendingDetailRefreshes();
   this.detailRefreshTimerToken = null;
   this.detailAdjustmentTimerToken = null;
   this.detailWorkActive = false;
   this.detailWorkToken = null;
   this.detailPreviewPendingAdjustment = false;
   this.detailPreviewPendingNavigation = this.shouldUseDetailPreview();
   if (this.lowZoomLoupeShouldBeActive())
      this.scheduleLowZoomLoupeRefresh("Detail loupe queued");
   else
      this.clearLowZoomLoupe();
   this.appState.cache.detail = null;
   this.appState.cache.detailTarget = null;
   this.clearDetailProtectedOverlay();
};

AstroContrastEnhancerDialog.prototype.capturePreviewStateToken = function(reason) {
   return {
      reason: reason || "",
      detailGeneration: this.detailRefreshGeneration || 0,
      editGeneration: this.editGeneration || 0,
      geometryGeneration: this.geometryGeneration || 0,
      commitGeneration: this.commitGeneration || 0,
      lassoVersion: this.appState ? (this.appState.lassoVersion || 0) : 0,
      paramsKey: this.appState ? JSON.stringify(aceCopyParams(this.appState.params)) : "",
      previewMode: this.processingMode || "full",
      previewViewMode: this.appState && this.appState.preview ? (this.appState.preview.viewMode || "preview") : "preview",
      showBefore: !!(this.appState && this.appState.preview && this.appState.preview.showBefore),
      showMask: !!(this.appState && this.appState.preview && this.appState.preview.showMask),
      zoomMode: this.appState && this.appState.preview ? this.appState.preview.zoomMode : "fit",
      zoomScale: this.appState && this.appState.preview ? this.appState.preview.zoomScale : 1,
      panX: this.appState && this.appState.preview ? this.appState.preview.panX : 0,
      panY: this.appState && this.appState.preview ? this.appState.preview.panY : 0
   };
};

AstroContrastEnhancerDialog.prototype.previewStateTokenIsCurrent = function(token) {
   if (!token)
      return false;
   if ((this.detailRefreshGeneration || 0) !== token.detailGeneration)
      return false;
   if ((this.editGeneration || 0) !== token.editGeneration)
      return false;
   if ((this.geometryGeneration || 0) !== token.geometryGeneration)
      return false;
   if ((this.commitGeneration || 0) !== token.commitGeneration)
      return false;
   if (this.appState && (this.appState.lassoVersion || 0) !== token.lassoVersion)
      return false;
   if ((this.processingMode || "full") !== token.previewMode)
      return false;
   if (this.appState && this.appState.preview) {
      if ((this.appState.preview.viewMode || "preview") !== token.previewViewMode)
         return false;
      if (!!this.appState.preview.showMask !== token.showMask)
         return false;
      if (this.appState.preview.zoomMode !== token.zoomMode)
         return false;
      if (Math.abs((this.appState.preview.zoomScale || 1) - token.zoomScale) > 1.0e-6)
         return false;
      if (Math.abs((this.appState.preview.panX || 0) - token.panX) > 0.5)
         return false;
      if (Math.abs((this.appState.preview.panY || 0) - token.panY) > 0.5)
         return false;
   }
   if (!!(this.appState && this.appState.preview && this.appState.preview.showBefore) !== token.showBefore)
      return false;
   if (this.appState && JSON.stringify(aceCopyParams(this.appState.params)) !== token.paramsKey)
      return false;
   if (this.selectionTransitionBusy || this.lassoDrawing || this.lassoMoving || this.pendingLassoStatusText)
      return false;
   return true;
};

AstroContrastEnhancerDialog.prototype.discardStaleDetailWork = function(token, statusText) {
   if (this.previewStateTokenIsCurrent(token))
      return false;
   this.detailPreviewPendingNavigation = false;
   this.detailPreviewPendingAdjustment = false;
   this.detailWorkActive = false;
   this.detailWorkToken = null;
   if (statusText)
      this.refreshPreviewStatus(this.describeLoadedSource(), statusText);
   return true;
};

AstroContrastEnhancerDialog.prototype.lowZoomLoupeShouldBeActive = function() {
   if (!ACE_LOW_ZOOM_GLOBAL_LOUPE_ENABLED)
      return false;
   if (!this.lowZoomLoupeIsAvailable())
      return false;
   if (!this.lowZoomLoupeShiftDown)
      return false;
   return true;
};

AstroContrastEnhancerDialog.prototype.lowZoomLoupeIsAvailable = function() {
   if (!ACE_LOW_ZOOM_GLOBAL_LOUPE_ENABLED)
      return false;
   if (!this.lowZoomLoupeEnabled)
      return false;
   if (!this.appState || !this.appState.preview || !this.appState.cache || !this.appState.cache.source)
      return false;
   if (this.processingMode !== "full")
      return false;
   if (this.appState.preview.viewMode !== "preview" || this.appState.preview.showMask)
      return false;
   if (this.appState.preview.zoomMode === "fit")
      return true;
   return (this.appState.preview.zoomScale || 1) <= ACE_LOW_ZOOM_GLOBAL_LOUPE_MAX_ZOOM;
};

AstroContrastEnhancerDialog.prototype.setLowZoomLoupeShiftDown = function(active) {
   active = !!active;
   if (this.lowZoomLoupeShiftDown === active)
      return;
   this.lowZoomLoupeShiftDown = active;
   if (!active)
      this.lowZoomLoupeShowBefore = false;
   if (active && this.lowZoomLoupeShouldBeActive()) {
      if (this.lowZoomLoupeMouseValid)
         this.scheduleLowZoomLoupeRefresh("Detail loupe queued");
   } else
      this.clearLowZoomLoupe();
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.isLowZoomLoupeShiftEvent = function(key, modifiers) {
   return key === Key_Shift || (modifiers & KeyModifier_Shift) !== 0;
};

AstroContrastEnhancerDialog.prototype.isLowZoomLoupeToggleKey = function(key, modifiers) {
   var isC = key === Key_C || key === 0x43 || key === 0x63;
   var commandDown = (modifiers & KeyModifier_Control) !== 0 || (modifiers & KeyModifier_Meta) !== 0 || (modifiers & KeyModifier_Alt) !== 0;
   return isC && this.lowZoomLoupeShiftDown && !commandDown;
};

AstroContrastEnhancerDialog.prototype.toggleLowZoomLoupeBeforeAfter = function() {
   if (!this.lowZoomLoupeShouldBeActive())
      return false;
   this.lowZoomLoupeShowBefore = !this.lowZoomLoupeShowBefore;
   this.refreshPreviewStatus(this.describeLoadedSource(), this.lowZoomLoupeShowBefore ? "Loupe: Before" : "Loupe: After");
   if (this.preview)
      this.preview.update();
   return true;
};

AstroContrastEnhancerDialog.prototype.sourcePointForPreviewPosition = function(x, y) {
   var source = this.appState && this.appState.cache ? this.appState.cache.source : null;
   var draft = this.appState && this.appState.cache ? this.appState.cache.draft : null;
   if (!source || !draft || !this.preview || !source.width || !source.height)
      return null;
   var scale = this.appState.preview.zoomMode === "fit" ?
      aceGetFitScale(this.preview.width, this.preview.height, draft.width, draft.height) :
      Math.max(ACE_EPSILON, this.appState.preview.zoomScale || 1);
   var rect = aceGetViewportRectForScale(
      this.preview.width,
      this.preview.height,
      draft.width,
      draft.height,
      scale,
      this.appState.preview.zoomMode === "fit" ? 0 : this.appState.preview.panX,
      this.appState.preview.zoomMode === "fit" ? 0 : this.appState.preview.panY
   );
   if (!rect)
      return null;
   var dx = (x - rect.x0) / Math.max(ACE_EPSILON, scale);
   var dy = (y - rect.y0) / Math.max(ACE_EPSILON, scale);
   if (dx < 0 || dy < 0 || dx >= draft.width || dy >= draft.height)
      return null;
   return {
      x: aceClamp(dx * source.width / Math.max(1, draft.width), 0, source.width - 1),
      y: aceClamp(dy * source.height / Math.max(1, draft.height), 0, source.height - 1)
   };
};

AstroContrastEnhancerDialog.prototype.clearLowZoomLoupe = function() {
   if (this.lowZoomLoupeTimer)
      this.lowZoomLoupeTimer.stop();
   this.lowZoomLoupeTimerToken = null;
   this.lowZoomLoupePending = false;
   this.lowZoomLoupeActive = false;
   if (this.appState && this.appState.cache)
      this.appState.cache.lowZoomLoupe = null;
};

AstroContrastEnhancerDialog.prototype.captureLowZoomLoupeToken = function(reason) {
   var preview = this.appState && this.appState.preview ? this.appState.preview : null;
   return {
      reason: reason || "",
      lowZoomGeneration: this.lowZoomLoupeGeneration || 0,
      editGeneration: this.editGeneration || 0,
      geometryGeneration: this.geometryGeneration || 0,
      commitGeneration: this.commitGeneration || 0,
      paramsKey: this.appState ? JSON.stringify(aceCopyParams(this.appState.params)) : "",
      advancedKey: this.appState ? JSON.stringify(aceCopyAdvancedParams(this.appState.advanced)) : "",
      protectionKey: this.appState ? JSON.stringify(aceCopyProtectionOptions(this.getProtectionOptions())) : "",
      previewMode: this.processingMode || "full",
      viewMode: preview ? (preview.viewMode || "preview") : "preview",
      showMask: !!(preview && preview.showMask),
      zoomMode: preview ? preview.zoomMode : "fit",
      zoomScale: preview ? preview.zoomScale : 1,
      panX: preview ? preview.panX : 0,
      panY: preview ? preview.panY : 0,
      mouseValid: !!this.lowZoomLoupeMouseValid,
      mouseX: this.lowZoomLoupeMouseX || 0,
      mouseY: this.lowZoomLoupeMouseY || 0
   };
};

AstroContrastEnhancerDialog.prototype.lowZoomLoupeStateTokenIsCurrent = function(token) {
   if (!token)
      return false;
   if (!this.lowZoomLoupeShouldBeActive())
      return false;
   if ((this.lowZoomLoupeGeneration || 0) !== token.lowZoomGeneration)
      return false;
   if ((this.editGeneration || 0) !== token.editGeneration)
      return false;
   if ((this.geometryGeneration || 0) !== token.geometryGeneration)
      return false;
   if ((this.commitGeneration || 0) !== token.commitGeneration)
      return false;
   if ((this.processingMode || "full") !== token.previewMode)
      return false;
   var preview = this.appState.preview;
   if ((preview.viewMode || "preview") !== token.viewMode || !!preview.showMask !== token.showMask)
      return false;
   if (preview.zoomMode !== token.zoomMode)
      return false;
   if (Math.abs((preview.zoomScale || 1) - token.zoomScale) > 1.0e-6)
      return false;
   if (Math.abs((preview.panX || 0) - token.panX) > 0.5 || Math.abs((preview.panY || 0) - token.panY) > 0.5)
      return false;
   if (!!this.lowZoomLoupeMouseValid !== !!token.mouseValid)
      return false;
   if (token.mouseValid && (Math.abs((this.lowZoomLoupeMouseX || 0) - token.mouseX) > 0.5 || Math.abs((this.lowZoomLoupeMouseY || 0) - token.mouseY) > 0.5))
      return false;
   if (JSON.stringify(aceCopyParams(this.appState.params)) !== token.paramsKey)
      return false;
   if (JSON.stringify(aceCopyAdvancedParams(this.appState.advanced)) !== token.advancedKey)
      return false;
   if (JSON.stringify(aceCopyProtectionOptions(this.getProtectionOptions())) !== token.protectionKey)
      return false;
   if (this.outputRendering || this.targetImageLoading || this.selectionTransitionBusy || this.lassoDrawing || this.lassoMoving || this.pendingLassoStatusText)
      return false;
   return true;
};

AstroContrastEnhancerDialog.prototype.getLowZoomLoupeRequest = function() {
   var source = this.appState && this.appState.cache ? this.appState.cache.source : null;
   var draft = this.appState && this.appState.cache ? this.appState.cache.draft : null;
   if (!source || !draft || !source.width || !source.height)
      return null;
   var centerX = source.width * 0.5;
   var centerY = source.height * 0.5;
   if (this.lowZoomLoupeMouseValid) {
      var p = this.sourcePointForPreviewPosition(this.lowZoomLoupeMouseX, this.lowZoomLoupeMouseY);
      if (p) {
         centerX = p.x;
         centerY = p.y;
      } else
         return null;
   }
   else if (this.appState.preview.zoomMode !== "fit" && this.preview) {
      var draftRect = aceGetViewportRectForScale(
         this.preview.width,
         this.preview.height,
         draft.width,
         draft.height,
         this.appState.preview.zoomScale,
         this.appState.preview.panX,
         this.appState.preview.panY
      );
      if (draftRect) {
         var scale = Math.max(ACE_EPSILON, this.appState.preview.zoomScale || 1);
         var draftX = aceClamp((this.preview.width * 0.5 - draftRect.x0) / scale, 0, draft.width - 1);
         var draftY = aceClamp((this.preview.height * 0.5 - draftRect.y0) / scale, 0, draft.height - 1);
         centerX = draftX * source.width / Math.max(1, draft.width);
         centerY = draftY * source.height / Math.max(1, draft.height);
      }
   }
   var reqW = Math.min(source.width, ACE_LOW_ZOOM_GLOBAL_LOUPE_WIDTH);
   var reqH = Math.min(source.height, ACE_LOW_ZOOM_GLOBAL_LOUPE_HEIGHT);
   var x0 = aceClamp(Math.round(centerX - reqW * 0.5), 0, Math.max(0, source.width - reqW));
   var y0 = aceClamp(Math.round(centerY - reqH * 0.5), 0, Math.max(0, source.height - reqH));
   return { x0: x0, y0: y0, x1: x0 + reqW, y1: y0 + reqH, width: reqW, height: reqH };
};

AstroContrastEnhancerDialog.prototype.scheduleLowZoomLoupeRefresh = function(statusText) {
   if (!this.lowZoomLoupeShouldBeActive()) {
      this.clearLowZoomLoupe();
      return;
   }
   this.lowZoomLoupePending = true;
   this.lowZoomLoupeTimerToken = this.captureLowZoomLoupeToken("low-zoom-loupe");
   if (statusText)
      this.refreshPreviewStatus(this.describeLoadedSource(), statusText);
   if (this.lowZoomLoupeTimer) {
      this.lowZoomLoupeTimer.stop();
      this.lowZoomLoupeTimer.start();
   } else
      this.performLowZoomLoupeRefresh(this.lowZoomLoupeTimerToken);
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.performLowZoomLoupeRefresh = function(token) {
   token = token || this.lowZoomLoupeTimerToken || this.captureLowZoomLoupeToken("low-zoom-loupe");
   if (!this.lowZoomLoupeStateTokenIsCurrent(token))
      return;
   var req = this.getLowZoomLoupeRequest();
   if (!req)
      return;
   this.lowZoomLoupeActive = true;
   this.lowZoomLoupePending = true;
   try {
      var found = aceFindViewForViewId(this.appState.cache.source.viewId);
      if (!found || !found.view)
         return;
      var crop = aceReadRgbCropFromView(found.view, req);
      if (!this.lowZoomLoupeStateTokenIsCurrent(token))
         return;
      var sourceRgb = crop.rgb;
      var committedRgb = this.applyCommittedRecipeToDetailRgb(crop.width, crop.height, crop.rgb, crop.x0, crop.y0);
      var previewData = {
         width: crop.width,
         height: crop.height,
         rgb: committedRgb,
         scale: 1,
         layerCache: null
      };
      var processed = null;
      if (this.appState.params && this.appState.params.hasEffect && this.appState.params.hasEffect()) {
         var options = this.getProtectionOptions();
         options.fastFullResolutionStarMask = true;
         options.rgbOnlyOutput = true;
         processed = this.appState.processor.processPreview(previewData, this.appState.params, options, this.appState.advanced, null, "Low zoom loupe");
      }
      if (!this.lowZoomLoupeStateTokenIsCurrent(token))
         return;
      var currentRgb = processed && processed.rgb ? processed.rgb : committedRgb;
      this.appState.cache.lowZoomLoupe = {
         x0: crop.x0,
         y0: crop.y0,
         width: crop.width,
         height: crop.height,
         beforeBitmap: aceRenderBitmapFromRgb(crop.width, crop.height, committedRgb),
         afterBitmap: aceRenderBitmapFromRgb(crop.width, crop.height, currentRgb),
         stateKey: token.paramsKey,
         status: "ready"
      };
      this.lowZoomLoupePending = false;
      this.refreshPreviewStatus(this.describeLoadedSource(), "Detail loupe updated");
      if (this.preview)
         this.preview.update();
   } finally {
      this.lowZoomLoupeActive = false;
   }
};

AstroContrastEnhancerDialog.prototype.stopPendingDetailRefreshes = function() {
   if (this.detailAdjustmentIdleTimer)
      this.detailAdjustmentIdleTimer.stop();
   if (this.detailRefreshTimer)
      this.detailRefreshTimer.stop();
};

AstroContrastEnhancerDialog.prototype.clearDetailPreviewState = function() {
   if (!this.appState || !this.appState.cache)
      return;
   this.bumpDetailRefreshGeneration();
   this.stopPendingDetailRefreshes();
   this.appState.cache.detail = null;
   this.appState.cache.detailTarget = null;
   this.detailPreviewPendingNavigation = false;
   this.detailPreviewPendingAdjustment = false;
   this.clearDetailProtectedOverlay();
};

AstroContrastEnhancerDialog.prototype.resetPreviewInteractionStateKeepDetail = function() {
   if (this.previewHoldTimer)
      this.previewHoldTimer.stop();
   if (this.deferredLassoUpdateTimer)
      this.deferredLassoUpdateTimer.stop();
   if (this.interactivePreviewTimer)
      this.interactivePreviewTimer.stop();
   this.clearLowZoomLoupe();
   this.clearPreviewGestureBitmap();
   this.pendingLassoStatusText = "";
   this.pendingLassoAutoFocus = false;
   this.pendingInteractivePreviewLabel = "";
   this.pendingInteractivePreviewStatus = "";
   this.pendingInteractivePreviewInvalidateAdvanced = false;
   this.selectionTransitionBusy = false;
   this.selectionTransitionReason = "";
   this.beforeAfterComparisonActive = false;
   this.beforeAfterShortcutDown = false;
   this.previewMouseDown = false;
   this.previewDragging = false;
   this.previewCanPanFromPress = false;
   this.previewCompareArmed = false;
   this.previewMomentaryBefore = false;
   this.lassoDrawing = false;
   this.lassoMoving = false;
   this.lassoHoverInside = false;
   this.lassoDragOperation = "none";
   this.lassoDrawPoints = [];
   this.lassoMoveStartPoint = null;
   this.lassoMoveOriginalPoints = [];
   this.lastLassoMovePreviewUpdateMs = 0;
   this.previewCursorShape = null;
   if (this.appState && this.appState.preview)
      this.appState.preview.showBefore = false;
   if (this.beforeAfterPill)
      this.beforeAfterPill.setActive(false);
};

AstroContrastEnhancerDialog.prototype.resetPreviewInteractionState = function(clearDetail) {
   if (this.previewHoldTimer)
      this.previewHoldTimer.stop();
   if (this.deferredLassoUpdateTimer)
      this.deferredLassoUpdateTimer.stop();
   if (this.interactivePreviewTimer)
      this.interactivePreviewTimer.stop();
   this.clearLowZoomLoupe();
   this.clearPreviewGestureBitmap();
   this.stopPendingDetailRefreshes();
   this.bumpDetailRefreshGeneration();
   this.pendingLassoStatusText = "";
   this.pendingLassoAutoFocus = false;
   this.pendingInteractivePreviewLabel = "";
   this.pendingInteractivePreviewStatus = "";
   this.pendingInteractivePreviewInvalidateAdvanced = false;
   this.selectionTransitionBusy = false;
   this.selectionTransitionReason = "";
   this.detailWorkActive = false;
   this.detailWorkToken = null;
   this.detailRefreshTimerToken = null;
   this.detailAdjustmentTimerToken = null;
   this.detailPreviewRefreshAfterActiveWork = false;
   this.detailAdjustmentRefreshAfterActiveWork = false;
   this.deferredEffectChangesDuringDetail = null;
   this.deferredEffectChangeDuringDetail = null;
   this.beforeAfterComparisonActive = false;
   this.beforeAfterShortcutDown = false;
   this.previewMouseDown = false;
   this.previewDragging = false;
   this.previewCanPanFromPress = false;
   this.previewCompareArmed = false;
   this.previewMomentaryBefore = false;
   this.lassoDrawing = false;
   this.lassoMoving = false;
   this.lassoHoverInside = false;
   this.lassoDragOperation = "none";
   this.lassoDrawPoints = [];
   this.lassoMoveStartPoint = null;
   this.lassoMoveOriginalPoints = [];
   this.lastLassoMovePreviewUpdateMs = 0;
   this.previewCursorShape = null;
   this.detailPreviewPendingNavigation = false;
   this.detailPreviewPendingAdjustment = false;
   if (this.appState && this.appState.preview)
      this.appState.preview.showBefore = false;
   if (clearDetail && this.appState && this.appState.cache) {
      this.appState.cache.detail = null;
      this.appState.cache.detailTarget = null;
      this.clearDetailProtectedOverlay();
   }
};

AstroContrastEnhancerDialog.prototype.scheduleDetailPreviewRefresh = function() {
   if (this.selectionTransitionBusy || this.lassoDrawing || this.lassoMoving || this.pendingLassoStatusText)
      return;
   if (!this.shouldUseDetailPreview())
      return;
   if (this.detailWorkActive) {
      this.detailPreviewRefreshAfterActiveWork = true;
      this.detailPreviewPendingNavigation = true;
      return;
   }
   this.detailRefreshTimerGeneration = this.detailRefreshGeneration || 0;
   this.detailRefreshTimerToken = this.capturePreviewStateToken("detail-timer");
   if (this.detailRefreshTimer) {
      this.detailRefreshTimer.stop();
      this.detailRefreshTimer.start();
   } else {
      this.refreshDetailPreviewIfNeeded(false);
   }
};

AstroContrastEnhancerDialog.prototype.schedulePendingDetailAdjustmentRefresh = function() {
   if (!this.detailPreviewPendingAdjustment || !this.shouldUseDetailPreview())
      return;
   this.detailAdjustmentTimerGeneration = this.detailRefreshGeneration || 0;
   this.detailAdjustmentTimerToken = this.capturePreviewStateToken("detail-adjustment-timer");
   if (this.detailAdjustmentIdleTimer) {
      this.detailAdjustmentIdleTimer.stop();
      this.detailAdjustmentIdleTimer.start();
   } else {
      this.performPendingDetailAdjustmentRefresh("idle");
   }
};

AstroContrastEnhancerDialog.prototype.performPendingDetailAdjustmentRefresh = function(reason) {
   if (this.outputRendering || this.targetImageLoading)
      return;
   if (this.selectionTransitionBusy || this.lassoDrawing || this.lassoMoving || this.pendingLassoStatusText)
      return;
   if (!this.detailPreviewPendingAdjustment || !this.shouldUseDetailPreview())
      return;
   if (this.previewDragging || this.detailPreviewPendingNavigation)
      return;
   if (this.detailWorkActive) {
      this.detailAdjustmentRefreshAfterActiveWork = true;
      this.detailPreviewPendingAdjustment = true;
      return;
   }
   this.setPendingPreviewStage("Processing detail...");
   this.refreshDetailPreviewIfNeeded(false);
   this.refreshPreviewStatus(
      this.describeLoadedSource(),
      this.appState.cache.detail ? "Preview: detail crop" : "Preview: draft"
   );
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.detailProcessedStateIsCurrent = function() {
   if (!this.shouldUseDetailPreview() || !this.appState || !this.appState.cache)
      return false;
   var existingDetail = this.appState.cache.detail;
   var existingTarget = existingDetail ? (existingDetail.computeTarget || existingDetail) : (this.appState.cache.detailTarget || null);
   return !!(existingTarget && existingTarget.processedRgb && existingTarget.processedStateKey === this.detailProcessingStateKey());
};

AstroContrastEnhancerDialog.prototype.clearCommittedDetailPreview = function() {
   this.committedDetailPreviewFrozen = false;
};

AstroContrastEnhancerDialog.prototype.prepareForZoomNavigation = function() {
   if (!this.appState || !this.appState.cache)
      return;
   this.exitBeforeAfterForEditChange();
   this.clearPreviewGestureBitmap();
   if (this.interactivePreviewTimer)
      this.interactivePreviewTimer.stop();
   if (this.pendingInteractivePreviewLabel)
      this.performQueuedInteractivePreview();
   this.bumpDetailRefreshGeneration();
   this.stopPendingDetailRefreshes();
   this.detailRefreshTimerToken = null;
   this.detailAdjustmentTimerToken = null;
   this.detailWorkActive = false;
   this.detailWorkToken = null;
   this.detailPreviewPendingNavigation = false;
   this.detailPreviewPendingAdjustment = false;
   this.appState.cache.detail = null;
   this.appState.cache.detailTarget = null;
   this.clearDetailProtectedOverlay();
};

AstroContrastEnhancerDialog.prototype.applyCommittedRecipeToDetailRgb = function(width, height, rgb, sourceX0, sourceY0) {
   var recipe = this.appState.editRecipe || [];
   if (!recipe.length)
      return rgb;
   var output = new Float32Array(rgb);
   var cropRect = {
      x0: sourceX0 || 0,
      y0: sourceY0 || 0,
      x1: (sourceX0 || 0) + width,
      y1: (sourceY0 || 0) + height
   };
   for (var i = 0; i < recipe.length; ++i) {
      var edit = recipe[i];
      if (!edit || edit.type !== "lasso" || !edit.params || !EffectParameters.prototype.hasEffect.call(edit.params))
         continue;
      if (!edit.lassoPoints || edit.lassoPoints.length < 3)
         continue;
      var editBounds = aceLassoBounds(edit.lassoPoints, this.appState.cache.source.width, this.appState.cache.source.height, edit.feather || 0);
      if (editBounds.x1 <= cropRect.x0 || editBounds.x0 >= cropRect.x1 || editBounds.y1 <= cropRect.y0 || editBounds.y0 >= cropRect.y1)
         continue;
      var lassoWeight = aceBuildLassoWeightMap(
         width,
         height,
         sourceX0 || 0,
         sourceY0 || 0,
         1,
         1,
         edit.lassoPoints,
         edit.feather || 0,
         !!edit.inverted
      );
      output = this.applyFullResolutionOperation(width, height, output, edit.params, edit.protection, lassoWeight, edit.advanced, null, "Detail committed edit");
   }
   return output;
};

AstroContrastEnhancerDialog.prototype.setZoomScale = function(scale) {
   this.clearCommittedDetailPreview();
   this.prepareForZoomNavigation();
   this.appState.preview.zoomMode = "manual";
   this.appState.preview.zoomScale = aceClamp(scale, 0.25, ACE_MAX_PREVIEW_ZOOM);
   this.clampPan();
   this.detailPreviewPendingNavigation = this.shouldUseDetailPreview();
   this.detailPreviewPendingAdjustment = false;
   if (this.shouldUseDetailPreview() && this.processingMode === "lasso" && this.appState.params && this.appState.params.hasEffect())
      this.refreshDetailPreviewIfNeeded(true);
   else
      this.scheduleDetailPreviewRefresh();
   if (this.lowZoomLoupeShouldBeActive()) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "Preview: draft | detail loupe queued");
      this.scheduleLowZoomLoupeRefresh("Preview: draft | detail loupe queued");
   } else {
      this.clearLowZoomLoupe();
      this.refreshPreviewStatus(this.describeLoadedSource(), this.shouldUseDetailPreview() ? "Draft shown | detail queued" : "Preview: draft");
   }
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.setZoomScaleCentered = function(scale) {
   this.clearCommittedDetailPreview();
   this.prepareForZoomNavigation();
   var draft = this.appState.cache.draft;
   if (!draft || !this.preview)
      return this.setZoomScale(scale);
   var oldScale = this.appState.preview.zoomMode === "fit" ?
      aceGetFitScale(this.preview.width, this.preview.height, draft.width, draft.height) :
      this.appState.preview.zoomScale;
   var centerX = (draft.width * oldScale * 0.5 - this.appState.preview.panX) / Math.max(ACE_EPSILON, oldScale);
   var centerY = (draft.height * oldScale * 0.5 - this.appState.preview.panY) / Math.max(ACE_EPSILON, oldScale);
   var nextScale = aceClamp(scale, 0.25, ACE_MAX_PREVIEW_ZOOM);
   this.appState.preview.zoomMode = "manual";
   this.appState.preview.zoomScale = nextScale;
   this.appState.preview.panX = draft.width * nextScale * 0.5 - centerX * nextScale;
   this.appState.preview.panY = draft.height * nextScale * 0.5 - centerY * nextScale;
   this.clampPan();
   this.detailPreviewPendingNavigation = this.shouldUseDetailPreview();
   this.detailPreviewPendingAdjustment = false;
   if (this.shouldUseDetailPreview() && this.processingMode === "lasso" && this.appState.params && this.appState.params.hasEffect())
      this.refreshDetailPreviewIfNeeded(true);
   else
      this.scheduleDetailPreviewRefresh();
   if (this.lowZoomLoupeShouldBeActive()) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "Preview: draft | detail loupe queued");
      this.scheduleLowZoomLoupeRefresh("Preview: draft | detail loupe queued");
   } else {
      this.clearLowZoomLoupe();
      this.refreshPreviewStatus(this.describeLoadedSource(), this.shouldUseDetailPreview() ? "Draft shown | detail queued" : "Preview: draft");
   }
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.getProtectionOptions = function() {
   this.syncProtectionFamilyControls();
   var starsActive = this.inputType === "stars" && this.protectStars && this.protectStars.checked;
   return {
      protectSky: !this.protectSky || this.protectSky.checked,
      preventDark: !this.preventDark || this.preventDark.checked,
      inputType: this.inputType || "starless",
      protectStars: starsActive,
      protectHalos: starsActive && (!this.protectHalos || this.protectHalos.checked),
      advanced: aceCopyAdvancedParams(this.appState ? this.appState.advanced : null)
   };
};

AstroContrastEnhancerDialog.prototype.shouldShowProtectedOverlay = function() {
   return this.processingMode === "lasso" &&
      this.appState.preview.viewMode === "preview" &&
      !this.appState.preview.showMask &&
      !this.appState.preview.showBefore &&
      !this.previewMomentaryBefore &&
      this.hasLassoSelection() &&
      !this.featherAdjusting &&
      !this.selectionTransitionBusy &&
      !this.lassoDrawing &&
      !this.lassoMoving &&
      !this.outputRendering &&
      (!this.protectedOverlayCheck || this.protectedOverlayCheck.checked);
};

AstroContrastEnhancerDialog.prototype.getProtectedOverlaySettings = function() {
   var item = this.protectedOverlayIntensity ? this.protectedOverlayIntensity.currentItem : 1;
   if (item === 0)
      return { frost: 0.24, hatch: 0.20, spacing: 16 };
   if (item === 2)
      return { frost: 0.42, hatch: 0.32, spacing: 12 };
   return { frost: ACE_PROTECTED_OVERLAY_STRENGTH, hatch: ACE_PROTECTED_HATCH_STRENGTH, spacing: ACE_PROTECTED_HATCH_SPACING };
};

AstroContrastEnhancerDialog.prototype.getProtectedOverlayBitmap = function(sourceBitmap) {
   var cache = this.appState.cache;
   if (!sourceBitmap || !cache.draft || !cache.currentRgb)
      return null;
   var target = cache.draft;
   var rgb = cache.currentRgb;
   var overlayCache = cache;
   var overlayKeyPrefix = "draft";
   if (cache.pendingDisplayBitmap && sourceBitmap === cache.pendingDisplayBitmap && cache.pendingDisplayRgb) {
      rgb = cache.pendingDisplayRgb;
      overlayKeyPrefix = "pending-display";
   }
   if (this.shouldUseDetailPreview() && cache.detail && sourceBitmap === cache.detail.currentBitmap) {
      if (this.detailPreviewPendingAdjustment || this.pendingInteractivePreviewLabel || this.interactiveSliderDrag)
         return null;
      target = cache.detail;
      rgb = cache.detail.currentRgb || cache.detail.rgb;
      overlayCache = cache.detail;
      overlayKeyPrefix = "detail:" + (cache.detail.x0 || 0) + ":" + (cache.detail.y0 || 0) + ":" + cache.detail.width + "x" + cache.detail.height;
   }
   if (!target || !rgb)
      return null;
   var lassoWeight = this.getLassoWeightForTarget(target);
   if (!lassoWeight)
      return null;
   var key = [
      overlayKeyPrefix,
      this.appState.lassoVersion,
      this.appState.lassoInverted ? 1 : 0,
      this.featherSlider ? this.featherSlider.value : ACE_FEATHER_DEFAULT,
      this.appState.params.texture,
      this.appState.params.clarity,
      this.appState.params.dehaze,
      aceNormalizeClarityMode(this.appState.params.clarityMode),
      cache.pendingActive ? 1 : 0,
      this.featherAdjusting ? 1 : 0,
      this.protectedOverlayIntensity ? this.protectedOverlayIntensity.currentItem : 1,
      cache.workingBitmap === sourceBitmap ? "working" : "current"
   ].join(":");
   if (overlayCache.protectedOverlayBitmap && overlayCache.protectedOverlaySourceBitmap === sourceBitmap && overlayCache.protectedOverlayLassoKey === key)
      return overlayCache.protectedOverlayBitmap;
   var width = target.width;
   var height = target.height;
   var count = width * height;
   var output = new Float32Array(rgb.length);
   var overlaySettings = this.getProtectedOverlaySettings();
   var strength = overlaySettings.frost;
   var hatchSpacing = Math.max(6, overlaySettings.spacing);
   var hatchWidth = Math.max(1, ACE_PROTECTED_HATCH_WIDTH);
   for (var y = 0; y < height; ++y) {
      for (var x = 0; x < width; ++x) {
         var i = y * width + x;
         var protectedWeight = aceClamp01(1 - lassoWeight[i]);
         var mix = strength * protectedWeight;
         var base = i * 3;
         output[base] = aceClamp01(rgb[base] * (1 - mix) + 0.22 * mix);
         output[base + 1] = aceClamp01(rgb[base + 1] * (1 - mix) + 0.27 * mix);
         output[base + 2] = aceClamp01(rgb[base + 2] * (1 - mix) + 0.35 * mix);
         if (protectedWeight > 0.18) {
            var hatchA = (x + y) % hatchSpacing;
            var hatchB = (x - y + height * hatchSpacing) % hatchSpacing;
            if (hatchA < hatchWidth || hatchB < hatchWidth) {
               var hatchMix = overlaySettings.hatch * aceSmoothStep(0.18, 0.75, protectedWeight);
               output[base] = aceClamp01(output[base] * (1 - hatchMix) + 0.72 * hatchMix);
               output[base + 1] = aceClamp01(output[base + 1] * (1 - hatchMix) + 0.76 * hatchMix);
               output[base + 2] = aceClamp01(output[base + 2] * (1 - hatchMix) + 0.82 * hatchMix);
            }
         }
         if (this.featherAdjusting) {
            var featherBand = aceClamp01(1 - Math.abs(lassoWeight[i] * 2 - 1));
            var featherMix = ACE_FEATHER_OVERLAY_STRENGTH * featherBand;
            output[base] = aceClamp01(output[base] * (1 - featherMix) + 0.95 * featherMix);
            output[base + 1] = aceClamp01(output[base + 1] * (1 - featherMix) + 0.70 * featherMix);
            output[base + 2] = aceClamp01(output[base + 2] * (1 - featherMix) + 0.18 * featherMix);
         }
      }
   }
   overlayCache.protectedOverlayBitmap = aceRenderBitmapFromRgb(width, height, output);
   overlayCache.protectedOverlaySourceBitmap = sourceBitmap;
   overlayCache.protectedOverlayLassoKey = key;
   return overlayCache.protectedOverlayBitmap;
};

AstroContrastEnhancerDialog.prototype.drawProtectedOverlayLayer = function(g, bitmap) {
   if (!g || !bitmap || !this.shouldShowProtectedOverlay())
      return;
   if (this.overlaySuppressedUntilMs && Date.now() < this.overlaySuppressedUntilMs)
      return;
   var draftBitmap = this.isDetailBitmap(bitmap) ? this.getDraftPreviewBitmapForCurrentMode() : bitmap;
   if (!draftBitmap)
      return;
   var rect = this.isDetailBitmap(bitmap) ? (this.previewDisplayRect || this.getCurrentViewportRect(draftBitmap)) : this.getCurrentViewportRect(bitmap);
   if (!rect)
      return;
   var x0 = Math.max(1, Math.round(rect.x0));
   var y0 = Math.max(1, Math.round(rect.y0));
   var x1 = Math.min(this.preview.width - 1, Math.round(rect.x1));
   var y1 = Math.min(this.preview.height - 1, Math.round(rect.y1));
   if (x1 <= x0 || y1 <= y0)
      return;
   var points = this.appState.lassoPoints || [];
   if (points.length < 3)
      return;
   var screenPoints = [];
   for (var p = 0; p < points.length; ++p) {
      var sp = this.previewPointFromSource(points[p], draftBitmap);
      if (sp)
         screenPoints.push(sp);
   }
   if (screenPoints.length < 3)
      return;
   var settings = this.getProtectedOverlaySettings();
   var hatchAlpha = aceClamp(settings.hatch * 1.15, 0.14, 0.42);
   var hatchA = Math.round(hatchAlpha * 255);
   var hatchColor = (hatchA << 24) | 0xd8e0ee;
   var spacing = Math.max(8, Math.round(settings.spacing));
   var width = x1 - x0;
   var height = y1 - y0;
   var inverted = !!this.appState.lassoInverted;
   var isProtectedScreenPoint = function(px, py) {
      var inside = acePointInPolygon(px, py, screenPoints);
      return inverted ? inside : !inside;
   };
   var segment = Math.max(6, Math.round(spacing * 0.72));
   var half = segment * 0.5;
   var drawProtectedStroke = function(cx, cy, dir) {
      if (cx < x0 || cx > x1 || cy < y0 || cy > y1)
         return;
      if (!isProtectedScreenPoint(cx, cy))
         return;
      var dx = dir;
      var dy = 1;
      var norm = Math.sqrt(dx * dx + dy * dy);
      dx = dx / norm * half;
      dy = dy / norm * half;
      var ax = aceClamp(cx - dx, x0, x1);
      var ay = aceClamp(cy - dy, y0, y1);
      var bx = aceClamp(cx + dx, x0, x1);
      var by = aceClamp(cy + dy, y0, y1);
      g.drawLine(Math.round(ax), Math.round(ay), Math.round(bx), Math.round(by));
   };
   g.pen = new Pen(hatchColor, Math.max(1, ACE_PROTECTED_HATCH_WIDTH));
   var margin = spacing;
   for (var yy = y0 - margin; yy <= y1 + margin; yy += spacing) {
      for (var xx = x0 - margin; xx <= x1 + margin; xx += spacing) {
         drawProtectedStroke(xx, yy, 1);
         drawProtectedStroke(xx + spacing * 0.5, yy + spacing * 0.5, -1);
      }
   }
};

AstroContrastEnhancerDialog.prototype.hasLassoSelection = function() {
   return !!(this.appState &&
      this.appState.lassoPoints &&
      this.appState.lassoPoints.length >= 3 &&
      aceLassoGeometryInfo(this.appState.lassoPoints).valid);
};

AstroContrastEnhancerDialog.prototype.invalidateLassoMasks = function() {
   var cache = this.appState.cache;
   cache.lassoMaskBitmap = null;
   cache.lassoMaskKey = "";
   cache.localBoundedDraftCache = null;
   cache.localBoundedDraftCacheKey = "";
   this.invalidateProtectedOverlay();
   if (cache.draft) {
      cache.draft.lassoMask = null;
      cache.draft.lassoMaskKey = "";
   }
   if (cache.detail) {
      cache.detail.lassoMaskBitmap = null;
      cache.detail.lassoMask = null;
      cache.detail.lassoMaskKey = "";
   }
};

AstroContrastEnhancerDialog.prototype.invalidateProtectedOverlay = function() {
   if (!this.appState || !this.appState.cache)
      return;
   this.appState.cache.protectedOverlayBitmap = null;
   this.appState.cache.protectedOverlaySourceBitmap = null;
   this.appState.cache.protectedOverlayLassoKey = "";
   if (this.appState.cache.detail) {
      this.appState.cache.detail.protectedOverlayBitmap = null;
      this.appState.cache.detail.protectedOverlaySourceBitmap = null;
      this.appState.cache.detail.protectedOverlayLassoKey = "";
   }
};

AstroContrastEnhancerDialog.prototype.beginLassoGeometryTransition = function(reason) {
   if (!this.appState || !this.appState.cache)
      return;
   this.selectionTransitionBusy = true;
   this.selectionTransitionReason = reason || "lasso geometry";
   this.selectionTransitionGeneration = (this.selectionTransitionGeneration || 0) + 1;
   this.bumpGeometryGeneration();
   this.exitBeforeAfterForEditChange();
   if (this.deferredLassoUpdateTimer)
      this.deferredLassoUpdateTimer.stop();
   if (this.interactivePreviewTimer)
      this.interactivePreviewTimer.stop();
   this.pendingInteractivePreviewLabel = "";
   this.pendingInteractivePreviewStatus = "";
   this.pendingInteractivePreviewInvalidateAdvanced = false;
   this.clearNativeDetailForLassoGeometryChange();
   this.clearPendingLocalPreview(true);
   this.invalidateLassoMasks();
};

AstroContrastEnhancerDialog.prototype.endLassoGeometryTransition = function() {
   this.selectionTransitionBusy = false;
   this.selectionTransitionReason = "";
};

AstroContrastEnhancerDialog.prototype.markLassoGeometryDirty = function() {
   if (!this.appState || !this.appState.cache)
      return;
   this.invalidateLassoMasks();
   this.clearNativeDetailForLassoGeometryChange();
   this.clearPendingLocalPreview(true);
};

AstroContrastEnhancerDialog.prototype.clearDetailProtectedOverlay = function() {
   if (!this.appState || !this.appState.cache || !this.appState.cache.detail)
      return;
   this.appState.cache.detail.protectedOverlayBitmap = null;
   this.appState.cache.detail.protectedOverlaySourceBitmap = null;
   this.appState.cache.detail.protectedOverlayLassoKey = "";
   this.appState.cache.detail.localBeforeBitmap = null;
};

AstroContrastEnhancerDialog.prototype.clearNativeDetailForLassoGeometryChange = function() {
   if (!this.appState || !this.appState.cache)
      return;
   this.bumpDetailRefreshGeneration();
   if (this.detailRefreshTimer)
      this.detailRefreshTimer.stop();
   if (this.detailAdjustmentIdleTimer)
      this.detailAdjustmentIdleTimer.stop();
   this.detailPreviewPendingNavigation = false;
   this.detailPreviewPendingAdjustment = false;
   this.appState.cache.detail = null;
   this.appState.cache.detailTarget = null;
   this.invalidateProtectedOverlay();
};

AstroContrastEnhancerDialog.prototype.canStartLassoShapeAction = function(actionLabel) {
   if (!this.hasLassoSelection()) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "Draw a lasso selection first");
      return false;
   }
   if (this.selectionTransitionBusy || this.pendingLassoStatusText || this.lassoDrawing || this.lassoMoving) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "Finish selection update before " + (actionLabel || "shape change"));
      return false;
   }
   if (this.detailPreviewPendingNavigation || this.detailPreviewPendingAdjustment || this.detailWorkActive) {
      this.stopPendingDetailRefreshes();
      this.detailRefreshTimerToken = null;
      this.detailAdjustmentTimerToken = null;
      this.detailWorkActive = false;
      this.detailWorkToken = null;
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      this.appState.cache.detail = null;
      this.appState.cache.detailTarget = null;
      this.refreshPreviewStatus(this.describeLoadedSource(), "Native detail canceled for " + (actionLabel || "shape change"));
   }
   return true;
};

AstroContrastEnhancerDialog.prototype.getLassoWeightForTarget = function(target) {
   if (!target || !target.rgb)
      return null;
   if (this.processingMode !== "lasso")
      return null;
   var feather = this.featherSlider ? this.featherSlider.value : ACE_FEATHER_DEFAULT;
   var source = this.appState.cache.source;
   var hasSelection = this.hasLassoSelection();
   var key = [
      this.appState.lassoVersion,
      feather,
      this.appState.lassoInverted ? 1 : 0,
      hasSelection ? 1 : 0,
      target.x0 || 0,
      target.y0 || 0,
      target.width,
      target.height
   ].join(":");
   if (target.lassoMaskKey === key && target.lassoMask)
      return target.lassoMask;
   var sourceX0 = target.x0 || 0;
   var sourceY0 = target.y0 || 0;
   var stepX = target.x0 !== undefined ? 1 : source.width / Math.max(1, target.width);
   var stepY = target.y0 !== undefined ? 1 : source.height / Math.max(1, target.height);
   target.lassoMask = aceBuildLassoWeightMap(
      target.width,
      target.height,
      sourceX0,
      sourceY0,
      stepX,
      stepY,
      hasSelection ? this.appState.lassoPoints : [],
      feather,
      this.appState.lassoInverted
   );
   target.lassoMaskKey = key;
   return target.lassoMask;
};

AstroContrastEnhancerDialog.prototype.applyLassoWeightToOptions = function(target, options) {
   options = options || {};
   options.lassoAllowedWeight = this.getLassoWeightForTarget(target);
   return options;
};

AstroContrastEnhancerDialog.prototype.updateMaskBitmapFromAllowedWeight = function(target, width, height, allowedWeight) {
   if (!target)
      return;
   if (!allowedWeight) {
      var count = width * height;
      allowedWeight = new Float32Array(count);
      for (var i = 0; i < count; ++i)
         allowedWeight[i] = 1;
   }
   target.maskBitmap = aceRenderBitmapFromGray(width, height, allowedWeight);
   target.allowedMaskBitmap = target.maskBitmap;
};

AstroContrastEnhancerDialog.prototype.updateLassoMaskBitmapFromWeight = function(target, width, height, lassoWeight) {
   if (!target)
      return;
   if (!lassoWeight)
      lassoWeight = new Float32Array(width * height);
   target.lassoMaskBitmap = aceRenderBitmapFromGray(width, height, lassoWeight);
};

AstroContrastEnhancerDialog.prototype.combineAllowedWeights = function(width, height, backgroundAllowed, starAllowed, lassoAllowed) {
   var count = width * height;
   var combined = new Float32Array(count);
   for (var i = 0; i < count; ++i) {
      var b = backgroundAllowed ? backgroundAllowed[i] : 1;
      var s = starAllowed ? starAllowed[i] : 1;
      var l = lassoAllowed ? lassoAllowed[i] : 1;
      combined[i] = aceClamp01(b * s * l);
   }
   return combined;
};

AstroContrastEnhancerDialog.prototype.blendRgbThroughLasso = function(baseRgb, processedRgb, lassoWeight) {
   if (!baseRgb || !processedRgb || !lassoWeight)
      return processedRgb;
   var count = lassoWeight.length;
   var output = new Float32Array(processedRgb.length);
   for (var i = 0; i < count; ++i) {
      var w = aceClamp01(lassoWeight[i]);
      var base = i * 3;
      output[base] = baseRgb[base] * (1 - w) + processedRgb[base] * w;
      output[base + 1] = baseRgb[base + 1] * (1 - w) + processedRgb[base + 1] * w;
      output[base + 2] = baseRgb[base + 2] * (1 - w) + processedRgb[base + 2] * w;
   }
   return output;
};

AstroContrastEnhancerDialog.prototype.lassoWeightIsRestrictive = function(lassoWeight) {
   var stats = this.lassoWeightStats(lassoWeight);
   if (!stats.valid)
      return false;
   return stats.maxValue > 0.01 &&
      stats.minValue < 0.999 &&
      stats.mean > 0.0001 &&
      stats.mean < 0.9999;
};

AstroContrastEnhancerDialog.prototype.lassoWeightStats = function(lassoWeight) {
   if (!lassoWeight || lassoWeight.length < 1)
      return { valid: false, minValue: 1, maxValue: 0, mean: 0 };
   var minValue = 1;
   var maxValue = 0;
   var sum = 0;
   for (var i = 0; i < lassoWeight.length; ++i) {
      var w = aceClamp01(lassoWeight[i]);
      minValue = Math.min(minValue, w);
      maxValue = Math.max(maxValue, w);
      sum += w;
   }
   var mean = sum / Math.max(1, lassoWeight.length);
   return { valid: true, minValue: minValue, maxValue: maxValue, mean: mean };
};

AstroContrastEnhancerDialog.prototype.localLassoDraftEditReady = function() {
   return !!(this.processingMode === "lasso" &&
      this.hasLassoSelection() &&
      this.appState &&
      this.appState.params &&
      this.appState.params.hasEffect() &&
      this.appState.cache &&
      this.appState.cache.pendingActive &&
      this.appState.cache.pendingRgb);
};

AstroContrastEnhancerDialog.prototype.canSettleLassoAsOutlineOnly = function() {
   return !!(this.processingMode === "lasso" &&
      this.hasLassoSelection() &&
      this.appState &&
      this.appState.params &&
      !this.appState.params.hasEffect() &&
      this.appState.preview &&
      this.appState.preview.viewMode === "preview" &&
      !this.appState.preview.showMask);
};

AstroContrastEnhancerDialog.prototype.reportLocalLassoDraftFailure = function(label) {
   if (this.processingMode !== "lasso" || !this.hasLassoSelection() || !this.appState.params.hasEffect())
      return;
   var cache = this.appState.cache;
   var lassoWeight = cache && cache.draft ? this.getLassoWeightForTarget(cache.draft) : null;
   var stats = this.lassoWeightStats(lassoWeight);
   var reason = !stats.valid ? "no lasso mask" :
      (!this.lassoWeightIsRestrictive(lassoWeight) ?
         ("mask rejected min=" + aceValidationNumber(stats.minValue, 5) +
          " max=" + aceValidationNumber(stats.maxValue, 5) +
          " mean=" + aceValidationNumber(stats.mean, 5)) :
         "processor produced no pending lasso result");
   this.refreshPreviewStatus(this.describeLoadedSource(), (label || "Local edit") + " did not update draft | " + reason);
   aceDevelopmentConsoleWriteLine("[ACE] Local lasso draft missing | label=" + (label || "Local edit") +
      " pendingActive=" + (cache && cache.pendingActive ? "yes" : "no") +
      " pendingRgb=" + (cache && cache.pendingRgb ? "yes" : "no") +
      " hasSelection=" + (this.hasLassoSelection() ? "yes" : "no") +
      " hasEffect=" + (this.appState.params.hasEffect() ? "yes" : "no") +
      " reason=" + reason);
};

AstroContrastEnhancerDialog.prototype.localDraftDeltaSummary = function(beforeRgb, afterRgb) {
   if (!beforeRgb || !afterRgb || beforeRgb.length !== afterRgb.length)
      return "delta=unavailable";
   var length = beforeRgb.length;
   var stride = Math.max(3, Math.floor(length / 240000));
   stride -= stride % 3;
   if (stride < 3)
      stride = 3;
   var samples = 0;
   var sumAbs = 0;
   var maxAbs = 0;
   var above002 = 0;
   var above005 = 0;
   for (var i = 0; i < length; i += stride) {
      var d0 = Math.abs(afterRgb[i] - beforeRgb[i]);
      var d1 = i + 1 < length ? Math.abs(afterRgb[i + 1] - beforeRgb[i + 1]) : 0;
      var d2 = i + 2 < length ? Math.abs(afterRgb[i + 2] - beforeRgb[i + 2]) : 0;
      var d = Math.max(d0, d1, d2);
      sumAbs += (d0 + d1 + d2) / 3;
      maxAbs = Math.max(maxAbs, d);
      if (d > 0.002)
         ++above002;
      if (d > 0.005)
         ++above005;
      ++samples;
   }
   return "meanAbs=" + aceValidationNumber(sumAbs / Math.max(1, samples), 6) +
      " maxAbs=" + aceValidationNumber(maxAbs, 6) +
      " pct_gt_0p002=" + aceValidationNumber(100 * above002 / Math.max(1, samples), 3) + "%" +
      " pct_gt_0p005=" + aceValidationNumber(100 * above005 / Math.max(1, samples), 3) + "%";
};

AstroContrastEnhancerDialog.prototype.localDraftDisplayGain = function() {
   var cache = this.appState ? this.appState.cache : null;
   if (!cache || !cache.source || !cache.draft || !cache.source.width || !cache.draft.width)
      return 1;
   var scaleX = cache.source.width / Math.max(1, cache.draft.width);
   var scaleY = cache.source.height / Math.max(1, cache.draft.height);
   var sourceToDraft = Math.max(1, Math.min(scaleX, scaleY));
   return aceClamp(sourceToDraft * ACE_LOCAL_DRAFT_DISPLAY_GAIN_SCALE,
      ACE_LOCAL_DRAFT_DISPLAY_GAIN_MIN,
      ACE_LOCAL_DRAFT_DISPLAY_GAIN_MAX);
};

AstroContrastEnhancerDialog.prototype.buildLocalDraftDisplayRgb = function(baseRgb, finalRgb, lassoWeight) {
   if (!baseRgb || !finalRgb || baseRgb.length !== finalRgb.length)
      return null;
   var gain = this.localDraftDisplayGain();
   if (gain <= 1.02)
      return null;
   var out = new Float32Array(finalRgb.length);
   var pixelCount = Math.floor(finalRgb.length / 3);
   for (var i = 0; i < pixelCount; ++i) {
      var w = lassoWeight && i < lassoWeight.length ? aceClamp01(lassoWeight[i]) : 1;
      var g = 1 + (gain - 1) * w;
      var j = i * 3;
      out[j] = aceClamp01(baseRgb[j] + (finalRgb[j] - baseRgb[j]) * g);
      out[j + 1] = aceClamp01(baseRgb[j + 1] + (finalRgb[j + 1] - baseRgb[j + 1]) * g);
      out[j + 2] = aceClamp01(baseRgb[j + 2] + (finalRgb[j + 2] - baseRgb[j + 2]) * g);
   }
   return out;
};

AstroContrastEnhancerDialog.prototype.buildLocalDisplayAllowedWeight = function(target, processed, lassoWeight) {
   if (!target)
      return lassoWeight || null;
   var options = this.getProtectionOptions();
   var backgroundAllowed = options.protectSky && target.layerCache ? target.layerCache.allowedWeight : null;
   var starAllowed = processed && processed.starAllowedWeight ? processed.starAllowedWeight : null;
   if (!starAllowed && target.starProtectionMaps)
      starAllowed = target.starProtectionMaps.allowedWeight;
   if (!backgroundAllowed && !starAllowed)
      return lassoWeight || null;
   return this.combineAllowedWeights(target.width, target.height, backgroundAllowed, starAllowed, lassoWeight);
};

AstroContrastEnhancerDialog.prototype.buildProtectedLocalDraftDisplayRgb = function(baseRgb, finalRgb, lassoWeight, allowedWeight) {
   if (!baseRgb || !finalRgb || baseRgb.length !== finalRgb.length)
      return null;
   if (!allowedWeight)
      return this.buildLocalDraftDisplayRgb(baseRgb, finalRgb, lassoWeight);
   var gain = this.localDraftDisplayGain();
   if (gain <= 1.02)
      return null;
   var out = new Float32Array(finalRgb.length);
   var pixelCount = Math.floor(finalRgb.length / 3);
   for (var i = 0; i < pixelCount; ++i) {
      var selectionWeight = lassoWeight && i < lassoWeight.length ? aceClamp01(lassoWeight[i]) : 1;
      var allowed = i < allowedWeight.length ? aceClamp01(allowedWeight[i]) : selectionWeight;
      var displayWeight = Math.min(selectionWeight, allowed);
      var g = 1 + (gain - 1) * displayWeight;
      var j = i * 3;
      out[j] = aceClamp01(baseRgb[j] + (finalRgb[j] - baseRgb[j]) * g);
      out[j + 1] = aceClamp01(baseRgb[j + 1] + (finalRgb[j + 1] - baseRgb[j + 1]) * g);
      out[j + 2] = aceClamp01(baseRgb[j + 2] + (finalRgb[j + 2] - baseRgb[j + 2]) * g);
   }
   return out;
};

AstroContrastEnhancerDialog.prototype.sampleRgbBilinear = function(width, height, rgb, x, y, channel) {
   if (!rgb || width < 1 || height < 1)
      return 0;
   x = aceClamp(x, 0, Math.max(0, width - 1));
   y = aceClamp(y, 0, Math.max(0, height - 1));
   var x0 = Math.floor(x);
   var y0 = Math.floor(y);
   var x1 = Math.min(width - 1, x0 + 1);
   var y1 = Math.min(height - 1, y0 + 1);
   var fx = x - x0;
   var fy = y - y0;
   var c = channel || 0;
   var i00 = (y0 * width + x0) * 3 + c;
   var i10 = (y0 * width + x1) * 3 + c;
   var i01 = (y1 * width + x0) * 3 + c;
   var i11 = (y1 * width + x1) * 3 + c;
   var top = rgb[i00] * (1 - fx) + rgb[i10] * fx;
   var bottom = rgb[i01] * (1 - fx) + rgb[i11] * fx;
   return top * (1 - fy) + bottom * fy;
};

AstroContrastEnhancerDialog.prototype.buildSourceInformedLocalDraftDisplayRgb = function(baseRgb, fallbackRgb, lassoWeight) {
   var cache = this.appState ? this.appState.cache : null;
   if (!cache || !cache.sourceRgb || !cache.source || !cache.draft || !baseRgb || !fallbackRgb)
      return null;
   if (!this.hasLassoSelection() || !this.appState.params.hasEffect())
      return null;
   if (this.appState.params.texture === 0 && this.appState.params.clarity === 0)
      return null;
   var source = cache.source;
   var draft = cache.draft;
   var feather = this.featherSlider ? this.featherSlider.value : ACE_FEATHER_DEFAULT;
   var advanced = aceCopyAdvancedParams(this.appState.advanced);
   var maxRadius = Math.max(
      this.appState.params.texture !== 0 ? ACE_TEXTURE_RADIUS * aceAdvancedFactor(advanced, "textureScale") : 0,
      this.appState.params.clarity !== 0 ? ACE_CLARITY_RADIUS * aceAdvancedFactor(advanced, "clarityScale") : 0,
      this.appState.params.dehaze !== 0 ? ACE_DEHAZE_VEIL_RADIUS * aceAdvancedFactor(advanced, "dehazeVeilSize") : 0
   );
   var rect = aceLassoBounds(this.appState.lassoPoints, source.width, source.height, feather + maxRadius + 12);
   if (rect.x1 <= rect.x0 || rect.y1 <= rect.y0)
      return null;
   var region = aceExtractRgbRect(source.width, source.height, cache.sourceRgb, rect);
   if (!region || !region.rgb)
      return null;
   var regionBase = this.applyCommittedRecipeToDetailRgb(region.width, region.height, region.rgb, rect.x0, rect.y0);
   var proxy = aceDownsampleRgbAntialias(regionBase, region.width, region.height, ACE_LOCAL_DRAFT_SOURCE_PROXY_MAX_EDGE);
   proxy.x0 = rect.x0;
   proxy.y0 = rect.y0;
   proxy.sourceWidth = region.width;
   proxy.sourceHeight = region.height;
   var stepX = region.width / Math.max(1, proxy.width);
   var stepY = region.height / Math.max(1, proxy.height);
   var proxyLasso = aceBuildLassoWeightMap(
      proxy.width,
      proxy.height,
      rect.x0,
      rect.y0,
      stepX,
      stepY,
      this.appState.lassoPoints,
      feather,
      this.appState.lassoInverted
   );
   var proxyProtection = aceCopyProtectionOptions(this.getProtectionOptions());
   proxyProtection.lassoAllowedWeight = proxyLasso;
   proxyProtection.layerCacheRequirements = aceLayerCacheRequirementsForParams(this.appState.params);
   var proxyTiming = { items: [] };
   var proxyStart = Date.now();
   var processed = this.appState.processor.processPreview(proxy, this.appState.params, proxyProtection, this.appState.advanced, proxyTiming, "Selection source proxy");
   if (!processed || !processed.rgb)
      return null;
   var out = new Float32Array(fallbackRgb);
   var sourceToDraftX = draft.width / Math.max(1, source.width);
   var sourceToDraftY = draft.height / Math.max(1, source.height);
   var dx0 = aceClamp(Math.floor(rect.x0 * sourceToDraftX), 0, draft.width - 1);
   var dy0 = aceClamp(Math.floor(rect.y0 * sourceToDraftY), 0, draft.height - 1);
   var dx1 = aceClamp(Math.ceil(rect.x1 * sourceToDraftX), dx0 + 1, draft.width);
   var dy1 = aceClamp(Math.ceil(rect.y1 * sourceToDraftY), dy0 + 1, draft.height);
   for (var y = dy0; y < dy1; ++y) {
      if ((y & 15) === 0)
         aceYieldToPixInsight();
      var sourceY = (y + 0.5) / Math.max(ACE_EPSILON, sourceToDraftY);
      var py = (sourceY - rect.y0) / Math.max(ACE_EPSILON, stepY) - 0.5;
      var draftRow = y * draft.width;
      for (var x = dx0; x < dx1; ++x) {
         var di = draftRow + x;
         var w = lassoWeight && di < lassoWeight.length ? aceClamp01(lassoWeight[di]) : 1;
         if (w <= 0.002)
            continue;
         var sourceX = (x + 0.5) / Math.max(ACE_EPSILON, sourceToDraftX);
         var px = (sourceX - rect.x0) / Math.max(ACE_EPSILON, stepX) - 0.5;
         var base = di * 3;
         out[base] = aceClamp01(baseRgb[base] + (this.sampleRgbBilinear(proxy.width, proxy.height, processed.rgb, px, py, 0) - baseRgb[base]) * w);
         out[base + 1] = aceClamp01(baseRgb[base + 1] + (this.sampleRgbBilinear(proxy.width, proxy.height, processed.rgb, px, py, 1) - baseRgb[base + 1]) * w);
         out[base + 2] = aceClamp01(baseRgb[base + 2] + (this.sampleRgbBilinear(proxy.width, proxy.height, processed.rgb, px, py, 2) - baseRgb[base + 2]) * w);
      }
   }
   function mapProxyGrayToDraft(proxyGray, defaultValue) {
      if (!proxyGray)
         return null;
      var mapped = new Float32Array(draft.width * draft.height);
      for (var mi = 0; mi < mapped.length; ++mi)
         mapped[mi] = defaultValue;
      for (var my = dy0; my < dy1; ++my) {
         var sourceY2 = (my + 0.5) / Math.max(ACE_EPSILON, sourceToDraftY);
         var py2 = (sourceY2 - rect.y0) / Math.max(ACE_EPSILON, stepY) - 0.5;
         var y0p = aceClamp(Math.floor(py2), 0, proxy.height - 1);
         var draftRow2 = my * draft.width;
         for (var mx = dx0; mx < dx1; ++mx) {
            var sourceX2 = (mx + 0.5) / Math.max(ACE_EPSILON, sourceToDraftX);
            var px2 = (sourceX2 - rect.x0) / Math.max(ACE_EPSILON, stepX) - 0.5;
            var x0p = aceClamp(Math.floor(px2), 0, proxy.width - 1);
            mapped[draftRow2 + mx] = proxyGray[y0p * proxy.width + x0p];
         }
      }
      return mapped;
   }
   cache.pendingDisplayProxy = "source-proxy " + proxy.width + "x" + proxy.height + " rect=" + region.width + "x" + region.height + " ms=" + (Date.now() - proxyStart);
   aceDevelopmentConsoleWriteLine("[ACE] Local draft source proxy | total=" + (Date.now() - proxyStart) + " ms" +
      " sourceRect=" + region.width + "x" + region.height +
      " proxy=" + proxy.width + "x" + proxy.height +
      " draftRect=" + (dx1 - dx0) + "x" + (dy1 - dy0) +
      " texture=" + this.appState.params.texture +
      " clarity=" + this.appState.params.clarity +
      " dehaze=" + this.appState.params.dehaze +
      " | " + aceTimingSummary(proxyTiming, 8));
   return {
      rgb: out,
      allowedWeight: mapProxyGrayToDraft(processed.allowedWeight, 1),
      starProtectionMask: mapProxyGrayToDraft(processed.starProtectionMask, 0),
      starAllowedWeight: mapProxyGrayToDraft(processed.starAllowedWeight, 1)
   };
};

AstroContrastEnhancerDialog.prototype.localDraftProcessingMargin = function() {
   var advanced = aceCopyAdvancedParams(this.appState ? this.appState.advanced : null);
   var radius = 0;
   if (this.appState && this.appState.params) {
      if (this.appState.params.texture !== 0)
         radius = Math.max(radius, ACE_TEXTURE_RADIUS * aceAdvancedFactor(advanced, "textureScale"));
      if (this.appState.params.clarity !== 0)
         radius = Math.max(radius, ACE_CLARITY_RADIUS * aceAdvancedFactor(advanced, "clarityScale"));
      if (this.appState.params.dehaze !== 0)
         radius = Math.max(radius, ACE_DEHAZE_VEIL_RADIUS * aceAdvancedFactor(advanced, "dehazeVeilSize"));
   }
   var source = this.appState && this.appState.cache ? this.appState.cache.source : null;
   var draft = this.appState && this.appState.cache ? this.appState.cache.draft : null;
   var sourceToDraft = source && draft ? Math.min(draft.width / Math.max(1, source.width), draft.height / Math.max(1, source.height)) : 1;
   var feather = this.featherSlider ? this.featherSlider.value : ACE_FEATHER_DEFAULT;
   return Math.max(8, Math.ceil((radius + feather + 18) * sourceToDraft));
};

AstroContrastEnhancerDialog.prototype.draftRectFromLassoWeight = function(lassoWeight, width, height, margin) {
   if (!lassoWeight || width < 1 || height < 1)
      return null;
   var x0 = width;
   var y0 = height;
   var x1 = -1;
   var y1 = -1;
   for (var y = 0; y < height; ++y) {
      var row = y * width;
      for (var x = 0; x < width; ++x) {
         if (lassoWeight[row + x] > 0.001) {
            if (x < x0) x0 = x;
            if (x > x1) x1 = x;
            if (y < y0) y0 = y;
            if (y > y1) y1 = y;
         }
      }
   }
   if (x1 < x0 || y1 < y0)
      return null;
   margin = Math.max(0, Math.ceil(margin || 0));
   return {
      x0: aceClamp(x0 - margin, 0, width - 1),
      y0: aceClamp(y0 - margin, 0, height - 1),
      x1: aceClamp(x1 + margin + 1, x0 + 1, width),
      y1: aceClamp(y1 + margin + 1, y0 + 1, height)
   };
};

AstroContrastEnhancerDialog.prototype.boundedLocalDraftCacheKey = function(rect, baseRgb) {
   var protection = this.getProtectionOptions();
   return [
      this.appState.cache.source.version || 0,
      this.appState.lassoVersion || 0,
      this.appState.lassoInverted ? 1 : 0,
      this.featherSlider ? this.featherSlider.value : ACE_FEATHER_DEFAULT,
      rect.x0, rect.y0, rect.x1, rect.y1,
      protection.inputType || "stars",
      protection.protectSky !== false ? 1 : 0,
      protection.preventDark !== false ? 1 : 0,
      protection.protectStars !== false ? 1 : 0,
      protection.protectHalos !== false ? 1 : 0,
      aceAdvancedKey(this.appState.advanced),
      baseRgb === this.appState.cache.workingRgb ? "working" : "draft"
   ].join(":");
};

AstroContrastEnhancerDialog.prototype.getBoundedLocalDraftTarget = function(baseRgb, lassoWeight, rect, timing) {
   var cache = this.appState.cache;
   var draft = cache.draft;
   var key = this.boundedLocalDraftCacheKey(rect, baseRgb);
   var cached = cache.localBoundedDraftCache;
   if (cached &&
       cache.localBoundedDraftCacheKey === key &&
       cached.baseRgbRef === baseRgb &&
       cached.previewData &&
       cached.lassoWeight) {
      acePerfMark(timing, "Selection bounded draft cache hit", Date.now());
      return cached;
   }
   var stage = Date.now();
   var regionRgb = aceExtractRgbRect(draft.width, draft.height, baseRgb, rect).rgb;
   acePerfMark(timing, "Selection bounded draft extract", stage);
   stage = Date.now();
   var regionLasso = aceCropGrayBuffer(lassoWeight, draft.width, draft.height, rect.x0, rect.y0, rect.x1 - rect.x0, rect.y1 - rect.y0);
   var previewData = {
      width: rect.x1 - rect.x0,
      height: rect.y1 - rect.y0,
      rgb: regionRgb,
      scale: draft.scale,
      layerCache: null,
      starProtectionBase: null,
      starProtectionMaps: null,
      starProtectionKey: ""
   };
   cached = {
      key: key,
      baseRgbRef: baseRgb,
      rect: rect,
      previewData: previewData,
      lassoWeight: regionLasso
   };
   cache.localBoundedDraftCache = cached;
   cache.localBoundedDraftCacheKey = key;
   acePerfMark(timing, "Selection bounded draft setup", stage);
   return cached;
};

AstroContrastEnhancerDialog.prototype.buildBoundedLocalDraftPreview = function(baseRgb, baseBitmap, lassoWeight, options, timing) {
   var cache = this.appState.cache;
   var draft = cache.draft;
   if (!draft || !baseRgb || !lassoWeight || !this.appState.params.hasEffect())
      return null;
   if (this.currentViewNeedsScaleMaps() || this.appState.preview.showMask || this.appState.preview.viewMode !== "preview")
      return null;
   var rect = this.draftRectFromLassoWeight(lassoWeight, draft.width, draft.height, this.localDraftProcessingMargin());
   if (!rect || rect.x1 <= rect.x0 || rect.y1 <= rect.y0)
      return null;
   var fullPixels = draft.width * draft.height;
   var regionPixels = (rect.x1 - rect.x0) * (rect.y1 - rect.y0);
   if (regionPixels >= fullPixels * 0.78)
      return null;
   var boundedTarget = this.getBoundedLocalDraftTarget(baseRgb, lassoWeight, rect, timing);
   if (!boundedTarget || !boundedTarget.previewData || !boundedTarget.lassoWeight)
      return null;
   var stage = Date.now();
   var regionTarget = boundedTarget.previewData;
   var regionOptions = aceCopyProtectionOptions(options);
   regionOptions.lassoAllowedWeight = boundedTarget.lassoWeight;
   regionOptions.layerCacheRequirements = aceLayerCacheRequirementsForParams(this.appState.params);
   var regionTiming = { items: [] };
   var processedRegion = this.appState.processor.processPreview(regionTarget, this.appState.params, regionOptions, this.appState.advanced, regionTiming, "Selection bounded draft");
   acePerfMark(timing, "Selection bounded draft process " + regionTarget.width + "x" + regionTarget.height, stage);
   if (!processedRegion || !processedRegion.rgb)
      return null;
   for (var ti = 0; ti < regionTiming.items.length; ++ti)
      if (timing && timing.items)
         timing.items.push(regionTiming.items[ti]);
   stage = Date.now();
   var finalRgb = new Float32Array(baseRgb);
   aceWriteRgbRect(draft.width, draft.height, finalRgb, rect, processedRegion.rgb);
   var allowedWeight = processedRegion.allowedWeight ? aceFilledGray(draft.width, draft.height, 1) : null;
   if (allowedWeight)
      aceWriteGrayRect(draft.width, draft.height, allowedWeight, rect, processedRegion.allowedWeight);
   var starMask = processedRegion.starProtectionMask ? aceFilledGray(draft.width, draft.height, 0) : null;
   if (starMask)
      aceWriteGrayRect(draft.width, draft.height, starMask, rect, processedRegion.starProtectionMask);
   var starAllowed = processedRegion.starAllowedWeight ? aceFilledGray(draft.width, draft.height, 1) : null;
   if (starAllowed)
      aceWriteGrayRect(draft.width, draft.height, starAllowed, rect, processedRegion.starAllowedWeight);
   acePerfMark(timing, "Selection bounded draft composite", stage);
   stage = Date.now();
   var finalBitmap = aceRenderBitmapFromRgb(draft.width, draft.height, finalRgb);
   acePerfMark(timing, "Selection bounded draft bitmap", stage);
   return {
      width: draft.width,
      height: draft.height,
      rgb: finalRgb,
      bitmap: finalBitmap,
      allowedWeight: allowedWeight,
      starProtectionMask: starMask,
      starAllowedWeight: starAllowed,
      boundedRect: rect,
      boundedRegionPixels: regionPixels,
      boundedFullPixels: fullPixels
   };
};

AstroContrastEnhancerDialog.prototype.refreshCompletedLocalDraftDisplay = function(label) {
   if (!this.localLassoDraftEditReady())
      return;
   this.appState.preview.showBefore = false;
   if (this.beforeAfterPill)
      this.beforeAfterPill.setActive(false);
   this.invalidateProtectedOverlay();
   this.refreshPreviewStatus(this.describeLoadedSource(), (label || "Local edit") + " draft updated");
   var lassoStats = this.lassoWeightStats(this.getLassoWeightForTarget(this.appState.cache.draft));
   var baseRgb = this.appState.cache.workingRgb || this.appState.cache.draft.rgb;
   var displayDelta = this.appState.cache.pendingDisplayRgb ?
      " displayDelta(" + this.localDraftDeltaSummary(baseRgb, this.appState.cache.pendingDisplayRgb) + ")" :
      "";
   aceDevelopmentConsoleWriteLine("[ACE] Local draft display state | label=" + (label || "Local edit") +
      " pendingActive=yes" +
      " zoom=" + this.getZoomReadout() +
      " view=" + this.appState.preview.viewMode +
      " display=pending-draft" +
      " displayGain=" + aceValidationNumber(this.appState.cache.pendingDisplayGain || 1, 3) +
      " proxy=" + (this.appState.cache.pendingDisplayProxy || "none") +
      " lassoMean=" + aceValidationNumber(lassoStats.mean || 0, 5) +
      " lassoMin=" + aceValidationNumber(lassoStats.minValue || 0, 5) +
      " lassoMax=" + aceValidationNumber(lassoStats.maxValue || 0, 5) +
      " pendingDelta(" + this.localDraftDeltaSummary(baseRgb, this.appState.cache.pendingRgb) + ")" +
      displayDelta);
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.updateStarMaskBitmapFromProtection = function(target, width, height, protectionMask) {
   if (!target)
      return;
   if (!protectionMask)
      protectionMask = new Float32Array(width * height);
   target.starMaskBitmap = aceRenderBitmapFromGray(width, height, protectionMask);
};

AstroContrastEnhancerDialog.prototype.detailPreviewNeedsMaskBitmaps = function() {
   if (!this.appState || !this.appState.preview)
      return false;
   if (this.appState.preview.showMask)
      return true;
   var mode = this.appState.preview.viewMode || "preview";
   return mode === "star" || mode === "allowed" || mode === "lasso" || mode === "mask";
};

AstroContrastEnhancerDialog.prototype.rebuildProcessedDraftPreview = function() {
   var cache = this.appState.cache;
   if (!cache.draft || !cache.draft.rgb)
      return;
   var baseRgb = cache.workingRgb ? cache.workingRgb : cache.draft.rgb;
   var baseBitmap = cache.workingBitmap ? cache.workingBitmap : cache.draftBitmap;
   var target = cache.draft;
   var originalRgb = target.rgb;
   var originalLayerCache = target.layerCache;
   var usingWorkingBase = baseRgb !== cache.draft.rgb;
   if (usingWorkingBase) {
      target.rgb = baseRgb;
      target.layerCache = cache.workingLayerCache;
   }
   var updateScaleMaps = this.currentViewNeedsScaleMaps();
   var options = this.applyLassoWeightToOptions(cache.draft, this.getProtectionOptions());
   var lassoWeight = options.lassoAllowedWeight || null;
   var lassoEditRequested = this.processingMode === "lasso" && this.hasLassoSelection();
   var pendingStateKey = lassoEditRequested ? this.localDraftProcessingStateKey() : "";
   var lassoWeightValid = !lassoEditRequested || this.lassoWeightIsRestrictive(lassoWeight);
   var interactiveMapOnly = this.interactiveSliderDrag && updateScaleMaps && this.appState.preview.viewMode !== "delta";
   if (interactiveMapOnly) {
      this.updateInteractiveAdvancedScaleMap("Advanced");
      if (usingWorkingBase) {
         cache.draft.rgb = originalRgb;
         cache.draft.layerCache = originalLayerCache;
      }
      this.refreshLocalSelectionControls();
      return;
   }
   if (!this.appState.params.hasEffect()) {
      cache.currentBitmap = baseBitmap;
      cache.currentRgb = baseRgb;
      cache.pendingBitmap = null;
      cache.pendingRgb = null;
      cache.pendingDisplayRgb = null;
      cache.pendingDisplayBitmap = null;
      cache.pendingDisplayGain = 1;
      cache.pendingDisplayProxy = "";
      cache.pendingActive = false;
      cache.pendingDraftStateKey = "";
      this.invalidateProtectedOverlay();
      var plainPreviewOnly = this.appState.preview.viewMode === "preview" &&
         !this.appState.preview.showMask &&
         !updateScaleMaps;
      if (plainPreviewOnly) {
         cache.lassoMaskBitmap = null;
         cache.starMaskBitmap = null;
         cache.maskBitmap = null;
         cache.allowedMaskBitmap = null;
         if (usingWorkingBase) {
            cache.draft.rgb = originalRgb;
            cache.draft.layerCache = originalLayerCache;
         }
         this.refreshLocalSelectionControls();
         return;
      }
      if (!target.layerCache)
         target.layerCache = this.appState.processor.engine.buildLayerCache(target.width, target.height, target.rgb, this.appState.advanced, null, null, target.scale, aceLayerCacheRequirementsForParams(this.appState.params));
      if (usingWorkingBase)
         cache.workingLayerCache = target.layerCache;
      else
         cache.draftLayerCache = target.layerCache;
      var starMaps = this.appState.processor.getStarProtectionMaps(cache.draft, options);
      if (updateScaleMaps) {
         cache.mapBitmaps = aceMergeScaleMapBitmaps(cache.mapBitmaps, this.appState.processor.buildScaleMapBitmaps(cache.draft, this.appState.params, baseRgb, this.appState.advanced, this.appState.preview.viewMode));
         this.scaleMapDisplayQuality = "Accurate draft map";
         this.clearScaleMapRebuildPending();
      }
      this.updateLassoMaskBitmapFromWeight(cache, cache.draft.width, cache.draft.height, lassoWeight);
      this.updateStarMaskBitmapFromProtection(cache, cache.draft.width, cache.draft.height, starMaps ? starMaps.protectionMask : null);
      if (options.protectSky && cache.draft.layerCache && cache.draft.layerCache.allowedWeight)
         this.updateMaskBitmapFromAllowedWeight(cache, cache.draft.width, cache.draft.height, this.combineAllowedWeights(cache.draft.width, cache.draft.height, cache.draft.layerCache.allowedWeight, starMaps ? starMaps.allowedWeight : null, lassoWeight));
      else
         this.updateMaskBitmapFromAllowedWeight(cache, cache.draft.width, cache.draft.height, this.combineAllowedWeights(cache.draft.width, cache.draft.height, null, starMaps ? starMaps.allowedWeight : null, lassoWeight));
      if (usingWorkingBase) {
         cache.draft.rgb = originalRgb;
         cache.draft.layerCache = originalLayerCache;
      }
      this.refreshLocalSelectionControls();
      return;
   }
   if (this.appState.params.hasEffect() && lassoEditRequested && !lassoWeightValid) {
      cache.currentBitmap = baseBitmap;
      cache.currentRgb = baseRgb;
      cache.pendingBitmap = null;
      cache.pendingRgb = null;
      cache.pendingDisplayRgb = null;
      cache.pendingDisplayBitmap = null;
      cache.pendingDisplayGain = 1;
      cache.pendingDisplayProxy = "";
      cache.pendingActive = false;
      cache.pendingDraftStateKey = "";
      this.invalidateProtectedOverlay();
      if (usingWorkingBase) {
         cache.draft.rgb = originalRgb;
         cache.draft.layerCache = originalLayerCache;
      }
      this.refreshPreviewStatus(this.describeLoadedSource(), "Selection mask invalid - local edit blocked");
      this.refreshLocalSelectionControls();
      return;
   }
   cache.draft.layerCache = cache.draft.layerCache || (usingWorkingBase ? cache.workingLayerCache : cache.draftLayerCache);
   var requireFaithfulLocalDisplay = this.localPreviewRequiresFaithfulDisplay();
   var useBoundedLocalDraft = lassoEditRequested &&
      lassoWeightValid &&
      !updateScaleMaps &&
      this.appState.preview.viewMode === "preview" &&
      !this.appState.preview.showMask;
   var useLocalSourceProxyPrimary = lassoEditRequested &&
      lassoWeightValid &&
      !updateScaleMaps &&
      !requireFaithfulLocalDisplay &&
      (this.appState.params.texture !== 0 || this.appState.params.clarity !== 0);
   cache.pendingDisplayProxy = "";
   var sourceProxyResult = useLocalSourceProxyPrimary ?
      this.buildSourceInformedLocalDraftDisplayRgb(baseRgb, baseRgb, lassoWeight) : null;
   var sourceProxyRgb = sourceProxyResult && sourceProxyResult.rgb ? sourceProxyResult.rgb : null;
   var sourceProxyBitmap = sourceProxyRgb ? aceRenderBitmapFromRgb(cache.draft.width, cache.draft.height, sourceProxyRgb) : null;
   var processed = null;
   if (sourceProxyRgb) {
      processed = {
         width: cache.draft.width,
         height: cache.draft.height,
         rgb: sourceProxyRgb,
         bitmap: sourceProxyBitmap,
         allowedWeight: sourceProxyResult.allowedWeight || null,
         starProtectionMask: sourceProxyResult.starProtectionMask || null,
         starAllowedWeight: sourceProxyResult.starAllowedWeight || null
      };
   } else {
      var draftPreviewTiming = (this.processingMode === "lasso" || this.hasLassoSelection()) ? { items: [] } : null;
      var draftPreviewStart = draftPreviewTiming ? Date.now() : 0;
      processed = useBoundedLocalDraft ?
         this.buildBoundedLocalDraftPreview(baseRgb, baseBitmap, lassoWeight, options, draftPreviewTiming) :
         null;
      if (!processed)
         processed = this.appState.processor.processPreview(cache.draft, this.appState.params, options, this.appState.advanced, draftPreviewTiming, this.processingMode === "lasso" ? "Selection draft" : "Draft preview");
      if (draftPreviewTiming && Date.now() - draftPreviewStart >= ACE_DETAIL_TIMING_LOG_THRESHOLD_MS) {
         aceDevelopmentConsoleWriteLine("[ACE] Selection draft timing | total=" + (Date.now() - draftPreviewStart) + " ms" +
            " draft=" + cache.draft.width + "x" + cache.draft.height +
            (processed && processed.boundedRect ? (" bounded=" + (processed.boundedRect.x1 - processed.boundedRect.x0) + "x" + (processed.boundedRect.y1 - processed.boundedRect.y0)) : "") +
            " mode=" + this.processingMode +
            " lasso=" + (this.hasLassoSelection() ? "yes" : "no") +
            " texture=" + this.appState.params.texture +
            " clarity=" + this.appState.params.clarity +
            " dehaze=" + this.appState.params.dehaze +
            " | " + aceTimingSummary(draftPreviewTiming, 12));
      }
   }
   if (usingWorkingBase)
      cache.workingLayerCache = cache.draft.layerCache;
   else
      cache.draftLayerCache = cache.draft.layerCache;
   var finalRgb = processed ? processed.rgb : baseRgb;
   var finalBitmap = processed ? (processed.bitmap || aceRenderBitmapFromRgb(cache.draft.width, cache.draft.height, finalRgb)) : baseBitmap;
   var displayAllowedWeight = lassoEditRequested && lassoWeightValid && processed ?
      this.buildLocalDisplayAllowedWeight(cache.draft, processed, lassoWeight) : null;
   var useSourceProxyDisplay = lassoEditRequested &&
      lassoWeightValid &&
      processed &&
      !sourceProxyRgb &&
      !updateScaleMaps &&
      this.appState.preview.viewMode === "preview" &&
      !this.appState.preview.showMask &&
      (this.appState.params.texture !== 0 || this.appState.params.clarity !== 0);
   var pendingDisplayResult = useSourceProxyDisplay ?
      this.buildSourceInformedLocalDraftDisplayRgb(baseRgb, finalRgb, lassoWeight) :
      null;
   var pendingDisplayRgb = pendingDisplayResult && pendingDisplayResult.rgb ? pendingDisplayResult.rgb : null;
   if (!pendingDisplayRgb && !requireFaithfulLocalDisplay)
      pendingDisplayRgb = lassoEditRequested && lassoWeightValid && processed ?
         this.buildProtectedLocalDraftDisplayRgb(baseRgb, finalRgb, lassoWeight, displayAllowedWeight) : null;
   var pendingDisplayBitmap = pendingDisplayRgb ?
      aceRenderBitmapFromRgb(cache.draft.width, cache.draft.height, pendingDisplayRgb) : null;
   cache.currentBitmap = finalBitmap;
   cache.currentRgb = finalRgb;
   cache.pendingBitmap = lassoEditRequested && lassoWeightValid && processed ? finalBitmap : null;
   cache.pendingRgb = lassoEditRequested && lassoWeightValid && processed ? finalRgb : null;
   cache.pendingDisplayRgb = pendingDisplayRgb;
   cache.pendingDisplayBitmap = pendingDisplayBitmap;
   cache.pendingDisplayGain = pendingDisplayBitmap ? this.localDraftDisplayGain() : 1;
   if (pendingDisplayBitmap && !cache.pendingDisplayProxy)
      cache.pendingDisplayProxy = "gain-only";
   cache.pendingActive = lassoEditRequested && lassoWeightValid && processed;
   cache.pendingDraftStateKey = cache.pendingActive ? pendingStateKey : "";
   this.invalidateProtectedOverlay();
   if (this.interactiveSliderDrag) {
      if (updateScaleMaps) {
         cache.mapBitmaps = aceMergeScaleMapBitmaps(cache.mapBitmaps, this.appState.processor.buildScaleMapBitmaps(cache.draft, this.appState.params, cache.currentRgb, this.appState.advanced, this.appState.preview.viewMode));
         this.scaleMapDisplayQuality = "Accurate draft map";
         this.clearScaleMapRebuildPending();
      }
      this.refreshLocalSelectionControls();
      if (usingWorkingBase) {
         cache.draft.rgb = originalRgb;
         cache.draft.layerCache = originalLayerCache;
      }
      return;
   }
   if (updateScaleMaps)
      cache.mapBitmaps = aceMergeScaleMapBitmaps(cache.mapBitmaps, this.appState.processor.buildScaleMapBitmaps(cache.draft, this.appState.params, cache.currentRgb, this.appState.advanced, this.appState.preview.viewMode));
   if (updateScaleMaps) {
      this.scaleMapDisplayQuality = "Accurate draft map";
      this.clearScaleMapRebuildPending();
   }
   this.updateLassoMaskBitmapFromWeight(cache, cache.draft.width, cache.draft.height, lassoWeight);
   this.updateStarMaskBitmapFromProtection(cache, cache.draft.width, cache.draft.height, processed ? processed.starProtectionMask : null);
   this.updateMaskBitmapFromAllowedWeight(cache, cache.draft.width, cache.draft.height, processed ? processed.allowedWeight : null);
   if (usingWorkingBase) {
      cache.draft.rgb = originalRgb;
      cache.draft.layerCache = originalLayerCache;
   }
   this.refreshLocalSelectionControls();
};

AstroContrastEnhancerDialog.prototype.rebuildProcessedDetailPreview = function(timing, timingPrefix) {
   var detail = this.appState.cache.detail;
   if (!detail || !detail.rgb)
      return;
   var prefix = timingPrefix || "Detail preview";
   var computeTarget = detail.computeTarget || detail;
   this.appState.cache.detailTarget = computeTarget;
   var desiredMode = this.desiredDetailPreviewMode();
   detail.detailPreviewMode = desiredMode;
   computeTarget.detailPreviewMode = desiredMode;
   var updateScaleMaps = this.currentViewNeedsScaleMaps();
   var detailMasksNeeded = this.detailPreviewNeedsMaskBitmaps();
   var options = this.applyLassoWeightToOptions(computeTarget, this.getProtectionOptions());
   options.fastFullResolutionStarMask = true;
   if (!detailMasksNeeded && this.appState.preview.viewMode === "preview" && !this.appState.preview.showMask)
      options.rgbOnlyOutput = true;
   if (computeTarget !== detail)
      options.skipBitmapRender = true;
   var lassoWeight = options.lassoAllowedWeight || null;
   if (!this.appState.params.hasEffect()) {
      detail.currentRgb = detail.rgb;
      detail.currentBitmap = aceRenderBitmapFromRgb(detail.width, detail.height, detail.currentRgb);
      this.clearDetailProtectedOverlay();
      if (this.appState.preview.viewMode === "preview" && !this.appState.preview.showMask && !updateScaleMaps)
         return;
      var plainPreviewOnly = this.appState.preview.viewMode === "preview" &&
         !this.appState.preview.showMask &&
         !this.hasLassoSelection();
      if (plainPreviewOnly)
         return;
      if (!computeTarget.layerCache)
         computeTarget.layerCache = this.appState.processor.engine.buildLayerCache(computeTarget.width, computeTarget.height, computeTarget.rgb, this.appState.advanced, null, null, computeTarget.scale, aceLayerCacheRequirementsForParams(this.appState.params));
      if (!detail.layerCache)
         detail.layerCache = computeTarget !== detail ?
            { allowedWeight: aceCropGrayBuffer(computeTarget.layerCache.allowedWeight, computeTarget.width, computeTarget.height, computeTarget.innerX0, computeTarget.innerY0, detail.width, detail.height) } :
            computeTarget.layerCache;
      var starMaps = this.appState.processor.getStarProtectionMaps(computeTarget, options);
      if (updateScaleMaps) {
         detail.mapBitmaps = aceMergeScaleMapBitmaps(detail.mapBitmaps, this.appState.processor.buildScaleMapBitmaps(detail, this.appState.params, detail.rgb, this.appState.advanced, this.appState.preview.viewMode));
         this.scaleMapDisplayQuality = "Accurate high-res map";
         this.clearScaleMapRebuildPending();
      }
      this.updateLassoMaskBitmapFromWeight(detail, detail.width, detail.height, lassoWeight);
      var visibleBackgroundAllowed = computeTarget.layerCache && computeTarget.layerCache.allowedWeight && computeTarget !== detail ?
         aceCropGrayBuffer(computeTarget.layerCache.allowedWeight, computeTarget.width, computeTarget.height, computeTarget.innerX0, computeTarget.innerY0, detail.width, detail.height) :
         (computeTarget.layerCache ? computeTarget.layerCache.allowedWeight : null);
      var visibleStarMask = starMaps && computeTarget !== detail ?
         aceCropGrayBuffer(starMaps.protectionMask, computeTarget.width, computeTarget.height, computeTarget.innerX0, computeTarget.innerY0, detail.width, detail.height) :
         (starMaps ? starMaps.protectionMask : null);
      var visibleStarAllowed = starMaps && computeTarget !== detail ?
         aceCropGrayBuffer(starMaps.allowedWeight, computeTarget.width, computeTarget.height, computeTarget.innerX0, computeTarget.innerY0, detail.width, detail.height) :
         (starMaps ? starMaps.allowedWeight : null);
      this.updateStarMaskBitmapFromProtection(detail, detail.width, detail.height, visibleStarMask);
      if (options.protectSky && visibleBackgroundAllowed)
         this.updateMaskBitmapFromAllowedWeight(detail, detail.width, detail.height, this.combineAllowedWeights(detail.width, detail.height, visibleBackgroundAllowed, visibleStarAllowed, lassoWeight));
      else
         this.updateMaskBitmapFromAllowedWeight(detail, detail.width, detail.height, this.combineAllowedWeights(detail.width, detail.height, null, visibleStarAllowed, lassoWeight));
      return;
   }
   var processed = this.appState.processor.processPreview(computeTarget, this.appState.params, options, this.appState.advanced, timing, prefix);
   if (processed) {
      computeTarget.processedStateKey = this.detailProcessingStateKey();
      computeTarget.processedRgb = processed.rgb;
      computeTarget.processedAllowedWeight = processed.allowedWeight;
      computeTarget.processedStarProtectionMask = processed.starProtectionMask;
   } else {
      computeTarget.processedStateKey = "";
      computeTarget.processedRgb = null;
      computeTarget.processedAllowedWeight = null;
      computeTarget.processedStarProtectionMask = null;
   }
   if (processed && computeTarget !== detail) {
      detail.currentRgb = aceCropRgbBuffer(processed.rgb, computeTarget.width, computeTarget.height, computeTarget.innerX0, computeTarget.innerY0, detail.width, detail.height);
      detail.currentBitmap = aceRenderBitmapFromRgb(detail.width, detail.height, detail.currentRgb);
      detail.visibleAllowedWeight = detailMasksNeeded && processed.allowedWeight ?
         aceCropGrayBuffer(processed.allowedWeight, computeTarget.width, computeTarget.height, computeTarget.innerX0, computeTarget.innerY0, detail.width, detail.height) :
         null;
      detail.visibleStarProtectionMask = detailMasksNeeded && processed.starProtectionMask ?
         aceCropGrayBuffer(processed.starProtectionMask, computeTarget.width, computeTarget.height, computeTarget.innerX0, computeTarget.innerY0, detail.width, detail.height) :
         null;
   } else {
      detail.currentBitmap = processed ? processed.bitmap : detail.originalBitmap;
      detail.currentRgb = processed ? processed.rgb : detail.rgb;
      detail.visibleAllowedWeight = detailMasksNeeded && processed ? processed.allowedWeight : null;
      detail.visibleStarProtectionMask = detailMasksNeeded && processed ? processed.starProtectionMask : null;
   }
   this.clearDetailProtectedOverlay();
   if (updateScaleMaps)
      detail.mapBitmaps = aceMergeScaleMapBitmaps(detail.mapBitmaps, this.appState.processor.buildScaleMapBitmaps(detail, this.appState.params, detail.currentRgb, this.appState.advanced, this.appState.preview.viewMode));
   if (updateScaleMaps) {
      this.scaleMapDisplayQuality = "Accurate high-res map";
      this.clearScaleMapRebuildPending();
   }
   if (detailMasksNeeded) {
      this.updateLassoMaskBitmapFromWeight(detail, detail.width, detail.height, lassoWeight);
      this.updateStarMaskBitmapFromProtection(detail, detail.width, detail.height, detail.visibleStarProtectionMask);
      this.updateMaskBitmapFromAllowedWeight(detail, detail.width, detail.height, detail.visibleAllowedWeight);
   } else {
      detail.lassoMaskBitmap = null;
      detail.starMaskBitmap = null;
      detail.maskBitmap = null;
      detail.allowedMaskBitmap = null;
   }
   if (this.processingMode === "lasso" && detail.rgb && !detail.localBeforeBitmap)
      detail.localBeforeBitmap = aceRenderBitmapFromRgb(detail.width, detail.height, detail.rgb);
};

AstroContrastEnhancerDialog.prototype.rebuildProcessedPreviews = function(statusText) {
   this.rebuildProcessedDraftPreview();
   this.rebuildProcessedDetailPreview();
   this.refreshPreviewStatus(this.describeLoadedSource(), statusText || "Preview updated");
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.resetEnhancementAdjustments = function() {
   if (this.outputRendering || this.targetImageLoading)
      return;
   if (!this.appState || !this.appState.cache)
      return;
   this.exitBeforeAfterForEditChange();
   if (this.interactivePreviewTimer)
      this.interactivePreviewTimer.stop();
   this.stopPendingDetailRefreshes();
   this.bumpEditGeneration();
   this.deferredEffectChangesDuringDetail = null;
   this.deferredEffectChangeDuringDetail = null;
   this.detailPreviewRefreshAfterActiveWork = false;
   this.detailAdjustmentRefreshAfterActiveWork = false;
   this.detailWorkActive = false;
   this.detailWorkToken = null;
   this.detailRefreshTimerToken = null;
   this.detailAdjustmentTimerToken = null;
   this.pendingInteractivePreviewLabel = "";
   this.pendingInteractivePreviewStatus = "";
   this.pendingInteractivePreviewInvalidateAdvanced = false;
   this.interactiveSliderDrag = false;
   this.detailPreviewPendingNavigation = false;
   this.detailPreviewPendingAdjustment = false;
   this.resetEffectSlidersSilently();
   this.appState.fullResolutionCache = null;
   this.appState.fullResolutionCacheKey = "";
   if (this.processingMode === "full")
      this.appState.globalParams = aceCopyParams(this.appState.params);
   this.clearPendingLocalPreview(false);
   this.rebuildProcessedDraftPreview();
   this.previewFirstAdjustmentDone = false;
   this.previewWarmupDone = true;
   this.lastInteractivePreviewName = "";
   this.lastInteractivePreviewValue = 0;
   this.lastLocalAction = this.processingMode === "lasso" && this.hasLassoSelection() ? "reset" : this.lastLocalAction;
   if (this.commitButton)
      this.commitButton.setActive(false);
   this.refreshPreviewStatus(this.describeLoadedSource(), "Adjustments reset | draft");
   this.setFooterStatus("Adjustments reset | draft");
   if (this.preview)
      this.preview.update();
   if (this.shouldUseDetailPreview()) {
      this.detailPreviewPendingNavigation = true;
      this.scheduleDetailPreviewRefresh();
   }
};

AstroContrastEnhancerDialog.prototype.applyCoalescedDeferredEffectChanges = function(deferredChanges, deferredEffect) {
   var changes = [];
   if (deferredChanges && deferredChanges.length) {
      for (var i = 0; i < deferredChanges.length; ++i)
         changes.push(deferredChanges[i]);
   }
   if (deferredEffect)
      changes.push(deferredEffect);
   if (!changes.length)
      return false;
   var finalByName = {};
   var order = [];
   for (var c = 0; c < changes.length; ++c) {
      var change = changes[c];
      if (!change || (change.name !== "texture" && change.name !== "clarity" && change.name !== "dehaze"))
         continue;
      if (!finalByName.hasOwnProperty(change.name))
         order.push(change.name);
      finalByName[change.name] = {
         value: change.value,
         isDragging: !!change.isDragging
      };
   }
   if (!order.length)
      return false;
   this.exitBeforeAfterForEditChange();
   this.absorbPendingLassoBeforeEffectChange();
   this.bumpEditGeneration();
   if (this.processingMode !== "lasso" && this.hasLassoSelection())
      this.setProcessingMode("lasso");
   var lastName = order[order.length - 1];
   for (var o = 0; o < order.length; ++o)
      this.appState.params[order[o]] = finalByName[order[o]].value;
   if (this.enhancementControlBay)
      this.enhancementControlBay.update();
   if (this.processingMode === "full") {
      this.appState.globalParams = aceCopyParams(this.appState.params);
      this.appState.globalAdvanced = aceCopyAdvancedParams(this.appState.advanced);
      this.appState.fullResolutionCache = null;
      this.appState.fullResolutionCacheKey = "";
   }
   if (this.processingMode === "lasso" || this.processingMode === "full")
      this.lastLocalAction = "";
   if (this.commitButton)
      this.commitButton.setActive(false);
   if (!this.appState.cache.draft || !this.appState.cache.draft.rgb) {
      this.refreshPreviewStatus("No active image", "Open an image and select its view.");
      return true;
   }
   if (this.interactivePreviewTimer)
      this.interactivePreviewTimer.stop();
   if (this.detailAdjustmentIdleTimer)
      this.detailAdjustmentIdleTimer.stop();
   if (this.detailRefreshTimer)
      this.detailRefreshTimer.stop();
   this.bumpDetailRefreshGeneration();
   this.pendingInteractivePreviewLabel = "";
   this.pendingInteractivePreviewStatus = "";
   this.pendingInteractivePreviewInvalidateAdvanced = false;
   this.invalidateProtectedOverlay();
   this.invalidateScaleMapBitmaps();
   var activeLocalSliderChange = this.processingMode === "lasso" && this.hasLassoSelection();
   if (activeLocalSliderChange) {
      this.appState.cache.detail = null;
      // Preserve the hidden compute target during coalesced slider replay; the
      // visible detail crop is stale, but the source crop/cache is still valid.
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
   }
   if (!this.appState.params.hasEffect()) {
      this.setPendingPreviewStage("Adjustments cleared | resetting local preview...");
      this.clearLowZoomLoupe();
      if (this.processingMode === "lasso")
         this.clearPendingLocalPreview(true);
      else
         this.clearDetailPreviewState();
      this.rebuildProcessedDraftPreview();
      this.previewFirstAdjustmentDone = false;
      this.previewWarmupDone = true;
      this.lastInteractivePreviewName = lastName;
      this.lastInteractivePreviewValue = finalByName[lastName].value;
      this.refreshPreviewStatus(this.describeLoadedSource(), "Adjustments cleared | draft");
      if (this.preview)
         this.preview.update();
      return true;
   }
   this.setPendingPreviewStage("Processing combined adjustments | draft layers...");
   this.interactiveSliderDrag = false;
   this.rebuildProcessedDraftPreview();
   if (this.processingMode === "lasso" && this.appState.params.hasEffect() && !this.localLassoDraftEditReady())
      this.reportLocalLassoDraftFailure("Adjustments");
   else if (this.localLassoDraftEditReady())
      this.refreshCompletedLocalDraftDisplay("Adjustments");
   var skipLocalDetail = this.shouldSkipDetailPreviewForLocalEdit();
   if (skipLocalDetail) {
      this.appState.cache.detail = null;
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      if (this.detailAdjustmentIdleTimer)
         this.detailAdjustmentIdleTimer.stop();
   } else if (this.shouldUseDetailPreview()) {
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = true;
      this.setPendingPreviewStage("Combined draft ready | detail queued");
      this.schedulePendingDetailAdjustmentRefresh();
   }
   this.previewFirstAdjustmentDone = true;
   this.previewWarmupDone = true;
   this.lastInteractivePreviewName = lastName;
   this.lastInteractivePreviewValue = finalByName[lastName].value;
   var tier = this.shouldUseDetailPreview() && this.appState.cache.detail ? "detail crop" : "draft";
   if (this.detailPreviewPendingAdjustment)
      tier = "draft | detail pending";
   var loupeQueued = this.lowZoomLoupeShouldBeActive();
   var loupeAvailable = this.lowZoomLoupeIsAvailable();
   var zoomHint = loupeQueued ? " | detail loupe queued" :
      (!this.shouldUseDetailPreview() && this.appState.preview.viewMode === "preview" ?
         (loupeAvailable ? " | draft; hold Shift for native loupe" : " | draft only; zoom to 200% for native detail") : "");
   this.refreshPreviewStatus(this.describeLoadedSource(), "Adjustments updated | " + tier + zoomHint);
   if (loupeQueued)
      this.scheduleLowZoomLoupeRefresh("Adjustments updated | detail loupe queued");
   else if (this.processingMode === "full")
      this.clearLowZoomLoupe();
   if (this.preview)
      this.preview.update();
   return true;
};

AstroContrastEnhancerDialog.prototype.schedulePreviewWarmup = function(statusText) {
   this.previewWarmupDone = false;
   this.previewWarmupActive = true;
   if (statusText)
      this.setFooterStatus(statusText, ACE_COLORS.warning);
   this.refreshPreviewStatus(this.describeLoadedSource ? this.describeLoadedSource() : "Loaded", "Preparing first preview response...");
   if (this.preview)
      this.preview.update();
   if (this.previewWarmupTimer) {
      this.previewWarmupTimer.stop();
      this.previewWarmupTimer.start();
   } else {
      this.performPreviewWarmup();
   }
};

AstroContrastEnhancerDialog.prototype.performPreviewWarmup = function() {
   var warmupStart = Date.now();
   if (this.previewWarmupDone || this.outputRendering || this.targetImageLoading || this.interactiveSliderDrag)
      return;
   var draft = this.appState && this.appState.cache ? this.appState.cache.draft : null;
   if (!draft || !draft.rgb)
      return;
   try {
      this.previewWarmupActive = true;
      this.setFooterStatus("Preparing first preview response...", ACE_COLORS.warning);
      if (this.preview)
         this.preview.update();
      var warmDraft = aceDownsampleRgbAntialias(draft.rgb, draft.width, draft.height, 256);
      var warmParams = new EffectParameters;
      warmParams.texture = 1;
      warmParams.clarity = 1;
      warmParams.dehaze = 1;
      var warmProtection = aceCopyProtectionOptions(this.getProtectionOptions());
      this.appState.processor.processPreview(warmDraft, warmParams, warmProtection, this.appState.advanced);
      this.previewWarmupDone = true;
      this.previewWarmupActive = false;
      this.setFooterStatus("Preview controls ready");
      this.refreshPreviewStatus(this.describeLoadedSource(), "Preview: draft");
      aceDevelopmentConsoleWriteLine("[ACE] Preview warmup timing | total=" + (Date.now() - warmupStart) + " ms mode=lightweight warmDraft=256 leadDraft=skipped");
   } catch (error) {
      this.previewWarmupDone = true;
      this.previewWarmupActive = false;
      this.setFooterStatus("Preview ready");
      this.refreshPreviewStatus(this.describeLoadedSource(), "Preview: draft");
      aceDevelopmentConsoleWriteLine("[ACE] Preview warmup timing | total=" + (Date.now() - warmupStart) + " ms mode=lightweight status=error message=" + (error && error.message ? error.message : String(error)));
   }
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.zoomPreviewStep = function(direction) {
   if (this.appState.preview.zoomMode === "fit" && direction >= 0) {
      if (!this.zoomPreviewToSelection(1))
         this.setZoomScaleCentered(1);
      return;
   }
   var levels = [0.25, 0.5, 1, 2, 4, 6, 8, 12, 16];
   var current = this.appState.preview.zoomMode === "fit" ? 1 : this.appState.preview.zoomScale;
   var epsilon = 0.01;
   var next = levels[direction >= 0 ? levels.length - 1 : 0];
   if (direction >= 0) {
      for (var up = 0; up < levels.length; ++up) {
         if (levels[up] > current + epsilon) {
            next = levels[up];
            break;
         }
      }
   } else {
      for (var down = levels.length - 1; down >= 0; --down) {
         if (levels[down] < current - epsilon) {
            next = levels[down];
            break;
         }
      }
   }
   if (!this.zoomPreviewToSelection(next))
      this.setZoomScaleCentered(next);
};

AstroContrastEnhancerDialog.prototype.zoomPreviewToSelection = function(scale) {
   if (this.processingMode !== "lasso" || !this.hasLassoSelection() || !this.appState.cache.draft || !this.appState.cache.source)
      return false;
   this.prepareForZoomNavigation();
   var bounds = this.getLassoBounds();
   if (!bounds)
      return false;
   var source = this.appState.cache.source;
   var draft = this.appState.cache.draft;
   var centerX = (bounds.x0 + bounds.x1) * 0.5 * draft.width / Math.max(1, source.width);
   var centerY = (bounds.y0 + bounds.y1) * 0.5 * draft.height / Math.max(1, source.height);
   this.appState.preview.zoomMode = "manual";
   this.appState.preview.zoomScale = aceClamp(scale, 0.25, ACE_MAX_PREVIEW_ZOOM);
   this.appState.preview.panX = this.appState.preview.zoomScale * (draft.width * 0.5 - centerX);
   this.appState.preview.panY = this.appState.preview.zoomScale * (draft.height * 0.5 - centerY);
   this.detailPreviewPendingNavigation = this.shouldUseDetailPreview();
   this.detailPreviewPendingAdjustment = false;
   this.clampPan();
   if (this.shouldUseDetailPreview()) {
      if (this.processingMode === "lasso" && this.appState.params && this.appState.params.hasEffect())
         this.refreshDetailPreviewIfNeeded(true);
      else
         this.scheduleDetailPreviewRefresh();
   }
   this.refreshPreviewStatus(this.describeLoadedSource(), this.shouldUseDetailPreview() ? "Selection zoomed | detail queued" : "Zoom: selection centered");
   if (this.preview)
      this.preview.update();
   return true;
};

AstroContrastEnhancerDialog.prototype.shouldUseDetailPreview = function() {
   if (!ACE_DETAIL_CROP_PREVIEW_ENABLED)
      return false;
   if (!this.appState || !this.appState.preview || !this.appState.cache || !this.appState.cache.source)
      return false;
   var zoomEligible = this.appState.preview.zoomMode !== "fit" && this.appState.preview.zoomScale >= ACE_DETAIL_ZOOM_THRESHOLD;
   if (!zoomEligible)
      return false;
   if (this.processingMode === "lasso") {
      if (!this.hasLassoSelection())
         return false;
      if (this.lassoDrawing || this.lassoMoving || this.selectionTransitionBusy || this.pendingLassoStatusText)
         return false;
      return true;
   }
   if (this.processingMode === "full") {
      var hasEffect = !!(this.appState.params && this.appState.params.hasEffect && this.appState.params.hasEffect());
      if (this.appState.preview.viewMode === "preview" && !this.appState.preview.showMask)
         return true;
      return hasEffect || this.currentViewNeedsScaleMaps() || this.detailPreviewNeedsMaskBitmaps();
   }
   return false;
};

AstroContrastEnhancerDialog.prototype.shouldSkipDetailPreviewForLocalEdit = function() {
   return false;
};

AstroContrastEnhancerDialog.prototype.getDetailCropRequest = function() {
   var source = this.appState.cache.source;
   var draft = this.appState.cache.draft;
   if (!source || !source.viewId || !draft || this.appState.preview.zoomMode === "fit")
      return null;
   var visibleDraft = aceGetVisibleBitmapRectForScale(
      this.preview.width,
      this.preview.height,
      draft.width,
      draft.height,
      this.appState.preview.zoomScale,
      this.appState.preview.panX,
      this.appState.preview.panY
   );
   if (visibleDraft.width <= 0 || visibleDraft.height <= 0)
      return null;
   var scaleX = source.width / Math.max(1, draft.width);
   var scaleY = source.height / Math.max(1, draft.height);
   var x0 = aceClamp(Math.floor(visibleDraft.x0 * scaleX), 0, source.width - 1);
   var y0 = aceClamp(Math.floor(visibleDraft.y0 * scaleY), 0, source.height - 1);
   var x1 = aceClamp(Math.ceil(visibleDraft.x1 * scaleX), x0 + 1, source.width);
   var y1 = aceClamp(Math.ceil(visibleDraft.y1 * scaleY), y0 + 1, source.height);
   if (this.processingMode === "lasso" && this.hasLassoSelection()) {
      var feather = this.featherSlider ? this.featherSlider.value : ACE_FEATHER_DEFAULT;
      var detailMargin = this.appState.params && this.appState.params.hasEffect() ? 12 : 0;
      var editBounds = aceLassoBounds(this.appState.lassoPoints, source.width, source.height, feather + detailMargin);
      var ex0 = aceClamp(Math.floor(editBounds.x0), 0, source.width - 1);
      var ey0 = aceClamp(Math.floor(editBounds.y0), 0, source.height - 1);
      var ex1 = aceClamp(Math.ceil(editBounds.x1), ex0 + 1, source.width);
      var ey1 = aceClamp(Math.ceil(editBounds.y1), ey0 + 1, source.height);
      var ix0 = Math.max(x0, ex0);
      var iy0 = Math.max(y0, ey0);
      var ix1 = Math.min(x1, ex1);
      var iy1 = Math.min(y1, ey1);
      if (ix1 <= ix0 || iy1 <= iy0) {
         this.detailPreviewPendingNavigation = false;
         this.detailPreviewPendingAdjustment = false;
         return null;
      }
      x0 = ix0;
      y0 = iy0;
      x1 = ix1;
      y1 = iy1;
   }
   return { x0: x0, y0: y0, x1: x1, y1: y1, width: x1 - x0, height: y1 - y0 };
};

AstroContrastEnhancerDialog.prototype.limitProcessedLocalDetailCropRequest = function(req, source) {
   if (!req || !source)
      return req;
   if (this.desiredDetailPreviewMode() !== "processed-local")
      return req;
   var maxPixels = Math.max(1, ACE_DETAIL_RESPONSIVE_LOCAL_MAX_PIXELS);
   var pixels = req.width * req.height;
   if (pixels <= maxPixels)
      return req;
   var aspect = req.width / Math.max(1, req.height);
   var targetWidth = Math.max(1, Math.floor(Math.sqrt(maxPixels * aspect)));
   var targetHeight = Math.max(1, Math.floor(targetWidth / Math.max(ACE_EPSILON, aspect)));
   if (targetHeight > req.height) {
      targetHeight = req.height;
      targetWidth = Math.max(1, Math.floor(maxPixels / Math.max(1, targetHeight)));
   }
   if (targetWidth > req.width) {
      targetWidth = req.width;
      targetHeight = Math.max(1, Math.floor(maxPixels / Math.max(1, targetWidth)));
   }
   targetWidth = Math.max(1, Math.min(req.width, targetWidth));
   targetHeight = Math.max(1, Math.min(req.height, targetHeight));
   var cx = (req.x0 + req.x1) * 0.5;
   var cy = (req.y0 + req.y1) * 0.5;
   var x0 = aceClamp(Math.floor(cx - targetWidth * 0.5), req.x0, Math.max(req.x0, req.x1 - targetWidth));
   var y0 = aceClamp(Math.floor(cy - targetHeight * 0.5), req.y0, Math.max(req.y0, req.y1 - targetHeight));
   var limited = {
      x0: x0,
      y0: y0,
      x1: x0 + targetWidth,
      y1: y0 + targetHeight,
      width: targetWidth,
      height: targetHeight,
      limitedFromWidth: req.width,
      limitedFromHeight: req.height
   };
   aceDevelopmentConsoleWriteLine("[ACE] Native detail local crop capped | from=" + req.width + "x" + req.height +
      " to=" + limited.width + "x" + limited.height +
      " maxPixels=" + maxPixels);
   return limited;
};

AstroContrastEnhancerDialog.prototype.limitProcessedGlobalDetailCropRequest = function(req, source) {
   if (!req || !source)
      return req;
   if (this.desiredDetailPreviewMode() !== "processed-global")
      return req;
   if (this.currentViewNeedsScaleMaps() || this.detailPreviewNeedsMaskBitmaps())
      return req;
   var maxPixels = Math.max(1, ACE_DETAIL_RESPONSIVE_GLOBAL_MAX_PIXELS);
   var pixels = req.width * req.height;
   if (pixels <= maxPixels)
      return req;
   var aspect = req.width / Math.max(1, req.height);
   var targetWidth = Math.max(1, Math.floor(Math.sqrt(maxPixels * aspect)));
   var targetHeight = Math.max(1, Math.floor(targetWidth / Math.max(ACE_EPSILON, aspect)));
   if (targetHeight > req.height) {
      targetHeight = req.height;
      targetWidth = Math.max(1, Math.floor(maxPixels / Math.max(1, targetHeight)));
   }
   if (targetWidth > req.width) {
      targetWidth = req.width;
      targetHeight = Math.max(1, Math.floor(maxPixels / Math.max(1, targetWidth)));
   }
   targetWidth = Math.max(1, Math.min(req.width, targetWidth));
   targetHeight = Math.max(1, Math.min(req.height, targetHeight));
   var cx = (req.x0 + req.x1) * 0.5;
   var cy = (req.y0 + req.y1) * 0.5;
   var x0 = aceClamp(Math.floor(cx - targetWidth * 0.5), req.x0, Math.max(req.x0, req.x1 - targetWidth));
   var y0 = aceClamp(Math.floor(cy - targetHeight * 0.5), req.y0, Math.max(req.y0, req.y1 - targetHeight));
   var limited = {
      x0: x0,
      y0: y0,
      x1: x0 + targetWidth,
      y1: y0 + targetHeight,
      width: targetWidth,
      height: targetHeight,
      limitedFromWidth: req.width,
      limitedFromHeight: req.height,
      responsiveGlobalPreview: true
   };
   aceDevelopmentConsoleWriteLine("[ACE] Native detail global crop capped | from=" + req.width + "x" + req.height +
      " to=" + limited.width + "x" + limited.height +
      " maxPixels=" + maxPixels);
   return limited;
};

AstroContrastEnhancerDialog.prototype.getDetailPreviewContextMargin = function() {
   var params = this.appState.params || new EffectParameters;
   var advanced = this.appState.advanced || new AdvancedParameters;
   var radius = ACE_STRUCTURE_RADIUS;
   if (params.texture !== 0) {
      var textureRadius = aceAdvancedRadiusPx(advanced, "textureScale", ACE_TEXTURE_RADIUS);
      if (aceNormalizeTextureMode(params.textureMode) === ACE_TEXTURE_MODE_WIDE60)
         textureRadius = Math.max(textureRadius, ACE_TEXTURE_WIDE60_RADIUS);
      radius = Math.max(radius, textureRadius);
   }
   if (params.clarity !== 0)
      radius = Math.max(radius, aceAdvancedRadiusPx(advanced, "clarityScale", ACE_CLARITY_RADIUS));
   if (params.dehaze !== 0)
      radius = Math.max(radius, aceAdvancedRadiusPx(advanced, "dehazeVeilSize", ACE_DEHAZE_RADIUS));
   if ((this.protectSky && this.protectSky.checked) || (this.preventDark && this.preventDark.checked))
      radius = Math.max(radius, ACE_FLOOR_RADIUS);
   return Math.max(ACE_DETAIL_MIN_CONTEXT_MARGIN, Math.min(ACE_DETAIL_MAX_CONTEXT_MARGIN, Math.ceil(radius * ACE_DETAIL_CONTEXT_RADIUS_SCALE)));
};

AstroContrastEnhancerDialog.prototype.getDetailComputeRequest = function(req, margin, source) {
   if (!req || !source)
      return null;
   var m = Math.max(0, Math.min(ACE_DETAIL_MAX_CONTEXT_MARGIN, Math.round(margin || 0)));
   var computeReq = null;
   for (;;) {
      computeReq = {
         x0: aceClamp(req.x0 - m, 0, source.width - 1),
         y0: aceClamp(req.y0 - m, 0, source.height - 1),
         x1: aceClamp(req.x1 + m, req.x0 + 1, source.width),
         y1: aceClamp(req.y1 + m, req.y0 + 1, source.height),
         contextMargin: m
      };
      computeReq.width = computeReq.x1 - computeReq.x0;
      computeReq.height = computeReq.y1 - computeReq.y0;
      if (m <= ACE_DETAIL_MIN_CONTEXT_MARGIN || computeReq.width * computeReq.height <= ACE_DETAIL_SOFT_MAX_PIXELS)
         return computeReq;
      m = Math.max(ACE_DETAIL_MIN_CONTEXT_MARGIN, Math.floor(m * 0.72));
   }
};

AstroContrastEnhancerDialog.prototype.desiredDetailPreviewMode = function() {
   if (this.appState.params && this.appState.params.hasEffect())
      return this.processingMode === "lasso" && this.hasLassoSelection() ? "processed-local" : "processed-global";
   if (this.currentViewNeedsScaleMaps() || this.detailPreviewNeedsMaskBitmaps())
      return "source-maps";
   return "source-only";
};

AstroContrastEnhancerDialog.prototype.detailProcessingStateKey = function() {
   var protection = aceCopyProtectionOptions(this.getProtectionOptions());
   return JSON.stringify({
      detailMode: this.desiredDetailPreviewMode(),
      params: aceCopyParams(this.appState.params),
      advanced: aceCopyAdvancedParams(this.appState.advanced),
      protection: protection,
      lasso: {
         mode: this.processingMode,
         version: this.appState.lassoVersion || 0,
         inverted: !!this.appState.lassoInverted,
         feather: this.featherSlider ? this.featherSlider.value : ACE_FEATHER_DEFAULT,
         active: this.hasLassoSelection()
      }
   });
};

AstroContrastEnhancerDialog.prototype.localDraftProcessingStateKey = function() {
   var protection = aceCopyProtectionOptions(this.getProtectionOptions());
   return JSON.stringify({
      params: aceCopyParams(this.appState.params),
      advanced: aceCopyAdvancedParams(this.appState.advanced),
      protection: protection,
      lasso: {
         mode: this.processingMode,
         version: this.appState.lassoVersion || 0,
         inverted: !!this.appState.lassoInverted,
         feather: this.featherSlider ? this.featherSlider.value : ACE_FEATHER_DEFAULT,
         active: this.hasLassoSelection()
      },
      base: {
         sourceVersion: this.appState.cache.source.version || 0,
         recipeLength: this.appState.editRecipe ? this.appState.editRecipe.length : 0,
         working: this.appState.cache.currentRgb === this.appState.cache.workingRgb ? 1 : 0
      },
      view: {
         mode: this.appState.preview ? this.appState.preview.viewMode : "preview",
         showMask: !!(this.appState.preview && this.appState.preview.showMask),
         scaleMaps: this.currentViewNeedsScaleMaps() ? 1 : 0,
         faithful: this.localPreviewRequiresFaithfulDisplay() ? 1 : 0
      }
   });
};

AstroContrastEnhancerDialog.prototype.tryReuseProcessedDetailTarget = function(existingTarget, req, computeReq, stateKey) {
   if (!existingTarget || !req || !computeReq)
      return false;
   var desiredMode = this.desiredDetailPreviewMode();
   if (existingTarget.detailPreviewMode && existingTarget.detailPreviewMode !== desiredMode)
      return false;
   if (this.currentViewNeedsScaleMaps())
      return false;
   if (existingTarget.x0 > computeReq.x0 ||
       existingTarget.y0 > computeReq.y0 ||
       existingTarget.x0 + existingTarget.width < computeReq.x1 ||
       existingTarget.y0 + existingTarget.height < computeReq.y1)
      return false;
   var hasEffect = this.appState.params.hasEffect();
   var hasReusableProcessedState = existingTarget.processedRgb && existingTarget.processedStateKey === stateKey;
   if (!hasReusableProcessedState &&
       desiredMode === "processed-global" &&
       (existingTarget.x0 !== computeReq.x0 ||
        existingTarget.y0 !== computeReq.y0 ||
        existingTarget.width !== computeReq.width ||
        existingTarget.height !== computeReq.height))
      return false;
   var innerX0 = req.x0 - existingTarget.x0;
   var innerY0 = req.y0 - existingTarget.y0;
   var sourceRgb = existingTarget.sourceRgb || existingTarget.rgb;
   var visibleSourceRgb = aceCropRgbBuffer(sourceRgb, existingTarget.width, existingTarget.height, innerX0, innerY0, req.width, req.height);
   var visibleRgb = aceCropRgbBuffer(existingTarget.rgb, existingTarget.width, existingTarget.height, innerX0, innerY0, req.width, req.height);
   var detail = {
      x0: req.x0,
      y0: req.y0,
      width: req.width,
      height: req.height,
      rgb: visibleRgb,
      scale: 1,
      layerCache: null,
      computeTarget: existingTarget,
      zoom: this.appState.preview.zoomScale,
      sourceRgb: visibleSourceRgb,
      originalBitmap: aceRenderBitmapFromRgb(req.width, req.height, visibleSourceRgb),
      currentBitmap: null,
      mode: "detail crop",
      detailPreviewMode: desiredMode,
      immediate: false
   };
   existingTarget.innerX0 = innerX0;
   existingTarget.innerY0 = innerY0;
   existingTarget.visibleWidth = req.width;
   existingTarget.visibleHeight = req.height;
   this.appState.cache.detail = detail;
   this.appState.cache.detailTarget = existingTarget;
   existingTarget.detailPreviewMode = desiredMode;
   if (!hasEffect && desiredMode === "source-only") {
      detail.currentRgb = detail.rgb;
      detail.currentBitmap = aceRenderBitmapFromRgb(detail.width, detail.height, detail.currentRgb);
      this.clearDetailProtectedOverlay();
      return true;
   }
   if (hasReusableProcessedState) {
      var detailMasksNeeded = this.detailPreviewNeedsMaskBitmaps();
      detail.currentRgb = aceCropRgbBuffer(existingTarget.processedRgb, existingTarget.width, existingTarget.height, innerX0, innerY0, req.width, req.height);
      detail.currentBitmap = aceRenderBitmapFromRgb(req.width, req.height, detail.currentRgb);
      this.clearDetailProtectedOverlay();
      detail.visibleAllowedWeight = detailMasksNeeded && existingTarget.processedAllowedWeight ?
         aceCropGrayBuffer(existingTarget.processedAllowedWeight, existingTarget.width, existingTarget.height, innerX0, innerY0, req.width, req.height) : null;
      detail.visibleStarProtectionMask = detailMasksNeeded && existingTarget.processedStarProtectionMask ?
         aceCropGrayBuffer(existingTarget.processedStarProtectionMask, existingTarget.width, existingTarget.height, innerX0, innerY0, req.width, req.height) : null;
      if (detailMasksNeeded) {
         this.updateLassoMaskBitmapFromWeight(detail, detail.width, detail.height, this.getLassoWeightForTarget(detail));
         this.updateStarMaskBitmapFromProtection(detail, detail.width, detail.height, detail.visibleStarProtectionMask);
         this.updateMaskBitmapFromAllowedWeight(detail, detail.width, detail.height, detail.visibleAllowedWeight);
      }
      return true;
   }
   return false;
};

AstroContrastEnhancerDialog.prototype.ensureDetailPreviewForBeforeAfter = function() {
   if (this.outputRendering || this.targetImageLoading)
      return false;
   if (this.selectionTransitionBusy || this.lassoDrawing || this.lassoMoving || this.pendingLassoStatusText)
      return false;
   if (!this.appState || !this.appState.preview || !this.appState.cache)
      return false;
   if (this.appState.preview.viewMode !== "preview" || this.appState.preview.showMask)
      return false;
   if (!this.shouldUseDetailPreview())
      return false;
   if (this.previewDragging)
      return false;
   var detail = this.appState.cache.detail;
   if (detail && !this.detailPreviewPendingNavigation && !this.detailPreviewPendingAdjustment)
      return true;
   if (this.pendingInteractivePreviewLabel)
      this.performQueuedInteractivePreview();
   if (this.detailRefreshTimer)
      this.detailRefreshTimer.stop();
   if (this.detailAdjustmentIdleTimer)
      this.detailAdjustmentIdleTimer.stop();
   this.detailPreviewPendingNavigation = false;
   this.detailPreviewPendingAdjustment = false;
   this.setPendingPreviewStage("Preparing detail B/A...");
   this.refreshDetailPreviewIfNeeded(true);
   detail = this.appState.cache.detail;
   return !!detail;
};

AstroContrastEnhancerDialog.prototype.refreshDetailPreviewIfNeeded = function(immediate) {
   var detailStartMs = Date.now();
   if (this.selectionTransitionBusy || this.lassoDrawing || this.lassoMoving || this.pendingLassoStatusText)
      return;
   var detailToken = this.capturePreviewStateToken(immediate ? "detail-immediate" : "detail-refresh");
   if (this.lastOutputRenderFinishedMs && Date.now() - this.lastOutputRenderFinishedMs < ACE_OUTPUT_DETAIL_REFRESH_COOLDOWN_MS) {
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      if (this.detailAdjustmentIdleTimer)
         this.detailAdjustmentIdleTimer.stop();
      return;
   }
   if (!this.shouldUseDetailPreview()) {
      this.appState.cache.detail = null;
      this.appState.cache.detailTarget = null;
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      if (this.detailAdjustmentIdleTimer)
         this.detailAdjustmentIdleTimer.stop();
      return;
   }
   if (!this.previewStateTokenIsCurrent(detailToken))
      return;
   if (this.processingMode === "lasso" &&
       this.hasLassoSelection() &&
       this.appState.params.hasEffect() &&
       !this.localLassoDraftEditReady()) {
      this.appState.cache.detail = null;
      this.appState.cache.detailTarget = null;
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      if (this.detailAdjustmentIdleTimer)
         this.detailAdjustmentIdleTimer.stop();
      this.reportLocalLassoDraftFailure("Native detail blocked");
      return;
   }
   if (this.detailWorkActive)
      return;
   this.detailWorkActive = true;
   this.detailWorkToken = detailToken;
   try {
   var req = this.getDetailCropRequest();
   req = this.limitProcessedLocalDetailCropRequest(req, this.appState.cache.source);
   req = this.limitProcessedGlobalDetailCropRequest(req, this.appState.cache.source);
   if (!req || req.width * req.height > ACE_DETAIL_MAX_PIXELS) {
      this.appState.cache.detail = null;
      this.appState.cache.detailTarget = null;
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      if (this.detailAdjustmentIdleTimer)
         this.detailAdjustmentIdleTimer.stop();
      this.refreshPreviewStatus(this.describeLoadedSource(), "Native detail unavailable for current lasso crop");
      return;
   }
   if (!this.previewStateTokenIsCurrent(detailToken))
      return;
   var found = aceFindViewForViewId(this.appState.cache.source.viewId);
   if (!found || !found.view) {
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      if (this.detailAdjustmentIdleTimer)
         this.detailAdjustmentIdleTimer.stop();
      return;
   }
   if (!this.previewStateTokenIsCurrent(detailToken))
      return;
   var source = this.appState.cache.source;
   var desiredMode = this.desiredDetailPreviewMode();
   var plainPreviewOnly = this.appState.preview.viewMode === "preview" &&
      !this.appState.preview.showMask &&
      !this.hasLassoSelection() &&
      !this.appState.params.hasEffect();
   var margin = desiredMode === "source-only" || plainPreviewOnly ? 0 : this.getDetailPreviewContextMargin();
   var computeReq = this.getDetailComputeRequest(req, margin, source);
   if (desiredMode === "processed-local" &&
       computeReq &&
       computeReq.width * computeReq.height > ACE_DETAIL_RESPONSIVE_LOCAL_MAX_PIXELS &&
       margin > 0) {
      margin = 0;
      computeReq = this.getDetailComputeRequest(req, margin, source);
   }
   if (desiredMode === "processed-global" &&
       computeReq &&
       computeReq.width * computeReq.height > ACE_DETAIL_RESPONSIVE_GLOBAL_MAX_PIXELS &&
       margin > 0) {
      margin = 0;
      computeReq = this.getDetailComputeRequest(req, margin, source);
   }
   if (!computeReq || computeReq.width * computeReq.height > ACE_DETAIL_MAX_PIXELS) {
      if (margin > 0) {
         margin = 0;
         computeReq = this.getDetailComputeRequest(req, margin, source);
      }
      if (!computeReq || computeReq.width * computeReq.height > ACE_DETAIL_MAX_PIXELS) {
         this.appState.cache.detail = null;
         this.appState.cache.detailTarget = null;
         this.detailPreviewPendingNavigation = false;
         this.detailPreviewPendingAdjustment = false;
         if (this.detailAdjustmentIdleTimer)
            this.detailAdjustmentIdleTimer.stop();
         return;
      }
   }
   var existingDetail = this.appState.cache.detail;
   var existingTarget = existingDetail ? (existingDetail.computeTarget || existingDetail) : (this.appState.cache.detailTarget || null);
   var processingStateKey = this.detailProcessingStateKey();
   var existingTargetHasProcessedState = existingTarget &&
      existingTarget.processedRgb &&
      existingTarget.processedStateKey === processingStateKey;
   var existingTargetNeedsFirstEffectCache = existingTarget &&
      this.appState.params.hasEffect() &&
      !existingTargetHasProcessedState &&
      !existingTarget.layerCache;
   var reuseStartMs = Date.now();
   if (!existingTargetNeedsFirstEffectCache &&
       this.tryReuseProcessedDetailTarget(existingTarget, req, computeReq, processingStateKey)) {
      var reuseMs = Date.now() - reuseStartMs;
      if (this.discardStaleDetailWork(detailToken, "Stale native detail discarded"))
         return;
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      if (this.detailAdjustmentIdleTimer)
         this.detailAdjustmentIdleTimer.stop();
      this.refreshPreviewStatus(this.describeLoadedSource(), this.currentViewNeedsScaleMaps() ? (this.scaleMapDisplayQuality || "Accurate high-res map") : (req.responsiveGlobalPreview ? "Preview: responsive detail crop" : "Preview: detail crop"));
      if (this.preview)
         this.preview.update();
      if (reuseMs >= 100) {
         aceDevelopmentConsoleWriteLine("[ACE] Native detail fast reuse | total=" + reuseMs + " ms" +
            " visible=" + req.width + "x" + req.height +
            " compute=" + existingTarget.width + "x" + existingTarget.height +
            " margin=" + (existingTarget.contextMargin !== undefined ? existingTarget.contextMargin : "n/a") +
            " zoom=" + this.getZoomReadout());
      }
      return;
   }
   existingDetail = this.appState.cache.detail || existingDetail;
   var existingTargetMatchesCompute = existingTarget &&
      existingTarget.x0 === computeReq.x0 &&
      existingTarget.y0 === computeReq.y0 &&
      existingTarget.width === computeReq.width &&
      existingTarget.height === computeReq.height;
   if (!existingTargetNeedsFirstEffectCache &&
       existingDetail &&
       existingTarget &&
       (desiredMode !== "processed-global" || existingTargetMatchesCompute) &&
       existingDetail.x0 === req.x0 &&
       existingDetail.y0 === req.y0 &&
       existingDetail.width === req.width &&
       existingDetail.height === req.height &&
       existingTarget.x0 <= computeReq.x0 &&
       existingTarget.y0 <= computeReq.y0 &&
       existingTarget.x0 + existingTarget.width >= computeReq.x1 &&
       existingTarget.y0 + existingTarget.height >= computeReq.y1) {
      this.setPendingPreviewStage("Processing detail...");
      var reuseTiming = { items: [] };
      var reuseProcessStartMs = Date.now();
      var self = this;
      aceWithSuppressedEventYields(function() {
         self.rebuildProcessedDetailPreview(reuseTiming, "Detail preview");
      });
      var reuseProcessMs = Date.now() - reuseProcessStartMs;
      var reuseTotalMs = Date.now() - detailStartMs;
      if (this.discardStaleDetailWork(detailToken, "Stale native detail discarded"))
         return;
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      if (this.detailAdjustmentIdleTimer)
         this.detailAdjustmentIdleTimer.stop();
      this.refreshPreviewStatus(this.describeLoadedSource(), this.currentViewNeedsScaleMaps() ? (this.scaleMapDisplayQuality || "Accurate high-res map") : (req.responsiveGlobalPreview ? "Preview: responsive detail crop" : "Preview: detail crop"));
      if (reuseProcessMs >= ACE_DETAIL_TIMING_LOG_THRESHOLD_MS) {
         aceDevelopmentConsoleWriteLine("[ACE] Slow native detail cache reuse | total=" + reuseTotalMs + " ms" +
            " setup=" + Math.max(0, reuseTotalMs - reuseProcessMs) + " ms" +
            " process=" + reuseProcessMs + " ms" +
            " visible=" + req.width + "x" + req.height +
            " compute=" + existingTarget.width + "x" + existingTarget.height +
            " margin=" + (existingTarget.contextMargin !== undefined ? existingTarget.contextMargin : "n/a") +
            " zoom=" + this.getZoomReadout() +
            " view=" + this.appState.preview.viewMode +
            " hasEffect=" + (this.appState.params.hasEffect() ? "yes" : "no") +
            " lasso=" + (this.hasLassoSelection() ? "yes" : "no") +
            " | " + aceTimingSummary(reuseTiming, 10));
      }
      return;
   }
   this.setPendingPreviewStage("Reading detail...");
   var readStartMs = Date.now();
   var crop = aceReadRgbCropFromView(found.view, computeReq);
   var readMs = Date.now() - readStartMs;
   if (this.discardStaleDetailWork(detailToken, "Stale native detail discarded"))
      return;
   var prepStartMs = Date.now();
   var innerX0 = req.x0 - crop.x0;
   var innerY0 = req.y0 - crop.y0;
   var sourceRgb = crop.rgb;
   var visibleSourceRgb = aceCropRgbBuffer(sourceRgb, crop.width, crop.height, innerX0, innerY0, req.width, req.height);
   var originalBitmap = aceRenderBitmapFromRgb(req.width, req.height, visibleSourceRgb);
   var committedRgb = this.applyCommittedRecipeToDetailRgb(crop.width, crop.height, crop.rgb, crop.x0, crop.y0);
   var visibleRgb = aceCropRgbBuffer(committedRgb, crop.width, crop.height, innerX0, innerY0, req.width, req.height);
   var prepMs = Date.now() - prepStartMs;
   if (this.discardStaleDetailWork(detailToken, "Stale native detail discarded"))
      return;
   var computeTarget = {
      x0: crop.x0,
      y0: crop.y0,
      width: crop.width,
      height: crop.height,
      rgb: committedRgb,
      sourceRgb: sourceRgb,
      scale: 1,
      layerCache: null,
      innerX0: innerX0,
      innerY0: innerY0,
      visibleWidth: req.width,
      visibleHeight: req.height,
      contextMargin: computeReq.contextMargin
   };
   computeTarget.detailPreviewMode = desiredMode;
   this.appState.cache.detailTarget = computeTarget;
   this.appState.cache.detail = {
      x0: req.x0,
      y0: req.y0,
      width: req.width,
      height: req.height,
      rgb: visibleRgb,
      scale: 1,
      layerCache: null,
      computeTarget: computeTarget,
      zoom: this.appState.preview.zoomScale,
      originalBitmap: originalBitmap,
      currentBitmap: aceRenderBitmapFromRgb(req.width, req.height, visibleRgb),
      currentRgb: visibleRgb,
      mode: "detail crop",
      detailPreviewMode: desiredMode,
      immediate: !!immediate
   };
   if (desiredMode === "source-only") {
      this.clearDetailProtectedOverlay();
      if (this.discardStaleDetailWork(detailToken, "Stale native detail discarded")) {
         this.appState.cache.detail = null;
         this.appState.cache.detailTarget = null;
         return;
      }
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      if (this.detailAdjustmentIdleTimer)
         this.detailAdjustmentIdleTimer.stop();
      this.refreshPreviewStatus(this.describeLoadedSource(), req.responsiveGlobalPreview ? "Preview: responsive detail crop" : "Preview: detail crop");
      return;
   }
   this.setPendingPreviewStage("Processing detail...");
   var detailTiming = { items: [] };
   var processStartMs = Date.now();
   var self = this;
   aceWithSuppressedEventYields(function() {
      self.rebuildProcessedDetailPreview(detailTiming, "Detail preview");
   });
   var processMs = Date.now() - processStartMs;
   if (this.discardStaleDetailWork(detailToken, "Stale native detail discarded")) {
      this.appState.cache.detail = null;
      this.appState.cache.detailTarget = null;
      return;
   }
   this.detailPreviewPendingNavigation = false;
   this.detailPreviewPendingAdjustment = false;
   if (this.detailAdjustmentIdleTimer)
      this.detailAdjustmentIdleTimer.stop();
   this.refreshPreviewStatus(this.describeLoadedSource(), this.currentViewNeedsScaleMaps() ? (this.scaleMapDisplayQuality || "Accurate high-res map") : (req.responsiveGlobalPreview ? "Preview: responsive detail crop" : "Preview: detail crop"));
   var totalMs = Date.now() - detailStartMs;
   if (totalMs >= ACE_DETAIL_TIMING_LOG_THRESHOLD_MS) {
      var untrackedMs = Math.max(0, totalMs - readMs - prepMs - processMs);
      aceDevelopmentConsoleWriteLine("[ACE] Slow native detail refresh | total=" + totalMs + " ms" +
         " setup=" + untrackedMs + " ms read=" + readMs + " ms prep=" + prepMs + " ms process=" + processMs + " ms" +
         " visible=" + req.width + "x" + req.height +
         " compute=" + computeReq.width + "x" + computeReq.height +
         " margin=" + computeReq.contextMargin +
         " zoom=" + this.getZoomReadout() +
         " view=" + this.appState.preview.viewMode +
         " hasEffect=" + (this.appState.params.hasEffect() ? "yes" : "no") +
         " lasso=" + (this.hasLassoSelection() ? "yes" : "no") +
         " plainPreview=" + (plainPreviewOnly ? "yes" : "no") +
         " | " + aceTimingSummary(detailTiming, 10));
   }
   } finally {
      var deferredChanges = this.deferredEffectChangesDuringDetail || null;
      var deferredEffect = this.deferredEffectChangeDuringDetail || null;
      var replayNavigationDetail = !!this.detailPreviewRefreshAfterActiveWork;
      var replayAdjustmentDetail = !!this.detailAdjustmentRefreshAfterActiveWork;
      this.detailRefreshTimerToken = null;
      this.detailAdjustmentTimerToken = null;
      this.deferredEffectChangesDuringDetail = null;
      this.deferredEffectChangeDuringDetail = null;
      this.detailPreviewRefreshAfterActiveWork = false;
      this.detailAdjustmentRefreshAfterActiveWork = false;
      this.detailWorkActive = false;
      this.detailWorkToken = null;
      if (this.applyCoalescedDeferredEffectChanges(deferredChanges, deferredEffect)) {
         // The coalesced update schedules any required native detail refresh itself.
      } else if (replayAdjustmentDetail && this.detailPreviewPendingAdjustment)
         this.schedulePendingDetailAdjustmentRefresh();
      else if (replayNavigationDetail && this.detailPreviewPendingNavigation)
         this.scheduleDetailPreviewRefresh();
   }
};

AstroContrastEnhancerDialog.prototype.clampPan = function() {
   var bitmap = this.appState.cache.draftBitmap;
   if (!bitmap || this.appState.preview.zoomMode === "fit") {
      this.appState.preview.panX = 0;
      this.appState.preview.panY = 0;
      return;
   }
   var scale = this.appState.preview.zoomScale;
   var overX = Math.max(0, bitmap.width * scale - this.preview.width);
   var overY = Math.max(0, bitmap.height * scale - this.preview.height);
   var limitX = overX * 0.5;
   var limitY = overY * 0.5;
   this.appState.preview.panX = aceClamp(this.appState.preview.panX, -limitX, limitX);
   this.appState.preview.panY = aceClamp(this.appState.preview.panY, -limitY, limitY);
};

AstroContrastEnhancerDialog.prototype.sourcePointFromPreview = function(x, y) {
   var bmp = this.previewGestureInputBitmap || this.getCurrentPreviewBitmap();
   var displayRect = this.getPreviewInputDisplayRect(bmp);
   if (!bmp || !displayRect)
      return null;
   var scale = this.getCurrentViewportScale(bmp);
   var bx = (x - displayRect.x0) / Math.max(ACE_EPSILON, scale);
   var by = (y - displayRect.y0) / Math.max(ACE_EPSILON, scale);
   if (bx < 0 || by < 0 || bx >= bmp.width || by >= bmp.height)
      return null;
   var source = this.appState.cache.source;
   if (this.previewGestureDetail && bmp === this.previewGestureDetail.bitmap) {
      return {
         x: aceClamp(this.previewGestureDetail.x0 + bx, 0, source.width - 1),
         y: aceClamp(this.previewGestureDetail.y0 + by, 0, source.height - 1)
      };
   }
   if (this.isDetailBitmap(bmp) && this.appState.cache.detail) {
      return {
         x: aceClamp(this.appState.cache.detail.x0 + bx, 0, source.width - 1),
         y: aceClamp(this.appState.cache.detail.y0 + by, 0, source.height - 1)
      };
   }
   var draft = this.appState.cache.draft;
   if (!draft)
      return null;
   return {
      x: aceClamp(bx * source.width / Math.max(1, draft.width), 0, source.width - 1),
      y: aceClamp(by * source.height / Math.max(1, draft.height), 0, source.height - 1)
   };
};

AstroContrastEnhancerDialog.prototype.previewPointFromSource = function(point, bitmap) {
   if (this.previewGestureInputBitmap)
      bitmap = this.previewGestureInputBitmap;
   var displayRect = this.getPreviewInputDisplayRect(bitmap);
   if (!point || !bitmap || !displayRect)
      return null;
   var bx;
   var by;
   var source = this.appState.cache.source;
   if (this.previewGestureDetail && bitmap === this.previewGestureDetail.bitmap) {
      bx = point.x - this.previewGestureDetail.x0;
      by = point.y - this.previewGestureDetail.y0;
   } else if (this.isDetailBitmap(bitmap) && this.appState.cache.detail) {
      bx = point.x - this.appState.cache.detail.x0;
      by = point.y - this.appState.cache.detail.y0;
   } else {
      var draft = this.appState.cache.draft;
      if (!draft || !source.width || !source.height)
         return null;
      bx = point.x * draft.width / Math.max(1, source.width);
      by = point.y * draft.height / Math.max(1, source.height);
   }
   var scale = this.getCurrentViewportScale(bitmap);
   return {
      x: displayRect.x0 + bx * scale,
      y: displayRect.y0 + by * scale
   };
};

AstroContrastEnhancerDialog.prototype.drawLassoOverlay = function(g, bitmap) {
   if (this.processingMode !== "lasso" || !bitmap || this.appState.preview.viewMode === "star")
      return;
   var points = this.lassoDrawing ? this.lassoDrawPoints : this.appState.lassoPoints;
   if (!points || points.length < 2)
      return;
   var screenPoints = [];
   var minX = 1.0e9;
   var minY = 1.0e9;
   var maxX = -1.0e9;
   var maxY = -1.0e9;
   for (var p = 0; p < points.length; ++p) {
      var sp = this.previewPointFromSource(points[p], bitmap);
      if (sp) {
         screenPoints.push(sp);
         minX = Math.min(minX, sp.x);
         minY = Math.min(minY, sp.y);
         maxX = Math.max(maxX, sp.x);
         maxY = Math.max(maxY, sp.y);
      }
   }
   if (screenPoints.length < 2)
      return;

   var closed = !this.lassoDrawing && screenPoints.length > 2;
   var drawPath = function(color, width, dx, dy) {
      g.pen = new Pen(color, width);
      var previous = screenPoints[0];
      for (var i = 1; i < screenPoints.length; ++i) {
         var current = screenPoints[i];
         g.drawLine(Math.round(previous.x + dx), Math.round(previous.y + dy), Math.round(current.x + dx), Math.round(current.y + dy));
         previous = current;
      }
      if (closed) {
         var first = screenPoints[0];
         g.drawLine(Math.round(previous.x + dx), Math.round(previous.y + dy), Math.round(first.x + dx), Math.round(first.y + dy));
      }
   };
   var drawScreenPath = function(pathPoints, color, width) {
      if (!pathPoints || pathPoints.length < 2)
         return;
      g.pen = new Pen(color, width);
      var previous = pathPoints[0];
      for (var i = 1; i < pathPoints.length; ++i) {
         var current = pathPoints[i];
         g.drawLine(Math.round(previous.x), Math.round(previous.y), Math.round(current.x), Math.round(current.y));
         previous = current;
      }
      if (pathPoints.length > 2) {
         var first = pathPoints[0];
         g.drawLine(Math.round(previous.x), Math.round(previous.y), Math.round(first.x), Math.round(first.y));
      }
   };
   if (this.lassoDrawing) {
      drawPath(0xff101010, 3, 1, 1);
      drawPath(0xffffd277, 1, 0, 0);
      return;
   }

   if (this.lassoMoving || this.lassoHoverInside) {
      var activeColor = this.appState.lassoInverted ? 0xff74d6ff : 0xfff4c542;
      drawPath(0xd0000000, this.lassoMoving ? 8 : 7, 0, 0);
      drawPath(activeColor, this.lassoMoving ? 5 : 4, 0, 0);
      drawPath(0xffffffff, 2, 0, 0);
      drawPath(this.appState.lassoInverted ? 0x9074d6ff : 0x90f4c542, 1, 3, 3);

      var handleRadius = this.lassoMoving ? 5 : 4;
      var handleColor = this.appState.lassoInverted ? 0xff74d6ff : (this.lassoMoving ? 0xffffdf72 : 0xffffc928);
      var handles = [
         { x: minX, y: minY },
         { x: maxX, y: minY },
         { x: minX, y: maxY },
         { x: maxX, y: maxY },
         { x: (minX + maxX) * 0.5, y: minY },
         { x: (minX + maxX) * 0.5, y: maxY },
         { x: minX, y: (minY + maxY) * 0.5 },
         { x: maxX, y: (minY + maxY) * 0.5 }
      ];
      g.pen = new Pen(0xff101010, 2);
      g.brush = new Brush(handleColor);
      for (var h = 0; h < handles.length; ++h)
         g.drawEllipse(Math.round(handles[h].x - handleRadius), Math.round(handles[h].y - handleRadius),
                       Math.round(handles[h].x + handleRadius), Math.round(handles[h].y + handleRadius));
   } else {
      drawPath(0xc0000000, 5, 1, 1);
      drawPath(this.appState.lassoInverted ? 0xff74d6ff : 0xffd8ad2f, 3, 0, 0);
      drawPath(0xd0ffffff, 1, 0, 0);
   }

   if (this.featherAdjusting && closed && this.featherSlider) {
      var featherPx = Math.max(0, this.featherSlider.value);
      if (featherPx > 0 && this.appState.cache && this.appState.cache.source) {
         var cxSource = 0;
         var cySource = 0;
         for (var fp = 0; fp < points.length; ++fp) {
            cxSource += points[fp].x;
            cySource += points[fp].y;
         }
         cxSource /= Math.max(1, points.length);
         cySource /= Math.max(1, points.length);
         var outer = [];
         var inner = [];
         for (var oi = 0; oi < points.length; ++oi) {
            var vx = points[oi].x - cxSource;
            var vy = points[oi].y - cySource;
            var len = Math.sqrt(vx * vx + vy * vy);
            if (len <= ACE_EPSILON)
               continue;
            var nx = vx / len;
            var ny = vy / len;
            var innerStep = Math.min(featherPx, len * 0.75);
            var outerScreen = this.previewPointFromSource({ x: points[oi].x + nx * featherPx, y: points[oi].y + ny * featherPx }, bitmap);
            var innerScreen = this.previewPointFromSource({ x: points[oi].x - nx * innerStep, y: points[oi].y - ny * innerStep }, bitmap);
            if (outerScreen)
               outer.push(outerScreen);
            if (innerScreen)
               inner.push(innerScreen);
         }
         drawScreenPath(outer, 0xd0000000, 3);
         drawScreenPath(inner, 0xd0000000, 3);
         drawScreenPath(outer, this.appState.lassoInverted ? 0xee74d6ff : 0xeeffd45c, 2);
         drawScreenPath(inner, this.appState.lassoInverted ? 0xdd74d6ff : 0xddffd45c, 2);
      }
   }

   if (this.appState.lassoInverted) {
      var label = "INVERTED - outside active";
      var font = new Font;
      font.pixelSize = ACE_FONT_SMALL;
      font.bold = true;
      g.font = font;
      var lx = Math.round(Math.max(8, minX));
      var ly = Math.round(Math.max(22, minY - 22));
      var lw = Math.max(190, font.width(label) + 22);
      g.brush = new Brush(0xa0202020);
      g.pen = new Pen(0x5074d6ff, 1);
      g.drawRect(new Rect(lx, ly - 20, lx + lw, ly + 6));
      g.pen = new Pen(0xff74d6ff);
      g.drawText(lx + 8, ly, label);
   }
};

AstroContrastEnhancerDialog.prototype.handleLassoChanged = function(statusText, autoFocus) {
   var hasSelection = this.hasLassoSelection();
   if (hasSelection)
      this.clearNativeDetailForLassoGeometryChange();
   else {
      this.bumpDetailRefreshGeneration();
      this.stopPendingDetailRefreshes();
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      this.invalidateProtectedOverlay();
   }
   ++this.appState.lassoVersion;
   this.invalidateLassoMasks();
   if (autoFocus)
      this.autoFocusLassoSelection();
   var outlineOnly = this.canSettleLassoAsOutlineOnly();
   this.refreshLocalSelectionControls();
   if (!outlineOnly)
      this.rebuildProcessedDraftPreview();
   this.refreshPreviewStatus(this.describeLoadedSource(), statusText || (this.hasLassoSelection() ? "Lasso updated" : "Draw a lasso selection"));
   this.updatePreviewCursor();
   if (this.preview)
      this.preview.update();
   this.endLassoGeometryTransition();
   if (hasSelection && this.shouldUseDetailPreview() && !this.shouldSkipDetailPreviewForLocalEdit()) {
      this.detailPreviewPendingNavigation = true;
      this.scheduleDetailPreviewRefresh();
      this.refreshPreviewStatus(this.describeLoadedSource(), outlineOnly ? "Lasso active | detail pending" : "Lasso updated | detail pending");
   }
   this.clearLassoActionButtonFlash();
   this.refreshLocalSelectionControls();
};

AstroContrastEnhancerDialog.prototype.scheduleLassoChanged = function(statusText, autoFocus) {
   if (!this.selectionTransitionBusy)
      this.selectionTransitionBusy = true;
   this.pendingLassoStatusText = statusText || "Lasso updated";
   this.pendingLassoAutoFocus = !!autoFocus;
   this.refreshPreviewStatus(this.describeLoadedSource(), "Updating selection...");
   this.refreshLocalSelectionControls();
   this.updatePreviewCursor();
   if (this.deferredLassoUpdateTimer) {
      this.deferredLassoUpdateTimer.stop();
      this.deferredLassoUpdateTimer.start();
   } else {
      this.performDeferredLassoUpdate();
   }
};

AstroContrastEnhancerDialog.prototype.performDeferredLassoUpdate = function() {
   var statusText = this.pendingLassoStatusText || "Lasso updated";
   var autoFocus = !!this.pendingLassoAutoFocus;
   this.pendingLassoStatusText = "";
   this.pendingLassoAutoFocus = false;
   try {
      this.handleLassoChanged(statusText, autoFocus);
   } finally {
      this.endLassoGeometryTransition();
   }
};

AstroContrastEnhancerDialog.prototype.absorbPendingLassoBeforeEffectChange = function() {
   if (!this.pendingLassoStatusText)
      return;
   if (this.deferredLassoUpdateTimer)
      this.deferredLassoUpdateTimer.stop();
   this.pendingLassoStatusText = "";
   this.pendingLassoAutoFocus = false;
   if (this.hasLassoSelection())
      this.clearNativeDetailForLassoGeometryChange();
   else {
      this.bumpDetailRefreshGeneration();
      this.stopPendingDetailRefreshes();
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      this.invalidateProtectedOverlay();
   }
   ++this.appState.lassoVersion;
   this.invalidateLassoMasks();
   this.clearPendingLocalPreview(true);
   this.refreshLocalSelectionControls();
   this.updatePreviewCursor();
   this.endLassoGeometryTransition();
};

AstroContrastEnhancerDialog.prototype.handleFeatherPreviewChanged = function(statusText) {
   this.featherAdjusting = true;
   this.refreshPreviewStatus(this.describeLoadedSource(), statusText || "Feather adjusting - release to update");
   if (this.preview)
      this.preview.update();
   this.refreshLocalSelectionControls();
};

AstroContrastEnhancerDialog.prototype.offsetLassoSelection = function(deltaPx) {
   var actionLabel = deltaPx >= 0 ? "expand" : "contract";
   if (!this.canStartLassoShapeAction(actionLabel))
      return;
   this.beginLassoGeometryTransition(actionLabel);
   this.flashLassoActionButton(deltaPx >= 0 ? this.expandLassoButton : this.contractLassoButton,
      deltaPx >= 0 ? "Expand..." : "Contract...");
   if (this.processingMode !== "lasso")
      this.setProcessingMode("lasso");
   var points = this.appState.lassoPoints;
   var source = this.appState.cache.source;
   var beforeInfo = aceLassoGeometryInfo(points);
   var sign = deltaPx < 0 ? -1 : 1;
   var adaptiveDelta = Math.max(
      Math.abs(deltaPx),
      Math.min(160, Math.max(18, Math.min(beforeInfo.width, beforeInfo.height) * 0.04))
   );
   deltaPx = sign * adaptiveDelta;
   var cx = 0;
   var cy = 0;
   for (var i = 0; i < points.length; ++i) {
      cx += points[i].x;
      cy += points[i].y;
   }
   cx /= Math.max(1, points.length);
   cy /= Math.max(1, points.length);
   var next = [];
   for (var p = 0; p < points.length; ++p) {
      var dx = points[p].x - cx;
      var dy = points[p].y - cy;
      var len = Math.max(ACE_EPSILON, Math.sqrt(dx * dx + dy * dy));
      var scale = Math.max(0.05, (len + deltaPx) / len);
      next.push({
         x: aceClamp(cx + dx * scale, 0, Math.max(0, source.width - 1)),
         y: aceClamp(cy + dy * scale, 0, Math.max(0, source.height - 1))
      });
   }
   var afterInfo = aceLassoGeometryInfo(next);
   if (!afterInfo.valid) {
      this.clearLassoActionButtonFlash();
      this.refreshPreviewStatus(this.describeLoadedSource(), deltaPx >= 0 ? "Selection too small to expand" : "Selection too small to contract");
      this.endLassoGeometryTransition();
      return;
   }
   if (deltaPx > 0 && afterInfo.area <= beforeInfo.area) {
      this.clearLassoActionButtonFlash();
      this.refreshPreviewStatus(this.describeLoadedSource(), "Expand blocked: selection would shrink");
      this.endLassoGeometryTransition();
      return;
   }
   if (deltaPx < 0 && afterInfo.area >= beforeInfo.area) {
      this.clearLassoActionButtonFlash();
      this.refreshPreviewStatus(this.describeLoadedSource(), "Contract blocked");
      this.endLassoGeometryTransition();
      return;
   }
   this.appState.lassoPoints = next;
   this.lastLocalAction = deltaPx >= 0 ? "expanded" : "contracted";
   this.markLassoGeometryDirty();
   this.refreshPreviewStatus(this.describeLoadedSource(), deltaPx >= 0 ? "Expand..." : "Contract...");
   if (this.preview)
      this.preview.update();
   this.scheduleLassoChanged(deltaPx >= 0 ? "Lasso: expanded" : "Lasso: contracted");
};

AstroContrastEnhancerDialog.prototype.clearPendingLocalPreview = function(preserveDetail) {
   var cache = this.appState.cache;
   cache.pendingRgb = null;
   cache.pendingBitmap = null;
   cache.pendingDisplayRgb = null;
   cache.pendingDisplayBitmap = null;
   cache.pendingDisplayGain = 1;
   cache.pendingDisplayProxy = "";
   cache.pendingActive = false;
   cache.pendingDraftStateKey = "";
   if (preserveDetail) {
      this.stopPendingDetailRefreshes();
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
   } else {
      this.clearDetailPreviewState();
   }
   if (this.processingMode === "lasso" && cache.workingRgb) {
      cache.currentRgb = cache.workingRgb;
      cache.currentBitmap = cache.workingBitmap;
   }
};

AstroContrastEnhancerDialog.prototype.resetEffectSlidersSilently = function() {
   this.appState.params.reset();
   this.textureSlider.setValue(0);
   this.claritySlider.setValue(0);
   this.dehazeSlider.setValue(0);
   this.refreshTextureModeUi();
   this.refreshClarityModeUi();
   if (this.enhancementControlBay)
      this.enhancementControlBay.update();
};

AstroContrastEnhancerDialog.prototype.setEffectSlidersSilently = function(params) {
   this.appState.params.texture = params ? params.texture : 0;
   this.appState.params.clarity = params ? params.clarity : 0;
   this.appState.params.dehaze = params ? params.dehaze : 0;
   this.appState.params.textureMode = aceNormalizeTextureMode(params ? params.textureMode : this.appState.params.textureMode);
   this.appState.params.clarityMode = aceNormalizeClarityMode(params ? params.clarityMode : this.appState.params.clarityMode);
   this.appState.params.clarityV2Tuning = aceNormalizeClarityV2Tuning(params ? params.clarityV2Tuning : this.appState.params.clarityV2Tuning);
   this.textureSlider.setValue(this.appState.params.texture);
   this.claritySlider.setValue(this.appState.params.clarity);
   this.dehazeSlider.setValue(this.appState.params.dehaze);
   this.refreshTextureModeUi();
   this.refreshClarityModeUi();
   if (this.enhancementControlBay)
      this.enhancementControlBay.update();
};

AstroContrastEnhancerDialog.prototype.pushUndoState = function() {
   var cache = this.appState.cache;
   if (!cache.workingRgb)
      return;
   this.appState.undoStack.push({
      rgb: new Float32Array(cache.workingRgb),
      bitmap: cache.workingBitmap,
      recipe: aceCopyEditRecipe(this.appState.editRecipe),
      globalParams: aceCopyParams(this.appState.globalParams),
      globalAdvanced: aceCopyAdvancedParams(this.appState.globalAdvanced),
      globalProtection: aceCopyProtectionOptions(this.appState.globalProtection)
   });
   while (this.appState.undoStack.length > ACE_MAX_UNDO_STEPS)
      this.appState.undoStack.shift();
};

AstroContrastEnhancerDialog.prototype.currentLassoEditRecord = function() {
   return {
      type: "lasso",
      params: aceCopyParams(this.appState.params),
      advanced: aceCopyAdvancedParams(this.appState.advanced),
      protection: aceCopyProtectionOptions(this.getProtectionOptions()),
      lassoPoints: aceCopyPointArray(this.appState.lassoPoints),
      feather: this.featherSlider ? this.featherSlider.value : ACE_FEATHER_DEFAULT,
      inverted: !!this.appState.lassoInverted,
      algorithmVersion: ACE_VERSION
   };
};

AstroContrastEnhancerDialog.prototype.currentGlobalEditRecord = function() {
   return {
      type: "global",
      params: aceCopyParams(this.appState.params),
      advanced: aceCopyAdvancedParams(this.appState.advanced),
      protection: aceCopyProtectionOptions(this.getProtectionOptions()),
      lassoPoints: [],
      feather: 0,
      inverted: false,
      algorithmVersion: ACE_VERSION
   };
};

AstroContrastEnhancerDialog.prototype.commitCurrentEdit = function() {
   if (this.processingMode === "lasso" || this.hasLassoSelection())
      this.commitLocalEdit();
   else
      this.commitGlobalEdit();
};

AstroContrastEnhancerDialog.prototype.commitGlobalEdit = function() {
   var cache = this.appState.cache;
   if (this.hasLassoSelection()) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "Global commit blocked while lasso is active");
      return;
   }
   if (!cache.draft || !cache.currentRgb) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "No image loaded");
      return;
   }
   if (!this.appState.params.hasEffect()) {
      this.appState.globalParams = new EffectParameters;
      this.appState.globalAdvanced = aceCopyAdvancedParams(this.appState.advanced);
      this.appState.globalProtection = aceCopyProtectionOptions(this.getProtectionOptions());
      this.refreshPreviewStatus(this.describeLoadedSource(), "Global adjustment cleared");
      return;
   }
   this.appState.globalParams = aceCopyParams(this.appState.params);
   this.appState.globalAdvanced = aceCopyAdvancedParams(this.appState.advanced);
   this.appState.globalProtection = aceCopyProtectionOptions(this.getProtectionOptions());
   this.appState.fullResolutionCache = null;
   this.appState.fullResolutionCacheKey = "";
   this.lastLocalAction = "committed";
   if (this.commitButton)
      this.commitButton.setActive(true);
   this.refreshPreviewStatus(this.describeLoadedSource(), "Global adjustment set");
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.preparePendingLocalEditForCommit = function() {
   var timing = this.localCommitTiming || null;
   var stage = Date.now();
   if (this.interactivePreviewTimer)
      this.interactivePreviewTimer.stop();
   if (this.detailAdjustmentIdleTimer)
      this.detailAdjustmentIdleTimer.stop();
   if (this.detailRefreshTimer)
      this.detailRefreshTimer.stop();
   if (timing && timing.items)
      timing.items.push({ label: "stop timers", ms: Date.now() - stage });
   stage = Date.now();
   this.detailRefreshTimerToken = null;
   this.detailAdjustmentTimerToken = null;
   this.detailPreviewRefreshAfterActiveWork = false;
   this.detailAdjustmentRefreshAfterActiveWork = false;
   this.applyCoalescedDeferredEffectChanges(this.deferredEffectChangesDuringDetail, this.deferredEffectChangeDuringDetail);
   this.deferredEffectChangesDuringDetail = null;
   this.deferredEffectChangeDuringDetail = null;
   this.detailPreviewPendingNavigation = false;
   this.detailPreviewPendingAdjustment = false;
   this.detailWorkActive = false;
   this.detailWorkToken = null;
   this.pendingInteractivePreviewLabel = "";
   this.pendingInteractivePreviewStatus = "";
   this.pendingInteractivePreviewInvalidateAdvanced = false;
   this.appState.cache.detail = null;
   this.appState.cache.detailTarget = null;
   this.invalidateProtectedOverlay();
   if (timing && timing.items)
      timing.items.push({ label: "settle state", ms: Date.now() - stage });
   stage = Date.now();
   var cache = this.appState.cache;
   var currentKey = this.localDraftProcessingStateKey();
   if (cache.pendingActive &&
       cache.pendingRgb &&
       cache.pendingDraftStateKey === currentKey &&
       this.localLassoDraftEditReady()) {
      if (timing && timing.items)
         timing.items.push({ label: "reuse current pending draft", ms: Date.now() - stage });
      return true;
   }
   this.setPendingPreviewStage("Preparing local commit | final protected draft...");
   if (timing && timing.items)
      timing.items.push({ label: "reuse rejected", ms: Date.now() - stage });
   stage = Date.now();
   this.rebuildProcessedDraftPreview();
   if (timing && timing.items)
      timing.items.push({ label: "final protected draft rebuild", ms: Date.now() - stage });
   return this.localLassoDraftEditReady();
};

AstroContrastEnhancerDialog.prototype.commitLocalEdit = function() {
   var commitStart = Date.now();
   var cache = this.appState.cache;
   this.exitBeforeAfterForEditChange();
   if (this.processingMode !== "lasso" && this.hasLassoSelection())
      this.processingMode = "lasso";
   if (this.processingMode !== "lasso" || !this.hasLassoSelection()) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "No local edit to commit");
      return;
   }
   if (!this.appState.params.hasEffect()) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "No adjustment to commit");
      return;
   }
   var commitTiming = { items: [] };
   this.localCommitTiming = commitTiming;
   try {
      this.preparePendingLocalEditForCommit();
   } finally {
      this.localCommitTiming = null;
   }
   cache = this.appState.cache;
   if (!cache.pendingRgb) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "No adjustment to commit");
      return;
   }
   var commitStage = Date.now();
   var commitLassoWeight = this.getLassoWeightForTarget(cache.draft);
   commitTiming.items.push({ label: "draft lasso mask", ms: Date.now() - commitStage });
   commitStage = Date.now();
   if (!this.lassoWeightIsRestrictive(commitLassoWeight)) {
      commitTiming.items.push({ label: "mask restrictive check", ms: Date.now() - commitStage });
      cache.pendingRgb = null;
      cache.pendingBitmap = null;
      cache.pendingDisplayRgb = null;
      cache.pendingDisplayBitmap = null;
      cache.pendingDisplayGain = 1;
      cache.pendingDisplayProxy = "";
      cache.pendingActive = false;
      cache.pendingDraftStateKey = "";
      this.refreshPreviewStatus(this.describeLoadedSource(), "Commit blocked: selection mask is not restrictive");
      this.refreshLocalSelectionControls();
      if (this.preview)
         this.preview.update();
      return;
   }
   commitTiming.items.push({ label: "mask restrictive check", ms: Date.now() - commitStage });
   commitStage = Date.now();
   this.pushUndoState();
   commitTiming.items.push({ label: "push undo state", ms: Date.now() - commitStage });
   commitStage = Date.now();
   var committedEditRecord = this.currentLassoEditRecord();
   this.bumpCommitGeneration();
   cache.workingRgb = cache.pendingRgb;
   cache.workingBitmap = cache.pendingBitmap || aceRenderBitmapFromRgb(cache.draft.width, cache.draft.height, cache.workingRgb);
   cache.workingLayerCache = null;
   cache.currentRgb = cache.workingRgb;
   cache.currentBitmap = cache.workingBitmap;
   cache.pendingRgb = null;
   cache.pendingBitmap = null;
   cache.pendingDisplayRgb = null;
   cache.pendingDisplayBitmap = null;
   cache.pendingDisplayGain = 1;
   cache.pendingDisplayProxy = "";
   cache.pendingActive = false;
   cache.pendingDraftStateKey = "";
   cache.detail = null;
   cache.detailTarget = null;
   this.detailPreviewPendingNavigation = false;
   this.detailPreviewPendingAdjustment = false;
   if (this.detailAdjustmentIdleTimer)
      this.detailAdjustmentIdleTimer.stop();
   if (this.detailRefreshTimer)
      this.detailRefreshTimer.stop();
   this.appState.editRecipe.push(committedEditRecord);
   this.appState.fullResolutionCache = null;
   this.appState.fullResolutionCacheKey = "";
   this.appState.redoStack = [];
   this.resetPreviewInteractionState(true);
   this.appState.lassoPoints = [];
   this.appState.lassoInverted = false;
   this.localSelectionNewActive = false;
   ++this.appState.lassoVersion;
   this.lassoDrawing = false;
   this.lassoMoving = false;
   this.lassoHoverInside = false;
   this.lassoDragOperation = "none";
   this.lassoDrawPoints = [];
   this.lassoMoveStartPoint = null;
   this.lassoMoveOriginalPoints = [];
   this.invalidateLassoMasks();
   this.appState.preview.showBefore = false;
   this.appState.preview.showMask = false;
   this.appState.preview.viewMode = "preview";
   if (this.beforeAfterPill)
      this.beforeAfterPill.setActive(false);
   this.setProcessingMode("full");
   this.committedDetailPreviewFrozen = false;
   this.lastLocalAction = "committed";
   if (this.commitButton)
      this.commitButton.setActive(true);
   this.refreshLocalSelectionControls();
   this.refreshPreviewStatus(this.describeLoadedSource(), "Committed");
   commitTiming.items.push({ label: "commit state update", ms: Date.now() - commitStage });
   aceDevelopmentConsoleWriteLine("[ACE] Local selection commit timing | total=" + (Date.now() - commitStart) + " ms" +
      " draft=" + (cache.draft ? cache.draft.width + "x" + cache.draft.height : "n/a") +
      " points=" + (this.appState.editRecipe.length ? this.appState.editRecipe[this.appState.editRecipe.length - 1].lassoPoints.length : 0) +
      " feather=" + (this.appState.editRecipe.length ? this.appState.editRecipe[this.appState.editRecipe.length - 1].feather : 0) +
      " recipe=" + this.appState.editRecipe.length +
      " | " + aceTimingSummary(commitTiming, 8));
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.cancelLocalEdit = function() {
   if (this.processingMode !== "lasso" || !this.appState.cache.pendingActive) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "No pending edit");
      return;
   }
   this.resetEffectSlidersSilently();
   this.setAdvancedSlidersSilently(this.appState.advanced);
   this.refreshAdvancedUi();
   this.clearPendingLocalPreview(true);
   this.lastLocalAction = "canceled";
   if (this.commitButton)
      this.commitButton.setActive(false);
   this.rebuildProcessedDraftPreview();
   this.refreshPreviewStatus(this.describeLoadedSource(), "Local edit canceled");
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.undoLocalEdit = function() {
   var cache = this.appState.cache;
   if (cache.pendingActive) {
      this.cancelLocalEdit();
      this.refreshPreviewStatus(this.describeLoadedSource(), "Pending edit canceled; undo again for history");
      return;
   }
   if (!this.appState.undoStack.length) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "Nothing to undo");
      return;
   }
   this.appState.redoStack.push({
      rgb: new Float32Array(cache.workingRgb),
      bitmap: cache.workingBitmap,
      recipe: aceCopyEditRecipe(this.appState.editRecipe),
      globalParams: aceCopyParams(this.appState.globalParams),
      globalAdvanced: aceCopyAdvancedParams(this.appState.globalAdvanced),
      globalProtection: aceCopyProtectionOptions(this.appState.globalProtection)
   });
   var previous = this.appState.undoStack.pop();
   cache.workingRgb = new Float32Array(previous.rgb);
   cache.workingBitmap = previous.bitmap || aceRenderBitmapFromRgb(cache.draft.width, cache.draft.height, cache.workingRgb);
   cache.workingLayerCache = null;
   cache.currentRgb = cache.workingRgb;
   cache.currentBitmap = cache.workingBitmap;
   this.appState.editRecipe = aceCopyEditRecipe(previous.recipe);
   this.appState.globalParams = aceCopyParams(previous.globalParams);
   this.appState.globalAdvanced = aceCopyAdvancedParams(previous.globalAdvanced);
   if (this.processingMode === "full")
      this.appState.advanced = aceCopyAdvancedParams(this.appState.globalAdvanced);
   this.appState.globalProtection = aceCopyProtectionOptions(previous.globalProtection);
   if (this.processingMode === "full")
      this.setEffectSlidersSilently(this.appState.globalParams);
   if (this.processingMode === "full")
      this.setAdvancedSlidersSilently(this.appState.globalAdvanced);
   this.refreshAdvancedUi();
   this.appState.fullResolutionCache = null;
   this.appState.fullResolutionCacheKey = "";
   this.clearPendingLocalPreview(true);
   this.refreshPreviewStatus(this.describeLoadedSource(), "Undo");
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.redoLocalEdit = function() {
   var cache = this.appState.cache;
   if (cache.pendingActive) {
      this.cancelLocalEdit();
      this.refreshPreviewStatus(this.describeLoadedSource(), "Pending edit canceled; redo again for history");
      return;
   }
   if (!this.appState.redoStack.length) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "Nothing to redo");
      return;
   }
   this.pushUndoState();
   var next = this.appState.redoStack.pop();
   cache.workingRgb = new Float32Array(next.rgb);
   cache.workingBitmap = next.bitmap || aceRenderBitmapFromRgb(cache.draft.width, cache.draft.height, cache.workingRgb);
   cache.workingLayerCache = null;
   cache.currentRgb = cache.workingRgb;
   cache.currentBitmap = cache.workingBitmap;
   this.appState.editRecipe = aceCopyEditRecipe(next.recipe);
   this.appState.globalParams = aceCopyParams(next.globalParams);
   this.appState.globalAdvanced = aceCopyAdvancedParams(next.globalAdvanced);
   if (this.processingMode === "full")
      this.appState.advanced = aceCopyAdvancedParams(this.appState.globalAdvanced);
   this.appState.globalProtection = aceCopyProtectionOptions(next.globalProtection);
   if (this.processingMode === "full")
      this.setEffectSlidersSilently(this.appState.globalParams);
   if (this.processingMode === "full")
      this.setAdvancedSlidersSilently(this.appState.globalAdvanced);
   this.refreshAdvancedUi();
   this.appState.fullResolutionCache = null;
   this.appState.fullResolutionCacheKey = "";
   this.clearPendingLocalPreview(true);
   this.refreshPreviewStatus(this.describeLoadedSource(), "Redo");
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.hasOutputImage = function() {
   return !!(this.appState && this.appState.cache && this.appState.cache.sourceRgb && this.appState.cache.source.width > 0);
};

AstroContrastEnhancerDialog.prototype.fullResolutionRecipeKey = function() {
   var cache = this.appState.cache;
   return [
      cache.source.viewId,
      cache.source.width,
      cache.source.height,
      cache.source.version,
      ACE_VERSION,
      JSON.stringify(this.appState.globalParams),
      JSON.stringify(this.appState.globalAdvanced),
      JSON.stringify(this.appState.globalProtection),
      JSON.stringify(this.appState.editRecipe)
   ].join("|");
};

AstroContrastEnhancerDialog.prototype.fullResolutionGlobalRecipeKey = function() {
   var cache = this.appState.cache;
   return [
      cache.source.viewId,
      cache.source.width,
      cache.source.height,
      cache.source.version,
      ACE_VERSION,
      JSON.stringify(this.appState.globalParams),
      JSON.stringify(this.appState.globalAdvanced),
      JSON.stringify(this.appState.globalProtection)
   ].join("|");
};

AstroContrastEnhancerDialog.prototype.fullResolutionRecipeTimingSummary = function() {
   var cache = this.appState.cache;
   var params = this.appState.globalParams || new EffectParameters;
   var recipe = this.appState.editRecipe || [];
   var activeLocal = 0;
   var localPixels = 0;
   var largestLocalPixels = 0;
   var largestLocalIndex = 0;
   var sourceWidth = cache && cache.source ? cache.source.width : 0;
   var sourceHeight = cache && cache.source ? cache.source.height : 0;
   for (var i = 0; i < recipe.length; ++i) {
      var edit = recipe[i];
      if (!edit || edit.type !== "lasso" || !edit.params || !EffectParameters.prototype.hasEffect.call(edit.params))
         continue;
      ++activeLocal;
      if (sourceWidth > 0 && sourceHeight > 0 && edit.lassoPoints && edit.lassoPoints.length >= 3) {
         var rect = this.fullResolutionLassoRect(sourceWidth, sourceHeight, edit);
         var pixels = Math.max(0, rect.x1 - rect.x0) * Math.max(0, rect.y1 - rect.y0);
         localPixels += pixels;
         if (pixels > largestLocalPixels) {
            largestLocalPixels = pixels;
            largestLocalIndex = i + 1;
         }
      }
   }
   return "source=" + (cache && cache.source ? (cache.source.viewId || "Image") : "Image") +
      " size=" + sourceWidth + "x" + sourceHeight +
      " global=" + (EffectParameters.prototype.hasEffect.call(params) ? "yes" : "no") +
      " T=" + (params.texture || 0) +
      " C=" + (params.clarity || 0) +
      " D=" + (params.dehaze || 0) +
      " active_local=" + activeLocal +
      " local_pixels=" + localPixels +
      " largest_local=" + largestLocalIndex + ":" + largestLocalPixels +
      " preview_cap_px=" + ACE_DETAIL_RESPONSIVE_LOCAL_MAX_PIXELS +
      " preview_cap_applies_to_full_output=no" +
      " full_resolution_output_uncapped=yes" +
      " recipe_edits=" + recipe.length;
};

AstroContrastEnhancerDialog.prototype.setOutputRendering = function(active, statusText) {
   this.outputRendering = !!active;
   if (!this.outputRendering) {
      this.outputWaitTitle = "";
      this.outputWaitSubtitle = "";
      this.lastOutputRenderFinishedMs = Date.now();
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      if (this.detailAdjustmentIdleTimer)
         this.detailAdjustmentIdleTimer.stop();
   }
   var enabled = !this.outputRendering;
   var controls = [
      this.textureSlider,
      this.claritySlider,
      this.dehazeSlider,
      this.featherSlider,
      this.sourceCombo,
      this.starlessRadio,
      this.starsPresentRadio,
      this.backgroundProtection,
      this.starProtection,
      this.protectSky,
      this.preventDark,
      this.protectStars,
      this.protectHalos,
      this.newImageButton,
      this.applyButton,
      this.saveCurrentMaskButton,
      this.saveMaskAuditButton,
      this.saveComputeAuditButton,
      this.fullTimingAuditButton,
      this.performanceFlowAuditButton,
      this.revertButton,
      this.closeButton,
      this.commitButton,
      this.cancelEditButton,
      this.undoButton,
      this.redoButton,
      this.expandLassoButton,
      this.contractLassoButton
   ];
   if (this.advancedControls)
      for (var a = 0; a < this.advancedControls.length; ++a)
         controls.push(this.advancedControls[a]);
   controls.push(this.advancedClarityResponseSelector);
   controls.push(this.advancedButton);
   controls.push(this.advancedDefaultsButton);
   controls.push(this.resetEnhancementButton);
   controls.push(this.clarityModeLegacyButton);
   controls.push(this.clarityModeV2Button);
   controls.push(this.clarityModeV3Button);
   controls.push(this.clarityModeV4Button);
   controls.push(this.clarityModeFeatureFitButton);
   controls.push(this.clarityModeDualZoneOptButton);
   controls.push(this.clarityModeDualZoneBoostButton);
   controls.push(this.textureModeSelector);
   controls.push(this.dehazeModeSelector);
   controls.push(this.clarityModeSelector);
   for (var i = 0; i < controls.length; ++i) {
      var c = controls[i];
      if (!c)
         continue;
      if (typeof c.setEnabled === "function")
         c.setEnabled(enabled);
      else
         c.enabled = enabled;
   }
   if (statusText)
      this.setFooterStatus(statusText, this.outputWaitTitle ? ACE_COLORS.warning : null);
   this.updatePreviewCursor();
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.setOutputProgress = function(text, waitTitle, waitSubtitle) {
   this.outputWaitTitle = waitTitle || "";
   this.outputWaitSubtitle = waitSubtitle || "";
   this.refreshPreviewStatus(this.describeLoadedSource(), text);
   this.setFooterStatus(text, this.outputWaitTitle ? ACE_COLORS.warning : null);
   if (typeof console !== "undefined" && console && typeof console.writeln === "function")
      console.writeln("[ACE] " + text);
   else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
      Console.writeln("[ACE] " + text);
   if (this.outputRendering && this.preview)
      this.preview.update();
   if (typeof CoreApplication !== "undefined" && typeof CoreApplication.processEvents === "function")
      CoreApplication.processEvents();
};

AstroContrastEnhancerDialog.prototype.confirmFullResolutionRender = function(actionLabel) {
   if (!this.hasOutputImage())
      return false;
   var cache = this.appState.cache;
   var recipe = this.appState.editRecipe || [];
   var hasGlobalAdjustment = this.appState.globalParams &&
      EffectParameters.prototype.hasEffect.call(this.appState.globalParams);
   var globalEditCount = hasGlobalAdjustment ? 1 : 0;
   var totalAdjustmentCount = globalEditCount + recipe.length;
   var megapixels = Math.round(cache.source.width * cache.source.height / 100000) / 10;
   var text =
      actionLabel + " will render from the full-resolution source image.\n\n" +
      "Source: " + (cache.source.viewId || "Image") + "\n" +
      "Size: " + cache.source.width + " x " + cache.source.height + " (" + megapixels + " MP)\n" +
      "Output adjustments: " + totalAdjustmentCount + "\n" +
      "Global adjustment: " + (hasGlobalAdjustment ? "1 active" : "none") + "\n" +
      "Local edits: " + recipe.length + " committed\n\n";
   if (hasGlobalAdjustment || recipe.length)
      text += "This can take a while in PixInsight because final output is rendered at full resolution, not written from the preview cache.\n";
   else
      text += "No global or local adjustments are active; this will save a full-resolution source copy.\n";
   text += "\nContinue?";
   var answer = (new MessageBox(text, ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Question, StdButton_Yes, StdButton_No)).execute();
   return answer === StdButton_Yes;
};

AstroContrastEnhancerDialog.prototype.revertToSource = function() {
   if (!this.hasOutputImage()) {
      this.refreshPreviewStatus("No active image", "No active image loaded.");
      return;
   }
   var cache = this.appState.cache;
   var hasChanges = (this.appState.editRecipe && this.appState.editRecipe.length > 0) ||
      (this.appState.undoStack && this.appState.undoStack.length > 0) ||
      (this.appState.redoStack && this.appState.redoStack.length > 0) ||
      (cache.pendingActive || this.appState.params.hasEffect());
   if (hasChanges) {
      var answer = (new MessageBox(
         "Revert to the starting image?\n\nThis clears committed edits, pending edits, lasso state, and undo/redo history. The source PixInsight view is not modified.",
         ACE_TOOL_NAME + " " + ACE_VERSION,
         StdIcon_Question,
         StdButton_Yes,
         StdButton_No
      )).execute();
      if (answer !== StdButton_Yes)
         return;
   }
   cache.workingRgb = new Float32Array(cache.draft.rgb);
   cache.workingBitmap = cache.draftBitmap;
   cache.currentRgb = cache.workingRgb;
   cache.currentBitmap = cache.workingBitmap;
   cache.pendingRgb = null;
   cache.pendingBitmap = null;
   cache.pendingDisplayRgb = null;
   cache.pendingDisplayBitmap = null;
   cache.pendingDisplayGain = 1;
   cache.pendingDisplayProxy = "";
   cache.pendingActive = false;
   cache.workingLayerCache = null;
   cache.detail = null;
   this.appState.editRecipe = [];
   this.appState.globalParams = new EffectParameters;
   this.appState.globalProtection = aceCopyProtectionOptions(this.getProtectionOptions());
   this.appState.undoStack = [];
   this.appState.redoStack = [];
   this.appState.fullResolutionCache = null;
   this.appState.fullResolutionCacheKey = "";
   this.appState.lassoPoints = [];
   this.appState.lassoInverted = false;
   this.localSelectionNewActive = false;
   ++this.appState.lassoVersion;
   this.lassoDrawing = false;
   this.lassoMoving = false;
   this.lassoHoverInside = false;
   this.lassoDragOperation = "none";
   this.lassoDrawPoints = [];
   this.lastLocalAction = "reverted";
   this.invalidateLassoMasks();
   this.resetEffectSlidersSilently();
   if (this.commitButton)
      this.commitButton.setActive(false);
   this.rebuildProcessedPreviews("Reverted to starting image");
};

AstroContrastEnhancerDialog.prototype.lassoWeightForFullResolutionEdit = function(width, height, edit) {
   if (!edit || edit.type !== "lasso" || !edit.lassoPoints || edit.lassoPoints.length < 3)
      return null;
   var lassoPoints = aceFullResolutionLassoPoints(edit.lassoPoints);
   return aceBuildLassoWeightMap(
      width,
      height,
      0,
      0,
      1,
      1,
      lassoPoints,
      edit.feather || 0,
      !!edit.inverted
   );
};

AstroContrastEnhancerDialog.prototype.fullResolutionLassoRect = function(width, height, edit) {
   var advanced = aceCopyAdvancedParams(edit ? edit.advanced : null);
   var maxRadius = Math.max(
      edit && edit.params && edit.params.texture !== 0 ? ACE_TEXTURE_RADIUS * aceAdvancedFactor(advanced, "textureScale") : 0,
      edit && edit.params && edit.params.clarity !== 0 ? ACE_CLARITY_RADIUS * aceAdvancedFactor(advanced, "clarityScale") : 0,
      edit && edit.params && edit.params.dehaze !== 0 ? ACE_DEHAZE_VEIL_RADIUS * aceAdvancedFactor(advanced, "dehazeVeilSize") : 0
   );
   var margin = (edit && edit.feather ? edit.feather : 0) + maxRadius + 12;
   return aceLassoBounds(edit.lassoPoints, width, height, margin);
};

AstroContrastEnhancerDialog.prototype.addRenderTiming = function(timing, label, startMs) {
   timing.items.push({ label: label, ms: Date.now() - startMs });
};

AstroContrastEnhancerDialog.prototype.addRenderTimingDetails = function(timing, detailTiming) {
   if (!timing || !timing.items || !detailTiming || !detailTiming.items)
      return;
   for (var i = 0; i < detailTiming.items.length; ++i)
      timing.items.push(detailTiming.items[i]);
};

AstroContrastEnhancerDialog.prototype.printRenderTiming = function(timing, width, height) {
   var total = Date.now() - timing.start;
   var lines = [];
   lines.push("ACE Full-Resolution Render Timing" + (timing.auditLabel ? " - " + timing.auditLabel : ""));
   lines.push("Source: " + (timing.sourceId || this.appState.cache.source.viewId || "Image"));
   lines.push("Size: " + width + " x " + height + " x 3");
   lines.push("Output source: original full-resolution RGB");
   lines.push("Preview responsive cap applies to output: no");
   lines.push("Full-resolution output uncapped: yes");
   lines.push("Cache mode: " + (timing.cacheMode || (timing.forceFresh ? "fresh render" : "normal render")));
   if (timing.localPixelCount !== undefined)
      lines.push("Local output work: edits=" + (timing.localEditCount || 0) + ", pixels=" + timing.localPixelCount + ", largest=" + (timing.largestLocalIndex || 0) + ":" + (timing.largestLocalPixels || 0));
   for (var i = 0; i < timing.items.length; ++i) {
      var item = timing.items[i];
      var indent = item.label.indexOf(" detail - ") >= 0 ? "  " : "";
      lines.push(indent + item.label + ": " + (item.ms / 1000).toFixed(2) + " s");
   }
   lines.push("Total: " + (total / 1000).toFixed(2) + " s");
   var report = lines.join("\n");
   var detailedOutput = timing.auditLabel || ACE_DEVELOPMENT_CONSOLE_LOGS_ENABLED || ACE_DEBUG_CONTROLS_ENABLED;
   if (detailedOutput) {
      if (typeof console !== "undefined" && console && typeof console.writeln === "function")
         console.writeln(report);
      else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
         Console.writeln(report);
      aceConsoleWriteLine("[ACE] Full-resolution render timing" + (timing.auditLabel ? " [" + timing.auditLabel + "]" : "") + " | total=" + total + " ms" +
         " size=" + width + "x" + height +
         " source=" + (timing.sourceId || this.appState.cache.source.viewId || "Image") +
         " global=" + (timing.globalActive ? "yes" : "no") +
         " local_edits=" + (timing.localEditCount || 0) +
         " local_pixels=" + (timing.localPixelCount || 0) +
         " largest_local=" + (timing.largestLocalIndex || 0) + ":" + (timing.largestLocalPixels || 0) +
         (timing.forceFresh ? " cache=fresh" : " cache=normal") +
         " cache_mode=" + (timing.cacheMode || "render") +
         " source_rgb=original_full_resolution" +
         " preview_cap_applies_to_full_output=no" +
         " full_resolution_output_uncapped=yes" +
         " | " + aceTimingSummary(timing, 14));
   } else {
      aceConsoleWriteLine("[ACE] Full-resolution render complete | total=" + total + " ms" +
         " size=" + width + "x" + height +
         " global=" + (timing.globalActive ? "yes" : "no") +
         " local_edits=" + (timing.localEditCount || 0));
   }
   return total;
};

AstroContrastEnhancerDialog.prototype.applyFullResolutionOperation = function(width, height, rgb, params, protection, lassoWeight, advanced, timing, timingPrefix) {
   if (!params || !EffectParameters.prototype.hasEffect.call(params))
      return rgb;
   var dialog = this;
   return aceWithSuppressedEventYields(function() {
      var prefix = timingPrefix || "Operation";
      var previewData = {
         width: width,
         height: height,
         rgb: rgb,
         layerCache: null,
         starProtectionBase: null,
         starProtectionMaps: null,
         starProtectionKey: ""
      };
      advanced = aceCopyAdvancedParams(advanced);
      var effectiveProtection = aceCopyProtectionOptions(protection);
      effectiveProtection.advanced = advanced;
      if (lassoWeight)
         effectiveProtection.lassoAllowedWeight = lassoWeight;
      effectiveProtection.fastFullResolutionStarMask = true;
      effectiveProtection.rgbOnlyOutput = true;
      effectiveProtection.layerCacheRequirements = aceLayerCacheRequirementsForParams(params);
      previewData.layerCache = dialog.appState.processor.engine.buildLayerCache(width, height, rgb, advanced, timing, prefix, 1, effectiveProtection.layerCacheRequirements);
      var starMaps = dialog.appState.processor.getStarProtectionMaps(previewData, effectiveProtection, timing, prefix);
      effectiveProtection.starAllowedWeight = starMaps ? starMaps.allowedWeight : null;
      return dialog.appState.processor.engine.apply(width, height, rgb, params, previewData.layerCache, effectiveProtection, advanced, timing, prefix);
   });
};

AstroContrastEnhancerDialog.prototype.applyFullResolutionLassoEdit = function(width, height, rgb, edit, index, timing) {
   if (!edit || edit.type !== "lasso" || !edit.params || !EffectParameters.prototype.hasEffect.call(edit.params))
      return rgb;
   if (!edit.lassoPoints || edit.lassoPoints.length < 3)
      return rgb;
   var localStart = Date.now();
   var stage = localStart;
   var rect = this.fullResolutionLassoRect(width, height, edit);
   if (rect.x1 <= rect.x0 || rect.y1 <= rect.y0)
      return rgb;
   this.addRenderTiming(timing, "Local edit " + (index + 1) + " bounds", stage);
   stage = Date.now();
   var region = aceExtractRgbRect(width, height, rgb, rect);
   this.addRenderTiming(timing, "Local edit " + (index + 1) + " extract " + region.width + " x " + region.height, stage);
   stage = Date.now();
   var lassoPoints = aceFullResolutionLassoPoints(edit.lassoPoints);
   var localPrefix = "Local edit " + (index + 1);
   var lassoWeight = aceBuildFullResolutionLassoWeightMap(
      region.width,
      region.height,
      rect.x0,
      rect.y0,
      lassoPoints,
      edit.feather || 0,
      !!edit.inverted,
      timing,
      localPrefix
   );
   this.addRenderTiming(timing, "Local edit " + (index + 1) + " lasso weight " + edit.lassoPoints.length + "->" + lassoPoints.length + " pts", stage);
   stage = Date.now();
   var detailTiming = { items: [] };
   var processed = this.applyFullResolutionOperation(region.width, region.height, region.rgb, edit.params, edit.protection, lassoWeight, edit.advanced, detailTiming, localPrefix);
   this.addRenderTiming(timing, "Local edit " + (index + 1) + " process " + region.width + " x " + region.height, stage);
   stage = Date.now();
   aceWriteRgbRect(width, height, rgb, rect, processed);
   this.addRenderTiming(timing, "Local edit " + (index + 1) + " writeback", stage);
   this.addRenderTiming(timing, "Local edit " + (index + 1) + " total (" + region.width + " x " + region.height + ", " + edit.lassoPoints.length + "->" + lassoPoints.length + " pts)", localStart);
   this.addRenderTimingDetails(timing, detailTiming);
   aceDevelopmentConsoleWriteLine("[ACE] Full-resolution local edit timing | index=" + (index + 1) +
      " total=" + (Date.now() - localStart) + " ms" +
      " rect=" + region.width + "x" + region.height +
      " pixels=" + (region.width * region.height) +
      " source=" + width + "x" + height +
      " points=" + edit.lassoPoints.length + "->" + lassoPoints.length +
      " feather=" + (edit.feather || 0) +
      " texture=" + (edit.params ? edit.params.texture : 0) +
      " clarity=" + (edit.params ? edit.params.clarity : 0) +
      " dehaze=" + (edit.params ? edit.params.dehaze : 0) +
      " source_rgb=original_full_resolution" +
      " preview_cap_applies_to_full_output=no" +
      " | " + aceTimingSummary(detailTiming, 12));
   return rgb;
};

AstroContrastEnhancerDialog.prototype.renderFullResolutionOutput = function(options) {
   options = options || {};
   if (!this.hasOutputImage())
      return null;
   var cache = this.appState.cache;
   var key = this.fullResolutionRecipeKey();
   if (!options.forceFresh && this.appState.fullResolutionCache && this.appState.fullResolutionCacheKey === key) {
      aceDevelopmentConsoleWriteLine("[ACE] Full-resolution output cache hit | source=" + (cache.source.viewId || "Image") +
         " size=" + cache.source.width + "x" + cache.source.height +
         " source_rgb=original_full_resolution" +
         " preview_cap_applies_to_full_output=no");
      this.appState.fullResolutionCache.cacheHit = true;
      return this.appState.fullResolutionCache;
   }
   var width = cache.source.width;
   var height = cache.source.height;
   var timing = {
      start: Date.now(),
      items: [],
      sourceId: cache.source.viewId || "Image",
      auditLabel: options.auditLabel || "",
      forceFresh: !!options.forceFresh,
      cacheMode: options.forceFresh ? "forced fresh render" : "fresh render"
   };
   var stage = Date.now();
   var result = new Float32Array(cache.sourceRgb);
   this.addRenderTiming(timing, "Source copy", stage);
   var recipe = this.appState.editRecipe || [];
   var globalParams = aceCopyParams(this.appState.globalParams);
   var globalAdvanced = aceCopyAdvancedParams(this.appState.globalAdvanced);
   var globalProtection = aceCopyProtectionOptions(this.appState.globalProtection);
   var globalKey = this.fullResolutionGlobalRecipeKey();
   var localRecipe = [];
   for (var r = 0; r < recipe.length; ++r)
      if (recipe[r] && recipe[r].type === "lasso")
         localRecipe.push(recipe[r]);
   timing.globalActive = EffectParameters.prototype.hasEffect.call(globalParams);
   timing.localEditCount = localRecipe.length;
   timing.localPixelCount = 0;
   timing.largestLocalPixels = 0;
   timing.largestLocalIndex = 0;
   for (var lp = 0; lp < localRecipe.length; ++lp) {
      var localEdit = localRecipe[lp];
      if (!localEdit || !localEdit.params || !EffectParameters.prototype.hasEffect.call(localEdit.params) || !localEdit.lassoPoints || localEdit.lassoPoints.length < 3)
         continue;
      var localRect = this.fullResolutionLassoRect(width, height, localEdit);
      var localPixels = Math.max(0, localRect.x1 - localRect.x0) * Math.max(0, localRect.y1 - localRect.y0);
      timing.localPixelCount += localPixels;
      if (localPixels > timing.largestLocalPixels) {
         timing.largestLocalPixels = localPixels;
         timing.largestLocalIndex = lp + 1;
      }
   }
   aceDevelopmentConsoleWriteLine("[ACE] Full-resolution output path audit | source_rgb=original_full_resolution" +
      " preview_cap_px=" + ACE_DETAIL_RESPONSIVE_LOCAL_MAX_PIXELS +
      " preview_cap_applies_to_full_output=no" +
      " full_resolution_output_uncapped=yes" +
      " local_pixels=" + timing.localPixelCount +
      " largest_local=" + timing.largestLocalIndex + ":" + timing.largestLocalPixels +
      " cache_mode=" + timing.cacheMode);
   this.setOutputProgress(
      "Rendering full resolution: preparing source. Please wait...",
      "Rendering output - please wait",
      "Full-resolution processing is in progress."
   );
   if (timing.globalActive) {
      if (!options.forceFresh &&
          this.appState.fullResolutionGlobalCache &&
          this.appState.fullResolutionGlobalCacheKey === globalKey &&
          this.appState.fullResolutionGlobalCache.width === width &&
          this.appState.fullResolutionGlobalCache.height === height &&
          this.appState.fullResolutionGlobalCache.rgb) {
         stage = Date.now();
         result = new Float32Array(this.appState.fullResolutionGlobalCache.rgb);
         this.addRenderTiming(timing, "Global adjustment cache copy", stage);
         aceDevelopmentConsoleWriteLine("[ACE] Full-resolution global intermediate cache hit | source=" + (cache.source.viewId || "Image") +
            " size=" + width + "x" + height +
            " local_edits=" + localRecipe.length);
      } else {
         stage = Date.now();
         this.setOutputProgress(
            "Rendering full resolution: global adjustment. Please wait...",
            "Rendering output - please wait",
            "Global full-resolution adjustment is in progress."
         );
         var globalDetailTiming = { items: [] };
         result = this.applyFullResolutionOperation(width, height, result, globalParams, globalProtection, null, globalAdvanced, globalDetailTiming, "Global adjustment");
         this.addRenderTiming(timing, "Global adjustment", stage);
         this.addRenderTimingDetails(timing, globalDetailTiming);
         this.appState.fullResolutionGlobalCache = {
            width: width,
            height: height,
            rgb: new Float32Array(result)
         };
         this.appState.fullResolutionGlobalCacheKey = globalKey;
         aceDevelopmentConsoleWriteLine("[ACE] Full-resolution global intermediate cache stored | source=" + (cache.source.viewId || "Image") +
            " size=" + width + "x" + height +
            " local_edits=" + localRecipe.length);
      }
   }
   for (var i = 0; i < localRecipe.length; ++i) {
      var edit = localRecipe[i];
      if (!edit.params || !EffectParameters.prototype.hasEffect.call(edit.params))
         continue;
      this.setOutputProgress(
         "Rendering full resolution: local edit " + (i + 1) + " of " + localRecipe.length + ". Please wait...",
         "Rendering output - please wait",
         "Committed local edits are being replayed at full resolution."
      );
      result = this.applyFullResolutionLassoEdit(width, height, result, edit, i, timing);
   }
   var rendered = { width: width, height: height, rgb: result };
   rendered.elapsedMs = this.printRenderTiming(timing, width, height);
   rendered.cacheHit = false;
   if (options.storeCache !== false) {
      this.appState.fullResolutionCache = rendered;
      this.appState.fullResolutionCacheKey = key;
   }
   return rendered;
};

AstroContrastEnhancerDialog.prototype.runFullResolutionTimingAudit = function() {
   if (this.outputRendering)
      return;
   if (!this.hasOutputImage()) {
      this.refreshPreviewStatus("No active image", "No active image loaded.");
      aceMessage("No active image loaded.", ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   if (!this.resolvePendingOutputChoice("Run Full Timing"))
      return;
   if (!this.confirmFullResolutionRender("Full Timing Audit"))
      return;
   this.setOutputRendering(true, "Running full-resolution timing audit. Please wait...");
   var rendered = null;
   var auditStart = Date.now();
   try {
      aceConsoleWriteLine("");
      aceConsoleWriteLine("[ACE] Full-resolution timing audit start | " + this.fullResolutionRecipeTimingSummary());
      this.setOutputProgress(
         "Running fresh full-resolution timing audit. Please wait...",
         "Timing full-resolution output - please wait",
         "This renders the current recipe but does not write an output image."
      );
      rendered = this.renderFullResolutionOutput({
         forceFresh: true,
         storeCache: true,
         auditLabel: "fresh-audit"
      });
      if (!rendered)
         throw new Error("Unable to render full-resolution timing audit.");
   } catch (error) {
      this.setOutputRendering(false, "Full timing audit failed.");
      aceMessage(error && error.message ? error.message : String(error), ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   var total = Date.now() - auditStart;
   this.setOutputRendering(false);
   this.refreshPreviewStatus(this.describeLoadedSource(), "Full timing audit: " + (total / 1000).toFixed(1) + " s");
   aceConsoleWriteLine("[ACE] Full-resolution timing audit done | total=" + total + " ms" +
      " render=" + (rendered.elapsedMs || 0) + " ms" +
      " cached_for_next_save=yes | " + this.fullResolutionRecipeTimingSummary());
   aceMessage("Full-resolution timing audit finished in " + (total / 1000).toFixed(1) + " s.\n\nNo output image was written. The rendered result is cached for the next Save New Image with the same recipe.\n\nSee the PixInsight console for the timing breakdown.", ACE_TOOL_NAME + " " + ACE_VERSION);
};

AstroContrastEnhancerDialog.prototype.resolvePendingOutputChoice = function(actionLabel) {
   var hasPendingLasso = this.appState.cache.pendingActive;
   if (!hasPendingLasso)
      return true;
   var choice = aceMessageChoice(
      "There is an uncommitted local edit.\n\nYes = Commit & " + actionLabel +
      "\nNo = " + actionLabel + " without pending edit\nCancel = Return to the tool",
      ACE_TOOL_NAME + " " + ACE_VERSION
   );
   if (choice === StdButton_Cancel)
      return false;
   if (choice === StdButton_Yes)
      this.commitLocalEdit();
   return true;
};

AstroContrastEnhancerDialog.prototype.createNewImageOutput = function() {
   if (this.outputRendering)
      return;
   if (!this.hasOutputImage()) {
      this.refreshPreviewStatus("No active image", "No active image loaded.");
      aceMessage("No active image loaded.", ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   if (!this.resolvePendingOutputChoice("Save New Image"))
      return;
   if (!this.confirmFullResolutionRender("Save New Image"))
      return;
   var cache = this.appState.cache;
   var sourceId = cache.source.viewId || "Image";
   var sourceBaseId = aceBaseSourceIdForGeneratedAceOutput(sourceId);
   var id = (sourceBaseId || sourceId) + "_ACE";
   var rendered = null;
   var created = null;
   var saveStart = Date.now();
   var renderWallMs = 0;
   var writeMs = 0;
   var showMs = 0;
   this.setOutputRendering(true, "Rendering full-resolution output. Please wait...");
   try {
      var renderWallStart = Date.now();
      rendered = this.renderFullResolutionOutput();
      renderWallMs = Date.now() - renderWallStart;
      if (!rendered)
         throw new Error("Unable to render full-resolution output.");
      this.setOutputProgress(
         "Writing full-resolution new image. Please wait...",
         "",
         ""
      );
      var writeStart = Date.now();
      created = aceCreateRgbImageWindow(rendered.width, rendered.height, rendered.rgb, id, false);
      writeMs = Date.now() - writeStart;
      this.refreshSourceCombo(sourceId);
      this.setOutputProgress(
         "Opening new image window. Please wait...",
         "Opening output - please wait",
         "PixInsight is creating and showing the new image window."
      );
   } catch (error) {
      this.setOutputRendering(false, "Output failed.");
      aceMessage(error && error.message ? error.message : String(error), ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   if (created && typeof created.show === "function") {
      var showStart = Date.now();
      try {
         created.show();
      } catch (showError) {
         this.setOutputRendering(false, "Output created, but window show failed.");
         aceMessage(showError && showError.message ? showError.message : String(showError), ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
         return;
      }
      showMs = Date.now() - showStart;
   }
   this.setOutputRendering(false);
   var createdId = created && created.mainView ? created.mainView.id : aceSanitizeImageId(id);
   var totalSaveMs = Date.now() - saveStart;
   var elapsedText = " in " + (totalSaveMs / 1000).toFixed(1) + " s";
   aceConsoleWriteLine("[ACE] Save New Image total timing | total=" + totalSaveMs + " ms" +
      " render=" + renderWallMs + " ms" +
      " render_compute=" + (rendered.elapsedMs || 0) + " ms" +
      " write=" + writeMs + " ms" +
      " show_window=" + showMs + " ms" +
      " cache=" + (rendered.cacheHit ? "final-hit" : "rendered"));
   this.refreshPreviewStatus(this.describeLoadedSource(), "Saved as new image" + elapsedText);
   aceMessage("Saved as full-resolution new image: " + createdId + elapsedText +
      "\n\nDimensions: " + rendered.width + " x " + rendered.height +
      "\nRender/cache: " + (renderWallMs / 1000).toFixed(1) + " s" +
      "\nNew image write: " + (writeMs / 1000).toFixed(1) + " s" +
      "\nOpen window: " + (showMs / 1000).toFixed(1) + " s", ACE_TOOL_NAME + " " + ACE_VERSION);
};

AstroContrastEnhancerDialog.prototype.applyWorkingResultToView = function() {
   if (this.outputRendering)
      return;
   if (!this.hasOutputImage()) {
      this.refreshPreviewStatus("No active image", "No active image loaded.");
      aceMessage("No active image loaded.", ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   if (!this.resolvePendingOutputChoice("Apply to Target"))
      return;
   if (!this.confirmFullResolutionRender("Apply to Target"))
      return;
   var cache = this.appState.cache;
   var found = aceFindViewForViewId(cache.source.viewId);
   if (!found || !found.view) {
      aceMessage("Original source view is unavailable.", ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      this.refreshPreviewStatus(this.describeLoadedSource(), "Original source view unavailable.");
      return;
   }
   var targetView = found.view;
   var rendered = null;
   this.setOutputRendering(true, "Rendering full-resolution output. Please wait...");
   try {
      rendered = this.renderFullResolutionOutput();
      if (!rendered)
         throw new Error("Unable to render full-resolution output.");
   } catch (error) {
      this.setOutputRendering(false, "Output failed.");
      aceMessage(error && error.message ? error.message : String(error), ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   if (targetView.image.width !== rendered.width || targetView.image.height !== rendered.height) {
      this.setOutputRendering(false, "Apply skipped: dimension mismatch.");
      aceMessage(
         "The rendered result is " + rendered.width + " x " + rendered.height +
         ", but the source view is " + targetView.image.width + " x " + targetView.image.height +
         ".\n\nApply to Target is disabled for mismatched dimensions.",
         ACE_TOOL_NAME + " " + ACE_VERSION,
         StdIcon_Warning
      );
      this.refreshPreviewStatus(this.describeLoadedSource(), "Apply skipped: dimension mismatch.");
      return;
   }
   this.setOutputProgress(
      "Applying full-resolution result to target. Please wait...",
      "Applying output - please wait",
      "PixInsight is writing pixels to the target view."
   );
   var applyWriteStart = Date.now();
   try {
      targetView.beginProcess();
      aceSetRgbImageSamples(targetView.image, rendered.width, rendered.height, rendered.rgb);
      targetView.endProcess();
   } catch (error) {
      try { targetView.endProcess(); } catch (ignore) {}
      this.setOutputRendering(false, "Apply failed.");
      aceMessage(error && error.message ? error.message : String(error), ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   this.setOutputProgress("Apply write time: " + ((Date.now() - applyWriteStart) / 1000).toFixed(2) + " s");
   this.setOutputRendering(false);
   var applyElapsedText = rendered.elapsedMs ? " in " + (rendered.elapsedMs / 1000).toFixed(1) + " s" : "";
   this.refreshPreviewStatus(this.describeLoadedSource(), "Applied to target" + applyElapsedText);
   aceMessage("Full-resolution result applied to target: " + targetView.id + applyElapsedText, ACE_TOOL_NAME + " " + ACE_VERSION);
};

AstroContrastEnhancerDialog.prototype.getCompositeMaskForDraft = function() {
   var cache = this.appState.cache;
   if (!cache.draft || !cache.draft.rgb)
      return null;
   if (!cache.draft.layerCache)
      cache.draft.layerCache = this.appState.processor.engine.buildLayerCache(cache.draft.width, cache.draft.height, cache.draft.rgb, this.appState.advanced, null, null, cache.draft.scale, { textureHybrid: false });
   var options = this.applyLassoWeightToOptions(cache.draft, this.getProtectionOptions());
   var starMaps = this.appState.processor.getStarProtectionMaps(cache.draft, options);
   var backgroundAllowed = options.protectSky && cache.draft.layerCache ? cache.draft.layerCache.allowedWeight : null;
   return this.combineAllowedWeights(
      cache.draft.width,
      cache.draft.height,
      backgroundAllowed,
      starMaps ? starMaps.allowedWeight : null,
      options.lassoAllowedWeight || null
   );
};

AstroContrastEnhancerDialog.prototype.getFullResolutionMaskContext = function() {
   var cache = this.appState.cache;
   if (!cache.sourceRgb || cache.source.width < 1 || cache.source.height < 1)
      return null;
   var context = {
      width: cache.source.width,
      height: cache.source.height,
      rgb: cache.sourceRgb,
      layerCache: null,
      starProtectionBase: null,
      starProtectionMaps: null,
      starProtectionKey: ""
   };
   context.layerCache = this.appState.processor.engine.buildLayerCache(context.width, context.height, context.rgb, this.appState.advanced, null, null, 1, { textureHybrid: false });
   return context;
};

AstroContrastEnhancerDialog.prototype.getCompositeMaskForFullResolution = function() {
   var context = this.getFullResolutionMaskContext();
   if (!context)
      return null;
   var protection = this.getProtectionOptions();
   var lassoWeight = this.hasLassoSelection() ?
      aceBuildLassoWeightMap(
         context.width,
         context.height,
         0,
         0,
         1,
         1,
         this.appState.lassoPoints,
         this.featherSlider ? this.featherSlider.value : ACE_FEATHER_DEFAULT,
         this.appState.lassoInverted
      ) :
      null;
   var starMaps = this.appState.processor.getStarProtectionMaps(context, protection);
   return this.combineAllowedWeights(
      context.width,
      context.height,
      protection.protectSky && context.layerCache ? context.layerCache.allowedWeight : null,
      starMaps ? starMaps.allowedWeight : null,
      lassoWeight
   );
};

AstroContrastEnhancerDialog.prototype.getCurrentMaskOutput = function() {
   var cache = this.appState.cache;
   if (!cache.sourceRgb || cache.source.width < 1 || cache.source.height < 1)
      return null;
   var mode = this.appState.preview.viewMode || "preview";
   if (this.appState.preview.showMask)
      mode = "allowed";
   if (!this.currentMaskViewCanSave())
      return null;
   var sourceId = cache.source.viewId || "Image";
   if (mode === "texture" || mode === "clarity" || mode === "dehaze" || mode === "delta") {
      var mapContext = this.getFullResolutionMaskContext();
      if (!mapContext || !mapContext.layerCache)
         return null;
      if (mode === "texture") {
         var textureRadius = Math.max(1, aceAdvancedRadiusPx(this.appState.advanced, "textureScale", ACE_TEXTURE_RADIUS));
         var textureBlur = aceTextureScaleBlurFloat(mapContext.width, mapContext.height, mapContext.layerCache.luminance, textureRadius);
         var textureMap = new Float32Array(mapContext.width * mapContext.height);
         for (var tx = 0; tx < textureMap.length; ++tx)
            textureMap[tx] = mapContext.layerCache.luminance[tx] - textureBlur[tx];
         return {
            width: mapContext.width,
            height: mapContext.height,
            gray: aceSignedMapToDisplayGray(mapContext.width, mapContext.height, textureMap, 3.2),
            id: sourceId + "_ACE_TextureMap",
            status: "Full-resolution Texture map saved."
         };
      }
      if (mode === "clarity") {
         var clarityMap = new Float32Array(mapContext.width * mapContext.height);
         var clarityScale = Math.max(1, Math.abs((this.appState.params && this.appState.params.clarity) || 100) / 100);
         for (var cl = 0; cl < clarityMap.length; ++cl)
            clarityMap[cl] = mapContext.layerCache.clarityLayer[cl] * clarityScale;
         return {
            width: mapContext.width,
            height: mapContext.height,
            gray: aceSignedMapToDisplayGray(mapContext.width, mapContext.height, clarityMap),
            id: sourceId + "_ACE_ClarityMap",
            status: "Full-resolution Clarity map saved."
         };
      }
      if (mode === "dehaze") {
         var dehazeProtection = this.getProtectionOptions();
         var dehazeStarMaps = this.appState.processor.getStarProtectionMaps(mapContext, dehazeProtection);
         var dehazeFields = this.appState.processor.engine.ensureDehazeVeilCache(
            mapContext.width,
            mapContext.height,
            mapContext.rgb,
            mapContext.layerCache,
            dehazeStarMaps ? dehazeStarMaps.allowedWeight : null,
            this.appState.advanced
         );
         return {
            width: mapContext.width,
            height: mapContext.height,
            gray: dehazeFields ? dehazeFields.veil : null,
            id: sourceId + "_ACE_DehazeMap",
            status: "Full-resolution Dehaze map saved."
         };
      }
      if (mode === "delta") {
         var rendered = this.renderFullResolutionOutput();
         if (!rendered || !rendered.rgb)
            return null;
         var sourceLum = aceLuminanceFromRgb(mapContext.width, mapContext.height, cache.sourceRgb);
         var renderedLum = aceLuminanceFromRgb(rendered.width, rendered.height, rendered.rgb);
         var deltaMap = new Float32Array(mapContext.width * mapContext.height);
         for (var dl = 0; dl < deltaMap.length; ++dl)
            deltaMap[dl] = renderedLum[dl] - sourceLum[dl];
         return {
            width: mapContext.width,
            height: mapContext.height,
            gray: aceSignedMapToDisplayGray(mapContext.width, mapContext.height, deltaMap, 3.0),
            id: sourceId + "_ACE_DeltaMap",
            status: "Full-resolution Delta map saved."
         };
      }
   }
   if (mode === "lasso") {
      if (!this.hasLassoSelection())
         return null;
      var lassoMask = aceBuildLassoWeightMap(
         cache.source.width,
         cache.source.height,
         0,
         0,
         1,
         1,
         this.appState.lassoPoints,
         this.featherSlider ? this.featherSlider.value : ACE_FEATHER_DEFAULT,
         this.appState.lassoInverted
      );
      return {
         width: cache.source.width,
         height: cache.source.height,
         gray: lassoMask,
         id: sourceId + "_ACE_LassoMask",
         status: "Full-resolution lasso mask saved."
      };
   }
   if (mode === "star") {
      var starContext = this.getFullResolutionMaskContext();
      var starMaps = starContext ? this.appState.processor.getStarProtectionMaps(starContext, this.getProtectionOptions()) : null;
      if (!starMaps || !starMaps.protectionMask)
         return null;
      return {
         width: cache.source.width,
         height: cache.source.height,
         gray: starMaps.protectionMask,
         id: sourceId + "_ACE_StarMask",
         status: "Full-resolution star mask saved."
      };
   }
   if (mode === "allowed" || mode === "mask")
      return {
         width: cache.source.width,
         height: cache.source.height,
         gray: this.getCompositeMaskForFullResolution(),
         id: sourceId + "_ACE_CompositeMask",
         status: "Full-resolution composite mask saved."
      };
   return null;
};

AstroContrastEnhancerDialog.prototype.addMaskAuditItem = function(items, width, height, gray, id, label) {
   if (!items || !gray)
      return;
   items.push({
      width: width,
      height: height,
      gray: gray,
      id: id,
      label: label
   });
};

AstroContrastEnhancerDialog.prototype.buildMaskAuditOutputs = function() {
   var cache = this.appState.cache;
   if (!cache.sourceRgb || cache.source.width < 1 || cache.source.height < 1)
      return [];
   var width = cache.source.width;
   var height = cache.source.height;
   var sourceId = cache.source.viewId || "Image";
   var context = this.getFullResolutionMaskContext();
   if (!context || !context.layerCache)
      return [];
   var protection = this.getProtectionOptions();
   var starMaps = this.appState.processor.getStarProtectionMaps(context, protection);
   var lassoWeight = this.hasLassoSelection() ?
      aceBuildLassoWeightMap(
         width,
         height,
         0,
         0,
         1,
         1,
         this.appState.lassoPoints,
         this.featherSlider ? this.featherSlider.value : ACE_FEATHER_DEFAULT,
         this.appState.lassoInverted
      ) :
      null;
   var composite = this.combineAllowedWeights(
      width,
      height,
      protection.protectSky && context.layerCache ? context.layerCache.allowedWeight : null,
      starMaps ? starMaps.allowedWeight : null,
      lassoWeight
   );
   var items = [];
   this.addMaskAuditItem(items, width, height, context.layerCache.allowedWeight, sourceId + "_ACE_Audit_SkyAllowed", "Sky/background allowed");
   this.addMaskAuditItem(items, width, height, context.layerCache.structureConfidence, sourceId + "_ACE_Audit_StructureConfidence", "Structure confidence");
   this.addMaskAuditItem(items, width, height, context.layerCache.localFloor, sourceId + "_ACE_Audit_LocalFloor", "Local floor");
   if (starMaps) {
      this.addMaskAuditItem(items, width, height, starMaps.protectionMask, sourceId + "_ACE_Audit_StarProtection", "Star protection");
      this.addMaskAuditItem(items, width, height, starMaps.allowedWeight, sourceId + "_ACE_Audit_StarAllowed", "Star allowed");
   }
   this.addMaskAuditItem(items, width, height, composite, sourceId + "_ACE_Audit_CompositeAllowed", "Composite allowed");
   this.addMaskAuditItem(items, width, height, lassoWeight, sourceId + "_ACE_Audit_LassoAllowed", "Lasso allowed");
   var advanced = aceCopyAdvancedParams(this.appState.globalAdvanced);
   var dehazeFields = this.appState.processor.engine.ensureDehazeVeilCache(
      width,
      height,
      cache.sourceRgb,
      context.layerCache,
      starMaps ? starMaps.allowedWeight : null,
      advanced
   );
   if (dehazeFields) {
      this.addMaskAuditItem(items, width, height, dehazeFields.veil, sourceId + "_ACE_Audit_DehazeVeil", "Dehaze veil");
      this.addMaskAuditItem(items, width, height, dehazeFields.confidence, sourceId + "_ACE_Audit_DehazeConfidence", "Dehaze confidence");
      this.addMaskAuditItem(items, width, height, dehazeFields.veilExcess, sourceId + "_ACE_Audit_DehazeVeilExcess", "Dehaze veil excess");
      this.addMaskAuditItem(items, width, height, dehazeFields.compactAllowed, sourceId + "_ACE_Audit_DehazeCompactAllowed", "Dehaze compact allowed");
      this.addMaskAuditItem(items, width, height, dehazeFields.highlightAllowed, sourceId + "_ACE_Audit_DehazeHighlightAllowed", "Dehaze highlight allowed");
   }
   return items;
};

AstroContrastEnhancerDialog.prototype.saveMaskAuditOutput = function() {
   if (this.outputRendering)
      return;
   if (!this.hasOutputImage()) {
      this.refreshPreviewStatus("No active image", "No active image loaded.");
      aceMessage("No active image loaded.", ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   if (!this.confirmFullResolutionRender("Mask Audit"))
      return;
   this.setOutputRendering(true, "Building full-resolution mask audit. Please wait...");
   var items = [];
   var created = 0;
   try {
      this.setOutputProgress(
         "Building full-resolution mask audit. Please wait...",
         "Building mask audit - please wait",
         "Saving diagnostic masks for artifact inspection."
      );
      items = this.buildMaskAuditOutputs();
      if (!items || items.length < 1)
         throw new Error("No diagnostic masks were available.");
      for (var i = 0; i < items.length; ++i) {
         var item = items[i];
         if (!item || !item.gray)
            continue;
         this.setOutputProgress(
            "Writing mask audit " + (i + 1) + " of " + items.length + ": " + item.label,
            "Writing mask audit - please wait",
            item.label
         );
         aceCreateGrayImageWindow(item.width, item.height, item.gray, item.id);
         ++created;
      }
   } catch (error) {
      this.setOutputRendering(false, "Mask audit failed.");
      aceMessage(error && error.message ? error.message : String(error), ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   this.setOutputRendering(false);
   this.refreshPreviewStatus(this.describeLoadedSource(), "Mask audit saved: " + created + " images");
   aceMessage("Mask audit saved " + created + " full-resolution diagnostic images.\n\nInspect these for rectangular/block structure around the artifact area.", ACE_TOOL_NAME + " " + ACE_VERSION);
};

function aceValidationWriteLine(text) {
   if (typeof console !== "undefined" && console && typeof console.writeln === "function")
      console.writeln(text);
   else if (typeof Console !== "undefined" && Console && typeof Console.writeln === "function")
      Console.writeln(text);
}

function aceValidationNumber(value, digits) {
   if (!isFinite(value))
      return "n/a";
   return Number(value).toFixed(digits);
}

function aceValidationMeanFloat(data) {
   if (!data || data.length < 1)
      return 0;
   var sum = 0;
   for (var i = 0; i < data.length; ++i)
      sum += data[i];
   return sum / data.length;
}

function aceValidationRgbDifferenceStats(a, b) {
   if (!a || !b || a.length !== b.length)
      return { meanAbs: 0, rms: 0, maxAbs: 0 };
   var sumAbs = 0;
   var sumSq = 0;
   var maxAbs = 0;
   for (var i = 0; i < a.length; ++i) {
      var d = a[i] - b[i];
      var ad = Math.abs(d);
      sumAbs += ad;
      sumSq += d * d;
      if (ad > maxAbs)
         maxAbs = ad;
   }
   return {
      meanAbs: sumAbs / Math.max(1, a.length),
      rms: Math.sqrt(sumSq / Math.max(1, a.length)),
      maxAbs: maxAbs
   };
}

function aceValidationLuminanceDelta(width, height, sourceLuminance, rgb) {
   var processed = aceLuminanceFromRgb(width, height, rgb);
   var count = width * height;
   var delta = new Float32Array(count);
   for (var i = 0; i < count; ++i)
      delta[i] = processed[i] - sourceLuminance[i];
   return delta;
}

function aceValidationDeltaStats(delta) {
   if (!delta || delta.length < 1)
      return { meanAbs: 0, rms: 0, maxAbs: 0 };
   var sumAbs = 0;
   var sumSq = 0;
   var maxAbs = 0;
   for (var i = 0; i < delta.length; ++i) {
      var v = delta[i];
      var av = Math.abs(v);
      sumAbs += av;
      sumSq += v * v;
      if (av > maxAbs)
         maxAbs = av;
   }
   return {
      meanAbs: sumAbs / Math.max(1, delta.length),
      rms: Math.sqrt(sumSq / Math.max(1, delta.length)),
      maxAbs: maxAbs
   };
}

function aceValidationMaskedDeltaStats(delta, mask) {
   var result = {
      protectedMeanAbs: 0,
      protectedRms: 0,
      protectedCount: 0,
      openMeanAbs: 0,
      openRms: 0,
      openCount: 0,
      protectedPct: 0,
      openPct: 0
   };
   if (!delta || !mask || delta.length !== mask.length || delta.length < 1)
      return result;
   var protectedAbs = 0;
   var protectedSq = 0;
   var openAbs = 0;
   var openSq = 0;
   for (var i = 0; i < delta.length; ++i) {
      var av = Math.abs(delta[i]);
      if (mask[i] >= 0.10) {
         protectedAbs += av;
         protectedSq += delta[i] * delta[i];
         ++result.protectedCount;
      }
      if (mask[i] <= 0.02) {
         openAbs += av;
         openSq += delta[i] * delta[i];
         ++result.openCount;
      }
   }
   result.protectedMeanAbs = protectedAbs / Math.max(1, result.protectedCount);
   result.protectedRms = Math.sqrt(protectedSq / Math.max(1, result.protectedCount));
   result.openMeanAbs = openAbs / Math.max(1, result.openCount);
   result.openRms = Math.sqrt(openSq / Math.max(1, result.openCount));
   result.protectedPct = result.protectedCount / Math.max(1, delta.length);
   result.openPct = result.openCount / Math.max(1, delta.length);
   return result;
}

function aceValidationHighToneDeltaStats(sourceLuminance, delta, threshold) {
   var result = {
      count: 0,
      pct: 0,
      positiveMean: 0,
      positiveMax: 0,
      meanAbs: 0,
      rms: 0
   };
   if (!sourceLuminance || !delta || sourceLuminance.length !== delta.length || delta.length < 1)
      return result;
   var highTone = threshold !== undefined ? threshold : 0.72;
   var positiveSum = 0;
   var absSum = 0;
   var sqSum = 0;
   for (var i = 0; i < delta.length; ++i) {
      if (sourceLuminance[i] < highTone)
         continue;
      var v = delta[i];
      var pv = Math.max(0, v);
      positiveSum += pv;
      if (pv > result.positiveMax)
         result.positiveMax = pv;
      absSum += Math.abs(v);
      sqSum += v * v;
      ++result.count;
   }
   result.pct = result.count / Math.max(1, delta.length);
   result.positiveMean = positiveSum / Math.max(1, result.count);
   result.meanAbs = absSum / Math.max(1, result.count);
   result.rms = Math.sqrt(sqSum / Math.max(1, result.count));
   return result;
}

function aceValidationMaskedRgbDifferenceStats(width, height, a, b, mask) {
   var result = {
      protectedMeanAbs: 0,
      protectedRms: 0,
      protectedCount: 0,
      openMeanAbs: 0,
      openRms: 0,
      openCount: 0,
      protectedPct: 0,
      openPct: 0
   };
   var count = width * height;
   if (!a || !b || !mask || a.length !== b.length || mask.length !== count || a.length !== count * 3)
      return result;
   var protectedAbs = 0;
   var protectedSq = 0;
   var openAbs = 0;
   var openSq = 0;
   for (var i = 0; i < count; ++i) {
      var base = i * 3;
      if (mask[i] >= 0.10) {
         for (var c = 0; c < 3; ++c) {
            var pd = a[base + c] - b[base + c];
            var pad = Math.abs(pd);
            protectedAbs += pad;
            protectedSq += pd * pd;
         }
         ++result.protectedCount;
      }
      if (mask[i] <= 0.02) {
         for (var oc = 0; oc < 3; ++oc) {
            var od = a[base + oc] - b[base + oc];
            var oad = Math.abs(od);
            openAbs += oad;
            openSq += od * od;
         }
         ++result.openCount;
      }
   }
   result.protectedMeanAbs = protectedAbs / Math.max(1, result.protectedCount * 3);
   result.protectedRms = Math.sqrt(protectedSq / Math.max(1, result.protectedCount * 3));
   result.openMeanAbs = openAbs / Math.max(1, result.openCount * 3);
   result.openRms = Math.sqrt(openSq / Math.max(1, result.openCount * 3));
   result.protectedPct = result.protectedCount / Math.max(1, count);
   result.openPct = result.openCount / Math.max(1, count);
   return result;
}

function aceValidationCorrelation(a, b) {
   if (!a || !b || a.length !== b.length || a.length < 2)
      return 1;
   var meanA = aceValidationMeanFloat(a);
   var meanB = aceValidationMeanFloat(b);
   var num = 0;
   var denA = 0;
   var denB = 0;
   for (var i = 0; i < a.length; ++i) {
      var da = a[i] - meanA;
      var db = b[i] - meanB;
      num += da * db;
      denA += da * da;
      denB += db * db;
   }
   if (denA <= ACE_EPSILON || denB <= ACE_EPSILON)
      return 1;
   return num / Math.sqrt(denA * denB);
}

function aceValidationGridArtifactScore(width, height, delta, period) {
   if (!delta || width < 3 || height < 3 || period < 2)
      return 1;
   var boundarySum = 0;
   var boundaryCount = 0;
   var interiorSum = 0;
   var interiorCount = 0;
   for (var y = 1; y < height; ++y) {
      var row = y * width;
      var prevRow = (y - 1) * width;
      var yBoundary = (y % period) === 0;
      for (var x = 1; x < width; ++x) {
         var idx = row + x;
         var dx = Math.abs(delta[idx] - delta[idx - 1]);
         var dy = Math.abs(delta[idx] - delta[prevRow + x]);
         if ((x % period) === 0) {
            boundarySum += dx;
            ++boundaryCount;
         } else {
            interiorSum += dx;
            ++interiorCount;
         }
         if (yBoundary) {
            boundarySum += dy;
            ++boundaryCount;
         } else {
            interiorSum += dy;
            ++interiorCount;
         }
      }
   }
   var boundaryMean = boundarySum / Math.max(1, boundaryCount);
   var interiorMean = interiorSum / Math.max(ACE_EPSILON, interiorCount);
   return boundaryMean / Math.max(ACE_EPSILON, interiorMean);
}

function aceValidationGridSummary(width, height, delta) {
   var periods = [8, 16, 32, 64];
   var best = { period: 0, score: 1, scores: {} };
   for (var i = 0; i < periods.length; ++i) {
      var score = aceValidationGridArtifactScore(width, height, delta, periods[i]);
      best.scores[periods[i]] = score;
      if (score > best.score)
         best = { period: periods[i], score: score, scores: best.scores };
   }
   return best;
}

function aceValidationGridScoreAt(summary, period) {
   if (!summary || !summary.scores || !period)
      return 1;
   return summary.scores[period] !== undefined ? summary.scores[period] : 1;
}

function aceValidationParams(texture, clarity, dehaze) {
   var params = new EffectParameters;
   params.texture = texture || 0;
   params.clarity = clarity || 0;
   params.dehaze = dehaze || 0;
   return params;
}

function aceValidationStatusFromGrid(score, sourceScore, amplification) {
   sourceScore = sourceScore !== undefined ? sourceScore : 1;
   amplification = amplification !== undefined ? amplification : score / Math.max(1, sourceScore);
   if (score >= 1.75 && amplification >= 1.20)
      return "FAIL";
   if (score >= 1.75 || amplification >= 1.12)
      return "REVIEW";
   if (score >= 1.35 && amplification >= 1.05)
      return "REVIEW";
   return "PASS";
}

function aceValidationGridClass(score, sourceScore, amplification) {
   sourceScore = sourceScore !== undefined ? sourceScore : 1;
   amplification = amplification !== undefined ? amplification : score / Math.max(1, sourceScore);
   if (score < 1.35)
      return "grid clean";
   if (amplification >= 1.20)
      return "grid ACE-amplified";
   if (amplification >= 1.08)
      return "grid mildly amplified";
   if (sourceScore >= 1.75)
      return "grid source-carried";
   return "grid elevated";
}

AstroContrastEnhancerDialog.prototype.handleValidationLogoClick = function() {
   var now = Date.now();
   if (!this.validationLogoClickTime || now - this.validationLogoClickTime > ACE_STATE_VALIDATION_CLICK_WINDOW_MS)
      this.validationLogoClickCount = 0;
   this.validationLogoClickTime = now;
   this.validationLogoClickCount = (this.validationLogoClickCount || 0) + 1;
   if (this.validationLogoClickCount < ACE_STATE_VALIDATION_CLICK_COUNT)
      return;
   this.validationLogoClickCount = 0;
   this.toggleDebugControls();
};

AstroContrastEnhancerDialog.prototype.stateValidationRoiFromCenter = function(label, centerX, centerY) {
   var cache = this.appState.cache;
   if (!cache || !cache.sourceRgb || !cache.source || cache.source.width < 1 || cache.source.height < 1)
      return null;
   var width = cache.source.width;
   var height = cache.source.height;
   var roiWidth = Math.min(width, ACE_STATE_VALIDATION_ROI_MAX_EDGE);
   var roiHeight = Math.min(height, ACE_STATE_VALIDATION_ROI_MAX_EDGE);
   var x0 = aceClamp(Math.floor(centerX - roiWidth * 0.5), 0, Math.max(0, width - roiWidth));
   var y0 = aceClamp(Math.floor(centerY - roiHeight * 0.5), 0, Math.max(0, height - roiHeight));
   var rect = { x0: x0, y0: y0, x1: x0 + roiWidth, y1: y0 + roiHeight };
   var roi = aceExtractRgbRect(width, height, cache.sourceRgb, rect);
   roi.label = label || "roi";
   roi.x0 = x0;
   roi.y0 = y0;
   return roi;
};

AstroContrastEnhancerDialog.prototype.addStateValidationRoiCandidate = function(rois, label, centerX, centerY) {
   if (!rois || rois.length >= ACE_STATE_VALIDATION_MAX_ROIS)
      return;
   for (var i = 0; i < rois.length; ++i) {
      var dx = centerX - (rois[i].x0 + rois[i].width * 0.5);
      var dy = centerY - (rois[i].y0 + rois[i].height * 0.5);
      if (Math.sqrt(dx * dx + dy * dy) < ACE_STATE_VALIDATION_ROI_MAX_EDGE * 0.65)
         return;
   }
   var roi = this.stateValidationRoiFromCenter(label, centerX, centerY);
   if (roi)
      rois.push(roi);
};

AstroContrastEnhancerDialog.prototype.extractStateValidationRois = function() {
   var cache = this.appState.cache;
   if (!cache || !cache.sourceRgb || !cache.source || cache.source.width < 1 || cache.source.height < 1)
      return [];
   var width = cache.source.width;
   var height = cache.source.height;
   var rgb = cache.sourceRgb;
   var rois = [];
   this.addStateValidationRoiCandidate(rois, "center", width * 0.5, height * 0.5);

   var step = Math.max(64, Math.round(ACE_STATE_VALIDATION_ROI_MAX_EDGE * 0.25));
   var bestBright = { score: -1, x: width * 0.5, y: height * 0.5 };
   var bestDark = { score: 2, x: width * 0.5, y: height * 0.5 };
   var bestStructure = { score: -1, x: width * 0.5, y: height * 0.5 };
   var xStart = Math.floor(step * 0.5);
   var yStart = Math.floor(step * 0.5);
   for (var y = yStart; y < height - 1; y += step) {
      for (var x = xStart; x < width - 1; x += step) {
         var idx = y * width + x;
         var base = idx * 3;
         var lum = 0.2126 * rgb[base] + 0.7152 * rgb[base + 1] + 0.0722 * rgb[base + 2];
         if (lum > bestBright.score)
            bestBright = { score: lum, x: x, y: y };
         if (lum < bestDark.score)
            bestDark = { score: lum, x: x, y: y };
         var rightBase = (idx + 1) * 3;
         var downBase = (idx + width) * 3;
         var lumRight = 0.2126 * rgb[rightBase] + 0.7152 * rgb[rightBase + 1] + 0.0722 * rgb[rightBase + 2];
         var lumDown = 0.2126 * rgb[downBase] + 0.7152 * rgb[downBase + 1] + 0.0722 * rgb[downBase + 2];
         var structure = Math.abs(lum - lumRight) + Math.abs(lum - lumDown);
         if (structure > bestStructure.score)
            bestStructure = { score: structure, x: x, y: y };
      }
   }
   this.addStateValidationRoiCandidate(rois, "bright-sample", bestBright.x, bestBright.y);
   this.addStateValidationRoiCandidate(rois, "dark-sample", bestDark.x, bestDark.y);
   this.addStateValidationRoiCandidate(rois, "edge-sample", bestStructure.x, bestStructure.y);
   return rois;
};

AstroContrastEnhancerDialog.prototype.makeStateValidationProtection = function(inputType, protectSky, protectStars, preventDarkPatches, protectHalos) {
   var protection = aceCopyProtectionOptions(this.getProtectionOptions());
   protection.inputType = inputType || "stars";
   protection.protectSky = !!protectSky;
   protection.protectStars = !!protectStars;
   protection.preventDarkPatches = !!preventDarkPatches;
   protection.protectStarHalos = !!protectHalos;
   return protection;
};

AstroContrastEnhancerDialog.prototype.runStateValidationOperation = function(roi, params, protection, advanced, route) {
   var start = Date.now();
   if (!params || !EffectParameters.prototype.hasEffect.call(params)) {
      return {
         width: roi.width,
         height: roi.height,
         rgb: new Float32Array(roi.rgb),
         timingMs: Date.now() - start,
         starMaps: null,
         starTimingMs: 0,
         applyTimingMs: 0
      };
   }
   var previewData = {
      width: roi.width,
      height: roi.height,
      rgb: new Float32Array(roi.rgb),
      layerCache: null,
      starProtectionBase: null,
      starProtectionMaps: null,
      starProtectionKey: ""
   };
   var effectiveProtection = aceCopyProtectionOptions(protection);
   effectiveProtection.advanced = advanced;
   effectiveProtection.fastFullResolutionStarMask = route === "full-fast";
   var starStart = Date.now();
   var starMaps = this.appState.processor.getStarProtectionMaps(previewData, effectiveProtection);
   var starTimingMs = Date.now() - starStart;
   effectiveProtection.starAllowedWeight = starMaps ? starMaps.allowedWeight : null;
   var applyStart = Date.now();
   var rgb = this.appState.processor.engine.apply(roi.width, roi.height, previewData.rgb, params, previewData.layerCache, effectiveProtection, advanced, null, "State validation");
   var applyTimingMs = Date.now() - applyStart;
   return {
      width: roi.width,
      height: roi.height,
      rgb: rgb,
      timingMs: Date.now() - start,
      starMaps: starMaps,
      starTimingMs: starTimingMs,
      applyTimingMs: applyTimingMs
   };
};

AstroContrastEnhancerDialog.prototype.stateValidationCase = function(roi, sourceLuminance, sourceGrid, label, route, inputType, params, protection) {
   var advanced = aceCopyAdvancedParams(this.appState.globalAdvanced || this.appState.advanced);
   var output = this.runStateValidationOperation(roi, params, protection, advanced, route);
   var delta = aceValidationLuminanceDelta(roi.width, roi.height, sourceLuminance, output.rgb);
   var stats = aceValidationDeltaStats(delta);
   var grid = aceValidationGridSummary(roi.width, roi.height, delta);
   var sourceGridScore = aceValidationGridScoreAt(sourceGrid, grid.period);
   var gridAmplification = grid.score / Math.max(1, sourceGridScore);
   var status = aceValidationStatusFromGrid(grid.score, sourceGridScore, gridAmplification);
   var gridClass = aceValidationGridClass(grid.score, sourceGridScore, gridAmplification);
   if (!EffectParameters.prototype.hasEffect.call(params) && stats.maxAbs > 1.0e-7)
      status = "FAIL";
   return {
      label: label,
      route: route,
      inputType: inputType,
      params: params,
      protection: protection,
      rgb: output.rgb,
      delta: delta,
      timingMs: output.timingMs,
      starTimingMs: output.starTimingMs || 0,
      applyTimingMs: output.applyTimingMs || 0,
      starProtectionMask: output.starMaps ? output.starMaps.protectionMask : null,
      starAllowedWeight: output.starMaps ? output.starMaps.allowedWeight : null,
      meanAbs: stats.meanAbs,
      rms: stats.rms,
      maxAbs: stats.maxAbs,
      gridPeriod: grid.period,
      gridScore: grid.score,
      sourceGridScore: sourceGridScore,
      gridAmplification: gridAmplification,
      gridClass: gridClass,
      status: status,
      note: ""
   };
};

AstroContrastEnhancerDialog.prototype.printStateValidationCase = function(row) {
   var p = row.params || new EffectParameters;
   var prot = row.protection || {};
   aceValidationWriteLine(
      row.status + " | " +
      row.label + " | " +
      row.route + " | " +
      row.inputType + " | " +
      "sky=" + (prot.protectSky ? "on" : "off") + " " +
      "stars=" + (prot.protectStars ? "on" : "off") + " " +
      "guard=" + (prot.preventDarkPatches ? "on" : "off") + " | " +
      "T=" + p.texture + " C=" + p.clarity + " D=" + p.dehaze + " | " +
      "meanAbs=" + aceValidationNumber(row.meanAbs, 6) + " " +
      "rms=" + aceValidationNumber(row.rms, 6) + " " +
      "max=" + aceValidationNumber(row.maxAbs, 6) + " | " +
      "grid=" + aceValidationNumber(row.gridScore, 3) + "@p" + row.gridPeriod + " | " +
      "srcGrid=" + aceValidationNumber(row.sourceGridScore, 3) + " " +
      "amp=" + aceValidationNumber(row.gridAmplification, 3) + " | " +
      row.gridClass + " | " +
      "time=" + aceValidationNumber(row.timingMs / 1000, 2) + "s" +
      (row.starTimingMs > 0 || row.applyTimingMs > 0 ?
         " star=" + aceValidationNumber(row.starTimingMs / 1000, 2) + "s apply=" + aceValidationNumber(row.applyTimingMs / 1000, 2) + "s" :
         "") +
      (row.note ? " | " + row.note : "")
   );
};

AstroContrastEnhancerDialog.prototype.printStateValidationCheck = function(status, label, details) {
   aceValidationWriteLine(status + " | CHECK | " + label + " | " + details);
};

function acePerfAuditStatus(ms, budgetMs) {
   if (ms <= budgetMs)
      return "PASS";
   if (ms <= budgetMs * 1.75)
      return "REVIEW";
   return "SLOW";
}

function acePerfAuditLassoFromRoi(roi) {
   var points = [];
   var cx = roi.x0 + roi.width * 0.5;
   var cy = roi.y0 + roi.height * 0.5;
   var rx = Math.max(24, roi.width * 0.36);
   var ry = Math.max(24, roi.height * 0.34);
   for (var i = 0; i < 18; ++i) {
      var a = 2 * Math.PI * i / 18;
      var wobble = 1 + 0.10 * Math.sin(a * 3.0);
      points.push({
         x: cx + Math.cos(a) * rx * wobble,
         y: cy + Math.sin(a) * ry * (1 - 0.08 * Math.cos(a * 2.0))
      });
   }
   return points;
}

AstroContrastEnhancerDialog.prototype.printPerformanceAuditRow = function(status, label, ms, budgetMs, detail) {
   aceValidationWriteLine(
      status + " | PERF | " + label +
      " | " + ms + " ms" +
      " budget=" + budgetMs + " ms" +
      (detail ? " | " + detail : "")
   );
};

AstroContrastEnhancerDialog.prototype.runPerformanceTimed = function(rows, label, budgetMs, fn) {
   var start = Date.now();
   var detail = "";
   try {
      detail = fn() || "";
   } catch (error) {
      var failMs = Date.now() - start;
      rows.push({ status: "FAIL", label: label, ms: failMs, budget: budgetMs, detail: error && error.message ? error.message : String(error) });
      this.printPerformanceAuditRow("FAIL", label, failMs, budgetMs, rows[rows.length - 1].detail);
      return null;
   }
   var ms = Date.now() - start;
   var status = acePerfAuditStatus(ms, budgetMs);
   rows.push({ status: status, label: label, ms: ms, budget: budgetMs, detail: detail });
   this.printPerformanceAuditRow(status, label, ms, budgetMs, detail);
   return ms;
};

function acePerformanceAuditIsWorkflowRow(label) {
   label = String(label || "");
   return label.indexOf("actual draft flow") >= 0 ||
      label.indexOf("native detail combined visible preview") >= 0 ||
      label.indexOf("reset flow draft recovery") >= 0;
}

function acePerformanceAuditCountRows(rows, workflowOnly) {
   var counts = { pass: 0, review: 0, slow: 0, fail: 0, total: 0 };
   for (var i = 0; i < rows.length; ++i) {
      if (workflowOnly && !acePerformanceAuditIsWorkflowRow(rows[i].label))
         continue;
      ++counts.total;
      if (rows[i].status === "FAIL")
         ++counts.fail;
      else if (rows[i].status === "SLOW")
         ++counts.slow;
      else if (rows[i].status === "REVIEW")
         ++counts.review;
      else
         ++counts.pass;
   }
   return counts;
}

AstroContrastEnhancerDialog.prototype.restoreAfterPerformanceFlowAudit = function(saved) {
   if (!saved || !this.appState)
      return;
   this.stopPendingDetailRefreshes();
   this.detailRefreshTimerToken = null;
   this.detailAdjustmentTimerToken = null;
   this.detailPreviewPendingNavigation = false;
   this.detailPreviewPendingAdjustment = false;
   this.detailWorkActive = false;
   this.detailWorkToken = null;
   this.processingMode = saved.processingMode;
   this.appState.lassoPoints = aceCopyPointArray(saved.lassoPoints);
   this.appState.lassoInverted = !!saved.lassoInverted;
   this.appState.lassoVersion = saved.lassoVersion || 0;
   this.setEffectSlidersSilently(saved.params);
   this.appState.globalParams = aceCopyParams(saved.globalParams);
   this.appState.advanced = aceCopyAdvancedParams(saved.advanced);
   this.appState.globalAdvanced = aceCopyAdvancedParams(saved.globalAdvanced);
   this.appState.globalProtection = aceCopyProtectionOptions(saved.globalProtection);
   this.appState.preview.zoomMode = saved.preview.zoomMode;
   this.appState.preview.zoomScale = saved.preview.zoomScale;
   this.appState.preview.panX = saved.preview.panX;
   this.appState.preview.panY = saved.preview.panY;
   this.appState.preview.viewMode = saved.preview.viewMode;
   this.appState.preview.showBefore = saved.preview.showBefore;
   this.appState.preview.showMask = saved.preview.showMask;
   this.clearPendingLocalPreview(false);
   this.rebuildProcessedDraftPreview();
   this.refreshLocalSelectionControls();
   this.refreshViewModeButtons();
};

AstroContrastEnhancerDialog.prototype.runPerformanceFlowAudit = function() {
   if (!this.hasOutputImage()) {
      aceMessage("No active image loaded for performance audit.", ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   if (this.appState.cache.pendingActive || this.appState.params.hasEffect() || this.hasLassoSelection()) {
      aceMessage("Performance audit needs a clean preview state.\n\nClear or commit the current local edit and reset active sliders before running it. This prevents the audit from consuming your working edit.", ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   var rois = this.extractStateValidationRois();
   if (!rois || rois.length < 1) {
      aceMessage("Unable to extract performance audit ROIs.", ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   var saved = {
      processingMode: this.processingMode,
      lassoPoints: aceCopyPointArray(this.appState.lassoPoints),
      lassoInverted: !!this.appState.lassoInverted,
      lassoVersion: this.appState.lassoVersion || 0,
      params: aceCopyParams(this.appState.params),
      globalParams: aceCopyParams(this.appState.globalParams),
      advanced: aceCopyAdvancedParams(this.appState.advanced),
      globalAdvanced: aceCopyAdvancedParams(this.appState.globalAdvanced),
      globalProtection: aceCopyProtectionOptions(this.appState.globalProtection),
      preview: {
         zoomMode: this.appState.preview.zoomMode,
         zoomScale: this.appState.preview.zoomScale,
         panX: this.appState.preview.panX,
         panY: this.appState.preview.panY,
         viewMode: this.appState.preview.viewMode,
         showBefore: !!this.appState.preview.showBefore,
         showMask: !!this.appState.preview.showMask
      }
   };
   var rows = [];
   var startAll = Date.now();
   var passCount = 0;
   var reviewCount = 0;
   var slowCount = 0;
   var failCount = 0;
   var cache = this.appState.cache;
   var advanced = aceCopyAdvancedParams(this.appState.advanced);
   var starsProtection = this.makeStateValidationProtection("stars", true, true, true, true);
   var textureFull = aceValidationParams(ACE_TEXTURE_SLIDER_MAX, 0, 0);
   var clarityFull = aceValidationParams(0, ACE_CLARITY_SLIDER_MAX, 0);
   var dehazeFull = aceValidationParams(0, 0, ACE_DEHAZE_SLIDER_MAX);
   var combined = aceValidationParams(ACE_TEXTURE_SLIDER_MAX, ACE_CLARITY_SLIDER_MAX, ACE_DEHAZE_SLIDER_MAX);

   this.refreshPreviewStatus(this.describeLoadedSource(), "Running performance audit...");
   aceValidationWriteLine("");
   aceValidationWriteLine("ACE PERFORMANCE FLOW AUDIT " + ACE_VERSION);
   aceValidationWriteLine("Source: " + (cache.source.viewId || "Image") + " | full=" + cache.source.width + "x" + cache.source.height + " | rois=" + Math.min(rois.length, ACE_PERF_AUDIT_MAX_ROIS));
   aceValidationWriteLine("Budgets: draft<=" + ACE_PERF_BUDGET_DRAFT_MS + "ms detail<=" + ACE_PERF_BUDGET_DETAIL_MS + "ms reset<=" + ACE_PERF_BUDGET_RESET_MS + "ms");
   aceValidationWriteLine("Rows: status | PERF | flow | elapsed | budget | detail");

   try {
      for (var r = 0; r < rois.length && r < ACE_PERF_AUDIT_MAX_ROIS; ++r) {
         var roi = rois[r];
         var labelPrefix = "ROI " + (r + 1) + " " + roi.label + " " + roi.width + "x" + roi.height;
         var lassoPoints = acePerfAuditLassoFromRoi(roi);
         var lassoWeight = aceBuildLassoWeightMap(roi.width, roi.height, roi.x0, roi.y0, 1, 1, lassoPoints, ACE_FEATHER_DEFAULT, false);
         var makePreviewData = function() {
            return {
               width: roi.width,
               height: roi.height,
               rgb: new Float32Array(roi.rgb),
               layerCache: null,
               starProtectionBase: null,
               starProtectionMaps: null,
               starProtectionKey: ""
            };
         };
         var localProtection = aceCopyProtectionOptions(starsProtection);
         localProtection.lassoAllowedWeight = lassoWeight;
         localProtection.advanced = advanced;
         var makeVisiblePreviewProtection = function() {
            var visibleProtection = aceCopyProtectionOptions(localProtection);
            visibleProtection.lassoAllowedWeight = lassoWeight;
            visibleProtection.advanced = advanced;
            visibleProtection.rgbOnlyOutput = true;
            visibleProtection.skipBitmapRender = true;
            return visibleProtection;
         };

         aceValidationWriteLine("");
         aceValidationWriteLine(labelPrefix + " | synthetic lasso points=" + lassoPoints.length);

         this.runPerformanceTimed(rows, labelPrefix + " / ROI Texture visible preview", ACE_PERF_BUDGET_DRAFT_MS, function() {
            var timing = { items: [] };
            this.appState.processor.processPreview(makePreviewData(), textureFull, makeVisiblePreviewProtection(), advanced, timing, "Perf ROI texture visible");
            return aceTimingSummary(timing, 8);
         }.bind(this));
         this.runPerformanceTimed(rows, labelPrefix + " / ROI Texture protected preview", ACE_PERF_BUDGET_DRAFT_MS, function() {
            var timing = { items: [] };
            this.appState.processor.processPreview(makePreviewData(), textureFull, localProtection, advanced, timing, "Perf ROI texture");
            return aceTimingSummary(timing, 8);
         }.bind(this));
         this.runPerformanceTimed(rows, labelPrefix + " / ROI combined visible preview", ACE_PERF_BUDGET_DRAFT_MS, function() {
            var timing = { items: [] };
            this.appState.processor.processPreview(makePreviewData(), combined, makeVisiblePreviewProtection(), advanced, timing, "Perf ROI combined visible");
            return aceTimingSummary(timing, 10);
         }.bind(this));
         this.runPerformanceTimed(rows, labelPrefix + " / native detail combined visible preview", ACE_PERF_BUDGET_DETAIL_MS, function() {
            var timing = { items: [] };
            this.appState.processor.processPreview(makePreviewData(), combined, makeVisiblePreviewProtection(), advanced, timing, "Detail preview perf ROI combined visible");
            return aceTimingSummary(timing, 10);
         }.bind(this));
         this.runPerformanceTimed(rows, labelPrefix + " / ROI Clarity protected preview", ACE_PERF_BUDGET_DRAFT_MS, function() {
            var timing = { items: [] };
            this.appState.processor.processPreview(makePreviewData(), clarityFull, localProtection, advanced, timing, "Perf ROI clarity");
            return aceTimingSummary(timing, 8);
         }.bind(this));
         this.runPerformanceTimed(rows, labelPrefix + " / ROI Dehaze protected preview", ACE_PERF_BUDGET_DRAFT_MS, function() {
            var timing = { items: [] };
            this.appState.processor.processPreview(makePreviewData(), dehazeFull, localProtection, advanced, timing, "Perf ROI dehaze");
            return aceTimingSummary(timing, 8);
         }.bind(this));
         this.runPerformanceTimed(rows, labelPrefix + " / ROI combined protected preview", ACE_PERF_BUDGET_DRAFT_MS, function() {
            var timing = { items: [] };
            this.appState.processor.processPreview(makePreviewData(), combined, localProtection, advanced, timing, "Perf ROI combined");
            return aceTimingSummary(timing, 10);
         }.bind(this));
         this.runPerformanceTimed(rows, labelPrefix + " / full-fast local operation", ACE_PERF_BUDGET_DETAIL_MS, function() {
            var timing = { items: [] };
            this.applyFullResolutionOperation(roi.width, roi.height, new Float32Array(roi.rgb), combined, starsProtection, lassoWeight, advanced, timing, "Perf full-fast local");
            return aceTimingSummary(timing, 10);
         }.bind(this));

         if (r === 0) {
            this.processingMode = "lasso";
            this.appState.lassoPoints = aceCopyPointArray(lassoPoints);
            this.appState.lassoInverted = false;
            ++this.appState.lassoVersion;
            this.invalidateLassoMasks();
            this.runPerformanceTimed(rows, labelPrefix + " / actual draft flow combined", ACE_PERF_BUDGET_DRAFT_MS, function() {
               this.setEffectSlidersSilently(combined);
               this.rebuildProcessedDraftPreview();
               return "pendingActive=" + (this.appState.cache.pendingActive ? "yes" : "no") + " detail=" + (this.appState.cache.detail ? "yes" : "no");
            }.bind(this));
            this.runPerformanceTimed(rows, labelPrefix + " / actual draft flow cache reuse", ACE_PERF_BUDGET_DRAFT_MS, function() {
               this.setEffectSlidersSilently(aceValidationParams(ACE_TEXTURE_SLIDER_MAX, ACE_CLARITY_SLIDER_MAX, 0));
               this.rebuildProcessedDraftPreview();
               return "pendingActive=" + (this.appState.cache.pendingActive ? "yes" : "no") +
                  " boundedCache=" + (this.appState.cache.localBoundedDraftCache ? "yes" : "no");
            }.bind(this));
            this.runPerformanceTimed(rows, labelPrefix + " / reset flow draft recovery", ACE_PERF_BUDGET_RESET_MS, function() {
               this.resetEnhancementAdjustments();
               this.stopPendingDetailRefreshes();
               this.detailPreviewPendingNavigation = false;
               this.detailPreviewPendingAdjustment = false;
               return "params=" + JSON.stringify(this.appState.params);
            }.bind(this));
         }
      }
   } finally {
      this.restoreAfterPerformanceFlowAudit(saved);
   }

   var workflowCounts = acePerformanceAuditCountRows(rows, true);
   var allCounts = acePerformanceAuditCountRows(rows, false);
   passCount = allCounts.pass;
   reviewCount = allCounts.review;
   slowCount = allCounts.slow;
   failCount = allCounts.fail;
   rows.sort(function(a, b) { return b.ms - a.ms; });
   aceValidationWriteLine("");
   aceValidationWriteLine("ACE PERFORMANCE WORKFLOW HEALTH");
   for (var w = 0, shownWorkflow = 0; w < rows.length && shownWorkflow < 8; ++w) {
      if (!acePerformanceAuditIsWorkflowRow(rows[w].label))
         continue;
      ++shownWorkflow;
      aceValidationWriteLine(shownWorkflow + ". " + rows[w].status + " | " + rows[w].ms + " ms | " + rows[w].label + (rows[w].detail ? " | " + rows[w].detail : ""));
   }
   aceValidationWriteLine("ACE PERFORMANCE DIAGNOSTIC TOP OFFENDERS");
   for (var t = 0, shownDiag = 0; t < rows.length && shownDiag < 8; ++t) {
      if (acePerformanceAuditIsWorkflowRow(rows[t].label))
         continue;
      ++shownDiag;
      aceValidationWriteLine(shownDiag + ". " + rows[t].status + " | " + rows[t].ms + " ms | " + rows[t].label + (rows[t].detail ? " | " + rows[t].detail : ""));
   }
   aceValidationWriteLine("ACE PERFORMANCE WORKFLOW SUMMARY | pass=" + workflowCounts.pass + " review=" + workflowCounts.review + " slow=" + workflowCounts.slow + " fail=" + workflowCounts.fail + " total_rows=" + workflowCounts.total);
   aceValidationWriteLine("ACE PERFORMANCE FLOW AUDIT SUMMARY | pass=" + passCount + " review=" + reviewCount + " slow=" + slowCount + " fail=" + failCount + " total_ms=" + (Date.now() - startAll));
   aceValidationWriteLine("Interpretation: workflow rows are the user-facing timing gates. Diagnostic rows are stress probes; REVIEW there identifies optimization debt, not a failed workflow.");
   aceValidationWriteLine("");
   this.refreshPreviewStatus(this.describeLoadedSource(), "Performance audit written to console");
   aceMessage("Performance audit written to the PixInsight console.\n\nNo diagnostic images were created. The audit restored the preview state after running synthetic local-edit flows.", ACE_TOOL_NAME + " " + ACE_VERSION);
};

AstroContrastEnhancerDialog.prototype.runStateValidationSuite = function() {
   if (!this.hasOutputImage()) {
      aceMessage("No active image loaded for validation.", ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   var rois = this.extractStateValidationRois();
   if (!rois || rois.length < 1) {
      aceMessage("Unable to extract validation ROIs.", ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   var cache = this.appState.cache;
   var passCount = 0;
   var reviewCount = 0;
   var failCount = 0;
   var highGridSourceCarried = 0;
   var highGridAmplified = 0;
   var highGridMildlyAmplified = 0;
   var highGridElevated = 0;
   var routeReviewCount = 0;
   var routeTinyDiffPassCount = 0;
   var starsStarlessReviewCount = 0;
   var starsStarlessExpectedCount = 0;
   var starsStarlessLeakCount = 0;
   var modeResponseReviewCount = 0;
   var modeResponseMaskedPassCount = 0;
   var starProtectedPreviewTime = 0;
   var starProtectedPreviewRows = 0;
   var unprotectedPreviewTime = 0;
   var unprotectedPreviewRows = 0;
   var zero = aceValidationParams(0, 0, 0);
   var textureMid = aceValidationParams(75, 0, 0);
   var textureFull = aceValidationParams(ACE_TEXTURE_SLIDER_MAX, 0, 0);
   var clarityMid = aceValidationParams(0, 75, 0);
   var clarityFull = aceValidationParams(0, ACE_CLARITY_SLIDER_MAX, 0);
   var combined = aceValidationParams(ACE_TEXTURE_SLIDER_MAX, ACE_CLARITY_SLIDER_MAX, 0);
   var dehazeFull = aceValidationParams(0, 0, ACE_DEHAZE_SLIDER_MAX);
   var starlessAll = this.makeStateValidationProtection("starless", true, false, true, false);
   var starsAll = this.makeStateValidationProtection("stars", true, true, true, true);
   var starsNoStarProtection = this.makeStateValidationProtection("stars", true, false, true, false);
   var starsNoSkyProtection = this.makeStateValidationProtection("stars", false, true, true, true);
   var starsNoGuard = this.makeStateValidationProtection("stars", true, true, false, true);

   this.refreshPreviewStatus(this.describeLoadedSource(), "Running state validation...");
   aceValidationWriteLine("");
   aceValidationWriteLine("ACE STATE VALIDATION " + ACE_VERSION);
   aceValidationWriteLine("Source: " + (cache.source.viewId || "Image") + " | full=" + cache.source.width + "x" + cache.source.height + " | rois=" + rois.length + " | maxRoiEdge=" + ACE_STATE_VALIDATION_ROI_MAX_EDGE);
   aceValidationWriteLine("Detail crop preview enabled: " + (ACE_DETAIL_CROP_PREVIEW_ENABLED ? "yes" : "no"));
   aceValidationWriteLine("Fast star preview path: " + (ACE_USE_FAST_STAR_PREVIEW ? "yes" : "no"));
   aceValidationWriteLine("No diagnostic images are created by this validation suite.");
   aceValidationWriteLine("Rows: status | case | route | image type | protections | params | delta metrics | grid-period score | source grid | amplification | grid class | time");
   aceValidationWriteLine("Star-protected rows include star/apply timing. State checks may include open/protected masked metrics.");

   for (var r = 0; r < rois.length; ++r) {
      var roi = rois[r];
      var sourceLuminance = aceLuminanceFromRgb(roi.width, roi.height, roi.rgb);
      var sourceGrid = aceValidationGridSummary(roi.width, roi.height, sourceLuminance);
      var rows = [];
      var prefix = "ROI " + (r + 1) + "/" + rois.length + " " + roi.label;

      aceValidationWriteLine("");
      aceValidationWriteLine(prefix + " | " + roi.width + "x" + roi.height + " @ " + roi.x0 + "," + roi.y0 + " | sourceGrid=" + aceValidationNumber(sourceGrid.score, 3) + "@p" + sourceGrid.period);

      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / identity starless preview", "preview", "starless", zero, starlessAll));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / identity stars full-fast", "full-fast", "stars", zero, starsAll));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / texture mid starless", "preview", "starless", textureMid, starlessAll));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / texture full starless", "preview", "starless", textureFull, starlessAll));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / clarity mid starless", "preview", "starless", clarityMid, starlessAll));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / clarity full starless", "preview", "starless", clarityFull, starlessAll));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / combined stars preview", "preview", "stars", combined, starsAll));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / combined stars full-fast", "full-fast", "stars", combined, starsAll));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / combined stars no-star-protect", "preview", "stars", combined, starsNoStarProtection));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / combined stars no-sky-protect", "preview", "stars", combined, starsNoSkyProtection));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / combined stars no-guard", "preview", "stars", combined, starsNoGuard));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / combined starless preview", "preview", "starless", combined, starlessAll));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / texture full stars preview", "preview", "stars", textureFull, starsAll));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / clarity full stars preview", "preview", "stars", clarityFull, starsAll));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / dehaze full stars preview", "preview", "stars", dehazeFull, starsAll));
      rows.push(this.stateValidationCase(roi, sourceLuminance, sourceGrid, prefix + " / dehaze full starless preview", "preview", "starless", dehazeFull, starlessAll));

      for (var i = 0; i < rows.length; ++i) {
         this.printStateValidationCase(rows[i]);
         if (rows[i].status === "FAIL")
            ++failCount;
         else if (rows[i].status === "REVIEW")
            ++reviewCount;
         else
            ++passCount;
         if (rows[i].gridScore >= 1.75) {
            if (rows[i].gridClass === "grid ACE-amplified")
               ++highGridAmplified;
            else if (rows[i].gridClass === "grid mildly amplified")
               ++highGridMildlyAmplified;
            else if (rows[i].gridClass === "grid source-carried")
               ++highGridSourceCarried;
            else
               ++highGridElevated;
         }
         if (rows[i].route === "preview" && rows[i].inputType === "stars" && rows[i].protection && rows[i].protection.protectStars) {
            starProtectedPreviewTime += rows[i].timingMs;
            ++starProtectedPreviewRows;
         } else if (rows[i].route === "preview") {
            unprotectedPreviewTime += rows[i].timingMs;
            ++unprotectedPreviewRows;
         }
      }

      var textureRatio = rows[3].meanAbs / Math.max(ACE_EPSILON, rows[2].meanAbs);
      var textureStatus = rows[3].meanAbs > rows[2].meanAbs * 1.15 ? "PASS" : "FAIL";
      this.printStateValidationCheck(textureStatus, prefix + " / texture monotonic response", "full/mid meanAbs ratio=" + aceValidationNumber(textureRatio, 3));
      if (textureStatus === "FAIL")
         ++failCount;
      else
         ++passCount;

      var clarityRatio = rows[5].meanAbs / Math.max(ACE_EPSILON, rows[4].meanAbs);
      var clarityStatus = rows[5].meanAbs > rows[4].meanAbs * 1.15 ? "PASS" : "FAIL";
      this.printStateValidationCheck(clarityStatus, prefix + " / clarity monotonic response", "full/mid meanAbs ratio=" + aceValidationNumber(clarityRatio, 3));
      if (clarityStatus === "FAIL")
         ++failCount;
      else
         ++passCount;

      var routeDiff = aceValidationRgbDifferenceStats(rows[6].rgb, rows[7].rgb);
      var routeCorr = aceValidationCorrelation(rows[6].delta, rows[7].delta);
      var routeTinyDiff = routeDiff.meanAbs <= 0.00025 && routeDiff.rms <= 0.003;
      var routeStatus = (routeCorr >= 0.985 && routeDiff.rms <= 0.015) || routeTinyDiff ? "PASS" : "REVIEW";
      this.printStateValidationCheck(routeStatus, prefix + " / preview vs full-fast route correlation", "corr=" + aceValidationNumber(routeCorr, 5) + " rgbRms=" + aceValidationNumber(routeDiff.rms, 6) + " meanAbs=" + aceValidationNumber(routeDiff.meanAbs, 6) + (routeTinyDiff ? " absGate=tiny-diff" : ""));
      if (routeStatus === "REVIEW")
         ++reviewCount;
      else
         ++passCount;
      if (routeStatus === "REVIEW")
         ++routeReviewCount;
      else if (routeTinyDiff)
         ++routeTinyDiffPassCount;

      var starProtectionStatus = rows[6].meanAbs <= rows[8].meanAbs * 1.05 ? "PASS" : "REVIEW";
      this.printStateValidationCheck(starProtectionStatus, prefix + " / star protection monotonicity", "protected meanAbs=" + aceValidationNumber(rows[6].meanAbs, 6) + " unprotected=" + aceValidationNumber(rows[8].meanAbs, 6));
      if (starProtectionStatus === "REVIEW")
         ++reviewCount;
      else
         ++passCount;

      var skyProtectionStatus = rows[6].meanAbs <= rows[9].meanAbs * 1.05 ? "PASS" : "REVIEW";
      this.printStateValidationCheck(skyProtectionStatus, prefix + " / sky protection monotonicity", "protected meanAbs=" + aceValidationNumber(rows[6].meanAbs, 6) + " unprotected=" + aceValidationNumber(rows[9].meanAbs, 6));
      if (skyProtectionStatus === "REVIEW")
         ++reviewCount;
      else
         ++passCount;

      var guardStatus = rows[6].meanAbs <= rows[10].meanAbs * 1.05 ? "PASS" : "REVIEW";
      this.printStateValidationCheck(guardStatus, prefix + " / dark-patch guard monotonicity", "guarded meanAbs=" + aceValidationNumber(rows[6].meanAbs, 6) + " unguarded=" + aceValidationNumber(rows[10].meanAbs, 6));
      if (guardStatus === "REVIEW")
         ++reviewCount;
      else
         ++passCount;

      var starsStarlessDiff = aceValidationRgbDifferenceStats(rows[6].rgb, rows[11].rgb);
      var starsStarlessCorr = aceValidationCorrelation(rows[6].delta, rows[11].delta);
      var starsStarlessMasked = aceValidationMaskedRgbDifferenceStats(roi.width, roi.height, rows[6].rgb, rows[11].rgb, rows[6].starProtectionMask);
      var starsStarlessExpected = starsStarlessMasked.openCount > 0 &&
         starsStarlessMasked.openMeanAbs <= 0.0015 &&
         starsStarlessMasked.openRms <= 0.010;
      var starsStarlessStatus = starsStarlessDiff.meanAbs <= 0.010 && (starsStarlessCorr >= 0.970 || starsStarlessExpected) ? "PASS" : "REVIEW";
      this.printStateValidationCheck(starsStarlessStatus, prefix + " / stars vs starless combined divergence", "corr=" + aceValidationNumber(starsStarlessCorr, 5) + " rgbRms=" + aceValidationNumber(starsStarlessDiff.rms, 6) + " meanAbs=" + aceValidationNumber(starsStarlessDiff.meanAbs, 6) + " protectedPct=" + aceValidationNumber(starsStarlessMasked.protectedPct * 100, 1) + "% openMeanAbs=" + aceValidationNumber(starsStarlessMasked.openMeanAbs, 6) + " protectedMeanAbs=" + aceValidationNumber(starsStarlessMasked.protectedMeanAbs, 6) + (starsStarlessExpected ? " expected=star-region" : ""));
      if (starsStarlessStatus === "REVIEW")
         ++reviewCount;
      else
         ++passCount;
      if (starsStarlessStatus === "REVIEW")
         ++starsStarlessReviewCount;
      else if (starsStarlessExpected && starsStarlessCorr < 0.970)
         ++starsStarlessExpectedCount;
      if (starsStarlessStatus === "REVIEW" && starsStarlessMasked.openCount > 0 && starsStarlessMasked.openMeanAbs > 0.0015)
         ++starsStarlessLeakCount;

      var textureModeRatio = rows[12].meanAbs / Math.max(ACE_EPSILON, rows[3].meanAbs);
      var textureStarsMaskStats = aceValidationMaskedDeltaStats(rows[12].delta, rows[12].starProtectionMask);
      var textureStarlessMaskStats = aceValidationMaskedDeltaStats(rows[3].delta, rows[12].starProtectionMask);
      var textureOpenRatio = textureStarsMaskStats.openMeanAbs / Math.max(ACE_EPSILON, textureStarlessMaskStats.openMeanAbs);
      var textureModeMaskedPass = textureStarsMaskStats.openCount > 0 && textureOpenRatio >= 0.65 && textureOpenRatio <= 1.35;
      var textureModeStatus = (textureModeRatio >= 0.65 && textureModeRatio <= 1.35) || textureModeMaskedPass ? "PASS" : "REVIEW";
      this.printStateValidationCheck(textureModeStatus, prefix + " / texture stars-vs-starless response", "stars/starless meanAbs ratio=" + aceValidationNumber(textureModeRatio, 3) + " openRatio=" + aceValidationNumber(textureOpenRatio, 3) + " protectedPct=" + aceValidationNumber(textureStarsMaskStats.protectedPct * 100, 1) + "%" + (textureModeMaskedPass && (textureModeRatio < 0.65 || textureModeRatio > 1.35) ? " expected=star-region" : ""));
      if (textureModeStatus === "REVIEW")
         ++reviewCount;
      else
         ++passCount;
      if (textureModeStatus === "REVIEW")
         ++modeResponseReviewCount;
      else if (textureModeMaskedPass && (textureModeRatio < 0.65 || textureModeRatio > 1.35))
         ++modeResponseMaskedPassCount;

      var clarityModeRatio = rows[13].meanAbs / Math.max(ACE_EPSILON, rows[5].meanAbs);
      var clarityStarsMaskStats = aceValidationMaskedDeltaStats(rows[13].delta, rows[13].starProtectionMask);
      var clarityStarlessMaskStats = aceValidationMaskedDeltaStats(rows[5].delta, rows[13].starProtectionMask);
      var clarityOpenRatio = clarityStarsMaskStats.openMeanAbs / Math.max(ACE_EPSILON, clarityStarlessMaskStats.openMeanAbs);
      var clarityModeMaskedPass = clarityStarsMaskStats.openCount > 0 && clarityOpenRatio >= 0.65 && clarityOpenRatio <= 1.35;
      var clarityModeStatus = (clarityModeRatio >= 0.65 && clarityModeRatio <= 1.35) || clarityModeMaskedPass ? "PASS" : "REVIEW";
      this.printStateValidationCheck(clarityModeStatus, prefix + " / clarity stars-vs-starless response", "stars/starless meanAbs ratio=" + aceValidationNumber(clarityModeRatio, 3) + " openRatio=" + aceValidationNumber(clarityOpenRatio, 3) + " protectedPct=" + aceValidationNumber(clarityStarsMaskStats.protectedPct * 100, 1) + "%" + (clarityModeMaskedPass && (clarityModeRatio < 0.65 || clarityModeRatio > 1.35) ? " expected=star-region" : ""));
      if (clarityModeStatus === "REVIEW")
         ++reviewCount;
      else
         ++passCount;
      if (clarityModeStatus === "REVIEW")
         ++modeResponseReviewCount;
      else if (clarityModeMaskedPass && (clarityModeRatio < 0.65 || clarityModeRatio > 1.35))
         ++modeResponseMaskedPassCount;

      var dehazeHighTone = aceValidationHighToneDeltaStats(sourceLuminance, rows[14].delta, 0.72);
      var dehazeHighToneStarless = aceValidationHighToneDeltaStats(sourceLuminance, rows[15].delta, 0.72);
      var dehazeHighToneStatus = dehazeHighTone.pct <= 0.005 || dehazeHighTone.positiveMean <= 0.0065 ? "PASS" : "REVIEW";
      this.printStateValidationCheck(dehazeHighToneStatus, prefix + " / dehaze high-tone lift guard", "brightPct=" + aceValidationNumber(dehazeHighTone.pct * 100, 1) + "% positiveMean=" + aceValidationNumber(dehazeHighTone.positiveMean, 6) + " positiveMax=" + aceValidationNumber(dehazeHighTone.positiveMax, 6) + " starlessPositiveMean=" + aceValidationNumber(dehazeHighToneStarless.positiveMean, 6));
      if (dehazeHighToneStatus === "REVIEW")
         ++reviewCount;
      else
         ++passCount;

      var clarityHighTone = aceValidationHighToneDeltaStats(sourceLuminance, rows[13].delta, 0.72);
      var clarityHighToneStarless = aceValidationHighToneDeltaStats(sourceLuminance, rows[5].delta, 0.72);
      var clarityHighToneStatus = clarityHighTone.pct <= 0.010 || clarityHighTone.positiveMean <= 0.0105 ? "PASS" : "REVIEW";
      this.printStateValidationCheck(clarityHighToneStatus, prefix + " / clarity high-tone lift guard", "brightPct=" + aceValidationNumber(clarityHighTone.pct * 100, 1) + "% positiveMean=" + aceValidationNumber(clarityHighTone.positiveMean, 6) + " positiveMax=" + aceValidationNumber(clarityHighTone.positiveMax, 6) + " starlessPositiveMean=" + aceValidationNumber(clarityHighToneStarless.positiveMean, 6));
      if (clarityHighToneStatus === "REVIEW")
         ++reviewCount;
      else
         ++passCount;
   }

   var protectedAvg = starProtectedPreviewRows > 0 ? starProtectedPreviewTime / starProtectedPreviewRows / 1000 : 0;
   var unprotectedAvg = unprotectedPreviewRows > 0 ? unprotectedPreviewTime / unprotectedPreviewRows / 1000 : 0;
   var latencyRatio = protectedAvg / Math.max(ACE_EPSILON, unprotectedAvg);
   aceValidationWriteLine("");
   aceValidationWriteLine("ACE VALIDATION RISK SUMMARY");
   aceValidationWriteLine("Grid rows >=1.75: source-carried=" + highGridSourceCarried + " mildly-amplified=" + highGridMildlyAmplified + " ACE-amplified=" + highGridAmplified + " elevated=" + highGridElevated);
   aceValidationWriteLine("State reviews: route-correlation=" + routeReviewCount + " stars-vs-starless=" + starsStarlessReviewCount + " mode-response=" + modeResponseReviewCount);
   aceValidationWriteLine("State context: route tiny-diff passes=" + routeTinyDiffPassCount + " expected star-region divergence=" + starsStarlessExpectedCount + " possible star-state leaks=" + starsStarlessLeakCount + " masked mode-response passes=" + modeResponseMaskedPassCount);
   aceValidationWriteLine("Preview latency: star-protected avg=" + aceValidationNumber(protectedAvg, 2) + "s unprotected avg=" + aceValidationNumber(unprotectedAvg, 2) + "s ratio=" + aceValidationNumber(latencyRatio, 2));
   aceValidationWriteLine("Interpretation: source-carried grid points to the source/test image or to ACE amplifying existing JPG block structure visually. ACE-amplified grid points to a computation artifact that should be fixed before tuning.");
   aceValidationWriteLine("Interpretation: expected star-region divergence means Stars Present and Starless differ mainly where star protection exists. Possible star-state leaks mean the open, unprotected region changed too much.");
   aceValidationWriteLine("ACE STATE VALIDATION SUMMARY | pass=" + passCount + " review=" + reviewCount + " fail=" + failCount);
   aceValidationWriteLine("Interpretation: FAIL means the state model is internally inconsistent. REVIEW means the metric found a plausible risk that needs targeted inspection, not a pile of diagnostic images.");
   aceValidationWriteLine("");
   this.refreshPreviewStatus(this.describeLoadedSource(), "Validation report written to console");
   aceMessage("State validation report written to the PixInsight console.\n\nNo diagnostic images were created.", ACE_TOOL_NAME + " " + ACE_VERSION);
};

AstroContrastEnhancerDialog.prototype.addComputeAuditItem = function(items, width, height, signedMap, id, label) {
   if (!items || !signedMap)
      return;
   var stats = aceSignedMapStats(width, height, signedMap);
   items.push({
      width: width,
      height: height,
      gray: aceSignedMapToDisplayGray(width, height, signedMap),
      id: id,
      label: label,
      stats: stats
   });
};

AstroContrastEnhancerDialog.prototype.luminanceDeltaFromRgb = function(width, height, sourceLuminance, rgb) {
   var processedLuminance = aceLuminanceFromRgb(width, height, rgb);
   var count = width * height;
   var delta = new Float32Array(count);
   for (var i = 0; i < count; ++i)
      delta[i] = processedLuminance[i] - sourceLuminance[i];
   return delta;
};

AstroContrastEnhancerDialog.prototype.runComputeAuditPass = function(width, height, sourceRgb, layerCache, params, protection, advanced, label) {
   var previewData = {
      width: width,
      height: height,
      rgb: sourceRgb,
      layerCache: layerCache,
      starProtectionBase: null,
      starProtectionMaps: null,
      starProtectionKey: ""
   };
   var effectiveProtection = aceCopyProtectionOptions(protection);
   effectiveProtection.advanced = advanced;
   effectiveProtection.fastFullResolutionStarMask = true;
   var starMaps = this.appState.processor.getStarProtectionMaps(previewData, effectiveProtection);
   effectiveProtection.starAllowedWeight = starMaps ? starMaps.allowedWeight : null;
   return this.appState.processor.engine.apply(width, height, sourceRgb, params, layerCache, effectiveProtection, advanced, null, label);
};

AstroContrastEnhancerDialog.prototype.buildComputeAuditOutputs = function() {
   var cache = this.appState.cache;
   if (!cache.sourceRgb || cache.source.width < 1 || cache.source.height < 1)
      return [];
   var width = cache.source.width;
   var height = cache.source.height;
   var sourceId = cache.source.viewId || "Image";
   var params = aceCopyParams(this.appState.globalParams);
   var protection = aceCopyProtectionOptions(this.appState.globalProtection || this.getProtectionOptions());
   var advanced = aceCopyAdvancedParams(this.appState.globalAdvanced);
   var layerCache = this.appState.processor.engine.buildLayerCache(width, height, cache.sourceRgb, advanced);
   var sourceLuminance = layerCache.luminance;
   var textureParams = new EffectParameters;
   var clarityParams = new EffectParameters;
   textureParams.texture = params.texture;
   clarityParams.clarity = params.clarity;

   var allRgb = this.runComputeAuditPass(width, height, cache.sourceRgb, layerCache, params, protection, advanced, "Compute audit combined");
   var textureRgb = this.runComputeAuditPass(width, height, cache.sourceRgb, layerCache, textureParams, protection, advanced, "Compute audit texture");
   var clarityRgb = this.runComputeAuditPass(width, height, cache.sourceRgb, layerCache, clarityParams, protection, advanced, "Compute audit clarity");

   var allDelta = this.luminanceDeltaFromRgb(width, height, sourceLuminance, allRgb);
   var textureDelta = this.luminanceDeltaFromRgb(width, height, sourceLuminance, textureRgb);
   var clarityDelta = this.luminanceDeltaFromRgb(width, height, sourceLuminance, clarityRgb);

   var items = [];
   this.addComputeAuditItem(items, width, height, allDelta, sourceId + "_ACE_Compute_CombinedDelta", "Combined final delta");
   this.addComputeAuditItem(items, width, height, textureDelta, sourceId + "_ACE_Compute_TextureOnlyDelta", "Texture-only final delta");
   this.addComputeAuditItem(items, width, height, clarityDelta, sourceId + "_ACE_Compute_ClarityOnlyDelta", "Clarity-only final delta");
   return items;
};

AstroContrastEnhancerDialog.prototype.saveComputeAuditOutput = function() {
   if (this.outputRendering)
      return;
   if (!this.hasOutputImage()) {
      this.refreshPreviewStatus("No active image", "No active image loaded.");
      aceMessage("No active image loaded.", ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   if (!this.confirmFullResolutionRender("Compute Audit"))
      return;
   this.setOutputRendering(true, "Building full-resolution compute audit. Please wait...");
   var items = [];
   var created = 0;
   try {
      this.setOutputProgress(
         "Building full-resolution compute audit. Please wait...",
         "Building compute audit - please wait",
         "Saving three targeted signed maps: Combined, Texture-only, and Clarity-only."
      );
      items = this.buildComputeAuditOutputs();
      if (!items || items.length < 1)
         throw new Error("No compute audit maps were available.");
      for (var i = 0; i < items.length; ++i) {
         var item = items[i];
         if (!item || !item.gray)
            continue;
         this.setOutputProgress(
            "Writing compute audit " + (i + 1) + " of " + items.length + ": " + item.label,
            "Writing compute audit - please wait",
            item.label
         );
         aceCreateGrayImageWindow(item.width, item.height, item.gray, item.id);
         ++created;
      }
   } catch (error) {
      this.setOutputRendering(false, "Compute audit failed.");
      aceMessage(error && error.message ? error.message : String(error), ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   this.setOutputRendering(false);
   this.refreshPreviewStatus(this.describeLoadedSource(), "Compute audit saved: " + created + " images");
   aceMessage("Compute audit saved " + created + " targeted full-resolution diagnostic images:\n\nCombinedDelta\nTextureOnlyDelta\nClarityOnlyDelta\n\nSigned delta maps use mid-gray as zero. Bright = positive luminance change; dark = negative luminance change.", ACE_TOOL_NAME + " " + ACE_VERSION);
};

AstroContrastEnhancerDialog.prototype.saveCurrentMaskOutput = function() {
   if (this.outputRendering)
      return;
   if (!this.hasOutputImage()) {
      this.refreshPreviewStatus("No active image", "No active image loaded.");
      aceMessage("No active image loaded.", ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   if (!this.currentMaskViewCanSave()) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "Switch to a diagnostic view to save it.");
      aceMessage("Save Current Mask saves the current diagnostic view.\n\nUse Texture, Clarity, Dehaze, Delta, Lasso, Star, or Edit Area view, then save.", ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Information);
      return;
   }
   if (!this.confirmFullResolutionRender("Save Current Mask"))
      return;
   this.setOutputRendering(true, "Building full-resolution diagnostic image. Please wait...");
   var saveStart = Date.now();
   var buildMs = 0;
   var writeMs = 0;
   var mask = null;
   var createdMask = null;
   try {
      this.setOutputProgress(
         "Building full-resolution diagnostic image. Please wait...",
         "Building diagnostic - please wait",
         "ACE is preparing the current diagnostic view at full resolution."
      );
      var buildStart = Date.now();
      mask = this.getCurrentMaskOutput();
      buildMs = Date.now() - buildStart;
      if (!mask || !mask.gray)
         throw new Error("No current mask to save.");
      this.setOutputProgress(
         "Writing full-resolution mask image. Please wait...",
         "Writing mask - please wait",
         "PixInsight may write swap files during this step."
      );
      var writeStart = Date.now();
      createdMask = aceCreateGrayImageWindow(mask.width, mask.height, mask.gray, mask.id);
      writeMs = Date.now() - writeStart;
   } catch (error) {
      this.setOutputRendering(false, "Mask save failed.");
      this.refreshPreviewStatus(this.describeLoadedSource(), "No current mask to save.");
      aceMessage(error && error.message ? error.message : String(error), ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Warning);
      return;
   }
   this.setOutputRendering(false);
   var totalMs = Date.now() - saveStart;
   var maskId = createdMask && createdMask.mainView ? createdMask.mainView.id : aceSanitizeImageId(mask.id);
   aceConsoleWriteLine("[ACE] Save Current Mask timing | total=" + totalMs + " ms" +
      " build=" + buildMs + " ms" +
      " write=" + writeMs + " ms" +
      " view=" + (this.appState.preview.viewMode || "preview"));
   this.refreshPreviewStatus(this.describeLoadedSource(), mask.status + " " + maskId + " in " + (totalMs / 1000).toFixed(1) + " s");
   aceMessage(mask.status + "\n\nCreated diagnostic image: " + maskId +
      "\nElapsed: " + (totalMs / 1000).toFixed(1) + " s" +
      "\nBuild: " + (buildMs / 1000).toFixed(1) + " s" +
      "\nWrite: " + (writeMs / 1000).toFixed(1) + " s", ACE_TOOL_NAME + " " + ACE_VERSION);
};

AstroContrastEnhancerDialog.prototype.clearLassoSelection = function() {
   var hadPending = this.appState.cache.pendingActive;
   this.exitBeforeAfterForEditChange();
   this.resetPreviewInteractionState(hadPending);
   this.clearPendingLocalPreview(!hadPending);
   this.appState.lassoPoints = [];
   this.appState.lassoInverted = false;
   this.localSelectionNewActive = false;
   this.lastLocalAction = "cleared";
   this.setProcessingMode("full");
   this.handleLassoChanged("Full Image active");
   this.refreshPreviewStatus(this.describeLoadedSource(), "Full Image active");
};

AstroContrastEnhancerDialog.prototype.newLassoSelection = function() {
   var hadPending = this.appState.cache.pendingActive;
   this.exitBeforeAfterForEditChange();
   var canKeepDetail = !hadPending && this.appState.cache.detail && this.shouldUseDetailPreview();
   if (canKeepDetail)
      this.resetPreviewInteractionStateKeepDetail();
   else
      this.resetPreviewInteractionState(hadPending);
   if (this.processingMode !== "lasso")
      this.setProcessingMode("lasso");
   this.clearPendingLocalPreview(!hadPending);
   this.resetEffectSlidersSilently();
   if (this.commitButton)
      this.commitButton.setActive(false);
   this.appState.lassoPoints = [];
   this.appState.lassoInverted = false;
   this.localSelectionNewActive = true;
   this.lastLocalAction = "new";
   if (hadPending) {
      this.handleLassoChanged("Pending edit discarded. Draw lasso selection.");
   } else {
      ++this.appState.lassoVersion;
      this.invalidateLassoMasks();
      this.refreshLocalSelectionControls();
      this.refreshPreviewStatus(this.describeLoadedSource(), "Draw lasso selection. Adjustment reset.");
      this.updatePreviewCursor();
      if (this.preview)
         this.preview.update();
   }
};

AstroContrastEnhancerDialog.prototype.flashLassoActionButton = function(button, statusText) {
   if (button)
      button.setActive(true);
   this.refreshPreviewStatus(this.describeLoadedSource(), statusText || "Updating selection...");
   if (this.preview)
      this.preview.update();
   if (button)
      button.update();
};

AstroContrastEnhancerDialog.prototype.clearLassoActionButtonFlash = function() {
   if (this.refineButton)
      this.refineButton.setActive(false);
   if (this.expandLassoButton)
      this.expandLassoButton.setActive(false);
   if (this.contractLassoButton)
      this.contractLassoButton.setActive(false);
};

AstroContrastEnhancerDialog.prototype.invertLassoSelection = function() {
   if (!this.canStartLassoShapeAction("invert"))
      return;
   this.beginLassoGeometryTransition("invert");
   this.appState.lassoInverted = !this.appState.lassoInverted;
   this.lastLocalAction = "inverted";
   this.markLassoGeometryDirty();
   this.scheduleLassoChanged(this.appState.lassoInverted ? "Lasso: inverted" : "Lasso: normal");
};

AstroContrastEnhancerDialog.prototype.refineLassoSelection = function() {
   if (!this.canStartLassoShapeAction("refine"))
      return;
   this.beginLassoGeometryTransition("refine");
   this.flashLassoActionButton(this.refineButton, "Refine...");
   var refined = aceFinalizeLassoPoints(this.appState.lassoPoints);
   if (!aceLassoGeometryInfo(refined).valid) {
      this.clearLassoActionButtonFlash();
      this.refreshPreviewStatus(this.describeLoadedSource(), "Selection too small to refine");
      this.endLassoGeometryTransition();
      return;
   }
   this.appState.lassoPoints = refined;
   this.lastLocalAction = "refined";
   this.markLassoGeometryDirty();
   this.refreshPreviewStatus(this.describeLoadedSource(), "Refine...");
   this.scheduleLassoChanged("Lasso: refined");
};

AstroContrastEnhancerDialog.prototype.getLassoBounds = function(points) {
   points = points || this.appState.lassoPoints;
   if (!points || points.length < 1)
      return null;
   var x0 = points[0].x;
   var y0 = points[0].y;
   var x1 = points[0].x;
   var y1 = points[0].y;
   for (var i = 1; i < points.length; ++i) {
      x0 = Math.min(x0, points[i].x);
      y0 = Math.min(y0, points[i].y);
      x1 = Math.max(x1, points[i].x);
      y1 = Math.max(y1, points[i].y);
   }
   return { x0: x0, y0: y0, x1: x1, y1: y1, width: Math.max(1, x1 - x0), height: Math.max(1, y1 - y0) };
};

AstroContrastEnhancerDialog.prototype.autoFocusLassoSelection = function() {
   if (!this.hasLassoSelection() || !this.preview || !this.appState.cache.draft)
      return;
   var bounds = this.getLassoBounds();
   if (!bounds)
      return;
   var source = this.appState.cache.source;
   var draft = this.appState.cache.draft;
   var feather = this.featherSlider ? this.featherSlider.value : ACE_FEATHER_DEFAULT;
   var featheredWidth = bounds.width + feather * 2;
   var featheredHeight = bounds.height + feather * 2;
   var expand = feather + Math.max(featheredWidth, featheredHeight) * ACE_LASSO_AUTO_FOCUS_MARGIN;
   var x0 = aceClamp(bounds.x0 - expand, 0, source.width);
   var y0 = aceClamp(bounds.y0 - expand, 0, source.height);
   var x1 = aceClamp(bounds.x1 + expand, 0, source.width);
   var y1 = aceClamp(bounds.y1 + expand, 0, source.height);
   var regionW = Math.max(1, (x1 - x0) * draft.width / Math.max(1, source.width));
   var regionH = Math.max(1, (y1 - y0) * draft.height / Math.max(1, source.height));
   var scale = Math.min(
      ACE_LASSO_AUTO_FOCUS_MAX_ZOOM,
      Math.max(0.25, Math.min((this.preview.width - 40) / regionW, (this.preview.height - 40) / regionH))
   );
   var centerX = (x0 + x1) * 0.5 * draft.width / Math.max(1, source.width);
   var centerY = (y0 + y1) * 0.5 * draft.height / Math.max(1, source.height);
   this.appState.preview.zoomMode = "manual";
   this.appState.preview.zoomScale = scale;
   this.appState.preview.panX = scale * (draft.width * 0.5 - centerX);
   this.appState.preview.panY = scale * (draft.height * 0.5 - centerY);
   this.clampPan();
   this.appState.cache.detail = null;
};

AstroContrastEnhancerDialog.prototype.isPointInsideCurrentLasso = function(point) {
   if (!point || !this.hasLassoSelection())
      return false;
   if (acePointInPolygon(point.x, point.y, this.appState.lassoPoints))
      return true;
   for (var i = 0; i < this.appState.lassoPoints.length; ++i) {
      var p = this.appState.lassoPoints[i];
      var dx = p.x - point.x;
      var dy = p.y - point.y;
      if (dx * dx + dy * dy <= ACE_LASSO_MOVE_HIT_TOLERANCE * ACE_LASSO_MOVE_HIT_TOLERANCE)
         return true;
   }
   return false;
};

AstroContrastEnhancerDialog.prototype.handlePreviewMousePress = function(x, y) {
   if (this.outputRendering)
      return;
   this.lowZoomLoupeMouseValid = true;
   this.lowZoomLoupeMouseX = x;
   this.lowZoomLoupeMouseY = y;
   if (!this.getCurrentPreviewBitmap())
      return;
   if (this.processingMode === "lasso" && this.appState.preview.viewMode !== "star") {
      var sourcePoint = this.sourcePointFromPreview(x, y);
      if (!this.hasLassoSelection()) {
         this.stopPendingDetailRefreshes();
         this.bumpDetailRefreshGeneration();
         this.detailPreviewPendingNavigation = false;
         this.detailPreviewPendingAdjustment = false;
         this.appState.preview.showBefore = false;
         this.previewCanPanFromPress = false;
         this.previewCompareArmed = false;
         this.previewDragging = false;
         if (!sourcePoint) {
            this.previewMouseDown = false;
            this.lassoDrawing = false;
            this.lassoDragOperation = "none";
            this.clearPreviewGestureBitmap();
            this.refreshPreviewStatus(this.describeLoadedSource(), "Click on image to draw lasso");
            this.updatePreviewCursor();
            if (this.preview)
               this.preview.update();
            return;
         }
         this.beginPreviewGestureBitmap(false, true);
         this.lassoDrawing = true;
         this.lassoDragOperation = "drawing";
         this.lassoDrawPoints = [sourcePoint];
         this.previewMouseDown = true;
         if (this.previewHoldTimer)
            this.previewHoldTimer.stop();
         this.refreshPreviewStatus(this.describeLoadedSource(), "Lasso: drawing");
         this.updatePreviewCursor();
         this.preview.update();
         return;
      }
      if (sourcePoint) {
         if (this.isPointInsideCurrentLasso(sourcePoint)) {
            this.beginPreviewGestureBitmap(true, false);
            this.beginLassoGeometryTransition("move");
            this.lassoMoving = true;
            this.lassoHoverInside = true;
            this.lassoDragOperation = "moving";
            this.lassoMoveStartPoint = sourcePoint;
            this.lassoMoveOriginalPoints = this.appState.lassoPoints.slice(0);
            this.previewMouseDown = true;
            this.previewDragging = false;
            this.previewCompareArmed = false;
            if (this.previewHoldTimer)
               this.previewHoldTimer.stop();
            this.refreshPreviewStatus(this.describeLoadedSource(), "Moving lasso...");
            this.updatePreviewCursor(true);
            this.preview.update();
            return;
         }
         if (this.hasLassoSelection()) {
            this.beginPreviewGestureBitmap(true, false);
            if (this.shouldUseDetailPreview())
               this.invalidateDetailForNavigation();
            this.previewMouseDown = true;
            this.previewDragging = false;
            this.previewCompareArmed = false;
            this.previewCanPanFromPress = true;
            this.lassoHoverInside = false;
            this.lassoDragOperation = "panning";
            this.previewDragStartX = x;
            this.previewDragStartY = y;
            this.previewPanStartX = this.appState.preview.panX;
            this.previewPanStartY = this.appState.preview.panY;
            this.previewLastMouseX = x;
            this.previewLastMouseY = y;
            if (this.previewHoldTimer)
               this.previewHoldTimer.stop();
            this.refreshPreviewStatus(this.describeLoadedSource(), "Drag to pan image");
            this.updatePreviewCursor(false);
            this.preview.update();
            return;
         }
         this.beginPreviewGestureBitmap(false, true);
         this.lassoDrawing = true;
         this.lassoDragOperation = "drawing";
         this.lassoDrawPoints = [sourcePoint];
         this.previewMouseDown = true;
         this.previewDragging = false;
         this.previewCompareArmed = false;
         if (this.previewHoldTimer)
            this.previewHoldTimer.stop();
         this.refreshPreviewStatus(this.describeLoadedSource(), "Lasso: drawing");
         this.updatePreviewCursor();
         this.preview.update();
         return;
      }
      this.clearPreviewGestureBitmap();
   }
   this.previewMouseDown = true;
   this.previewDragging = false;
   this.previewCompareArmed = this.appState.preview.viewMode === "preview" && !this.appState.preview.showMask;
   this.previewCanPanFromPress = this.appState.preview.tool === "pan" || this.appState.preview.zoomMode !== "fit";
   if (this.previewCanPanFromPress && this.shouldUseDetailPreview())
      this.invalidateDetailForNavigation();
   this.previewDragStartX = x;
   this.previewDragStartY = y;
   this.previewPanStartX = this.appState.preview.panX;
   this.previewPanStartY = this.appState.preview.panY;
   this.previewLastMouseX = x;
   this.previewLastMouseY = y;
   if (this.previewHoldTimer)
      this.previewHoldTimer.start();
};

AstroContrastEnhancerDialog.prototype.handlePreviewMouseMove = function(x, y) {
   if (this.outputRendering)
      return;
   this.lowZoomLoupeMouseValid = true;
   this.lowZoomLoupeMouseX = x;
   this.lowZoomLoupeMouseY = y;
   if (!this.previewMouseDown && this.lowZoomLoupeShouldBeActive()) {
      if (this.sourcePointForPreviewPosition(x, y))
         this.scheduleLowZoomLoupeRefresh("Detail loupe queued");
      else
         this.clearLowZoomLoupe();
   }
   if (!this.previewMouseDown && this.processingMode === "lasso" && this.appState.preview.viewMode !== "star" && this.hasLassoSelection()) {
      var hoverPoint = this.sourcePointFromPreview(x, y);
      var insideHover = this.isPointInsideCurrentLasso(hoverPoint);
      if (insideHover !== this.lassoHoverInside) {
         this.lassoHoverInside = insideHover;
         this.refreshPreviewStatus(this.describeLoadedSource(), insideHover ? "Drag to move selection" : "Drag to pan image");
         this.updatePreviewCursor(insideHover);
      }
      return;
   }
   if (this.lassoMoving) {
      var movePoint = this.sourcePointFromPreview(x, y);
      if (movePoint && this.lassoMoveStartPoint) {
         var dxMove = movePoint.x - this.lassoMoveStartPoint.x;
         var dyMove = movePoint.y - this.lassoMoveStartPoint.y;
         var source = this.appState.cache.source;
         var movedPoints = [];
         for (var m = 0; m < this.lassoMoveOriginalPoints.length; ++m)
            movedPoints.push({
               x: aceClamp(this.lassoMoveOriginalPoints[m].x + dxMove, 0, source.width - 1),
               y: aceClamp(this.lassoMoveOriginalPoints[m].y + dyMove, 0, source.height - 1)
            });
         this.appState.lassoPoints = movedPoints;
      }
      this.refreshPreviewStatus(this.describeLoadedSource(), "Moving selection");
      this.updatePreviewCursor(true);
      this.updatePreviewThrottled("lastLassoMovePreviewUpdateMs", 40);
      return;
   }
   if (this.lassoDrawing) {
      var sourcePoint = this.sourcePointFromPreview(x, y);
      if (sourcePoint) {
         var last = this.lassoDrawPoints.length ? this.lassoDrawPoints[this.lassoDrawPoints.length - 1] : null;
         var minDistance = 2.0;
         if (!last || Math.sqrt((sourcePoint.x - last.x) * (sourcePoint.x - last.x) + (sourcePoint.y - last.y) * (sourcePoint.y - last.y)) >= minDistance)
            this.lassoDrawPoints.push(sourcePoint);
      }
      this.updatePreviewCursor();
      if (this.preview)
         this.preview.update();
      return;
   }
   if (!this.previewMouseDown)
      return;
   var dx = x - this.previewDragStartX;
   var dy = y - this.previewDragStartY;
   var moved = Math.sqrt(dx * dx + dy * dy);
   var startedDragging = false;
   if (!this.previewDragging && this.previewCanPanFromPress && moved > this.previewMoveThreshold) {
      this.previewDragging = true;
      startedDragging = true;
      this.previewCompareArmed = false;
      if (this.previewHoldTimer)
         this.previewHoldTimer.stop();
      if (this.previewMomentaryBefore)
         this.endMomentaryBefore();
   }
   if (!this.previewDragging)
      return;
   this.clearCommittedDetailPreview();
   this.appState.preview.zoomMode = this.appState.preview.zoomMode === "fit" ? "manual" : this.appState.preview.zoomMode;
   this.appState.preview.panX = this.previewPanStartX + dx;
   this.appState.preview.panY = this.previewPanStartY + dy;
   this.previewLastMouseX = x;
   this.previewLastMouseY = y;
   this.clampPan();
   if (startedDragging)
      this.invalidateDetailForNavigation();
   this.detailPreviewPendingNavigation = this.shouldUseDetailPreview();
   this.detailPreviewPendingAdjustment = false;
   var navStatus = this.lassoDragOperation === "panning" ? "Panning selection view" : "Panning image";
   if (this.shouldUseDetailPreview())
      navStatus = "Draft while panning | release for detail";
   this.refreshPreviewStatus(this.describeLoadedSource(), navStatus);
   this.preview.update();
};

AstroContrastEnhancerDialog.prototype.handlePreviewMouseRelease = function(x, y) {
   if (this.outputRendering)
      return;
   if (this.previewHoldTimer)
      this.previewHoldTimer.stop();
   if (this.lassoDrawing) {
      var releasePoint = this.sourcePointFromPreview(x, y);
      if (releasePoint)
         this.lassoDrawPoints.push(releasePoint);
      this.lassoDrawing = false;
      this.lassoDragOperation = "none";
      this.previewMouseDown = false;
      if (this.lassoDrawPoints.length >= 3) {
         var finalized = aceFinalizeLassoPoints(this.lassoDrawPoints);
         if (aceLassoGeometryInfo(finalized).valid) {
            this.beginLassoGeometryTransition("draw");
            this.appState.lassoPoints = finalized;
            this.localSelectionNewActive = true;
            this.markLassoGeometryDirty();
            this.refreshLocalSelectionControls();
            this.clearPreviewGestureBitmap();
            this.scheduleLassoChanged("Lasso: active", this.appState.preview.zoomMode === "fit");
         } else {
            this.lassoDrawPoints = [];
            this.refreshPreviewStatus(this.describeLoadedSource(), "Selection too small");
         }
      } else {
         this.lassoDrawPoints = [];
         this.refreshPreviewStatus(this.describeLoadedSource(), "Selection too small");
      }
      this.lassoDrawPoints = [];
      this.clearPreviewGestureBitmap();
      this.updatePreviewCursor();
      return;
   }
   if (this.lassoMoving) {
      this.lassoMoving = false;
      this.lassoDragOperation = "none";
      this.previewMouseDown = false;
      this.lassoMoveStartPoint = null;
      this.lassoMoveOriginalPoints = [];
      if (!this.selectionTransitionBusy)
         this.beginLassoGeometryTransition("move");
      this.markLassoGeometryDirty();
      this.clearPreviewGestureBitmap();
      this.refreshPreviewStatus(this.describeLoadedSource(), "Lasso moved | updating selection...");
      this.scheduleLassoChanged("Lasso: moved");
      this.updatePreviewCursor();
      return;
   }
   var wasDragging = this.previewDragging;
   var wasMomentary = this.previewMomentaryBefore;
   this.previewMouseDown = false;
   this.previewDragging = false;
   this.previewCompareArmed = false;
   this.lassoDragOperation = "none";
   this.clearPreviewGestureBitmap();
   this.updatePreviewCursor();
   if (wasMomentary) {
      this.endMomentaryBefore();
      return;
   }
   if (!wasDragging)
      return;
   this.detailPreviewPendingNavigation = this.shouldUseDetailPreview();
   this.detailPreviewPendingAdjustment = false;
   this.scheduleDetailPreviewRefresh();
   if (this.lowZoomLoupeShouldBeActive()) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "Preview: draft | detail loupe queued");
      this.scheduleLowZoomLoupeRefresh("Preview: draft | detail loupe queued");
   } else {
      this.clearLowZoomLoupe();
      this.refreshPreviewStatus(this.describeLoadedSource(), this.shouldUseDetailPreview() ? "Draft shown | detail queued" : "Preview: draft");
   }
   this.preview.update();
};

AstroContrastEnhancerDialog.prototype.handlePreviewMouseWheel = function(x, y, delta) {
   if (this.outputRendering)
      return;
   this.refreshPreviewStatus(this.describeLoadedSource(), "Trackpad zoom disabled; use - / + / Fit");
};

AstroContrastEnhancerDialog.prototype.suppressProtectedOverlayBriefly = function() {
   this.overlaySuppressedUntilMs = Date.now() + 4000;
   this.invalidateProtectedOverlay();
   if (this.overlayRestoreTimer) {
      this.overlayRestoreTimer.stop();
      this.overlayRestoreTimer.interval = 4.0;
      this.overlayRestoreTimer.start();
   }
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.handlePreviewKeyPress = function(key, modifiers) {
   if (this.outputRendering)
      return false;
   if (this.isLowZoomLoupeShiftEvent(key, modifiers)) {
      this.setLowZoomLoupeShiftDown(true);
      if (key === Key_Shift)
         return true;
   }
   if (this.isLowZoomLoupeToggleKey(key, modifiers))
      return this.toggleLowZoomLoupeBeforeAfter();
   if (aceIsBeforeAfterShortcut(key, modifiers)) {
      if (!this.beforeAfterShortcutDown) {
         this.beforeAfterShortcutDown = true;
         this.setBeforeAfter(true);
         this.refreshPreviewStatus(this.describeLoadedSource(), "Before");
      }
      return true;
   }
   return false;
};

AstroContrastEnhancerDialog.prototype.handlePreviewKeyRelease = function(key, modifiers) {
   if (this.outputRendering)
      return false;
   if (key === Key_Shift || (modifiers & KeyModifier_Shift) === 0)
      this.setLowZoomLoupeShiftDown(false);
   if (aceIsBeforeAfterShortcut(key, modifiers) || key === Key_C || key === 0x43 || key === 0x63) {
      if (this.beforeAfterShortcutDown) {
         this.beforeAfterShortcutDown = false;
         this.setBeforeAfter(false);
         this.refreshPreviewStatus(this.describeLoadedSource(), "After");
      }
      return true;
   }
   return false;
};

AstroContrastEnhancerDialog.prototype.toggleBeforeAfter = function() {
   var showBefore = !this.appState.preview.showBefore;
   this.beforeAfterComparisonActive = true;
   if (showBefore) {
      this.ensureDetailPreviewForBeforeAfter();
      this.prepareDetailBeforeBitmap();
   }
   if (!showBefore)
      this.suppressProtectedOverlayBriefly();
   this.appState.preview.showBefore = showBefore;
   this.beforeAfterPill.setActive(this.appState.preview.showBefore);
   this.refreshPreviewStatus(this.describeLoadedSource(), this.appState.preview.showBefore ? "Before" : "After");
   aceRefreshNow(this.preview);
};

AstroContrastEnhancerDialog.prototype.setBeforeAfter = function(showBefore) {
   showBefore = !!showBefore;
   this.beforeAfterComparisonActive = true;
   if (showBefore) {
      this.ensureDetailPreviewForBeforeAfter();
      this.prepareDetailBeforeBitmap();
   }
   if (!showBefore)
      this.suppressProtectedOverlayBriefly();
   this.appState.preview.showBefore = showBefore;
   this.beforeAfterPill.setActive(this.appState.preview.showBefore);
   this.refreshPreviewStatus(this.describeLoadedSource(), this.appState.preview.showBefore ? "Before" : "After");
   aceRefreshNow(this.preview);
};

AstroContrastEnhancerDialog.prototype.beginMomentaryBefore = function() {
   if (this.previewMomentaryBefore || this.appState.preview.showMask || this.appState.preview.viewMode !== "preview")
      return;
   this.previewMomentaryBefore = true;
   this.setBeforeAfter(true);
   this.refreshPreviewStatus(this.describeLoadedSource(), "Before");
   aceRefreshNow(this.preview);
};

AstroContrastEnhancerDialog.prototype.endMomentaryBefore = function() {
   if (!this.previewMomentaryBefore && !this.appState.preview.showBefore)
      return;
   this.previewMomentaryBefore = false;
   this.setBeforeAfter(false);
};

AstroContrastEnhancerDialog.prototype.queueInteractivePreview = function(label, statusText, invalidateAdvanced) {
   this.bumpDetailRefreshGeneration();
   this.pendingInteractivePreviewLabel = label || "Preview";
   this.pendingInteractivePreviewStatus = statusText || (this.pendingInteractivePreviewLabel + " updated");
   this.pendingInteractivePreviewInvalidateAdvanced = this.pendingInteractivePreviewInvalidateAdvanced || !!invalidateAdvanced;
   this.invalidateProtectedOverlay();
   if (this.currentViewNeedsScaleMaps())
      this.markScaleMapRebuildPending(this.pendingInteractivePreviewLabel);
   this.refreshPreviewStatus(this.describeLoadedSource(), this.pendingInteractivePreviewLabel + " adjusting");
   if (this.preview)
      this.preview.update();
   if (this.interactivePreviewTimer) {
      this.interactivePreviewTimer.stop();
      this.interactivePreviewTimer.start();
   } else {
      this.performQueuedInteractivePreview();
   }
};

AstroContrastEnhancerDialog.prototype.performQueuedInteractivePreview = function() {
   if (this.outputRendering || this.targetImageLoading)
      return;
   if (this.selectionTransitionBusy || this.lassoDrawing || this.lassoMoving || this.pendingLassoStatusText)
      return;
   if (!this.appState.cache.draft || !this.appState.cache.draft.rgb)
      return;
   var label = this.pendingInteractivePreviewLabel || "Preview";
   var statusText = this.pendingInteractivePreviewStatus || (label + " updated");
   var invalidateAdvanced = !!this.pendingInteractivePreviewInvalidateAdvanced;
   this.pendingInteractivePreviewLabel = "";
   this.pendingInteractivePreviewStatus = "";
   this.pendingInteractivePreviewInvalidateAdvanced = false;
   var advancedMapOnly = invalidateAdvanced && this.currentViewNeedsScaleMaps() && this.appState.preview.viewMode !== "delta";
   if (invalidateAdvanced)
      this.invalidateAdvancedCaches();
   else
      this.invalidateScaleMapBitmaps();
   if (this.processingMode !== "lasso" && !this.shouldUseDetailPreview() && !(this.scaleMapRebuildPending && this.currentViewNeedsScaleMaps()))
      this.appState.cache.detail = null;
   this.invalidateProtectedOverlay();
   this.interactiveSliderDrag = true;
   this.setPendingPreviewStage("Previewing " + label + " | draft layers...");
   this.rebuildProcessedDraftPreview();
   if (this.currentViewNeedsScaleMaps())
      this.forceCurrentScaleMapBuild("interactive-slider");
   if (this.processingMode === "lasso" && this.appState.params.hasEffect() && !this.localLassoDraftEditReady())
      this.reportLocalLassoDraftFailure(label);
   else if (this.localLassoDraftEditReady())
      this.refreshCompletedLocalDraftDisplay(label);
   this.interactiveSliderDrag = false;
   var skipLocalDetail = this.shouldSkipDetailPreviewForLocalEdit();
   if (skipLocalDetail) {
      this.appState.cache.detail = null;
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      if (this.detailAdjustmentIdleTimer)
         this.detailAdjustmentIdleTimer.stop();
   }
   if (this.shouldUseDetailPreview() && !advancedMapOnly && !skipLocalDetail) {
      this.detailPreviewPendingAdjustment = false;
      statusText = this.appState.cache.detail ? label + " adjusted | release for detail" : label + " draft updated | release for detail";
   }
   this.previewFirstAdjustmentDone = true;
   this.previewWarmupDone = true;
   this.lastInteractivePreviewMs = Date.now();
   if (this.appState.preview.viewMode && this.appState.preview.viewMode !== "preview")
      statusText = this.viewModeStatusText(this.appState.preview.viewMode);
   this.refreshPreviewStatus(this.describeLoadedSource(), statusText);
   if (this.lowZoomLoupeShouldBeActive())
      this.scheduleLowZoomLoupeRefresh(label + " updated | detail loupe queued");
   else if (this.processingMode === "full")
      this.clearLowZoomLoupe();
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.toggleMaskView = function() {
   this.setViewMode(this.appState.preview.viewMode === "allowed" ? "preview" : "allowed");
};

AstroContrastEnhancerDialog.prototype.handleEffectParameterChange = function(name, value, isDragging) {
   if (this.outputRendering)
      return;
   if (this.lassoDrawing || this.lassoMoving) {
      this.refreshPreviewStatus(this.describeLoadedSource(), "Finish selection move before adjusting");
      return;
   }
   if (this.detailWorkActive) {
      if (!this.deferredEffectChangesDuringDetail)
         this.deferredEffectChangesDuringDetail = [];
      this.deferredEffectChangesDuringDetail.push({
         name: name,
         value: value,
         isDragging: !!isDragging
      });
      this.bumpEditGeneration();
      this.stopPendingDetailRefreshes();
      this.detailRefreshTimerToken = null;
      this.detailAdjustmentTimerToken = null;
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      this.refreshPreviewStatus(this.describeLoadedSource(), this.effectLabelForName(name) + " queued until detail finishes");
      return;
   }
   this.exitBeforeAfterForEditChange();
   this.absorbPendingLassoBeforeEffectChange();
   this.bumpEditGeneration();
   if (this.processingMode !== "lasso" && this.hasLassoSelection())
      this.setProcessingMode("lasso");
   this.appState.params[name] = value;
   if (this.enhancementControlBay)
      this.enhancementControlBay.update();
   if (this.processingMode === "full") {
      this.appState.globalParams = aceCopyParams(this.appState.params);
      this.appState.globalAdvanced = aceCopyAdvancedParams(this.appState.advanced);
      this.appState.fullResolutionCache = null;
      this.appState.fullResolutionCacheKey = "";
   }
   if (this.processingMode === "lasso" || this.processingMode === "full")
      this.lastLocalAction = "";
   if (this.commitButton)
      this.commitButton.setActive(false);
   if (!this.appState.cache.draft || !this.appState.cache.draft.rgb) {
      this.refreshPreviewStatus("No active image", "Open an image and select its view.");
      return;
   }
   var label = this.effectLabelForName(name);
   var interactive = !!isDragging;
   var firstAdjustment = !this.previewFirstAdjustmentDone;
   if (firstAdjustment && this.previewWarmupTimer)
      this.previewWarmupTimer.stop();
   if (value !== 0 && this.detailRefreshTimer)
      this.detailRefreshTimer.stop();
   if (value !== 0 && this.detailAdjustmentIdleTimer)
      this.detailAdjustmentIdleTimer.stop();
   var activeLocalSliderChange = this.processingMode === "lasso" && this.hasLassoSelection();
   if (activeLocalSliderChange) {
      this.appState.cache.detail = null;
      // Keep the hidden compute target so slider-only local recomputes can reuse
      // the same native crop, layer cache, and star-protection maps.
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      this.invalidateProtectedOverlay();
   }
   if (interactive) {
      this.lastInteractivePreviewName = name;
      this.lastInteractivePreviewValue = value;
      if (this.processingMode !== "lasso" && !this.shouldUseDetailPreview() && !this.currentViewNeedsScaleMaps())
         this.appState.cache.detail = null;
      if (!this.shouldUseDetailPreview()) {
         this.detailPreviewPendingAdjustment = false;
         if (this.detailAdjustmentIdleTimer)
            this.detailAdjustmentIdleTimer.stop();
      }
      this.queueInteractivePreview(label, label + " updated");
      return;
   }
   if (this.interactivePreviewTimer)
      this.interactivePreviewTimer.stop();
   if (this.detailAdjustmentIdleTimer)
      this.detailAdjustmentIdleTimer.stop();
   this.bumpDetailRefreshGeneration();
   this.pendingInteractivePreviewLabel = "";
   this.pendingInteractivePreviewStatus = "";
   this.pendingInteractivePreviewInvalidateAdvanced = false;
   this.invalidateProtectedOverlay();
   this.detailPreviewPendingAdjustment = this.shouldUseDetailPreview();
   this.invalidateScaleMapBitmaps();
   this.interactiveSliderDrag = false;
   if (!this.appState.params.hasEffect()) {
      this.setPendingPreviewStage(label + " cleared | resetting local preview...");
      this.clearLowZoomLoupe();
      if (this.processingMode === "lasso")
         this.clearPendingLocalPreview(true);
      else
         this.clearDetailPreviewState();
      this.rebuildProcessedDraftPreview();
      if (this.shouldUseDetailPreview()) {
         this.detailPreviewPendingNavigation = true;
         if (activeLocalSliderChange)
            this.scheduleDetailPreviewRefresh();
         else
            this.refreshDetailPreviewIfNeeded(true);
      }
      this.previewFirstAdjustmentDone = false;
      this.previewWarmupDone = true;
      this.lastInteractivePreviewName = name;
      this.lastInteractivePreviewValue = value;
      var clearedTier = this.shouldUseDetailPreview() && this.appState.cache.detail ? "detail crop" : "draft";
      this.refreshPreviewStatus(this.describeLoadedSource(), label + " cleared | " + clearedTier);
      if (this.preview)
         this.preview.update();
      return;
   }
   this.setPendingPreviewStage(firstAdjustment ? "First " + label + " preview | building draft layers..." : "Processing " + label + " | draft layers...");
   this.lastInteractivePreviewMs = Date.now();
   if (this.processingMode !== "lasso" && !this.shouldUseDetailPreview())
      this.appState.cache.detail = null;
   var canReuseInteractiveDraft =
      this.processingMode === "lasso" &&
      this.appState.cache.pendingActive &&
      this.appState.cache.pendingRgb &&
      this.lastInteractivePreviewName === name &&
      this.lastInteractivePreviewValue === value;
   if (!canReuseInteractiveDraft)
      this.rebuildProcessedDraftPreview();
   if (this.currentViewNeedsScaleMaps())
      this.forceCurrentScaleMapBuild("slider");
   if (this.processingMode === "lasso" && this.appState.params.hasEffect() && !this.localLassoDraftEditReady())
      this.reportLocalLassoDraftFailure(label);
   else if (this.localLassoDraftEditReady())
      this.refreshCompletedLocalDraftDisplay(label);
   this.interactiveSliderDrag = false;
   var skipLocalDetail = this.shouldSkipDetailPreviewForLocalEdit();
   if (skipLocalDetail) {
      this.appState.cache.detail = null;
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
      if (this.detailAdjustmentIdleTimer)
         this.detailAdjustmentIdleTimer.stop();
   }
   var detailAlreadyCurrent = activeLocalSliderChange ? false : this.detailProcessedStateIsCurrent();
   if (this.shouldUseDetailPreview() && !skipLocalDetail && !detailAlreadyCurrent) {
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = true;
      this.setPendingPreviewStage(label + " draft ready | detail queued");
      this.schedulePendingDetailAdjustmentRefresh();
   } else if (detailAlreadyCurrent) {
      this.detailPreviewPendingNavigation = false;
      this.detailPreviewPendingAdjustment = false;
   } else {
      this.detailPreviewPendingAdjustment = false;
   }
   this.previewFirstAdjustmentDone = true;
   this.previewWarmupDone = true;
   this.lastInteractivePreviewName = name;
   this.lastInteractivePreviewValue = value;
   var tier = this.shouldUseDetailPreview() && this.appState.cache.detail ? "detail crop" : "draft";
   if (this.detailPreviewPendingAdjustment)
      tier = "draft | detail pending";
   var loupeQueued = this.lowZoomLoupeShouldBeActive();
   var loupeAvailable = this.lowZoomLoupeIsAvailable();
   var lowZoomHint = loupeQueued ? " | detail loupe queued" :
      (!this.shouldUseDetailPreview() && this.appState.preview.viewMode === "preview" ?
         (loupeAvailable ? " | draft; hold Shift for native loupe" : " | draft only; zoom to 200% for native detail") : "");
   var status = this.appState.preview.viewMode && this.appState.preview.viewMode !== "preview" ?
      this.viewModeStatusText(this.appState.preview.viewMode) :
      label + " updated | " + tier + lowZoomHint;
   this.refreshPreviewStatus(this.describeLoadedSource(), status);
   if (loupeQueued)
      this.scheduleLowZoomLoupeRefresh(label + " updated | detail loupe queued");
   else if (this.processingMode === "full")
      this.clearLowZoomLoupe();
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.setInputType = function(type) {
   if (this.outputRendering)
      return;
   var nextType = type === "stars" ? "stars" : "starless";
   if (this.inputType === nextType && this.starlessRadio.checked === (nextType === "starless") && this.starsPresentRadio.checked === (nextType === "stars"))
      return;
   this.inputType = nextType;
   this.starlessRadio.checked = this.inputType === "starless";
   this.starsPresentRadio.checked = this.inputType === "stars";
   this.refreshImageTypeReadout();
   if (this.inputType === "stars" && this.starProtectionDesired === undefined)
      this.starProtectionDesired = true;
   this.syncProtectionFamilyControls();
   this.handleProtectionChange();
};

AstroContrastEnhancerDialog.prototype.handleProtectionChange = function() {
   if (this.outputRendering)
      return;
   this.syncProtectionFamilyControls();
   if (this.processingMode === "full" && this.appState)
      this.appState.globalProtection = aceCopyProtectionOptions(this.getProtectionOptions());
   if (this.processingMode === "full" && this.appState) {
      this.appState.fullResolutionCache = null;
      this.appState.fullResolutionCacheKey = "";
   }
   if (this.appState && this.appState.cache) {
      this.appState.cache.maskBitmap = null;
      this.appState.cache.starMaskBitmap = null;
      this.appState.cache.allowedMaskBitmap = null;
      this.appState.cache.mapBitmaps = null;
      this.appState.cache.detail = null;
      if (this.detailRefreshTimer)
         this.detailRefreshTimer.stop();
      if (this.appState.cache.draft) {
         this.appState.cache.draft.mapBitmaps = null;
         this.appState.cache.draft.maskBitmap = null;
         this.appState.cache.draft.starMaskBitmap = null;
         this.appState.cache.draft.allowedMaskBitmap = null;
         this.appState.cache.draft.starProtectionMaps = null;
         this.appState.cache.draft.starProtectionKey = "";
      }
   }
   this.refreshRightPanelContext();
   this.refreshAdvancedUi();
   this.refreshPreviewStatus(this.describeLoadedSource(), "Updating protection...");
   aceRefreshNow(this.backgroundProtection);
   aceRefreshNow(this.starProtection);
   aceRefreshNow(this.protectSky);
   aceRefreshNow(this.preventDark);
   aceRefreshNow(this.protectStars);
   aceRefreshNow(this.protectHalos);
   aceRefreshNow(this.footerLeft);
   aceRefreshNow(this.footerRight);
   if (this.protectionRefreshTimer) {
      this.protectionRefreshTimer.stop();
      this.protectionRefreshTimer.start();
      return;
   }
   this.performProtectionRebuild();
};

AstroContrastEnhancerDialog.prototype.performProtectionRebuild = function() {
   this.rebuildProcessedPreviews(this.protectionSummaryText());
   this.refreshPreviewStatus(this.describeLoadedSource(), this.viewModeStatusText(this.appState.preview.viewMode));
   if (this.preview)
      this.preview.update();
};

AstroContrastEnhancerDialog.prototype.getStarProtectionActive = function() {
   return this.inputType === "stars" && this.protectStars && this.protectStars.checked;
};

AstroContrastEnhancerDialog.prototype.refreshHeaderProtection = function() {
   this.refreshRightPanelContext();
};

try {
   if (!aceStartupHasRgbImage())
      throw new Error("__ACE_NO_STARTUP_RGB_IMAGE__");
   var aceDialog = new AstroContrastEnhancerDialog;
   aceDialog.showWorkspaceWarningIfNeeded();
   aceLogDisplayDiagnostics(aceDialog, !!aceDialog.displayWarningShown);
   aceDialog.execute();
} catch (error) {
   if (error && error.message === "__ACE_NO_STARTUP_RGB_IMAGE__") {
      aceReportStartupImageUnavailable();
   } else {
      var message = "Unexpected Astro Contrast Enhancer UI shell failure: " + (error && error.message ? error.message : String(error));
      console.criticalln(message);
      aceMessage(message, ACE_TOOL_NAME + " " + ACE_VERSION, StdIcon_Error);
   }
}
